package com.dipl.evin2.util;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.controller.BookingsController.BookingsByFilterPayload;
import com.dipl.evin2.controller.StoreController.TxnPayload;
import com.dipl.evin2.entity.Pranth;
import com.dipl.evin2.entity.SystemConfiguration;
import com.dipl.evin2.entity.UserBadge;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.model.ExportTxnModel;
import com.dipl.evin2.repository.UserBadgeRepository;
import com.dipl.evin2.service.ExportBookingService;
import com.dipl.evin2.service.ExportTransactionService;
import com.dipl.evin2.service.PranthService;
import com.dipl.evin2.service.SystemConfigurationService;
import com.dipl.evin2.service.UsersService;
import com.fasterxml.jackson.databind.node.ArrayNode;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class EvinTaskScheduler {

	private static final String GROUP_OF_USERS = "group_of_users";

	private static final String GROUP_OF_USER_TAGS = "group_of_user_tags";

	private static final String EVERYDAY_HOURS = "everyday_hours";

	@Autowired
	private TaskScheduler taskScheduler;

	@Autowired
	private ExportTransactionService exportTransactionService;
	
	@Autowired
	private ExportBookingService exportBookingService;

	@Autowired
	private UserBadgeRepository userBadgeRepository;

	@Autowired
	private UsersService usersService;

	@Autowired
	private SystemConfigurationService systemConfigurationService;

	@Autowired
	private PranthService pranthService;

	@Scheduled(cron = "0 0 0 ? * *")
	public void addPranthSchedules() throws CustomException {
		List<Pranth> pranths = pranthService.getAll();
		for (Pranth pranth : pranths) {
			addTransactionExportSchedules(pranth);
			addIndentExportSchedules(pranth);
		}
	}

	private void addTransactionExportSchedules(Pranth pranth) {
		try {
			SystemConfiguration systemConfiguration = systemConfigurationService.getByConfigutationType(Constants.USER_BADGE_TYPE, pranth.getId());
			List<String> times = new ArrayList<>();
			if(systemConfiguration != null && systemConfiguration.getConfigJson().findValue(EVERYDAY_HOURS) != null) {
				ArrayNode arrayNode = (ArrayNode) systemConfiguration.getConfigJson().findValue(EVERYDAY_HOURS);
				arrayNode.forEach(time -> times.add(time.asText()));
			}
			if(systemConfiguration != null && !times.isEmpty()) {
				for (int i = 0; i < times.size(); i++) {
					List<Integer> badgeIds = new ArrayList<>();
					if(systemConfiguration.getConfigJson().findValue(GROUP_OF_USER_TAGS) != null) {
						ArrayNode arrayNode = (ArrayNode) systemConfiguration.getConfigJson().findValue(GROUP_OF_USER_TAGS);
						arrayNode.forEach(tagId -> badgeIds.add(tagId.asInt()));
					}
					Set<Long> userIds = new HashSet<>();
					if(systemConfiguration.getConfigJson().findValue(GROUP_OF_USERS) != null) {
						ArrayNode arrayNode = (ArrayNode) systemConfiguration.getConfigJson().findValue(GROUP_OF_USERS);
						arrayNode.forEach(userId -> userIds.add(userId.asLong()));
					}
					List<UserBadge> userBadges = userBadgeRepository.findAllByBadgeId(badgeIds);
					userIds.addAll(userBadges.stream().map(UserBadge::getUserId).collect(Collectors.toList()));
					List<Users> users = usersService.findAllByUserIds(new ArrayList<>(userIds));
					Pageable pageable = PageRequest.of(0, Integer.MAX_VALUE);
					String[] timeSplitArray = times.get(i).split(":");
					LocalDateTime now = LocalDateTime.now();
					LocalDateTime localDateTime = LocalDateTime.of(now.getYear(), now.getMonth().getValue(), now.getDayOfMonth(), Integer.parseInt(timeSplitArray[0]), Integer.parseInt(timeSplitArray[1]));
					Runnable task = new Runnable() {
						@Override
						public void run() {
							users.forEach(users -> {
								LocalDate today = LocalDate.now();
								Date startDate = Date.from(today.atStartOfDay(ZoneId.systemDefault()).toInstant());
								ExportTxnModel transactionsPayload = ExportTxnModel.builder().pranthId(pranth.getId()).txnsFromDate(startDate).txnsToDate(new Date()).isActualTxn(false).build();
								try {
									exportTransactionService.getTransactionService(transactionsPayload, pranth.getId(), users.getId(), users.getUserId(), users.getEmail(), null);
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								
							});
						}
					};
					taskScheduler.schedule(task, new Date(localDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()));
				}
			}
		}catch (Exception e) {
			log.error("Error while creating schedular job for system configuration for pranth with id {} and name {} : ", pranth.getId(), pranth.getName(), e);
		}
	}
	
	private void addIndentExportSchedules(Pranth pranth) {
		try {
			SystemConfiguration systemConfiguration = systemConfigurationService.getByConfigutationType(Constants.ORDER_BADGE_TYPE, pranth.getId());
			List<String> times = new ArrayList<>();
			if(systemConfiguration != null && systemConfiguration.getConfigJson().findValue(EVERYDAY_HOURS) != null) {
				ArrayNode arrayNode = (ArrayNode) systemConfiguration.getConfigJson().findValue(EVERYDAY_HOURS);
				arrayNode.forEach(time -> times.add(time.asText()));
			}
			if(systemConfiguration != null && !times.isEmpty()) {
				for (int i = 0; i < times.size(); i++) {
					List<Integer> badgeIds = new ArrayList<>();
					if(systemConfiguration.getConfigJson().findValue(GROUP_OF_USER_TAGS) != null) {
						ArrayNode arrayNode = (ArrayNode) systemConfiguration.getConfigJson().findValue(GROUP_OF_USER_TAGS);
						arrayNode.forEach(tagId -> badgeIds.add(tagId.asInt()));
					}
					Set<Long> userIds = new HashSet<>();
					if(systemConfiguration.getConfigJson().findValue(GROUP_OF_USERS) != null) {
						ArrayNode arrayNode = (ArrayNode) systemConfiguration.getConfigJson().findValue(GROUP_OF_USERS);
						arrayNode.forEach(userId -> userIds.add(userId.asLong()));
					}
					List<UserBadge> userBadges = userBadgeRepository.findAllByBadgeId(badgeIds);
					userIds.addAll(userBadges.stream().map(UserBadge::getUserId).collect(Collectors.toList()));
					List<Users> users = usersService.findAllByUserIds(new ArrayList<>(userIds));
					//Pageable pageable = PageRequest.of(0, Integer.MAX_VALUE);
					String[] timeSplitArray = times.get(i).split(":");
					LocalDateTime now = LocalDateTime.now();
					LocalDateTime localDateTime = LocalDateTime.of(now.getYear(), now.getMonth().getValue(), now.getDayOfMonth(), Integer.parseInt(timeSplitArray[0]), Integer.parseInt(timeSplitArray[1]));
					Runnable task = new Runnable() {
						@Override
						public void run() {
							users.forEach(users -> {
								LocalDate today = LocalDate.now();
								Date startDate = Date.from(today.atStartOfDay(ZoneId.systemDefault()).toInstant());
								BookingsByFilterPayload transactionsPayload = BookingsByFilterPayload.builder().pranthId(pranth.getId()).fromDate(startDate).toDate(new Date()).build();
								try {
									exportBookingService.getBookingService(transactionsPayload, pranth.getId(), users.getId(), users.getUserId(), users.getEmail(), null);
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								
							});
						}
					};
					taskScheduler.schedule(task, new Date(localDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()));
				}
			}
		}catch (Exception e) {
			log.error("Error while creating schedular job for system configuration for pranth with id {} and name {} : ", pranth.getId(), pranth.getName(), e);
		}
	}

}
