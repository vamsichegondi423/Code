package com.dipl.evin2.mongo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;

public class Aggregation {
    @Autowired
    private MongoTemplate mongoTemplate;
	
//Aggregation agg= new Aggregation(MatchOperation)
	}
