package com.dipl.evin2.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor	
@JsonIgnoreProperties(ignoreUnknown = true)
public class StockReportDetails {

	private String state;
	private String district;
	private Long districtId;
	private String productName;
	private String store;
	private Long totalStock;    
	private Long storeId;

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor	
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class NationalStockDetails{
		private String location;
		private NationalLocationDetails locationDetails;
		@Data
		@NoArgsConstructor
		@Builder
		@AllArgsConstructor	
		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class NationalLocationDetails{
			private String state;
			private String district;
			private String productName;
			private Long totalStock;    
		}
	}
	
	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor	
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class StateStockDetails{
		private String location;
		private StateLocationDetails locationDetails;
		@Data
		@NoArgsConstructor
		@Builder
		@AllArgsConstructor	
		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class StateLocationDetails{
			private String state;
			private String district;
			private String store;
			private String productName;
			private Long totalStock;    
		}
	}

}
