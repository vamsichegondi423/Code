package com.dipl.evin2.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class TxnWithBatchDTO {
	
	private Long transactionId;
	private String transactionType;
	private String trackingObjectType;
	private String trackingNo;
	private Long	storeId;
	private String storeName;
	private String storeBadges;
	private Long productId;
	private String productName;
	private String materialBadges;
	private Boolean isBatch_enabled;
	private Long openingStock;
	private Long closingStock;
	private String transactionReason;
	private String materialReason;
	private Date updatedOn;
	private Date actualTransactionDate;
	private Long receivingStoreId;
	private Long quantity;
	private String receivingStoreName;
	private String batchId;
	private Date expriedDate;
	private String batchManufacturerName;
	private Date manufacturedDate;
	private Long openingStockBatch;
	private Long closingStockBatch;
	private String city;
	private String countryName;
	private String  stateName;
	private String  districtName;
	private String pin;
	private Double latitude;
	private Double longitude;
	private String sourceType;
	private Long createdBy;
	private String userId;
	private String fullName;
	private Date createdOn;

}
