package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.PranthHierarchy;
import com.dipl.evin2.entity.StoreBadgeRank;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.StoreBadgeRankRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StoreBadgeRankService {

	@Autowired
	private StoreBadgeRankRepository storeBadgeRankRepository;
	
	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public StoreBadgeRank getById(Integer id) throws CustomException {
		try {
			Optional<StoreBadgeRank> storeBadgeRankOptional = storeBadgeRankRepository.getById(id);
			if (storeBadgeRankOptional.isPresent()) {
				return storeBadgeRankOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public StoreBadgeRank save(StoreBadgeRank storeBadgeRank) throws CustomException {
		try {
			if (storeBadgeRank.getId() != null && storeBadgeRank.getId() > 0) {
				Optional<StoreBadgeRank> existingStoreBadgeRankRecord = storeBadgeRankRepository.getById(storeBadgeRank.getId());
				if (existingStoreBadgeRankRecord.isPresent()) {
					return storeBadgeRankRepository.save(storeBadgeRank);
				}
			} else {
				storeBadgeRank = storeBadgeRankRepository.save(storeBadgeRank);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return storeBadgeRank;
	}

	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<StoreBadgeRank> existingStoreBadgeRankRecord = storeBadgeRankRepository.getById(id);
			if (existingStoreBadgeRankRecord.isPresent()) {
				storeBadgeRankRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<StoreBadgeRank> getAll(Long pranthId) {
		try {
			return jdbcTemplate.query("	select s.id, s.store_badge_id as storeBadgeId, s.\"rank\", s.is_deleted as isDeleted, s.created_by as createdBy, s.created_on as createdOn, s.updated_by as updatedBy, s.updated_on as updatedOn, \n"
					+ " b.\"name\" as badgeName from store_badge_rank s join badge b on b.id = s.store_badge_id where s.is_deleted = false order by s.\"rank\"", new BeanPropertyRowMapper<StoreBadgeRank>(StoreBadgeRank.class));
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public List<StoreBadgeRank> saveAll(List<StoreBadgeRank> storeBadgeRanks) {
		return storeBadgeRankRepository.saveAll(storeBadgeRanks);
	}

	public StoreBadgeRank getByStorageBadgeId(Integer storageBadgeId, Long pranthId) {
		Optional<StoreBadgeRank> storeBadgeRankOptional = storeBadgeRankRepository.getByStorageBadgeId(storageBadgeId, pranthId);
		if (storeBadgeRankOptional.isPresent()) {
			return storeBadgeRankOptional.get();
		}
		return null;
	}

}