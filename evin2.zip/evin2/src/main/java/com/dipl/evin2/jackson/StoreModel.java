package com.dipl.evin2.jackson;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class StoreModel {
	@JsonProperty("id")
	private Long id;
	@JsonProperty("name")
	private String name;
	@JsonProperty("country_id")
	private int countryId;
	@JsonProperty( "state_id")
	private int stateId;
	@JsonProperty("district_id")
	private Integer districtId;
	@JsonProperty("block_id")
	private Integer blockId;
	@JsonProperty("city")
	private String city;
	@JsonProperty("pin")
	private String pin;
	@JsonProperty("address")
	private String address;
	@JsonProperty("latitude")
	private Double latitude;
	@JsonProperty("longitude")
	private Double longitude;
	@JsonProperty( "pranth_id")
	private Long pranthId;
	@JsonProperty( "store_users")
	private List<StoreUserModel> storeUserModel;
	@JsonProperty( "store_badges")
	private List<StoreBadgeModel> storeBadgeModel;
	@JsonProperty( "user_id")
	private String userId;
	
}
