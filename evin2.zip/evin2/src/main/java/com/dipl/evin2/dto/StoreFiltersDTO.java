package com.dipl.evin2.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StoreFiltersDTO {
	private String storeName;
	private String location;
	private String tag;
	private Date lastupdated;
	private String updatedBy;
	private Long storeId;
	private Long storeCount;
}
