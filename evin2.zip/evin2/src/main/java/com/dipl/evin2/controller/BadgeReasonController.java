package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.BadgeReason;
import com.dipl.evin2.entity.MasterReason;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.service.BadgeReasonService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/badge-reason")
public class BadgeReasonController {

	@Autowired
	private BadgeReasonService badgeReasonService;

	@ApiOperation("Use this api for saving or updating BadgeReason. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody BadgeReason badgeReason, BindingResult result, @RequestParam("pranthId") Long pranthId) {
		badgeReason.setPranthId(pranthId);
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (badgeReason.getId() == null || badgeReason.getId() == 0 && badgeReason.getReasonId() != 0) {
				BadgeReason existingBadgeReason = badgeReasonService.getByBadgeIdAndReasonId(badgeReason);
				if(existingBadgeReason != null) {
					return ResponseBean.builder().data(existingBadgeReason).message("Material Reason already exists.").returnCode(1).status(HttpStatus.OK).build();
				}
			}
			if (badgeReason.getId() != null && badgeReason.getId() > 0) {
				BadgeReason existingBadgeReason = badgeReasonService.getById(badgeReason.getId());
				if (existingBadgeReason != null) {
					badgeReason = badgeReasonService.save(badgeReason);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(badgeReason);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				badgeReason = badgeReasonService.save(badgeReason);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(badgeReason);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching BadgeReason record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			BadgeReason badgeReason = badgeReasonService.getById(id);
			if (badgeReason != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(badgeReason);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting BadgeReason record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Integer id, @RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = badgeReasonService.deleteById(id,pranthId);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all BadgeReason records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<BadgeReason> badgeReasonRecords = badgeReasonService.getAll();
			if (!badgeReasonRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(badgeReasonRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching BadgeReason record by badgeid. Provide badgeid as path param.")
	@GetMapping(value = "/v1/getreasonbybadge", produces = "application/json")
	public ResponseBean getByBadgeId(@RequestParam(value = "badgeId") Long badgeId, @RequestParam("pranthId") Long pranthId,
			@RequestParam("transactionType") String transactionType) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<MasterReason> masterReasonsList = badgeReasonService.getByBadgeId(badgeId, pranthId, transactionType);
			if (!masterReasonsList.isEmpty()) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterReasonsList);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for saving or updating badge reason. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/save-or-update-list")
	@Transactional(rollbackFor = Exception.class)
	public ResponseBean saveList(@RequestBody List<BadgeReason> badgeReasons, BindingResult result, @RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message(result.getAllErrors().get(0).getDefaultMessage()).status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			badgeReasons.forEach(br -> {
				br.setPranthId(pranthId);
				br.setCreatedBy(br.getUpdatedBy());
				br.setIsDeleted(false);
				br = badgeReasonService.save(br);
			});
			log.info("Record saved successfully");
			responseBean.setMessage("Record saved successfully");
			responseBean.setData(badgeReasons);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

}