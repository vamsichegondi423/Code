package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import com.dipl.evin2.entity.NotificationEvent;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface NotificationEventRepository extends JpaRepository<NotificationEvent, Integer> {

	@Query(value = "select * from notification_event where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<NotificationEvent> getById(Integer id);

	@Query(value = "select * from notification_event where is_deleted = false", nativeQuery = true)
	public List<NotificationEvent> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from notification_event where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);
	
	@Modifying
	@Transactional
	@Query(value = "update notification_event set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

	@Query(value = "select * from notification_event where notification_event_type_id = ?1 and is_deleted = false", nativeQuery = true)
	public List<NotificationEvent> getAllByModule(Integer moduleId);

	@Query(value = "select * from notification_event where notification_event_type_id = ?1 and asset_event_type = ?2 and is_deleted = false", nativeQuery = true)
	public List<NotificationEvent> getAllByModuleAndEventType(Integer moduleId, String assetEventType);
	
}