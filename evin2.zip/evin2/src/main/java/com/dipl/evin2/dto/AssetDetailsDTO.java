package com.dipl.evin2.dto;

import java.util.Date;
import java.util.List;

import com.dipl.evin2.entity.AssetConfiguration;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssetDetailsDTO {

	private Long assetId;
	private String serialNumber;
	private Integer assetModelId;
	private String modelName;
	private Integer assetVendorId;
	private String assetVendorName;
	private Long storeId;
	private String storeName;
	private String city;
	private String districtName;
	private String stateName;
	private String country;
	private Integer assetTypeId;
	private String assetTypeName;
	private Integer statusId;
	private String assetStatus;
	private Date createdOn;
	private Long createdBy;
	private String createdByUser;
	private Date updatedOn;
	private Long updatedBy;
	private String updatedByUser;
	private Long pranthId;
	private String pranthName;
	private Double latitude;
	private Double longitude;
	private Integer yearOfManufacture;
	private Double capacity;
	@JsonIgnore
	private String sensorMonitoringPoint;
	@JsonIgnore
	private String userDetail;
	private List<SensorMonitoringPoint> sensorMonitoringPoints;
	private List<UserDetails> userDetailsList;
	private List<TemperatureLogData> temperatureLogDataList;
	private Long mappedAssetId;
	private String mappedAssetSerialNumber;
	
	private AssetConfiguration assetConfiguration;

	@Builder
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class TemperatureLogData {
		private String sensor;
		private Boolean isDefault;
		private Integer type;
		private Double temperature;
		private Integer timeInSeconds;
		@JsonProperty("tempMin")
		public Double tempLow;
		@JsonProperty("tempMax")
		public Double tempHigh;
		private Date lastUpdated;
		
	}

	@Builder
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class UserDetails {

		@JsonProperty("user_role")
		public String userRole;
		@JsonProperty("user_list")
		public List<User> userList;

		@Builder
		@Data
		@NoArgsConstructor
		@AllArgsConstructor
		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class User {

			@JsonProperty("userId")
			public String userId;
			@JsonProperty("name")
			public String name;
			@JsonProperty("mobile")
			public String mobile;

		}
	}

	@Builder
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class SensorMonitoringPoint {

		@JsonProperty("sensor")
		public String sensor;
		@JsonProperty("monitoring_point")
		public String monitoringPoint;

	}
}
