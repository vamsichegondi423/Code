package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.controller.MasterAssetVendorController.VendorJackson;
import com.dipl.evin2.controller.MasterAssetVendorController.VendorJackson.AssetVendor;
import com.dipl.evin2.entity.MasterAssetType;
import com.dipl.evin2.entity.MasterAssetVendor;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterAssetTypeRepository;
import com.dipl.evin2.repository.MasterAssetVendorRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MasterAssetVendorService {

	@Autowired
	private MasterAssetVendorRepository masterAssetVendorRepository;

	@Autowired
	private MasterAssetTypeRepository masterAssetTypeRepository;

	@Autowired
	MasterAssetTypeService masterAssetTypeService;

	@Cacheable(value = "master-asset-vendor", key = "#id")
	public MasterAssetVendor getById(Long id) {
		Optional<MasterAssetVendor> masterAssetVendorOptional = masterAssetVendorRepository.getById(id);
		if (masterAssetVendorOptional.isPresent()) {
			return masterAssetVendorOptional.get();
		}
		return null;
	}

	@CachePut(value = "master-asset-vendor", key = "#masterAssetVendor.id")
	public MasterAssetVendor save(MasterAssetVendor masterAssetVendor) {
		if (masterAssetVendor.getId() != null && masterAssetVendor.getId() > 0) {
			Optional<MasterAssetVendor> existingMasterAssetVendorRecord = masterAssetVendorRepository
					.getById(masterAssetVendor.getId());
			if (existingMasterAssetVendorRecord.isPresent()) {
				return masterAssetVendorRepository.save(masterAssetVendor);
			}
		} else {
			masterAssetVendor = masterAssetVendorRepository.save(masterAssetVendor);
		}
		return masterAssetVendor;
	}

	public List<MasterAssetVendor> saveList(VendorJackson vendorJacksonList) throws CustomException {
		List<MasterAssetVendor> vendorLists = null;
		try {
			Map<Long, MasterAssetType> allMasterAssetTypeMap = masterAssetTypeService.getAll().stream().collect(Collectors.toMap(MasterAssetType::getId, MasterAssetType -> MasterAssetType));
			vendorLists =  new ArrayList<>();
			for(AssetVendor mv :vendorJacksonList.getVendorList()){
				if (mv.getId() != null && mv.getId() > 0) {
					Optional<MasterAssetVendor> existingMasterAssetVendorRecord = masterAssetVendorRepository
							.getById(mv.getId());
					if (existingMasterAssetVendorRecord.isPresent()) {
						existingMasterAssetVendorRecord.get().setIsActive(mv.getIsActive());
						existingMasterAssetVendorRecord.get().setUpdatedBy(vendorJacksonList.getUpdatedBy());
						vendorLists.add(existingMasterAssetVendorRecord.get());
					}
				} 
			}
			vendorLists = masterAssetVendorRepository.saveAll(vendorLists);
			MasterAssetType masterAssetType = allMasterAssetTypeMap.get(vendorJacksonList.getAssetTypeId());
			masterAssetType.setDefaultMonitoringPoint(vendorJacksonList.getDefaultMonitoringPoint());
			masterAssetType.setUpdatedBy(vendorJacksonList.getUpdatedBy());
			masterAssetType.setUpdatedOn(new Date());
			masterAssetTypeRepository.save(masterAssetType);
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException(e.toString(), HttpStatus.OK);
		}
		return vendorLists;
	}

	@CacheEvict(value = "master-asset-vendor", allEntries = true)
	public Integer deleteById(Long id) {
		Optional<MasterAssetVendor> existingMasterAssetVendorRecord = masterAssetVendorRepository.getById(id);
		if (existingMasterAssetVendorRecord.isPresent()) {
			masterAssetVendorRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	@Cacheable(value = "master-asset-vendor")
	public List<MasterAssetVendor> getAll() {
		return masterAssetVendorRepository.findAll();
	}

	public MasterAssetVendor getByName(String name) {
		Optional<MasterAssetVendor> masterAssetVendorOptional = masterAssetVendorRepository.getByName(name);
		if (masterAssetVendorOptional.isPresent()) {
			return masterAssetVendorOptional.get();
		} else {
			return null;
		}
	}

	public List<MasterAssetVendor> saveAll(List<MasterAssetVendor> masterAssetVendors) {
		if (!masterAssetVendors.isEmpty()) {
			masterAssetVendors = masterAssetVendorRepository.saveAll(masterAssetVendors);
		}
		return masterAssetVendors;
	}

	@Cacheable(value = "master-asset-vendor", key = "#assetTypeid")
	public List<MasterAssetVendor> getByAssetType(Long assetTypeid) {
		return masterAssetVendorRepository.getByAssetType(assetTypeid);
	}

	@Cacheable(value = "master-asset-vendor", key = "{#assetTypeid,#isActive}")
	public List<MasterAssetVendor> getActiveVendorsByAssetType(Long assetTypeid, Boolean isActive) {
		return masterAssetVendorRepository.getActiveVendorsByAssetType(assetTypeid, isActive);
	}

}