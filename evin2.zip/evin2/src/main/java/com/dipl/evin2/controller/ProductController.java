package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.Product;
import com.dipl.evin2.jackson.ProductModel;
import com.dipl.evin2.service.ProductService;
import com.dipl.evin2.service.StoreService;
import com.dipl.evin2.util.KafkaProducer;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/product")
public class ProductController {

	@Autowired
	private ProductService productService;
	@Autowired
	private KafkaProducer kafkaProducer;
	
	@ApiOperation("Use this api for saving or updating Product. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/create-product")
	public ResponseBean save(@RequestBody ProductModel productPayload, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		Product product = new Product();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (productPayload.getId() != null && productPayload.getId() > 0) {
				Product existingProduct = productService.getById(productPayload.getId());
				if (existingProduct != null) {
					product = productService.createProduct(productPayload);
					log.info("Product updated successfully");
					responseBean.setMessage("Product updated successfully");
					responseBean.setData(product);
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setReturnCode(1);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setReturnCode(1);
				}
			} else {
				if (productPayload.getName() != null) {
					product = productService.findProductByName(productPayload.getName());
					if (product != null) {
						responseBean.setData(product);
						responseBean.setMessage("Product is already exists with the " + product.getName() + " name.");
						responseBean.setStatus(HttpStatus.OK);
						responseBean.setReturnCode(1);
					} else {
						product = productService.createProduct(productPayload);
						try {
							kafkaProducer.saveProductToKafka(product.getName(),product.getId(),product.getIsDeleted());
						} catch (JsonProcessingException e) {
							e.printStackTrace();
						}
						if (product != null) {
							log.info("Product saved successfully");
							responseBean.setMessage("Product saved successfully");
							responseBean.setData(product);
							responseBean.setStatus(HttpStatus.OK);
							responseBean.setReturnCode(1);
						} else {
							log.info("Product not saved successfully");
							responseBean.setMessage("Product not saved successfully");
							responseBean.setData(null);
							responseBean.setStatus(HttpStatus.OK);
							responseBean.setReturnCode(1);
						}
					}
				}else {
					log.error("Invalid Payload");
					responseBean.setMessage("Invalid payload");
					responseBean.setStatus(HttpStatus.BAD_REQUEST);
					responseBean.setReturnCode(0);
				}
			}
			
		} catch (Exception e) {
			log.error("Exception occured while creating product ", e.getMessage());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured while creating product" + e.getCause());
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching Product record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Product product = productService.getById(id);
			if (product != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(product);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting Product record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = productService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all Product records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Product> productRecords = productService.getAll();
			if (!productRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(productRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(null);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
	@ApiOperation("Use this api for fetching products record by product name. Provide products name as path param.")
	@GetMapping(value = "/v1/get-products-by-filter", produces = "application/json")
	public ResponseBean getProductsByFilters(@RequestParam(value = "pranth") Long pranthId, @RequestParam(required = false, value = "productName") String productName,
			@RequestParam(required = false, value = "BadgeName") String BadgeName, Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		List<ProductFilterModel> products =  new ArrayList<>();
		ProductDetails productDetails = null;
		try {
			products = productService.getProductsByFilters(pranthId, productName, BadgeName, pageable);
			Long totalRecordCount =productService.getProductCount(pranthId, productName, BadgeName);
			productDetails = ProductDetails.builder().productFilterModel(products).totalRecordCount(totalRecordCount).build();
			if (!products.isEmpty()) {
				log.error("Products fetched successfully");
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setMessage("Products fetched successfully");
				responseBean.setData(productDetails);
			} else {
				log.error("Products not found ");
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setMessage("No record found ");
				responseBean.setData(products);
			}
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured while getting products : {}", e.getCause());
			responseBean.setMessage(e.getMessage());
			responseBean.setData(null);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setReturnCode(0);
			return responseBean;
		}
		return responseBean;
	}
	

	@ApiOperation("Use this api for fetching Material record by id. Provide id as path param.")
	@GetMapping(value = "/v1/get-product-by-id", produces = "application/json")
	public ResponseBean getProductByProductId(@RequestParam(required = true, value = "productId") Long productId, Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<ProdModel> materials = productService.getProductByProductId(productId, pageable);
			responseBean.setStatus(HttpStatus.OK);
			if (materials != null && !materials.isEmpty()) {
				log.error("materials fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(materials);
			} else {
				log.error("material not found  ");
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setMessage("material not found ");
				responseBean.setData(null);
			}
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
			responseBean.setMessage(e.getMessage());
			responseBean.setData(null);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setReturnCode(0);
			return responseBean;
		}
		return responseBean;
	}
	
	 @ApiOperation("Use this api for fetch products wise consumption ")
		@GetMapping(value = "/v1/get-products-wise-min-max-cnsmpt", produces = "application/json")
		public ResponseBean getMaterialWiseMinMaxConsumption(@RequestParam(value = "store_id") Long storeId,
				@RequestParam(required = false, value = "product_id") Long productId) {
			List<MaterialWiseMinMaxDTO> fetchStoresList = null;
			try {
				fetchStoresList = productService.getProductWiseMinMaxConsumption(storeId, productId);
			} catch (Exception e) {
				log.error("Exception occured  fetch products wise consumption : {}", e);
				return ResponseBean.builder().data(null).message("Exception occured  fetch products wise consumption " +e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
						.returnCode(0).build();
			}
			if (fetchStoresList.isEmpty()) {
				return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message("No records found")
						.build();
			}
			return ResponseBean.builder().data(fetchStoresList).status(HttpStatus.OK).returnCode(1)
					.message("Records fetched successfully").build();
		}
	 
	 @ApiOperation("Use this api for fetch history of materials")
		@GetMapping(value = "/v1/get-product-history", produces = "application/json")
		public ResponseBean getHistoryOfMaterails(@RequestParam(value = "store_id") Long storeId,
				@RequestParam(required = true,value = "product_id") Long productId) {
			List<Map<String, Object>> fetchStoresList = new ArrayList<Map<String,Object>>();
			try {
				fetchStoresList = productService.getHistoryOfProducts(storeId, productId);
			} catch (Exception e) {
				log.error("Exception occured for fetch history of materials : {}", e);
				return ResponseBean.builder().data(null).message("Exception occured for fetch history of materials :" +e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
						.returnCode(0).build();
			}
			if (fetchStoresList.isEmpty()) {
				return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message("No records found")
						.build();
			}
			return ResponseBean.builder().data(fetchStoresList).status(HttpStatus.OK).returnCode(1)
					.message("Records fetched successfully").build();
		}
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class ProductFilterModel {
		private Long productId;
		private String productName;
		private String description;
		private String badge;
		private String userId;
		private String batchEnabled;
		private Date lastUpdated;
	}
	@Builder
	@Data
	public static class ProductDetails{
		private List<ProductFilterModel> productFilterModel;
		private Long totalRecordCount;
		
	}
	@JsonInclude(JsonInclude.Include.NON_NULL)
	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class ProdModel {
		private Long product_id;
		private String productName;
		private String seasonal;
		private String badge;
		private String updatedBy;
		private Date updatedOn;
		private String batchEnabled;
		private String isSeasonal;
		private String isTempSensitive;
		
	}
	
	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class MaterialWiseMinMaxDTO {
		@JsonProperty("store_id")
		private Long StoreId;
		@JsonProperty("product_id")
		private Long productId;
		@JsonProperty("min")
		private Long min;
		@JsonProperty("max")
		private Long max;
//		@JsonProperty("consumption_rate")
//		private Double consumptionRate;
		@JsonProperty("updated_on")
		private Date updatedOn;
		@JsonProperty("updated_by")
		private String updatedBy;
		
	}
}