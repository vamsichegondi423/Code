package com.dipl.evin2.dto;

import java.util.Date;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class AssetDTO {

	private Long assetId;
	private String serialNumber;
	private Integer assetModelId;
	private String modelName;
	private Integer assetVendorId;
	private String assetVendorName;
	private Integer assetTypeId;
	private String assetTypeName;
	private Integer storeId;
	private String storeName;
	private String address;
	private String city;
	private String blockName;
	private String districtName;
	private String stateName;
	private String  country;
	private int lastUpdatedById;
	private String lastUpdatedByName;
	private Date lastUpdatedOn;
	
	
	
}
