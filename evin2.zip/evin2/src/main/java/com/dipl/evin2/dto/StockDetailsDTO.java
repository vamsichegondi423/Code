package com.dipl.evin2.dto;

public interface StockDetailsDTO {
	Long getAvailableStock();

	Long getAllocatedStock();

	Long getTotalStock();
	
	Long getIntransitStock();
	
	Long getQuantity();
}
