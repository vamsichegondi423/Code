package com.dipl.evin2.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.dipl.evin2.controller.CargoController.CargoFilterModel;
import com.dipl.evin2.service.ExportShimpentService;
import com.dipl.evin2.service.StoreService;
import com.dipl.evin2.util.ResponseBean;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/cargo")
public class ExportExcelShipmentController {

	@Autowired
	private ExportShimpentService exportShipmentService;

	@Autowired
	private StoreService storeService;

	@PostMapping(value = "/v1/export-shipments")
	public ResponseBean getBookings(@RequestBody CargoFilterModel shipmentPayload,
			@RequestParam(name = "pranthId") Long pranthId, @RequestParam(name = "userId") Long userId,
			@RequestParam(name = "userName") String userName, @RequestParam(name = "email") String email,Pageable pageable) {
		try {
			List<Long> totalStoreIds = storeService.getToatalStoreIds(pranthId, userId);
			return exportShipmentService.getShipmentService(shipmentPayload,pranthId, userId, userName,
					email, totalStoreIds);
		} catch (Exception e) {
			log.error("Exception occured while fetching all Order : {}", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
	}

}