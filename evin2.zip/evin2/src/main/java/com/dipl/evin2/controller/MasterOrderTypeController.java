package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.MasterOrderType;
import com.dipl.evin2.repository.MasterOrderTypeRepository;
import com.dipl.evin2.service.CacheEvictor;
import com.dipl.evin2.service.MasterOrderTypeService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/master-order-type")
public class MasterOrderTypeController {

	@Autowired
	private MasterOrderTypeService masterOrderTypeService;
	@Autowired
	private MasterOrderTypeRepository masterOrderTypeRepository;
	
	@Autowired
	private CacheEvictor cacheEvictor;

	@ApiOperation("Use this api for saving or updating MasterOrderType. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody MasterOrderType masterOrderType, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			MasterOrderType exstngMasterOrderType = masterOrderTypeRepository.getMasterOrderType(masterOrderType.getName());
			if(exstngMasterOrderType != null) {
				log.info("Master order name " + masterOrderType.getName() + " already exist");
				responseBean.setMessage("Master order name " + masterOrderType.getName() + " already exist");
				return responseBean;
			}
			if (masterOrderType.getId() != null && masterOrderType.getId() > 0) {
				MasterOrderType existingMasterOrderType = masterOrderTypeService.getById(masterOrderType.getId());
				if (existingMasterOrderType != null) {
					masterOrderType = masterOrderTypeService.save(masterOrderType);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(masterOrderType);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				masterOrderType = masterOrderTypeService.save(masterOrderType);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(masterOrderType);
			}
			cacheEvictor.evictAllCacheValues("order-type");
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching MasterOrderType record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			MasterOrderType masterOrderType = masterOrderTypeService.getById(id);
			if (masterOrderType != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterOrderType);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting MasterOrderType record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = masterOrderTypeService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all MasterOrderType records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll(@RequestParam (required = false , value="userId") Long userId ) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<MasterOrderType> masterOrderTypeRecords = masterOrderTypeService.getAll(userId);
			if (!masterOrderTypeRecords.isEmpty()) {
				log.error("Records fethed successfully");
				responseBean.setMessage("Records fethed successfully");
				responseBean.setData(masterOrderTypeRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured while fetching master order type", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occured while fetching master order type");
		}
		return responseBean;
	}
}