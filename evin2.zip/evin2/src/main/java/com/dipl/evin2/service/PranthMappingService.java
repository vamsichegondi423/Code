package com.dipl.evin2.service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Service
public class PranthMappingService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private final List<String> mappingLevels = Arrays.asList("BLOCK", "DISTRICT", "REGION", "STATE", "NATIONAL");
	
	public PranthMappingModel getPranthMapping(Long pranthId, String mappingType) {

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("select npranth_id as nPranthId, npranth_name as nPranthName, spranth_id as sPranthId, spranth_name as sPranthName,\r\n"
				+ "	rpranth_id as rPranthId, rpanth_name as rPranthName, dpranth_id as dPranthId,\r\n"
				+ "	dpranth_name as dPranthName, bpranth_id as bPranthId, bpranth_name as bPranthName from vw_pranth_mapping\r\n"
				+ "	where ");
		if(mappingType.equalsIgnoreCase("Block")) {
			queryBuilder.append(" bpranth_id="+pranthId);
		} else if(mappingType.equalsIgnoreCase("District")) {
			queryBuilder.append(" dpranth_id="+pranthId);
		} else if(mappingType.equalsIgnoreCase("Region")) {
			queryBuilder.append(" rpranth_id="+pranthId);
		} else if(mappingType.equalsIgnoreCase("State")) {
			queryBuilder.append(" spranth_id="+pranthId);
		} else if(mappingType.equalsIgnoreCase("National")) {
			queryBuilder.append(" npranth_id="+pranthId);
		}
		queryBuilder.append(" limit 1");
		return jdbcTemplate.queryForObject(queryBuilder.toString(), new BeanPropertyRowMapper<PranthMappingModel>(PranthMappingModel.class));
	}

	public List<String> getParentMappingLevels(String childMappingLevel){
		return mappingLevels.stream().filter(m -> mappingLevels.indexOf(childMappingLevel.toUpperCase()) > mappingLevels.indexOf(m.toUpperCase())).collect(Collectors.toList());
	}
	
	public List<String> getChildMappingLevels(String parentMappingLevel){
		return mappingLevels.stream().filter(m -> mappingLevels.indexOf(parentMappingLevel.toUpperCase()) < mappingLevels.indexOf(m.toUpperCase())).collect(Collectors.toList());
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder 
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class PranthMappingModel {
		private Integer nPranthId;
		private String nPranthName;
		private Integer sPranthId;
		private String sPranthName;
		private Integer rPranthId;
		private String rPranthName;
		private Integer dPranthId;
		private String dPranthName;
		private Integer bPranthId;
		private String bPranthName;
		private String mappingType;
	}
	
}
