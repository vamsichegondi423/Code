package com.dipl.evin2.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingInvoiceModel {
	private String issuingStoreName;
	private String issuingStoreState;
	private String issuingStoreDistrict;
	private String orderNo;
	private String receievingStoreName;
	private String receievingStoreState;
	private String receievingStoreDistrict;
	private String invoiceDate;
	private String issueReference;
	private String dateOfSupply;;
	private String dateOfReceipt;
	private String receiptReference;
	private List<BookingInvoiceItems> bookingItems;
	private Parameters parameters;
	private String shipmentId;


	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	public static class BookingInvoiceItems {
		private String name;
		private String quantity;
		private String recommended;
		private String remarks;
		private List<BookingInvoiceItemBatches> bookingItemBatches;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	public static class BookingInvoiceItemBatches {
		private String batchId;
		private String manufacturer;
		private String expiryDate;
		private String quantity;
	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	public static class Parameters {
		private Integer id;
		private String fileType;
	}
}
