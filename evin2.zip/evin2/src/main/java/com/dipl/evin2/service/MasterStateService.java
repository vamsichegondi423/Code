package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterState;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.exceptions.EvinException;
import com.dipl.evin2.repository.MasterStateRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterStateService {

	@Autowired
	private MasterStateRepository masterStateRepository;

	@Cacheable(value = "state", key = "#id")
	public MasterState getById(Integer id) throws CustomException {
		try {
			Optional<MasterState> masterStateOptional = masterStateRepository.getById(id);
			if (masterStateOptional.isPresent()) {
				return masterStateOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "state", key = "#masterState.id")
	public MasterState save(MasterState masterState) throws CustomException {
		try {
			if (masterState.getId() != null && masterState.getId() > 0) {
				Optional<MasterState> existingMasterStateRecord = masterStateRepository.getById(masterState.getId());
				if (existingMasterStateRecord.isPresent()) {
					masterState = masterStateRepository.save(masterState);
				}
			} else {
				masterState = masterStateRepository.save(masterState);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterState;
	}

	@CacheEvict(value = "state", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterState> existingMasterStateRecord = masterStateRepository.getById(id);
			if (existingMasterStateRecord.isPresent()) {
				masterStateRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}

		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "state")
	public List<MasterState> getAll() {
		try {
			return masterStateRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public List<Map<String, Object>> findStatesByCountryId(Integer countryId, Integer stateId, Integer districtId)
			throws Exception {
		List<Map<String, Object>> result = null;
		try {
			if (countryId != null) {
				result = masterStateRepository.findSatesByCid(countryId);
				return result;
			}
			if (stateId != null) {
				result = masterStateRepository.findDistrictBySid(stateId);
				return result;
			}
			if (districtId != null) {
				result = masterStateRepository.findBlocksByDid(districtId);
				return result;
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching master locations by ids: ", e.getCause());
			throw new Exception(" Exception occured while fetching master locations by ids: " + e.getMessage());
		}
		return null;
	}
}