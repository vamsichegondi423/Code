package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.IcatalogueProductBadge;
import com.dipl.evin2.repository.IcatalogueProductBadgeRepository;
import com.dipl.evin2.service.IcatalogueProductBadgeService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/icatalogue-product-badge")
public class IcatalogueProductBadgeController {

	@Autowired
	private IcatalogueProductBadgeService icatalogueProductBadgeService;
	@Autowired
	private IcatalogueProductBadgeRepository icatalogueProductBadgeRepository;

	@ApiOperation("Use this api for saving or updating IcatalogueProductBadge. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody IcatalogueProductBadge icatalogueProductBadge, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			IcatalogueProductBadge exstngIcataloguePranth = icatalogueProductBadgeRepository.getIcatalogueProductBadge(icatalogueProductBadge.getIcatalogueId(), icatalogueProductBadge.getProductId(), icatalogueProductBadge.getBadgeId());
			if(exstngIcataloguePranth != null) {
				log.info("Icatalogue  id " + icatalogueProductBadge.getIcatalogueId() + " with product id " + icatalogueProductBadge.getProductId() + " and badge id " +icatalogueProductBadge.getBadgeId()+ " already exist");
				responseBean.setMessage("Icatalogue  id " + icatalogueProductBadge.getIcatalogueId() + " with product id " + icatalogueProductBadge.getProductId() + " and badge id " +icatalogueProductBadge.getBadgeId()+ " already exist");
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setReturnCode(1);
				return responseBean;
			}
			if (icatalogueProductBadge.getId() != null && icatalogueProductBadge.getId() > 0) {
				IcatalogueProductBadge existingIcatalogueProductBadge = icatalogueProductBadgeService
						.getById(icatalogueProductBadge.getId());
				if (existingIcatalogueProductBadge != null) {
					icatalogueProductBadge = icatalogueProductBadgeService.save(icatalogueProductBadge);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(icatalogueProductBadge);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				icatalogueProductBadge = icatalogueProductBadgeService.save(icatalogueProductBadge);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(icatalogueProductBadge);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching IcatalogueProductBadge record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			IcatalogueProductBadge icatalogueProductBadge = icatalogueProductBadgeService.getById(id);
			if (icatalogueProductBadge != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(icatalogueProductBadge);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting IcatalogueProductBadge record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = icatalogueProductBadgeService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all IcatalogueProductBadge records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<IcatalogueProductBadge> icatalogueProductBadgeRecords = icatalogueProductBadgeService.getAll();
			if (!icatalogueProductBadgeRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(icatalogueProductBadgeRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
}