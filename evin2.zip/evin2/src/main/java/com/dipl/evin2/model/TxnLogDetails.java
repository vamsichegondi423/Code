package com.dipl.evin2.model;


import java.util.Date;

import javax.persistence.Id;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(value = "txn_log_details")
@JsonIgnoreProperties(ignoreUnknown = true)
public class TxnLogDetails {
	@Id
	private String id;
	private Long storeId;
	private String storeName;
	private Long storeBadgeId;
	private String storeBadgeName;
	private Long productId;
	private String productName;
	private Long productBadgeId;
	private String productBadgeName;
	private Date txnDate;
	private Integer txnTypeId;
	private String txnTypeName;
	private Long txnId;
	private Long stateId;
	private String stateName;
	private Long districtId;
	private String districtIdName;
	private Long blockId;
	private String blockName;
	@Builder.Default
	private Boolean isDeleted = false;
	@CreatedDate
	private Date createdOn;

}
