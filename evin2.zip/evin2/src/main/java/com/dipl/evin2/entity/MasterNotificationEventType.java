package com.dipl.evin2.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


/**
 * The persistent class for the master_notification_event_type database table.
 * 
 */
@Entity
@Table(name="master_notification_event_type")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder 
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MasterNotificationEventType extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="created_by")
	private Long createdBy;

	@Column(name="created_on")
	private Date createdOn;

	@Column(name="is_deleted")
	private Boolean isDeleted;

	@Column(name="notification_event_type", nullable=false, length=200)
	private String notificationEventType;

	@Column(name="updated_by")
	private Long updatedBy;

	@Column(name="updated_on")
	private Date updatedOn;

}