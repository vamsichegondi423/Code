package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterReason;
import com.dipl.evin2.entity.MasterStatus;
import com.dipl.evin2.entity.PranthHierarchy;
import com.dipl.evin2.entity.ReasonPranth;
import com.dipl.evin2.entity.StatusPranth;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterStatusRepository;
import com.dipl.evin2.repository.StatusPranthRepository;
import com.dipl.evin2.util.JdbcTemplateHelper;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterStatusService {

	@Autowired
	private MasterStatusRepository masterStatusRepository;

	@Autowired
	private StatusPranthRepository statusPranthRepository;

	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@Autowired
	private JdbcTemplateHelper jdbcTemplateHelper;
	
	private static final String QUERY_STRING = "select ms.id,ms.name, ms.remarks, ms.created_by as createdBy, ms.created_on as createdOn, ms.is_deleted as isDeleted, ms.updated_by as updatedBy, ms.updated_on as updatedOn, ms.status_type as statusType, sp.pranth_id as pranthId, sp.is_status_mandatory as isStatusMandatory from master_status ms join status_pranth sp on sp.status_id = ms.id where ";

	@Cacheable(value = "status", key = "#id")
	public MasterStatus getById(Integer id) throws CustomException {
		try {
			Optional<MasterStatus> masterStatusOptional = masterStatusRepository.getById(id);
			if (masterStatusOptional.isPresent()) {
//				StatusPranth byStatusId = statusPranthRepository.getByStatusId(id);
//				if(byStatusId != null)
//					masterStatusOptional.get().setPranthId(byStatusId.getPranthId());
				return masterStatusOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "status", key = "#masterStatus.id")
	public MasterStatus save(MasterStatus masterStatus,Long pranthId) {
		Boolean isStatusMand = masterStatus.getIsStatusMandatory();
		if (masterStatus.getId() != null && masterStatus.getId() > 0) {
			Optional<MasterStatus> existingMasterStatusRecord = masterStatusRepository.getById(masterStatus.getId());
			if (existingMasterStatusRecord.isPresent()) {
				masterStatus = masterStatusRepository.save(masterStatus);
				StatusPranth findByPranthIdAndId = statusPranthRepository.findByPranthIdAndStatusId(pranthId,masterStatus.getId());
				if(findByPranthIdAndId != null && findByPranthIdAndId.getId() != null && findByPranthIdAndId.getId() > 0) {
					findByPranthIdAndId.setIsStatusMandatory(isStatusMand);
					if(!findByPranthIdAndId.getIsActive()) {
						findByPranthIdAndId.setIsActive(true);
					}
					statusPranthRepository.save(findByPranthIdAndId);
				} else {
					StatusPranth reasonPranth = StatusPranth.builder().pranthId(pranthId).statusId(masterStatus.getId()).build();
					reasonPranth.setIsStatusMandatory(isStatusMand);
					statusPranthRepository.save(reasonPranth);
				}
				updateStatusMandatoryField(masterStatus,pranthId,isStatusMand);
				return masterStatus;
			}
		} else {
			masterStatus = masterStatusRepository.save(masterStatus);
			if(masterStatus.getId() > 0) {
				StatusPranth findByPranthIdAndId = statusPranthRepository.findByPranthIdAndStatusId(pranthId,masterStatus.getId());
				if(findByPranthIdAndId != null && findByPranthIdAndId.getId() != null && findByPranthIdAndId.getId() > 0) {
					findByPranthIdAndId.setIsStatusMandatory(isStatusMand);
					if(!findByPranthIdAndId.getIsActive()) {
						findByPranthIdAndId.setIsActive(true);
					}
					statusPranthRepository.save(findByPranthIdAndId);
				} else {
					StatusPranth reasonPranth = StatusPranth.builder().pranthId(pranthId).statusId(masterStatus.getId()).build();
					reasonPranth.setIsStatusMandatory(isStatusMand);
					statusPranthRepository.save(reasonPranth);
				}
				updateStatusMandatoryField(masterStatus,pranthId,isStatusMand);
			}
		}
		return masterStatus;
	}
	
	private void updateStatusMandatoryField(MasterStatus masterStatus, Long pranthId,Boolean isStatusMand) {
		List<StatusPranth> findAllByPranthId = statusPranthRepository.findAllByPranthId(pranthId,masterStatus.getStatusType());
		findAllByPranthId.stream().forEach(rp ->{
			rp.setIsStatusMandatory(isStatusMand);
		});
		statusPranthRepository.saveAll(findAllByPranthId);
	}

	@CacheEvict(value = "status", allEntries = true)
	public Integer deleteById(Integer id,Long pranthId) throws CustomException {
		try {
			Optional<MasterStatus> existingMasterStatusRecord = masterStatusRepository.getById(id);
			if (existingMasterStatusRecord.isPresent()) {
				masterStatusRepository.deleteByIdSoft(id);
				StatusPranth existsStatusPranth = statusPranthRepository.findByPranthIdAndStatusIdAndIsActiveTrue(pranthId, id);
				if(existsStatusPranth != null) {
					statusPranthRepository.deleteByIdSoft(existsStatusPranth.getId());
				}
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "status", key = "#pranthId")
	public List<MasterStatus> getAll(Long pranthId) {
		String query = QUERY_STRING + "sp.pranth_id = "+ pranthId+" and is_deleted = false";
		List<MasterStatus> masterStatusList= jdbcTemplateHelper.getResults(query, MasterStatus.class);
		return masterStatusList;

	}

	@Cacheable(value = "status", key = "{#statusType, #pranthId}")
	public List<MasterStatus> getStatusByType(String statusType, Long pranthId) {
		String query = QUERY_STRING + "sp.pranth_id = "+pranthId+" and ms.status_type = "+statusType+" and is_deleted = false";
		List<MasterStatus> masterStatusList= jdbcTemplateHelper.getResults(query, MasterStatus.class);
		return masterStatusList;
	}

	@Transactional(rollbackOn = { Exception.class , CustomException.class })
	public ResponseBean updateParentStatusToChild(Long pranthId, Long mappedPranthId, Long userId)  throws CustomException{
		ResponseBean responseBean  = new ResponseBean();
		Long pranthid = 0L;
		List<StatusPranth> spList= new ArrayList<>();
		Optional<PranthHierarchy> pranthHierarchy = pranthHierarchyService.getByMappingId(mappedPranthId);
		try {
			if(pranthHierarchy.isPresent()) {
				if(pranthId != null && pranthId != 0) {
					pranthid = pranthId;
				} else {
					pranthid = pranthHierarchy.get().getPranthId();
				}
				List<StatusPranth> statusPranthList = statusPranthRepository.findAll(pranthid);
				for(StatusPranth sp: statusPranthList) {
					StatusPranth masterStatus = new StatusPranth();
					StatusPranth statusPranthObject = statusPranthRepository.findByPranthIdAndStatusIdAndIsActiveTrue(mappedPranthId, sp.getStatusId());
					if(statusPranthObject == null) {
						masterStatus = StatusPranth.builder()
								.pranthId(mappedPranthId).isActive(true).statusId(sp.getStatusId()).build();
						spList.add(masterStatus);
					}
				}
				statusPranthRepository.saveAll(spList);
				responseBean.setMessage("MasterStaus has been updated for child");
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
			} else {
				responseBean.setMessage("No Record found with mappedPranthId");
				responseBean.setReturnCode(0);
				responseBean.setStatus(HttpStatus.NO_CONTENT);
			}
		}catch(Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseBean;
	}

}