package com.dipl.evin2.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StoreFilterDTO {
	
	private String storeName;
	private String location;
	private Long storeId;
	
}
