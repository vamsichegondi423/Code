package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.Producer;
import com.dipl.evin2.entity.ProducerBadge;
import com.dipl.evin2.entity.ProducerTm;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.service.ProducerBadgeService;
import com.dipl.evin2.service.ProducerService;
import com.dipl.evin2.service.ProducerTmService;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/producer")
public class ProducerController {

	@Autowired
	private ProducerService producerService;
	
	@Autowired
	private ProducerTmService producerTmService;
	
	@Autowired
	private ProducerBadgeService producerBadgeService;

	@ApiOperation("Use this api for saving or updating Producer. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	@Transactional(rollbackOn = Exception.class)
	public ResponseBean save(@RequestBody Producer producer, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (producer.getId() != null && producer.getId() > 0) {
				Producer existingProducer = producerService.getById(producer.getId());
				if (existingProducer != null) {
					producer.setCreatedBy(existingProducer.getCreatedBy());
					producer.setCreatedOn(existingProducer.getCreatedOn());
					Producer producer1 = producerService.save(producer);
					saveProducerBadges(producer,producer1);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				Producer producer1 = producerService.save(producer);
				saveProducerBadges(producer,producer1);
				saveProducerTm(producer,producer1);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
			}
			producer.setProducerBadges(producer != null && producer.getId() != null ? producerBadgeService.getAllByProducerId(producer.getId()) : null);
			responseBean.setData(producer);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	private void saveProducerTm(Producer producer, Producer producer1) {
		final Integer producerId = producer1.getId();
		if(producer.getProducerTm() != null && !producer.getProducerTm().isEmpty()) {
			producer.getProducerTm().forEach(ptm -> {
				if(ptm.getId() != null && ptm.getId() > 0) {
					ProducerTm producerTm = null;
					try {
						producerTm = producerTmService.getById(ptm.getId());
					} catch (CustomException e) {
						e.printStackTrace();
					}
					 if(producerTm != null) {
						 ptm.setCreatedBy(producerTm.getCreatedBy());
						 ptm.setCreatedOn(producerTm.getCreatedOn());
					 }
				}
				ptm.setProducerId(producerId);
				try {
					producerTmService.save(ptm);
				} catch (CustomException e) {
					e.printStackTrace();
				}
			});
		}
	}

	private void saveProducerBadges(Producer producer, Producer producer1) {
		final Integer producerId = producer1.getId();
		if(producer.getProducerBadges() != null && !producer.getProducerBadges().isEmpty()) {
			producer.getProducerBadges().forEach(mb -> {
				if(mb.getId() != null && mb.getId() > 0) {
					 ProducerBadge producerBadge = producerBadgeService.getById(mb.getId());
					 if(producerBadge != null) {
						 mb.setCreatedBy(producerBadge.getCreatedBy());
						 mb.setCreatedOn(producerBadge.getCreatedOn());
					 }
				}
				mb.setProducerId(producerId);
				producerBadgeService.save(mb);
			});
		}
	}

	@ApiOperation("Use this api for fetching Producer record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Producer producer = producerService.getById(id);
			if (producer != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(producer);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			producer.setProducerBadges(producer != null && producer.getId() != null ? producerBadgeService.getAllByProducerId(producer.getId()) : null);
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting Producer record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = producerService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all Producer records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll(Pageable pageable,HttpServletRequest request) {
		
		if(request.getParameter("page") == null) {
			pageable = PageRequest.of(0, Integer.MAX_VALUE);
		}
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Producer> producerRecords = producerService.getAll(pageable);
			if (!producerRecords.isEmpty()) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
			} else {
				log.info("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			producerRecords.forEach(m -> {
				m.setProducerBadges(m != null && m.getId() != null ? producerBadgeService.getAllByProducerId(m.getId()) : null);
			});
			responseBean.setData(producerRecords);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
	
	@ApiOperation("Use this api for fetching all Producer records. No params required.")
	@GetMapping(value = "/v1/get-producers-by-filter", produces = "application/json")
	public ResponseBean getAllProducers(@RequestParam (required = false,value = "producerName") String producerName,@RequestParam (required = false,value = "producerBadge") String producerBadge, Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		ProducerDetails producerDetails = null;
		List<ProducerFilterDTO> producerRecords = null;
		try {
				 producerRecords = producerService.findAllProducersByFillter(producerName,producerBadge,pageable);
				 Long totalRecordCount = producerService.findCountOfProducer(producerName,producerBadge);
				  producerDetails = ProducerDetails.builder().producerDTO(producerRecords).totalRecordCount(totalRecordCount).build();
			if (!producerRecords.isEmpty()) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
			} else {
				log.info("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			
			responseBean.setData(producerDetails);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured while find producers", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occured while find producers ");
		}
		return responseBean;
	}
	
	@ApiOperation("Use this api for fetching all Producer records. No params required.")
	@GetMapping(value = "/v1/get-producers-by-id", produces = "application/json")
	public ResponseBean getProducersById(@RequestParam (value = "producerId") Integer producerId) {
		ResponseBean responseBean = new ResponseBean();
		List<ProducerDTO> producerRecords = null;
		try {
				 producerRecords = producerService.findProducersByPid(producerId);
			if (!producerRecords.isEmpty()) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
			} else {
				log.info("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			
			responseBean.setData(producerRecords);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured while find producers", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occured while find producers ");
		}
		return responseBean;
	}
	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ProducerFilterDTO{
		
		private Integer producerId;
		 private String producerName;
		  private String location;
		 private Date lastupdated;
		  private String referenceId;
		 private String city;
		 private String badgeName;
	}
	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ProducerDTO {
		private String producerName;
		private String location;
		private Date lastupdated;
		private String referenceId;
		private String city;
		private String badgeName;
		private String updatedBy;
		private String phoneNumber;
		private String alternatePhoneNumber;
		private String email;
		private String countryName;
		private String stateName;
		private String districtName;
		private String blockName;
		private String pinCode;
		private String streetAddress;
		private float latitude;
		private float longitude;
		private Date createdOn;
		private String createdBy;
		private String contactName;
		private String description;

	}
	@Data
	@Builder
	public static class ProducerDetails{
		private List<ProducerFilterDTO> producerDTO;
		private Long totalRecordCount;
	}
}