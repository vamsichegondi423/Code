package com.dipl.evin2.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.controller.CargoController.CargoFilterModel;
import com.dipl.evin2.controller.CargoController.CargoModel;
import com.dipl.evin2.controller.CargoController.ShipmenByFiltertDTO;
import com.dipl.evin2.controller.CargoController.ShipmentByFilterDetails;
import com.dipl.evin2.dto.BookingCargoDTO;
import com.dipl.evin2.dto.CargoBatchDTO;
import com.dipl.evin2.dto.CargoDTO;
import com.dipl.evin2.dto.CargoProductsDTO;
import com.dipl.evin2.dto.StockDetailsDTO;
import com.dipl.evin2.entity.BookingItemBatch;
import com.dipl.evin2.entity.BookingItems;
import com.dipl.evin2.entity.BookingTracking;
import com.dipl.evin2.entity.Bookings;
import com.dipl.evin2.entity.Cargo;
import com.dipl.evin2.entity.CargoItem;
import com.dipl.evin2.entity.CargoItemBatch;
import com.dipl.evin2.entity.Carrier;
import com.dipl.evin2.entity.ClosingStockLog;
import com.dipl.evin2.entity.Icatalogue;
import com.dipl.evin2.entity.IcatalogueBatch;
import com.dipl.evin2.entity.Packages;
import com.dipl.evin2.entity.Product;
import com.dipl.evin2.entity.Txn;
import com.dipl.evin2.entity.TxnConsumptionLog;
import com.dipl.evin2.entity.TxnCountLog;
import com.dipl.evin2.entity.TxnLog;
import com.dipl.evin2.entity.UserComments;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.exceptions.CustomRollBackException;
import com.dipl.evin2.model.FulfilCargoModel;
import com.dipl.evin2.model.FulfilCargoModel.FulfillProductBatch;
import com.dipl.evin2.model.FulfilCargoModel.FulfillProducts;
import com.dipl.evin2.repository.BookingItemBatchRepository;
import com.dipl.evin2.repository.BookingItemsRepository;
import com.dipl.evin2.repository.BookingTrackingRepository;
import com.dipl.evin2.repository.BookingsRepository;
import com.dipl.evin2.repository.CargoItemBatchRepository;
import com.dipl.evin2.repository.CargoItemRepository;
import com.dipl.evin2.repository.CargoRepository;
import com.dipl.evin2.repository.CarrierRepository;
import com.dipl.evin2.repository.ClosingStockLogRepository;
import com.dipl.evin2.repository.IcatalogueBatchRepository;
import com.dipl.evin2.repository.IcatalogueRepository;
import com.dipl.evin2.repository.PackagesRepository;
import com.dipl.evin2.repository.ProductRepository;
import com.dipl.evin2.repository.TxnConsumptionRepository;
import com.dipl.evin2.repository.TxnCountLogRepository;
import com.dipl.evin2.repository.TxnLogRepository;
import com.dipl.evin2.repository.TxnRepository;
import com.dipl.evin2.repository.UserCommentsRepository;
import com.dipl.evin2.util.KafkaProducer;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.core.JsonProcessingException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CargoService {

	@Autowired
	private CargoRepository cargoRepository;

	@Autowired
	private CarrierRepository carrierRepository;

	@Autowired
	private IcatalogueRepository icatalogueRepository;

	@Autowired
	private IcatalogueLogService icatalogueLogService;

	@Autowired
	private PackagesRepository packagesRepository;
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private CargoItemRepository cargoItemRepository;

	@Autowired
	private CargoItemBatchRepository cargoItemBatchRepository;

	@Autowired
	private BookingsRepository bookingsRepository;

	@Autowired
	private BookingItemsRepository bookingItemsRepository;

	@Autowired
	private BookingItemBatchRepository bookingItemBatchRepository;

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private IcatalogueBatchRepository icatalogueBatchRepository;

	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@Autowired
	private TxnRepository txnRepository;
	@Autowired
	private TxnLogRepository txnLogRepository;

	@Autowired
	private BookingTrackingRepository bookingTrackingRepository;

	@Autowired
	private UserCommentsRepository userCommentsRepository;

	@Autowired
	private KafkaProducer kafkaProducer;

	@Autowired
	private TxnConsumptionRepository txnConsumptionRepository;
	
	@Autowired
	private ClosingStockLogRepository closingStockLogRepository;
	
	@Autowired
	private TxnCountLogRepository txnCountsLogRepository;

	public Cargo getById(Long id) throws CustomException {
		try {
			Optional<Cargo> cargoOptional = cargoRepository.getById(id);
			if (cargoOptional.isPresent()) {
				return cargoOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public Cargo save(Cargo cargo) throws CustomException {
		try {
			if (cargo.getId() != null && cargo.getId() > 0) {
				Optional<Cargo> existingCargoRecord = cargoRepository.getById(cargo.getId());
				if (existingCargoRecord.isPresent()) {
					return cargoRepository.save(cargo);
				}
			} else {
				cargo = cargoRepository.save(cargo);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return cargo;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<Cargo> existingCargoRecord = cargoRepository.getById(id);
			if (existingCargoRecord.isPresent()) {
				cargoRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<Cargo> getAll() {
		try {
			return cargoRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	@Transactional(rollbackFor = { Exception.class, CustomRollBackException.class })
	public ResponseBean createCargo(CargoModel cargoPayload) throws CustomRollBackException, Exception {
		ResponseBean responseBean = new ResponseBean();
		Cargo cargo = null;
		int txnTypeId = 1;
		Bookings booking = bookingsRepository.getByBookingId(cargoPayload.getBookingId());
		Long issuingStrore = booking.getIssuingStoreId();
		Long receivingStoreId = booking.getReceivingStoreId();
		JSONObject jsonObject = new JSONObject();
		if (cargoPayload.getCargoNo() == null) {
			cargoPayload.setCargoNo(cargoPayload.getBookingId() + "-1");
		}
		List<BookingItems> bkngItems = bookingItemsRepository.findAllByBookingId(cargoPayload.getBookingId());
		cargo = saveCargo(cargoPayload);
		Long cargoId = cargo.getId();
		Long bos = 0L;
		Long bcs = 0L;
		Long productTotalStock = 0L;
		for (BookingItems ci : bkngItems) {
			Icatalogue icatalogue = null;
			icatalogue = icatalogueRepository.getDetailsOfIcatalouge(ci.getProductId().longValue(), ci.getStoreId());
			Long icatId = icatalogue.getId();
			Icatalogue receiveingStoreIcat = icatalogueRepository.getDetailsOfIcatalouge(ci.getProductId().longValue(),
					receivingStoreId);
			Product product = productRepository.getProductById(ci.getProductId());
			if (product.getIsBatchEnabled().equals(false)) {
				saveCargoItemAndUpdateIntransitStock(cargoPayload, cargoId, ci, receiveingStoreIcat);
				productTotalStock = icatalogue.getTotalStock();
				Long aloCount = icatalogue.getAllocatedStock() - ci.getAllocatedStock();
				Long intransitStock = icatalogue.getInTransitStock();
				Long totalStock = aloCount + icatalogue.getCurrentStock();
				icatalogue.setAllocatedStock(aloCount);
				icatalogue.setInTransitStock(intransitStock);
				icatalogue.setTotalStock(totalStock);
				icatalogue.setUpdatedBy(cargoPayload.getUpdatedBy());
				icatalogue.setUpdatedOn(new Date());
				icatalogue.setPranthId(cargoPayload.getPranthId());
				icatalogue = icatalogueRepository.save(icatalogue);
				Txn txn = saveTxnForCargoItem(cargoPayload, issuingStrore, receivingStoreId, ci, icatalogue.getId(),
						null, null, bos, bcs, productTotalStock,null);
				Icatalogue icat = icatalogueRepository.getIcatalogueDetailsBySidPidIcatId(icatalogue.getStoreId(),
						ci.getProductId(), icatId);
				Integer abnormalTypeId = null;
				if (icat.getTotalStock().equals(0L)) {
					abnormalTypeId = 200;
				} else if (icat.getTotalStock() <= icat.getMinStock()) {
					abnormalTypeId = 201;
				} else if (icat.getTotalStock() >= icat.getMaxStock()) {
					abnormalTypeId = 202;
				} else if (!icatalogue.getTotalStock().equals(0L) || !(icatalogue.getTotalStock() <= icatalogue.getMinStock())
						|| !(icatalogue.getTotalStock() >= icatalogue.getMaxStock())) {
					abnormalTypeId = 0;
				}
				icatalogueLogService.saveIcatalogueLog(ci.getProductId(), receivingStoreId, ci.getPranthId(),
						txn.getTxnTypeId(), txn.getId(), icatId, cargoPayload.getCreatedBy(), txn.getIsDeleted(),
						abnormalTypeId);
			}
			if (product.getIsBatchEnabled().equals(true)) {
				CargoItem cargoItem = saveCargoItemAndUpdateIntransitStock(cargoPayload, cargoId, ci, null);
				List<BookingItemBatch> bookingItemBatches = bookingItemBatchRepository
						.getProductsByBookingItemId(ci.getId());
				if (!bookingItemBatches.isEmpty()) {
					for (BookingItemBatch bib : bookingItemBatches) {
						saveCargoItemBatch(cargoPayload, cargoItem.getId(), ci, bib);
						IcatalogueBatch icb = icatalogueBatchRepository.getDetailsOfIcatalougeBatch(icatId,
								bib.getBatchNo(), ci.getProductId(),bib.getProducerId());
						if(icb != null) {
							bos = icb.getTotalStock();
							bcs = icb.getTotalStock() - bib.getQuantity();
							Long alcStk = icb.getAllocatedStk() - bib.getQuantity();
							Long totalStock = alcStk + icb.getAvailableStock();
							icb.setQuantity(bib.getQuantity());
							icb.setAllocatedStk(alcStk);
							icb.setTotalStock(totalStock);
							icb.setUpdatedBy(cargoPayload.getCreatedBy());
							icb = icatalogueBatchRepository.save(icb);
						}else {
							log.info("we not found icatalogueBatch data for this shipment");
							throw new Exception();
						}
						Txn txn = saveTxnForCargoItem(cargoPayload, issuingStrore, receivingStoreId, ci,
								icatalogue.getId(), icb.getBatchNo(), bib, bos, bcs, productTotalStock,icb.getProducerId());
						updateStockICatalogueStockDetails(cargoPayload, ci, icatalogue, icatId);
						jsonObject.put("txnId", txn.getId());
					}
					updateIntransitStockInRecvingStore(cargoPayload, receiveingStoreIcat, cargoItem.getId());
					Icatalogue icat = icatalogueRepository.getIcatalogueDetailsBySidPidIcatId(icatalogue.getStoreId(),
							ci.getProductId(), icatId);
					Integer abnormalTypeId = null;
					Long txnId = (Long) jsonObject.get("txnId");
					if (icat.getTotalStock().equals(0L)) {
						abnormalTypeId = 200;
					} else if (icat.getTotalStock() <= icat.getMinStock()) {
						abnormalTypeId = 201;
					} else if (icat.getTotalStock() >= icat.getMaxStock()) {
						abnormalTypeId = 202;
					} else if (!icatalogue.getTotalStock().equals(0L)
							|| !(icatalogue.getTotalStock() <= icatalogue.getMinStock())
							|| !(icatalogue.getTotalStock() >= icatalogue.getMaxStock())) {
						abnormalTypeId = 0;
					}
					try {
						kafkaProducer.saveIcataLogueLogToKafka(ci.getProductId(), receivingStoreId, ci.getPranthId(),
								txnTypeId, txnId, icatId, cargoPayload.getCreatedBy(), icatalogue.getIsDeleted(),
								abnormalTypeId);
					} catch (JsonProcessingException e) {
						e.printStackTrace();
						log.error("Exception occured while icatalogue log saving to kafka Q.", e.getCause());
					}
				}else {
					log.info("not found any bookings to do shipments..");
					responseBean.setReturnCode(0);
					responseBean.setStatus(HttpStatus.NOT_FOUND);
					responseBean.setData(null);
					responseBean.setMessage("something went wrong");
				}
			}
			ci.setShippedStock(ci.getQuantity());
			ci.setUpdatedOn(new Date());
			ci.setUpdatedBy(cargoPayload.getUpdatedBy());
			bookingItemsRepository.save(ci);
		}
		Long carrierId = null;
		if (cargoPayload.getCarrierName() != null && !cargoPayload.getCarrierName().isEmpty()) {
			carrierId = saveCarrier(cargoPayload);
		}
		savePackage(cargoPayload, cargoId, carrierId);
		if (booking.getStatusId().equals(4)) {
			booking.setStatusId(7);
			booking.setUpdatedBy(cargoPayload.getCreatedBy());
			booking = bookingsRepository.save(booking);
			BookingTracking bookingTracking = BookingTracking.builder().bookingId(booking.getId())
					.pranthId(booking.getPranthId()).storeId(booking.getIssuingStoreId())
					.statusId(booking.getStatusId()).build();
			bookingTracking.setCreatedBy(cargoPayload.getCreatedBy());
			bookingTracking.setUpdatedBy(cargoPayload.getCreatedBy());
			bookingTracking = bookingTrackingRepository.save(bookingTracking);
			responseBean.setData(cargo);
			responseBean.setMessage("shipment created successfully");
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
			try {
				kafkaProducer.saveCargoStatusInCargoTopic(
						cargoPayload.getRemarks() == null ? null : cargoPayload.getRemarks(),
						cargoPayload.getCreatedBy(), cargoPayload.getBookingId(), cargoPayload.getCargoNo(), cargoId,
						"PENDING");
				kafkaProducer.saveCargoStausToKafka(
						cargoPayload.getRemarks() == null ? null : cargoPayload.getRemarks(),
						cargoPayload.getCreatedBy(), cargoPayload.getBookingId(), cargoPayload.getCargoNo(), "SHIPPED");
				kafkaProducer.saveCargoStatusInCargoTopic(
						cargoPayload.getRemarks() == null ? null : cargoPayload.getRemarks(),
						cargoPayload.getCreatedBy(), cargoPayload.getBookingId(), cargoPayload.getCargoNo(), cargoId,
						"SHIPPED");
			} catch (JsonProcessingException e) {
				e.printStackTrace();
				log.error("Exception occured while icatalogue log saving to kafka Q.", e.getCause());
			}
		}else {
			responseBean.setData(null);
			responseBean.setMessage("shipment not done successfully");
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setReturnCode(0);
		}
		return responseBean;
	}

	private void updateIntransitStockInRecvingStore(CargoModel cargoPayload, Icatalogue receiveingStoreIcatData,
			Long cargoItemId) {
		Long intranitStock = 0L;
		 intranitStock = cargoItemBatchRepository.findByCargoItemId(cargoItemId);
		// fetching the count value for handling NULL values for the first time
		Long intransitTableCount = receiveingStoreIcatData.getInTransitStock() == null ? 0l
				: receiveingStoreIcatData.getInTransitStock();
		receiveingStoreIcatData.setInTransitStock(intransitTableCount + intranitStock);
		receiveingStoreIcatData.setUpdatedBy(cargoPayload.getUpdatedBy());
		receiveingStoreIcatData.setUpdatedOn(new Date());
		receiveingStoreIcatData.setPranthId(cargoPayload.getPranthId());
		icatalogueRepository.save(receiveingStoreIcatData);
	}

	private void updateStockICatalogueStockDetails(CargoModel cargoPayload, BookingItems ci, Icatalogue icatalogue,
			Long icatId) {
		StockDetailsDTO sdt = icatalogueBatchRepository.getTotalAlc_Cur_Total_StockQuantity(icatId, ci.getProductId());
		icatalogue.setAllocatedStock(sdt.getAllocatedStock());
		icatalogue.setCurrentStock(sdt.getAvailableStock());
		icatalogue.setTotalStock(sdt.getAvailableStock() + sdt.getAllocatedStock());
		icatalogue.setUpdatedBy(cargoPayload.getUpdatedBy());
		icatalogue.setUpdatedOn(new Date());
		icatalogue.setPranthId(cargoPayload.getPranthId());
		icatalogueRepository.save(icatalogue);
	}

	private Txn saveTxnForCargoItem(CargoModel cargoPayload, Long issuingStoreId, Long destStoreId, BookingItems ci,
			Long icatId, String batchNo, BookingItemBatch bib, Long bos, Long bcs, Long productTotalStock,Integer producerId)
			throws Exception {
		Icatalogue closingStockDetailsOfProduct = null;
		Long pcs = Long.valueOf(0L);
		Long pos = Long.valueOf(0L);
		Long stock = Long.valueOf(0L);
		if (batchNo != null) {
			closingStockDetailsOfProduct = icatalogueRepository.getDetailsOfIcatalouge(ci.getProductId().longValue(),
					issuingStoreId);
			if (closingStockDetailsOfProduct != null
					&& closingStockDetailsOfProduct.getTotalStock() >= bib.getQuantity()) {
				log.info("Requested quanity is less than so, request came in side if condition...");
				pos = closingStockDetailsOfProduct.getTotalStock();
				pcs = closingStockDetailsOfProduct.getTotalStock() - bib.getQuantity();
				stock = bib.getQuantity();
			} else {
				log.error(
						"Exception Occured due to Invntry not found / Requested quantity is grater than avilable Quantity while doing shipment");
				throw new CustomRollBackException();
			}

		} else {
			closingStockDetailsOfProduct = icatalogueRepository.getDetailsOfIcatalouge(ci.getProductId().longValue(),
					issuingStoreId);
			if (closingStockDetailsOfProduct != null && productTotalStock >= ci.getOrderedStock()) {
				pos = productTotalStock;
				pcs = productTotalStock - ci.getOrderedStock();
				stock = ci.getOrderedStock();
			} else {
				log.error(
						"Exception Occured due to Invntry not found / Requested quantity is grater than avilable Quantity while doing shipment");
				throw new CustomRollBackException();
			}
		}
		Txn txnDetails = Txn.builder().batchNo(batchNo != null ? batchNo : null).closingStock(pcs).icatalogueId(icatId)
				.destStoreId(destStoreId).initialTxnDate(new Date()).openingStock(pos).closingStockBatch(bcs)
				.openingStockBatch(bos).pranthId(ci.getPranthId()).productId(ci.getProductId()).reasonId(null)
				.sourceStoreId(ci.getStoreId()).sourceType(cargoPayload.getSourceType()).stock(stock)
				.cargoId(cargoPayload.getCargoId()).txnTypeId(1).trackingNo(cargoPayload.getCargoNo()).producerId(producerId == null ? null : producerId)
				.trackingObjectTypeId(1).build();
		txnDetails.setUpdatedBy(cargoPayload.getUpdatedBy());
		txnDetails.setCreatedBy(cargoPayload.getCreatedBy());
		Txn txn = txnRepository.save(txnDetails);
		if (txn != null) {
			TxnLog txnLog = new TxnLog().builder().productId(Long.valueOf(ci.getProductId())).storeId(ci.getStoreId())
					.isActivityRead(false).isConsumptionRead(false).txnDate(new Date()).txnTypeId(1).txnId(txn.getId())
					.build();
			TxnLog tl = txnLogRepository.save(txnLog);
			
			if (tl != null) {
				insertConsumptionRecord(ci.getStoreId(), Long.valueOf(ci.getProductId()), 1, stock);
			}
			insertingInToTxnCountsLog(Long.valueOf(ci.getProductId()),ci.getStoreId(), stock, txn);
			insertingClosingStockData(Long.valueOf(ci.getProductId()),ci.getStoreId(), icatId, pcs, stock);		
		}
		return txn;
	}

	@Async("threadPoolTaskExecutor")
	public void insertingClosingStockData(Long productId,Long storeId, Long icatId, Long pcs, Long stock) throws Exception {
		Date baseDate = new Date();
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dbDate = sdf.format(baseDate);
		Date date;
		try {
		date = sdf.parse(dbDate);
		ClosingStockLog closingStockLog = closingStockLogRepository.getClosingStockDetails(date,productId,storeId);
		if(closingStockLog != null) {
			closingStockLog.setClosingStock(pcs);
			closingStockLog.setIsRead(false);
			closingStockLog.setUpdatedOn(new Date());
			closingStockLogRepository.save(closingStockLog);
		}else {
			ClosingStockLog clsingStock = new ClosingStockLog().builder().icatalogueId(icatId).closingStock(pcs).createdOn(new Date()).isRead(false).updatedOn(new Date())
					.productId(Long.valueOf(productId)).storeId(storeId).build();
			closingStockLogRepository.save(clsingStock);
		}
		} catch (Exception e) {
			log.error("Exception occured while inserting data in to txn closingStock log" + e.getMessage());
			throw new Exception();
		}
	}
    @Async("threadPoolTaskExecutor")
	public void insertingInToTxnCountsLog(Long productId,Long storeId, Long stock, Txn txn) {
		TxnCountLog txnCountLog = new TxnCountLog().builder().created_date(new Date()).productId(productId)
				.stock(stock).txnTypeId(txn.getTxnTypeId()).id(txn.getId())
				.storeId(storeId).isRead(false).build();
		txnCountsLogRepository.save(txnCountLog);
	}

	private void insertConsumptionRecord(Long storeId, Long productId, Integer txnTypeId, Long stock) {
		Date baseDate = new Date();
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dbDate = sdf.format(baseDate);
		Date date;
		try {
			date = sdf.parse(dbDate);
			TxnConsumptionLog tcl = txnConsumptionRepository.findConsumptionRecord(storeId, productId, txnTypeId, date);
			if (tcl != null) {
				tcl.setTxnCount(tcl.getTxnCount() == null ? 0 : tcl.getTxnCount() + stock.intValue());
				tcl.setIsConsumptionRead(false);
				tcl.setIsTxnCountRead(false);
				txnConsumptionRepository.save(tcl);
			} else {
				TxnConsumptionLog tc = new TxnConsumptionLog().builder().storeId(storeId).productId(productId)
						.txnDate(date).isConsumptionRead(false).txnTypeId(txnTypeId).txnCount(stock.intValue()).isTxnCountRead(false).build();
				txnConsumptionRepository.save(tc);
			}
		} catch (ParseException e) {
			log.info("Exception occured while inserting data in to txn consumption log");
		}

	}

	private void saveCargoItemBatch(CargoModel cargoPayload, Long cargoitemId, BookingItems ci,
			BookingItemBatch bookingItemBatch) {
		CargoItemBatch cargoItemBatch = CargoItemBatch.builder().batchExpiryDate(bookingItemBatch.getBatchExpiryDate())
				.batchNo(bookingItemBatch.getBatchNo()).cargoItemId(cargoitemId).orderedStock(ci.getOrderedStock())
				.fulfilledStock(0l).discardedReasonId(null).discardedStock(0l).producerId(bookingItemBatch.getProducerId())
				.cargoStock(bookingItemBatch.getQuantity()).build();
		cargoItemBatch.setUpdatedBy(cargoPayload.getUpdatedBy());
		cargoItemBatch.setCreatedBy(cargoPayload.getCreatedBy());
		cargoItemBatchRepository.save(cargoItemBatch);
	}

	private CargoItem saveCargoItemAndUpdateIntransitStock(CargoModel cargoPayload, Long cargoId, BookingItems ci,
			Icatalogue receiveingStoreIcat) {
		CargoItem cargoItem = CargoItem.builder().discardedReasonId(null).fulfilledStock(0l).cargoId(cargoId)
				.discardedStock(0l).orderedStock(ci.getOrderedStock()).productId(ci.getProductId())
				.cargoStock(ci.getOrderedStock()).build();
		cargoItem.setCreatedBy(cargoPayload.getCreatedBy());
		cargoItem.setUpdatedBy(cargoPayload.getUpdatedBy());
		CargoItem cargoItemData = cargoItemRepository.save(cargoItem);
		// updating the receiving store in-transit stock
		if (receiveingStoreIcat != null) {
			Long recvngStoreIntransitStk = receiveingStoreIcat.getInTransitStock() == null ? 0l
					: receiveingStoreIcat.getInTransitStock();
			receiveingStoreIcat.setInTransitStock(recvngStoreIntransitStk + ci.getOrderedStock());
			receiveingStoreIcat.setUpdatedBy(cargoPayload.getUpdatedBy());
			receiveingStoreIcat.setUpdatedOn(new Date());
			icatalogueRepository.save(receiveingStoreIcat);
		}
		return cargoItemData;
	}

	private Cargo saveCargo(CargoModel cargoPayload) {
		Cargo cargo = Cargo.builder().arrivalDate(cargoPayload.getArrivalDate()).bookingId(cargoPayload.getBookingId())
				.customerDelivery(cargoPayload.getCustomerDelivery()).departureDate(new Date())
				.orderReferenceNo(cargoPayload.getOrderReferenceNo()).pranthId(cargoPayload.getPranthId())
				.storeId(cargoPayload.getIssuingStoreId()).cargoNo(cargoPayload.getCargoNo()).build();
		cargo.setCreatedBy(cargoPayload.getCreatedBy());
		cargo.setUpdatedBy(cargoPayload.getUpdatedBy());
		Cargo cargoData = cargoRepository.save(cargo);
		if (cargoPayload.getRemarks() != null) {
			UserComments cargoComments = UserComments.builder().bookingId(cargoPayload.getBookingId())
					.cargoId(cargoPayload.getCargoId()).comments(cargoPayload.getRemarks())
					.createdBy(cargoPayload.getCreatedBy()).createdOn(new Date()).entryFrom("Booking").build();
			userCommentsRepository.save(cargoComments);
		}
		return cargoData;
	}

	private Long saveCarrier(CargoModel cargoPayload) throws Exception {
		Carrier carrierInfo = null;
		// String carrierTypeId = cargoPayload.getCarrierTypeId();
		carrierInfo = carrierRepository.getCarrierDetails(cargoPayload.getCarrierName());
		if (carrierInfo != null) {
			Long carrierId = carrierInfo.getId();
			return carrierId;
		} else {
			Carrier carrier = Carrier.builder().carrierName(cargoPayload.getCarrierName())
					.contactNo(cargoPayload.getDriverPhone()).carrierType(cargoPayload.getCarrierTypeId())
					.address(cargoPayload.getCarrierAddress()).build();
			carrier.setCreatedBy(cargoPayload.getCreatedBy());
			carrier.setUpdatedBy(cargoPayload.getUpdatedBy());
			Carrier carrierData = carrierRepository.save(carrier);
			Long carrierId = carrierData.getId();
			return carrierId;
		}
	}

	private void savePackage(CargoModel cargoPayload, Long cargoId, Long carrierId) {
		Packages packages = Packages.builder().arrivalDate(cargoPayload.getArrivalDate())
				.breadth(cargoPayload.getBreadth()).carrierId(carrierId).driverMobile(cargoPayload.getDriverPhone())
				.height(cargoPayload.getHeight()).weight(cargoPayload.getWtkg())
				.vehicleInfo(cargoPayload.getVehicleInfo()).remarks(cargoPayload.getRemarks())
				.packageType(cargoPayload.getPackageType() == null ? null : cargoPayload.getPackageType())
				.length(cargoPayload.getLength()).packageNo(cargoPayload.getPackageNo()).cargoId(cargoId)
				.packageQuantity(cargoPayload.getPackageQuantity()).packageCost(cargoPayload.getPackageCost()).build();
		packages.setCreatedBy(cargoPayload.getCreatedBy());
		packages.setUpdatedBy(cargoPayload.getUpdatedBy());
		packagesRepository.save(packages);
	}

	public List<BookingCargoDTO> getCargoByBookingId(Long bookingId) throws Exception {
		List<BookingCargoDTO> bookingCargoDTO = null;
		bookingCargoDTO = cargoRepository.getCargoByBookingId(bookingId);
		if (bookingCargoDTO != null) {
			return bookingCargoDTO;
		}
		return bookingCargoDTO;
	}

	public ShipmentByFilterDetails getAllShipmentsByDomainId(CargoFilterModel shipmentPayload, Pageable pageable,
			List<Long> totalstoreIds) throws Exception {
		ShipmentByFilterDetails shipmentByFilterDetails = null;
		try {
			Set<Long> consolidatedDomainIds = pranthHierarchyService
					.getConsolidatedPranthIds(shipmentPayload.getPranthId());
			String queryForConsolidatedDomainIds = pranthHierarchyService.buildQuery(consolidatedDomainIds);
			StringBuilder builder = new StringBuilder();
			Long count = buildQueryForShipmentFilterParams(shipmentPayload, builder, queryForConsolidatedDomainIds,
					pageable, totalstoreIds);
			if (count > 0) {
				String query = builder.toString();
				log.info(query);
				List<ShipmenByFiltertDTO> shipmenByFiltertDTO = jdbcTemplate.query(query,
						new RowMapper<ShipmenByFiltertDTO>() {
							@Override
							public ShipmenByFiltertDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
								return ShipmenByFiltertDTO.builder().createdName(rs.getString("created_by"))
										.createdOn(rs.getTimestamp("created_on")).pranthId(rs.getLong("pranth_id"))
										.expectedDateArrvl(rs.getTimestamp("arrival_date"))
										.issuingStoreId(rs.getLong("issuing_store_id"))
										.issuingStoreLocation(rs.getString("issuing_store_location"))
										.issuingStoreName(rs.getString("issuing_store_name"))
										.noOfItems(rs.getLong("cargo_stock")).bookingId(rs.getLong("booking_id"))
										.receivingStoreId(rs.getLong("receiving_store_id"))
										.receivingStoreLocation(rs.getString("receiving_store_location"))
										.receivingStoreName(rs.getString("receiving_store_name"))
										.cargoId(rs.getLong("cargo_id")).status(rs.getString("status"))
										.cargoNo(rs.getString("cargo_no")).transporter(rs.getString("carrier_name"))
										.sourceType(rs.getInt("source_type")).userId(rs.getString("user_id")).build();
							}
						});
				return ShipmentByFilterDetails.builder().shipmenByFiltertDTO(shipmenByFiltertDTO)
						.totalRecordsCount(count).build();
			} else {
				return shipmentByFilterDetails;
			}
		} catch (Exception e) {
			log.error("Exception occured while performing the shipments fetching..", e.getCause());
			e.printStackTrace();
		}
		return shipmentByFilterDetails;
	}

	public List<Map<String, Object>> getCargoDataByQuery(CargoFilterModel shipmentPayload, StringBuilder builder,
			String queryForConsolidatedDomainIds, Pageable pageable, List<Long> offsetKioskIds) {
		List<Map<String, Object>> cargoList = null;

		builder.append(
				"select distinct c.pranth_id,c.id as cargo_id,c.booking_id,c.cargo_no,1 as cargo_stock,b.receiving_store_id, rs.name as receiving_store_name,\r\n"
						+ "concat(rs.city,', ',rd.name,', ',rst.name,', ',rc.name) as receiving_store_location,b.issuing_store_id,s.name as issuing_store_name,\r\n"
						+ "concat(s.city,', ',d.name,', ',st.name,', ',ic.name) as issuing_store_location, ms.name as status,b.created_on,concat(u.f_name,' ',u.l_name) as created_by,\r\n"
						+ "u.user_id,b.arrival_date,ca.carrier_name,b.source_type from cargo c left join bookings b on b.id=c.booking_id left join store rs on b.receiving_store_id=rs.id\r\n"
						+ "left join master_status ms on ms.id=b.status_id left join master_district rd on rd.id=rs.district_id left join master_state rst on rst.id=rs.state_id\r\n"
						+ "left join master_country rc on rc.id=rs.country_id \r\n"
						+ "left join store s on s.id=b.issuing_store_id left join master_district d on d.id=s.district_id left join master_state st on st.id=s.state_id\r\n"
						+ "left join master_country ic on ic.id=s.country_id left join users u on u.id=b.created_by \r\n"
						+ "left join packages p on p.cargo_id=c.id left join carrier ca on p.carrier_id=ca.id ");
		builder.append(" where c.pranth_id in " + queryForConsolidatedDomainIds + "");
		if (offsetKioskIds != null && !offsetKioskIds.isEmpty()) {
			builder.append(" and (b.receiving_store_id in ( " + StringUtils.join(offsetKioskIds, " ,")
					+ "  ) or b.issuing_store_id in ( " + StringUtils.join(offsetKioskIds, " ,") + "  ))");
		}
		if (shipmentPayload.getReceivingStoreId() != null) {
			builder.append(" and b.receiving_store_id = " + shipmentPayload.getReceivingStoreId() + "");
		}
		if (shipmentPayload.getIssuingStoreId() != null) {
			builder.append(" and b.issuing_store_id = " + shipmentPayload.getIssuingStoreId() + "");
		}
		if (shipmentPayload.getStatus() != null && !shipmentPayload.getStatus().isEmpty()) {
			builder.append(" and ms.name like '%" + shipmentPayload.getStatus() + "%'");
		}
		if (shipmentPayload.getFromDate() != null && shipmentPayload.getToDate() != null) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			builder.append(" and  b.created_on   between '" + simpleDateFormat.format(shipmentPayload.getFromDate())
					+ "' and  '" + simpleDateFormat.format(shipmentPayload.getToDate()) + "'");
		} else {
			if (shipmentPayload.getFromDate() != null) {
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				builder.append(
						" and  b.created_on  >= '" + simpleDateFormat.format(shipmentPayload.getFromDate()) + "'");
			}
			if (shipmentPayload.getToDate() != null) {
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				builder.append(" and  b.created_on  <= '" + simpleDateFormat.format(shipmentPayload.getToDate()) + "'");
			}
		}
		if (shipmentPayload.getTransporter() != null && !shipmentPayload.getTransporter().isEmpty()) {
			builder.append(" and ca.carrier_name  like '%" + shipmentPayload.getTransporter() + "%'");
		}
		if (shipmentPayload.getFromExpectedArrvlDate() != null && shipmentPayload.getToExpectedArrvlDate() != null) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			builder.append(" and b.arrival_date  between '"
					+ simpleDateFormat.format(shipmentPayload.getFromExpectedArrvlDate()) + "' and  '"
					+ simpleDateFormat.format(shipmentPayload.getToExpectedArrvlDate()) + "'");
		} else {
			if (shipmentPayload.getFromExpectedArrvlDate() != null) {
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				builder.append(" and b.arrival_date >= '"
						+ simpleDateFormat.format(shipmentPayload.getFromExpectedArrvlDate()) + "'");
			}
			if (shipmentPayload.getToExpectedArrvlDate() != null) {
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				builder.append(" and b.arrival_date <= '"
						+ simpleDateFormat.format(shipmentPayload.getToExpectedArrvlDate()) + "'");
			}
		}
		builder.append(" order by b.created_on desc ");
		cargoList = jdbcTemplate.queryForList(builder.toString());
		return cargoList;
	}

	private Long buildQueryForShipmentFilterParams(CargoFilterModel shipmentPayload, StringBuilder builder,
			String queryForConsolidatedDomainIds, Pageable pageable, List<Long> offsetKioskIds) {

		getCargoDataByQuery(shipmentPayload, builder, queryForConsolidatedDomainIds, pageable, offsetKioskIds);
		String mainQuery = builder.toString();
		String queryForCount = "SELECT COUNT(*) FROM (" + mainQuery + " ) as cnt";
		Long count = jdbcTemplate.queryForObject(queryForCount, Long.class);
		if (count > 0) {
			builder.append(" LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset());
		} else {
			count = 0L;
		}
		return count;

	}

	public CargoDTO getCargoDetailsByCargoId(Long cargoId) throws Exception {
		CargoDTO cargoDTO = null;
		cargoDTO = cargoRepository.getCargoDetailsByCargoId(cargoId);
		if (cargoDTO != null) {
			return cargoDTO;
		}
		return cargoDTO;

	}

	public List<CargoProductsDTO> getProductsByCargoId(Long cargoId) throws Exception {
		List<CargoProductsDTO> cargoProductDTO = null;
		cargoProductDTO = cargoRepository.getProductsByCargoId(cargoId);
		if (cargoProductDTO != null) {
			return cargoProductDTO;
		}
		return cargoProductDTO;

	}

	public List<CargoBatchDTO> getBatchDetailsByShipmentId(Long cargoId, Long productId) throws Exception {
		List<CargoBatchDTO> cargoBatchDTO = null;
		cargoBatchDTO = cargoRepository.getBatchDetailsByCargoId(cargoId, productId);
		if (cargoBatchDTO != null && !cargoBatchDTO.isEmpty()) {
			return cargoBatchDTO;
		}
		return cargoBatchDTO;
	}

	@Transactional(rollbackFor = { Exception.class, CustomException.class })
	public ResponseBean createFulfilment(FulfilCargoModel fulfillModel) throws CustomException, JSONException {
		ResponseBean responseBean = new ResponseBean();
		Long bookingId = fulfillModel.getBookingId();
		Long rStoreId = fulfillModel.getReceievingStoreId();
		Long isStoreId = fulfillModel.getIssuingStoreId();
		String cargoNo = fulfillModel.getCargoNo();
		Integer abnormalTypeId = null;
		int txnTypeId = 2;
		Boolean flag = false;
		List<FulfillProducts> fulfillProducts = fulfillModel.getFulfillProducts();
		Cargo cargo = cargoRepository.getCargoDetailsByCidAndBid(cargoNo, bookingId, isStoreId);
		Long cargoId = cargo.getId();
		if (!fulfillProducts.isEmpty()) {
			for (FulfillProducts ffp : fulfillProducts) {
				CargoItem cargoItm = cargoItemRepository.getProductsBycidAndpid(ffp.getProductId().longValue(),
						cargoId);
				Long disardQnty = ffp.getShippedQuantity() - ffp.getQuantity();
				// saving cargo item while fulfilment
				cargoItm = CargoItem.builder().id(cargoItm.getId()).cargoStock(ffp.getShippedQuantity())
						.fulfilledStock(ffp.getQuantity()).discardedReasonId(ffp.getReasonId())
						.discardedStock(disardQnty).cargoId(cargoId).orderedStock(cargoItm.getOrderedStock())
						.productId(ffp.getProductId()).build();
				cargoItm.setUpdatedBy(fulfillModel.getUserId());
				cargoItm = cargoItemRepository.save(cargoItm);
				BookingItems bkItems = bookingItemsRepository.findBookingItemByProductId(ffp.getProductId().longValue(),
						bookingId);
				bkItems.setFulfilledStock(ffp.getQuantity());
				bookingItemsRepository.save(bkItems);
				Long IcatId = updateIcatalogue(fulfillModel, rStoreId, ffp.getProductId(), ffp.getQuantity(),
						ffp.getShippedQuantity());
				Long txnId = insertTxnIcatLogWithoutBatchProduct(fulfillModel, rStoreId, ffp, IcatId);
				// checking the abnormality type of product in icatalogue after fulfilment done
				Icatalogue icatalogue = icatalogueRepository.getIcatalogueDetailsBySidPidIcatId(rStoreId,
						ffp.getProductId(), IcatId);
				if (icatalogue.getTotalStock().equals(0L)) {
					abnormalTypeId = 200;
				} else if (icatalogue.getTotalStock() <= icatalogue.getMinStock()) {
					abnormalTypeId = 201;
				} else if (icatalogue.getTotalStock() >= icatalogue.getMaxStock()) {
					abnormalTypeId = 202;
				} else if (!icatalogue.getTotalStock().equals(0L) || !(icatalogue.getTotalStock() <= icatalogue.getMinStock())
						|| !(icatalogue.getTotalStock() >= icatalogue.getMaxStock())) {
					abnormalTypeId = 0;
				}
				icatalogueLogService.saveIcatalogueLog(ffp.getProductId(), rStoreId, fulfillModel.getPranthId(),
						txnTypeId, txnId, IcatId, fulfillModel.getUserId(), icatalogue.getIsDeleted(), abnormalTypeId);
				flag = true;
			}
		}
		List<FulfillProductBatch> fulfillBatches = fulfillModel.getFulfillProductBatch();
		if (fulfillBatches != null && !fulfillBatches.isEmpty()) {
			JSONObject jsonObject = new JSONObject();
			for (FulfillProductBatch ffpb : fulfillBatches) {
				Icatalogue icat = icatalogueRepository.getDetailsOfIcatalouge(ffpb.getProductId().longValue(),
						rStoreId);
				if (icat != null) {
					CargoItem cargoItm = cargoItemRepository.getCargoIdByCargo(cargoId, ffpb.getProductId());
					List<CargoItemBatch> cargoItemBatches = cargoItemBatchRepository
							.getProductBatchBycIdAndpid(cargoItm.getId(), ffpb.getBatchNo(),ffpb.getProducerId());
					for (CargoItemBatch cib : cargoItemBatches) {
						IcatalogueBatch icatalogueBatch = icatalogueBatchRepository.getBatchDetails(ffpb.getProductId(),
								ffpb.getBatchNo(), icat.getId(),ffpb.getProducerId());
						Long openingStockBatch = 0L;
						Long closingStockBatch = 0L;
						if (icatalogueBatch != null) {
							Long totalStock = 0l;
							 openingStockBatch = icatalogueBatch.getAvailableStock();
							Long availableStock = icatalogueBatch.getAvailableStock() == null ? 0:icatalogueBatch.getAvailableStock() + ffpb.getQuantity();
							 closingStockBatch = availableStock ;
							totalStock = availableStock + icatalogueBatch.getAllocatedStk();
							icatalogueBatch.setAvailableStock(availableStock);
							icatalogueBatch.setTotalStock(totalStock);
							icatalogueBatch.setUpdatedOn(new Date());
//							icatalogueBatch.setManufacturedDate(ffpb.getManufacturedDate());
							icatalogueBatch.setUpdatedBy(fulfillModel.getUserId());
							icatalogueBatchRepository.save(icatalogueBatch);
							Long transactionId = insertFulFillTxnAndIcatlogue(fulfillModel, rStoreId, ffpb, icat,openingStockBatch,closingStockBatch,cib.getProducerId());
							jsonObject.put("transactionId", transactionId);
						} else if (icat != null && icatalogueBatch == null) {
							IcatalogueBatch icb = IcatalogueBatch.builder().allocatedStk(0l)
									.availableStock(ffpb.getQuantity()).totalStock(ffpb.getQuantity())
									.batchNo(ffpb.getBatchNo()).expiryDate(ffpb.getExpiryDate())
									.icatalogueId(icat.getId()).inTransitStock(0l)
									.manufacturedDate(ffpb.getManufacturedDate()).productId(ffpb.getProductId())
									.producerId(ffpb.getProducerId()).quantity(ffpb.getQuantity()).build();
							icb.setCreatedBy(fulfillModel.getUserId());
							icb.setUpdatedBy(fulfillModel.getUserId());
							openingStockBatch = 0L;
							closingStockBatch = ffpb.getQuantity();
							icatalogueBatchRepository.save(icb);
							Long transactionId = insertFulFillTxnAndIcatlogue(fulfillModel, rStoreId, ffpb, icat,openingStockBatch,closingStockBatch,cib.getProducerId());
							jsonObject.put("transactionId", transactionId);
						}
						Long disardQnty = ffpb.getShippedQuantity() - ffpb.getQuantity();
						cib.setDiscardedReasonId(ffpb.getReasonId());
						cib.setDiscardedStock(disardQnty);
						cib.setFulfilledStock(ffpb.getQuantity());
						cargoItemBatchRepository.save(cib);
					}
					Long cargofulfQuty = cargoItemBatchRepository.findSumOfCargoFulfill(cargoItm.getId());
					if (cargofulfQuty == null) {
						cargofulfQuty = 0L;
					}
					cargoItm.setFulfilledStock(cargofulfQuty);
					cargoItemRepository.save(cargoItm);
					BookingItems bkItems = bookingItemsRepository
							.findBookingItemByProductId(ffpb.getProductId().longValue(), bookingId);
					Long fulfillQuty = bookingItemBatchRepository.sumOffulfilQuantity(bkItems.getId());
					if (fulfillQuty == null) {
						fulfillQuty = 0L;
					}
					bkItems.setFulfilledStock(fulfillQuty);
					bookingItemsRepository.save(bkItems);

					StockDetailsDTO dto = icatalogueBatchRepository.getTotalAlc_Cur_Total_StockQuantity(icat.getId(),
							ffpb.getProductId());
					icat.setTotalStock(dto.getTotalStock());
					if (icat.getInTransitStock().equals(0L)) {
						icat.setInTransitStock(dto.getIntransitStock() == null ? 0 : dto.getIntransitStock());
					} else {
						Long intransitStk = icat.getInTransitStock() - ffpb.getShippedQuantity();
						icat.setInTransitStock(intransitStk);
					}
					icat.setAllocatedStock(dto.getAllocatedStock());
					icat.setCurrentStock(dto.getAvailableStock());
					icat.setUpdatedOn(new Date());
					icat.setUpdatedBy(fulfillModel.getUserId());
					icatalogueRepository.save(icat);
					Icatalogue icatalogue = icatalogueRepository.getIcatalogueDetailsBySidPidIcatId(rStoreId,
							ffpb.getProductId(), icat.getId());
					Long txId = (Long) jsonObject.get("transactionId");
					if (icatalogue.getTotalStock().equals(0L)) {
						abnormalTypeId = 200;
					} else if (icatalogue.getTotalStock() <= icatalogue.getMinStock()) {
						abnormalTypeId = 201;
					} else if (icatalogue.getTotalStock() >= icatalogue.getMaxStock()) {
						abnormalTypeId = 202;
					} else if (!icatalogue.getTotalStock().equals(0L)
							|| !(icatalogue.getTotalStock() <= icatalogue.getMinStock())
							|| !(icatalogue.getTotalStock() >= icatalogue.getMaxStock())) {
						abnormalTypeId = 0;
					}
					try {
						kafkaProducer.saveIcataLogueLogToKafka(ffpb.getProductId(), rStoreId,
								fulfillModel.getPranthId(), txnTypeId, txId, icat.getId(), fulfillModel.getUserId(),
								icatalogue.getIsDeleted(), abnormalTypeId);
					} catch (JsonProcessingException e) {
						e.printStackTrace();
						log.error("Exception Occured while saving Indent fulfil data in to Kafka Q.", e.getCause());
					}
					flag = true;
				} else {
					flag = false;
					responseBean.setMessage("No Inventory found for the Order" + bookingId);
					responseBean.setReturnCode(0);
					responseBean.setStatus(HttpStatus.BAD_REQUEST);
				}
			}
		}
		if (flag) {
			Bookings booking = bookingsRepository.getByBookingId(bookingId);
			if (booking.getStatusId().equals(7)) {
				booking.setStatusId(2);
				booking.setUpdatedBy(fulfillModel.getUserId());
				booking = bookingsRepository.save(booking);
				if (fulfillModel.getComments() != null) {
					UserComments bookingComments = UserComments.builder().bookingId(bookingId).cargoId(null)
							.comments(fulfillModel.getComments()).createdBy(booking.getCreatedBy())
							.createdOn(new Date()).entryFrom("Booking").build();
					userCommentsRepository.save(bookingComments);
				}
				BookingTracking bookingTracking = BookingTracking.builder().bookingId(booking.getId())
						.pranthId(booking.getPranthId()).storeId(booking.getIssuingStoreId())
						.statusId(booking.getStatusId()).build();
				bookingTracking.setCreatedBy(fulfillModel.getUserId());
				bookingTracking.setUpdatedBy(fulfillModel.getUserId());
				bookingTracking = bookingTrackingRepository.save(bookingTracking);
				responseBean.setMessage("booking fullfilment done for this booking id " + bookingId);
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
				try {
					kafkaProducer.saveBookingStausToKafka(
							fulfillModel.getComments() == null ? null : fulfillModel.getComments(),
							fulfillModel.getUserId(), fulfillModel.getBookingId(), fulfillModel.getCargoNo(),
							"FULFILLED");
					kafkaProducer.saveCargoStatusInCargoTopic(
							fulfillModel.getComments() == null ? null : fulfillModel.getComments(),
							fulfillModel.getUserId(), fulfillModel.getBookingId(), fulfillModel.getCargoNo(), cargoId,
							"FULFILLED");
				} catch (JsonProcessingException e) {
					e.printStackTrace();
					log.error("Exception Occured while indent/shipment saving to Kafka Q", e.getCause());
				}
			} else {
				responseBean.setMessage("shipment is not done for this booking");
			}
		}

		return responseBean;
	}

	private Long insertTxnIcatLogWithoutBatchProduct(FulfilCargoModel fulfillModel, Long rStoreId, FulfillProducts ffp,
			Long IcatId) throws CustomException {
		Icatalogue icatalogue = icatalogueRepository.getIcatalogueDetailsBySidPidIcatId(rStoreId, ffp.getProductId(),
				IcatId);
		Long closingStock = 0l;
		Long openingStock = 0l;
		Long openingStockBatch = 0l;
		Long closingStockBatch = 0l;
		if (icatalogue != null) {
			openingStock = icatalogue.getCurrentStock() - (ffp.getQuantity());
			closingStock = icatalogue.getCurrentStock();
		} else {
			log.error("Invntry not found for receving store while booking fullfillment");
			throw new CustomException();
		}
		Txn txn = Txn.builder().batchNo(null).destStoreId(fulfillModel.getIssuingStoreId()).icatalogueId(IcatId)
				.initialTxnDate(new Date()).openingStock(openingStock).closingStock(closingStock)
				.openingStockBatch(openingStockBatch).closingStockBatch(closingStockBatch)
				.pranthId(fulfillModel.getPranthId()).productId(ffp.getProductId())
				.reasonId(ffp.getReasonId() == null ? null : ffp.getReasonId()).sourceStoreId(rStoreId)
				.sourceType(fulfillModel.getSourceType())
				.cargoId(fulfillModel.getCargoId() == null ? null : fulfillModel.getCargoId()).stock(ffp.getQuantity())
				.txnTypeId(2).build();
		txn.setUpdatedBy(fulfillModel.getUserId());
		txn.setCreatedBy(fulfillModel.getUserId());
		Txn txnDetails = txnRepository.save(txn);
		if (txnDetails != null) {
			TxnLog txnLog = new TxnLog().builder().productId(Long.valueOf(ffp.getProductId()))
					.storeId(fulfillModel.getIssuingStoreId()).isActivityRead(false).isConsumptionRead(false)
					.txnDate(new Date()).txnTypeId(2).txnId(txnDetails.getId()).build();
			TxnLog tl = txnLogRepository.save(txnLog);
			if (tl != null) {
				insertConsumptionRecord(fulfillModel.getReceievingStoreId(), Long.valueOf(ffp.getProductId()), 2,
						ffp.getQuantity());
			}
			try {
				insertingInToTxnCountsLog(Long.valueOf(ffp.getProductId()),fulfillModel.getReceievingStoreId(), ffp.getQuantity(), txnDetails);
				insertingClosingStockData(Long.valueOf(ffp.getProductId()),fulfillModel.getReceievingStoreId(), IcatId, closingStock, ffp.getQuantity());
			} catch (Exception e) {
				log.info("Exception Occured while inserting closing stock details ");
			}				
			
		}
		Long txnId = txnDetails.getId();
		return txnId;
	}

	private Long updateIcatalogue(FulfilCargoModel fulfillModel, Long rStoreId, Integer productId, Long quantity,
			Long shippedQty) {
		Icatalogue icatalogue = icatalogueRepository.getDetailsOfIcatalouge(productId.longValue(), rStoreId);
		String message = "No Inventry found for this Product and Store ID please try to add Inventry and fulfill the order";
		if (icatalogue != null) {
			Long intransitStk = icatalogue.getInTransitStock() - shippedQty;
			Long currentStock = icatalogue.getCurrentStock() + quantity;
			Long totalStk = icatalogue.getAllocatedStock() + currentStock;
			icatalogue.setCurrentStock(currentStock);
			icatalogue.setTotalStock(totalStk);
			icatalogue.setInTransitStock(intransitStk);
			icatalogue.setUpdatedOn(new Date());
			icatalogue.setUpdatedBy(fulfillModel.getUserId());
			icatalogueRepository.save(icatalogue);
			message = "Success";
		}
		return icatalogue.getId();
	}

	private Long insertFulFillTxnAndIcatlogue(FulfilCargoModel fulfillModel, Long rStoreId, FulfillProductBatch ffpb,
			Icatalogue icat,Long openingStockBatch ,Long closingStockBatch,Integer producerId) throws CustomException {
		Long openingStock = icat.getCurrentStock();
		Long closingStock = openingStock + ffpb.getQuantity();
		Txn txn = Txn.builder().batchNo(ffpb.getBatchNo()).destStoreId(fulfillModel.getIssuingStoreId())
				.icatalogueId(icat.getId()).initialTxnDate(new Date()).openingStock(openingStock)
				.openingStockBatch(openingStockBatch).closingStockBatch(closingStockBatch).closingStock(closingStock)
				.pranthId(fulfillModel.getPranthId()).productId(ffpb.getProductId())
				.reasonId(ffpb.getReasonId() == null ? null : ffpb.getReasonId()).sourceStoreId(rStoreId)
				.cargoId(fulfillModel.getCargoId() == null ? null : fulfillModel.getCargoId())
				.sourceType(fulfillModel.getSourceType()).stock(ffpb.getQuantity()).txnTypeId(2).producerId(producerId).build();
		txn.setUpdatedBy(fulfillModel.getUserId());
		txn.setCreatedBy(fulfillModel.getUserId());
		Txn txnDetails = txnRepository.save(txn);
		if (txnDetails != null) {
			TxnLog txnLog = new TxnLog().builder().productId(Long.valueOf(ffpb.getProductId()))
					.storeId(fulfillModel.getIssuingStoreId()).isActivityRead(false).isConsumptionRead(false)
					.txnDate(new Date()).txnTypeId(2).txnId(txnDetails.getId()).build();
			TxnLog tl = txnLogRepository.save(txnLog);
			if (tl != null) {
				insertConsumptionRecord(fulfillModel.getIssuingStoreId(), Long.valueOf(ffpb.getProductId()), 2,
						ffpb.getQuantity());
			}
			try {
				insertingInToTxnCountsLog(Long.valueOf(ffpb.getProductId()),fulfillModel.getIssuingStoreId(), ffpb.getQuantity(), txnDetails);
				insertingClosingStockData(Long.valueOf(ffpb.getProductId()),fulfillModel.getIssuingStoreId(), icat.getId(), closingStock, ffpb.getQuantity());
			} catch (Exception e) {
				log.info("Exception Occured while inserting closing stock details ");
			}	
			
		}
		Long txnId = txnDetails.getId();
		return txnId;
	}

}
