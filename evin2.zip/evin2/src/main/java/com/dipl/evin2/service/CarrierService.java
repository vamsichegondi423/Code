package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.Carrier;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.CarrierRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CarrierService {

	@Autowired
	private CarrierRepository carrierRepository;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public Carrier getById(Long id) throws CustomException {
		try {
			Optional<Carrier> carrierOptional = carrierRepository.getById(id);
			if (carrierOptional.isPresent()) {
				return carrierOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public Carrier save(Carrier carrier) throws CustomException {
		try {
			if (carrier.getId() != null && carrier.getId() > 0) {
				Optional<Carrier> existingCarrierRecord = carrierRepository.getById(carrier.getId());
				if (existingCarrierRecord.isPresent()) {
					return carrierRepository.save(carrier);
				}
			} else {
				carrier = carrierRepository.save(carrier);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return carrier;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<Carrier> existingCarrierRecord = carrierRepository.getById(id);
			if (existingCarrierRecord.isPresent()) {
				carrierRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<Carrier> getAll() {
		try {
			return carrierRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public List<Map<String, Object>> getAllCarrierByFilter(String carrierName,Long carrierId,Pageable pageable) {
		
		List<Map<String, Object>> carrierRecords = null;
		String sql = "select c.id,c.carrier_name, c.contact_no,c.carrier_type , u.user_id as updatedBy,c.updated_on,c.city ,c.address,c.pin as pin_code, " + 
				" c.vehicle_list as vehicleDetails,m.name as country,ms.name as state,d.name as distict ,b.name as block " + 
				" from carrier c " + 
				" join users u on u.id = c.updated_by  " + 
				" left join master_country m on m.id = c.country_id " + 
				" left join master_state ms on ms.id = c.state_id " + 
				" left join master_district d on d.id = c.district_id " + 
				" left join master_block b on b.id = c.block_id  " ; 
				sql = addCarrierFilterPayload(carrierName, carrierId, sql);
				sql = sql + " limit " + pageable.getPageSize() + " OFFSET " + pageable.getOffset() ;
		return carrierRecords = jdbcTemplate.queryForList(sql);
	}

	private String addCarrierFilterPayload(String carrierName, Long carrierId, String sql) {
		if(carrierId != null && carrierId > 0 && carrierName != null && !carrierName.isEmpty()) {
		sql = sql + "where c.id = " + carrierId + " and  c.carrier_name  like '%"+ carrierName + "%'";
		}else if(carrierId != null && carrierId > 0){
			sql = sql + " where c.id = " + carrierId + "";
		}else if(carrierName != null && !carrierName.isEmpty()) {
			sql = sql + " where c.carrier_name  like '%" + carrierName + "%'";
		}
		return sql;
	}

	public Long getAllCarrierCount(String carrierName, Long carrierId) {
		Long carrierRecordsCount = null;
		String sql = "select count (distinct id) from ( select c.id,c.carrier_name, c.contact_no,c.carrier_type , u.user_id as updatedBy,c.updated_on,c.city ,c.address,c.pin as pin_code, " + 
				" c.vehicle_list as vehicleDetails,m.name as country,ms.name as state,d.name as distict ,b.name as block " + 
				" from carrier c " + 
				" join users u on u.id = c.updated_by  " + 
				" left join master_country m on m.id = c.country_id " + 
				" left join master_state ms on ms.id = c.state_id " + 
				" left join master_district d on d.id = c.district_id " + 
				" left join master_block b on b.id = c.block_id  " ; 
				sql = addCarrierFilterPayload(carrierName, carrierId, sql);
				sql = sql + ")a";
		return carrierRecordsCount = jdbcTemplate.queryForObject(sql, Long.class);
	}
}