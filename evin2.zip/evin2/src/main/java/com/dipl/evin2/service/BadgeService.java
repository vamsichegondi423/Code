package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.Badge;
import com.dipl.evin2.entity.BadgePranth;
import com.dipl.evin2.entity.MasterStatus;
import com.dipl.evin2.entity.PranthHierarchy;
import com.dipl.evin2.entity.ReasonPranth;
import com.dipl.evin2.entity.StatusPranth;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.BadgePranthRepository;
import com.dipl.evin2.repository.BadgeRepository;
import com.dipl.evin2.util.JdbcTemplateHelper;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BadgeService {

	@Autowired
	private BadgeRepository badgeRepository;

	@Autowired
	private BadgePranthRepository badgePranthRepository;

	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@Autowired
	private JdbcTemplateHelper jdbcTemplateHelper;

	private static final String QUERY_STRING = "select distinct b.id as id,b.name as name, b.badge_type_id as badgeTypeId, b.description as description, b.created_on as createdOn, b.is_deleted as isDeleted, b.created_by as createdBy, b.updated_by as updatedBy, b.updated_on as updatedOn, bp.pranth_id  as pranthId from badge b join badge_pranth bp on bp.badge_id = b.id where ";

	public Badge BadgeTypeId(Integer id) throws CustomException {
		Optional<Badge> badgeOptional = badgeRepository.getById(id);
		if (badgeOptional.isPresent()) {
			return badgeOptional.get();
		}
		return badgeOptional.get();
	}

	@Transactional(rollbackOn =  Exception.class)
	public Badge save(Badge badge, Long pranthId) throws CustomException {
		try {
			if (badge.getId() != null && badge.getId() > 0) {
				Optional<Badge> existingBadgeRecord = badgeRepository.getById(badge.getId());
				if (existingBadgeRecord.isPresent()) {
					BadgePranth findByPranthIdAndId = badgePranthRepository.findByPranthIdAndBadgeId(pranthId,badge.getId());
					if(findByPranthIdAndId != null && findByPranthIdAndId.getId() != null && findByPranthIdAndId.getId() > 0) {
						if(!findByPranthIdAndId.getIsActive()) {
							findByPranthIdAndId.setIsActive(true);
						}
						badgePranthRepository.save(findByPranthIdAndId);
					}else {
						BadgePranth badgePranth = BadgePranth.builder().pranthId(pranthId).badgeId(badge.getId()).build();
						badgePranthRepository.save(badgePranth);
					}
					return badgeRepository.save(badge);
				}
			} else {
				badge = badgeRepository.save(badge);
				if(badge.getId() > 0) {
					BadgePranth findByPranthIdAndId = badgePranthRepository.findByPranthIdAndBadgeId(pranthId,badge.getId());
					if(findByPranthIdAndId != null && findByPranthIdAndId.getId() != null && findByPranthIdAndId.getId() > 0) {
						if(!findByPranthIdAndId.getIsActive()) {
							findByPranthIdAndId.setIsActive(true);
						}
						badgePranthRepository.save(findByPranthIdAndId);
					} else {
						BadgePranth badgePranth = BadgePranth.builder().pranthId(pranthId).badgeId(badge.getId()).build();
						badgePranthRepository.save(badgePranth);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return badge;
	}

	public Integer deleteById(Integer id,Long pranthId) throws CustomException {
		try {
			Optional<Badge> existingBadgeRecord = badgeRepository.getById(id);
			if (existingBadgeRecord.isPresent()) {
				badgeRepository.deleteByIdSoft(id);
				BadgePranth existsBadgePranth = badgePranthRepository.findByPranthIdAndBadgeIdAndIsActiveTrue(pranthId, id);
				if(existsBadgePranth != null) {
					badgePranthRepository.deleteByIdSoft(existsBadgePranth.getId());
				}
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<Badge> getAll(Long pranthId) throws CustomException {
		List<Badge> badges= null;
		String query=null;
		query = QUERY_STRING + "bp.pranth_id = "+pranthId+" and is_deleted = false";
		badges= jdbcTemplateHelper.getResults(query, Badge.class);
		return badges;
	}

	public Badge getById(Integer id) {
		try {
			Optional<Badge> badgeOptional = badgeRepository.getById(id);
			if (badgeOptional.isPresent()) {
				return badgeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<Badge> getAllForBadgeTypeId(Integer badgeTypeId, Long pranthId) {
		List<Badge> badges= null;
		String query = null;
		try {
			if(badgeTypeId == null || badgeTypeId.equals(0)) {
				query = QUERY_STRING + "bp.pranth_id = "+pranthId+" and is_deleted = false";
				badges= jdbcTemplateHelper.getResults(query, Badge.class);
			}else {
				query = QUERY_STRING + "bp.pranth_id = "+pranthId+" and b.badge_type_id = "+badgeTypeId +" and  is_deleted = false";
				badges = jdbcTemplateHelper.getResults(query, Badge.class);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return badges;

	}

	public List<Badge> saveAll(List<Badge> bookingBadges, Long pranthId) {
		for(Badge badge : bookingBadges) {
			if (badge.getId() != null && badge.getId() > 0) {
				Optional<Badge> existingBadgeRecord = badgeRepository.getById(badge.getId());
				if (existingBadgeRecord.isPresent()) {
					BadgePranth findByPranthIdAndId = badgePranthRepository.findByPranthIdAndBadgeIdAndIsActiveTrue(pranthId,badge.getId());
					if(findByPranthIdAndId.getId() != null && findByPranthIdAndId.getId() > 0) {
						badgePranthRepository.save(findByPranthIdAndId);
					}else {
						BadgePranth badgePranth = BadgePranth.builder().pranthId(pranthId).badgeId(badge.getId()).build();
						badgePranthRepository.save(badgePranth);
					}
					badge = badgeRepository.save(badge);
				}
			} else {
				badge = badgeRepository.save(badge);
				if(badge.getId() > 0) {
					BadgePranth findByPranthIdAndId = badgePranthRepository.findByPranthIdAndBadgeIdAndIsActiveTrue(pranthId,badge.getId());
					if(findByPranthIdAndId != null && findByPranthIdAndId.getId() != null && findByPranthIdAndId.getId() > 0) {
						badgePranthRepository.save(findByPranthIdAndId);
					} else {
						BadgePranth badgePranth = BadgePranth.builder().pranthId(pranthId).badgeId(badge.getId()).build();
						badgePranthRepository.save(badgePranth);
					}
				}
			}
		}
		return bookingBadges;
	}

	public List<Badge> getAllByNameAndBadgeType(String name, Integer badgeTypeId, Long pranthId) throws CustomException {
		List<Badge> badges= null;
		String query = null;
		if(name != null  && !name.equalsIgnoreCase("")  && badgeTypeId != null && !badgeTypeId.equals(0)) {
			query = QUERY_STRING + "bp.pranth_id = "+pranthId+" and b.badge_type_id = "+badgeTypeId +" and name like '%"+name+"%' and  is_deleted = false";
			badges = jdbcTemplateHelper.getResults(query, Badge.class);
		}else if(badgeTypeId != null && !badgeTypeId.equals(0)) {
			query = QUERY_STRING + "bp.pranth_id = "+pranthId+" and b.badge_type_id = "+badgeTypeId +" and  is_deleted = false";
			badges = jdbcTemplateHelper.getResults(query, Badge.class);
		}else {
			query = QUERY_STRING + "bp.pranth_id = "+pranthId+" and is_deleted = false";
			badges= jdbcTemplateHelper.getResults(query, Badge.class);
		}
		return badges;

	}

	public List<Integer> getAllByIds(List<Integer> productBadgeIds, Long pranthId) {
		return badgeRepository.getAllByNameAndBadgeType(productBadgeIds, pranthId);
	}

	@Transactional(rollbackOn = { Exception.class , CustomException.class })
	public ResponseBean updateParentBadgeToChild(Long pranthId, Long mappedPranthId, Long userId)  throws CustomException{
		ResponseBean responseBean  = new ResponseBean();
		Long pranthid = 0L;
		List<BadgePranth> bpList= new ArrayList<>();
		Optional<PranthHierarchy> pranthHierarchy = pranthHierarchyService.getByMappingId(mappedPranthId);
		try {
			if(pranthHierarchy.isPresent()) {
				if(pranthId != null && pranthId != 0) {
					pranthid = pranthId;
				} else {
					pranthid = pranthHierarchy.get().getPranthId();
				}
				List<BadgePranth> badgePranthList = badgePranthRepository.getByPranthId(pranthid);
				for(BadgePranth bp: badgePranthList) {
					BadgePranth badgePranth = new BadgePranth();
					BadgePranth badgePranthObject = badgePranthRepository.findByPranthIdAndBadgeIdAndIsActiveTrue(mappedPranthId, bp.getBadgeId());
					if(badgePranthObject == null) {
						badgePranth = BadgePranth.builder()
								.pranthId(mappedPranthId).isActive(true).badgeId(bp.getBadgeId()).build();
						bpList.add(badgePranth);
					}
				}
				badgePranthRepository.saveAll(bpList);
				responseBean.setMessage("Badge has been updated for child");
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
			} else {
				responseBean.setMessage("No Record found with mappedPranthId");
				responseBean.setReturnCode(0);
				responseBean.setStatus(HttpStatus.NO_CONTENT);
			}
		}catch(Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseBean;
	}


}