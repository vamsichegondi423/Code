package com.dipl.evin2.service;

import java.io.IOException;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ExcelWorkBookCreationService {
	
	public Sheet createExcel() throws IOException {		
	Workbook workbook = new XSSFWorkbook();
	Sheet sheet = workbook.createSheet("ExportExCel");
	CellStyle rowCellStyle = workbook.createCellStyle();
	rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
	workbook.close();
	return sheet;
	}

}
