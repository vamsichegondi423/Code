package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.BookingItemProductBadge;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.BookingItemProductBadgeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BookingItemProductBadgeService {

	@Autowired
	private BookingItemProductBadgeRepository bookingItemProductBadgeRepository;

	public BookingItemProductBadge getById(Long id) throws CustomException {
		try {
			Optional<BookingItemProductBadge> bookingItemProductBadgeOptional = bookingItemProductBadgeRepository.getById(id);
			if (bookingItemProductBadgeOptional.isPresent()) {
				return bookingItemProductBadgeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public BookingItemProductBadge save(BookingItemProductBadge bookingItemProductBadge) throws CustomException {
		try {
			if (bookingItemProductBadge.getId() != null && bookingItemProductBadge.getId() > 0) {
				Optional<BookingItemProductBadge> existingBookingItemProductBadgeRecord = bookingItemProductBadgeRepository
						.getById(bookingItemProductBadge.getId());
				if (existingBookingItemProductBadgeRecord.isPresent()) {
					return bookingItemProductBadgeRepository.save(bookingItemProductBadge);
				}
			} else {
				bookingItemProductBadge = bookingItemProductBadgeRepository.save(bookingItemProductBadge);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return bookingItemProductBadge;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<BookingItemProductBadge> existingBookingItemProductBadgeRecord = bookingItemProductBadgeRepository
					.getById(id);
			if (existingBookingItemProductBadgeRecord.isPresent()) {
				bookingItemProductBadgeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<BookingItemProductBadge> getAll() {
		try {
			return bookingItemProductBadgeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}