/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReportStore implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "store_name")
    private String storeName;
    @Basic(optional = false)
    @Column(name = "store_id")
    private long storeId;
    @Column(name = "is_active")
    private Boolean isActive;
    @Column(name = "store_badge")
    private String storeBadge;
    @Column(name = "state_id")
    private Integer stateId;
    @Column(name = "district_id")
    private Integer districtId;
    @Column(name = "block_id")
    private Integer blockId;
    @Column(name = "city")
    private String city;
    @Column(name = "badge_id")
    private Long badgeId;
}
