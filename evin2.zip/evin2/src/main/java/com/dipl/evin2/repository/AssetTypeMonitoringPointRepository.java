package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import com.dipl.evin2.entity.AssetTypeMonitoringPoint;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface AssetTypeMonitoringPointRepository extends JpaRepository<AssetTypeMonitoringPoint, Long> {

	@Query(value = "select * from asset_type_monitoring_point where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<AssetTypeMonitoringPoint> getById(Long id);

	@Query(value = "select * from asset_type_monitoring_point where is_deleted = false", nativeQuery = true)
	public List<AssetTypeMonitoringPoint> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from asset_type_monitoring_point where id = ?1", nativeQuery = true)
	public void deleteById(Long id);
	
	@Modifying
	@Transactional
	@Query(value = "update asset_type_monitoring_point set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from asset_type_monitoring_point where asset_type_id = ?1 and is_deleted = false", nativeQuery = true)
	public List<AssetTypeMonitoringPoint> getByAssetType(Long assetTypeId);
	
}