package com.dipl.evin2.mongo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.model.MasterState;
import com.dipl.evin2.mongo.repository.StateRepository;
import com.dipl.evin2.mongo.services.StateService;

@RestController
@RequestMapping("/state")

public class StateController {

	@Autowired
	private StateRepository StateRepository;
	@Autowired
	private StateService stateService;

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public MasterState save(@RequestBody MasterState state) {
		stateService.save(state);
		return state;
	}

	@RequestMapping(value = "/getstate/{state_id}", method = RequestMethod.GET)
	public List<MasterState> getstate(@PathVariable(value = "state_id") String stateId) {
		return StateRepository.findByStateId(stateId);
	}

	@RequestMapping(value = "/getblock/{block_code}", method = RequestMethod.GET)
	public List<MasterState> getblocks(@PathVariable(value = "block_code") String blockCode) {
		return stateService.getblock(blockCode);
	}
}
