/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "icatalogue_log")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder 
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class IcatalogueLog extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Long id;
	@Basic(optional = false)
	@Column(name = "product_id")
	private Integer productId;
	@Column(name = "store_id")
	private Long storeId;
	@Column(name = "pranth_id")
	private Long pranthId;
	@Column(name = "txn_type_id")
	private Integer txnTypeId;
	@Column(name = "txn_id")
	private Long txnId;
	@Column(name = "notes")
	private String notes;
	@Column(name = "icatalogue_id")
	private Long icatalogueId;
	@Column(name = "date_start")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateStart;
	@Column(name = "date_end")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateEnd;
	@Column(name = "abnormal_type_id")
	private Integer abnormalTypeId;
	
	
}
