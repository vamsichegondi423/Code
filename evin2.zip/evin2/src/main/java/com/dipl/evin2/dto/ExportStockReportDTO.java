package com.dipl.evin2.dto;


import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExportStockReportDTO {
	
	private String productName;
	private String productBadge;
	private String storeName;
	private String storeBadge;
	private String countryName;
	private String stateName;
	private String districtName;
	private String block_name;
	private String city;
	private Long totalStock;
	private Long daysOfStock;
	private Long allocatedStock;
	private Long inTransitStock;
	private Long minStock;
	private Long maxStock;
	private String abnormalityType;
	private Double abnormalityDurationDays;
	private Date updatedOn;
	
	private String batchNo;
	private Long stockInBatch;
	private Date batchExpiry;
	private String batchManufacturer;
	private Date batchManufacturedDate;
	private Date batchUpdatedOn;
	

}