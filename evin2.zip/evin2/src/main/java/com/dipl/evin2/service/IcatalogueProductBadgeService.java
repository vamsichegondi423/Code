package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.IcatalogueProductBadge;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.IcatalogueProductBadgeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class IcatalogueProductBadgeService {

	@Autowired
	private IcatalogueProductBadgeRepository icatalogueProductBadgeRepository;

	public IcatalogueProductBadge getById(Long id) throws CustomException {
		try {
			Optional<IcatalogueProductBadge> icatalogueProductBadgeOptional = icatalogueProductBadgeRepository
					.getById(id);
			if (icatalogueProductBadgeOptional.isPresent()) {
				return icatalogueProductBadgeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public IcatalogueProductBadge save(IcatalogueProductBadge icatalogueProductBadge) throws CustomException {
		try {
			if (icatalogueProductBadge.getId() != null && icatalogueProductBadge.getId() > 0) {
				Optional<IcatalogueProductBadge> existingIcatalogueProductBadgeRecord = icatalogueProductBadgeRepository
						.getById(icatalogueProductBadge.getId());
				if (existingIcatalogueProductBadgeRecord.isPresent()) {
					return icatalogueProductBadgeRepository.save(icatalogueProductBadge);
				}
			} else {
				icatalogueProductBadge = icatalogueProductBadgeRepository.save(icatalogueProductBadge);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return icatalogueProductBadge;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<IcatalogueProductBadge> existingIcatalogueProductBadgeRecord = icatalogueProductBadgeRepository
					.getById(id);
			if (existingIcatalogueProductBadgeRecord.isPresent()) {
				icatalogueProductBadgeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<IcatalogueProductBadge> getAll() {
		try {
			return icatalogueProductBadgeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public List<IcatalogueProductBadge> getByIcatalogueId(Long id) {
		try {
			return icatalogueProductBadgeRepository.findByIcatalogueId(id);
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}