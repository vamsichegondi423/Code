package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.MasterTxnType;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.repository.MasterTxnTypeRepository;
import com.dipl.evin2.service.CacheEvictor;
import com.dipl.evin2.service.MasterTxnTypeService;
import com.dipl.evin2.service.RolePermissionConfigurationService;
import com.dipl.evin2.service.RolePermissionConfigurationService.RolePermissionConfigurationModel;
import com.dipl.evin2.service.UsersService;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.databind.JsonNode;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/master-txn-type")
public class MasterTxnTypeController {

	@Autowired
	private MasterTxnTypeService masterTxnTypeService;

	@Autowired
	private MasterTxnTypeRepository MasterTxnTypeRepository;
	
	@Autowired
	private UsersService usersService;

	@Autowired
	private RolePermissionConfigurationService rolePermissionConfigurationService;

	@Value(value = "${GATEWAY_URL}")
	private String gatewayUrl;
	
	@Autowired
	private CacheEvictor cacheEvictor;

	@ApiOperation("Use this api for saving or updating MasterTxnType. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody MasterTxnType masterTxnType, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			MasterTxnType exstngMasterTxnType = MasterTxnTypeRepository.getMasterTxnType(masterTxnType.getName());
			if(exstngMasterTxnType != null) {
				log.info("Transaction type name " + masterTxnType.getName() +  " already exist");
				responseBean.setMessage("Transaction type name " + masterTxnType.getName() +  " already exist");
				return responseBean;
			}
			if (masterTxnType.getId() != null && masterTxnType.getId() > 0) {
				MasterTxnType existingMasterTxnType = masterTxnTypeService.getById(masterTxnType.getId());
				if (existingMasterTxnType != null) {
					masterTxnType = masterTxnTypeService.save(masterTxnType);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(masterTxnType);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				masterTxnType = masterTxnTypeService.save(masterTxnType);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(masterTxnType);
			}
			cacheEvictor.evictAllCacheValues("txn_type");
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching MasterTxnType record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			MasterTxnType masterTxnType = masterTxnTypeService.getById(id);
			if (masterTxnType != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterTxnType);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting MasterTxnType record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = masterTxnTypeService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all MasterTxnType records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll(@RequestParam(required = true, value = "userId") Long userId, @RequestParam(required = true, value = "pranthId") Long pranthId) {
		if(userId == null) {
			return ResponseBean.builder().returnCode(0).message("UserId is mandatory").status(HttpStatus.BAD_REQUEST).build();
		}
		ResponseBean responseBean = new ResponseBean();
		try {
			Users users = usersService.getById(userId);

			List<Integer> hidingTxnIds = new ArrayList<>(); 

			RolePermissionConfigurationModel configurationModel = rolePermissionConfigurationService.getPermissionCodeValue("mner2", users.getRoleId(), pranthId);
			if(configurationModel != null && configurationModel.getConfiguredValue() != null && !configurationModel.getConfiguredValue().get("value").isNull() && ((JsonNode) configurationModel.getConfiguredValue()).asBoolean()) {
				hidingTxnIds.add(2);
			}
			configurationModel = rolePermissionConfigurationService.getPermissionCodeValue("mneinu18", users.getRoleId(), pranthId);
			if(configurationModel != null && configurationModel.getConfiguredValue() != null && !configurationModel.getConfiguredValue().get("value").isNull() && ((JsonNode) configurationModel.getConfiguredValue()).asBoolean()) {
				hidingTxnIds.add(1);
			}
			configurationModel = rolePermissionConfigurationService.getPermissionCodeValue("mned19", users.getRoleId(), pranthId);
			if(configurationModel != null && configurationModel.getConfiguredValue() != null && !configurationModel.getConfiguredValue().get("value").isNull() && ((JsonNode) configurationModel.getConfiguredValue()).asBoolean()) {
				hidingTxnIds.add(4);
			}
			configurationModel = rolePermissionConfigurationService.getPermissionCodeValue("mnesc10", users.getRoleId(), pranthId);
			if(configurationModel != null && configurationModel.getConfiguredValue() != null && !configurationModel.getConfiguredValue().get("value").isNull() && ((JsonNode) configurationModel.getConfiguredValue()).asBoolean()) {
				hidingTxnIds.add(3);
			}
			configurationModel = rolePermissionConfigurationService.getPermissionCodeValue("mnts8", users.getRoleId(), pranthId);
			if(configurationModel != null && configurationModel.getConfiguredValue() != null && !configurationModel.getConfiguredValue().get("value").isNull() && ((JsonNode) configurationModel.getConfiguredValue()).asBoolean()) {
				hidingTxnIds.add(5);
			}
			List<MasterTxnType> masterTxnTypeRecords = masterTxnTypeService.getAll();
			if(!hidingTxnIds.isEmpty()) {
				masterTxnTypeRecords = masterTxnTypeRecords.stream().filter(mtt -> !hidingTxnIds.contains(mtt.getId())).collect(Collectors.toList());
			}
			if (!masterTxnTypeRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterTxnTypeRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}

}