package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.Store;

@Repository
public interface StoreRepository extends JpaRepository<Store, Long> {

	@Query(value = "select * from store where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<Store> getById(Long storeId);
	
	@Query(value = "select * from store where id = ?1 and is_deleted = false", nativeQuery = true)
	public List<Store> getByStoreId(Long storeId);

	@Query(value = "select * from store where is_deleted = false", nativeQuery = true)
	public List<Store> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from store where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update store set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);
	
	@Query(value ="select * from store where name =?1 and is_deleted = false ", nativeQuery = true)
	public Store getStoreByStoreName(String name);
	
	@Query(value ="select * from store where name =?1 and is_deleted = false ", nativeQuery = true)
	public List<Store> getStoreByName(String name);
	
	@Query(value ="select * from store where pranth_id =?1  and name =?2 and is_deleted = false ", nativeQuery = true)
	public List<Store> getStoreByPranthId(Long pranthId,String name);
	
	@Query(value ="select * from store where name =?1 and state_id = ?2 and pranth_id = ?3  and is_deleted = false ", nativeQuery = true)
	public List<Store> getStoreByNameAndStateAndPranth(String name,Integer stateId, Long pranthId);
	
	@Query(value ="select * from store where name =?1 and state_id = ?2 and district_id = ?3 and pranth_id = ?4 and is_deleted = false ", nativeQuery = true)
	public List<Store> getStoreByNameAndStateAndDistrictAndPranth(String name,Integer stateId, Integer districtId, Long pranthId);
	
	@Query(value ="select * from store where name =?1 and state_id = ?2 and district_id = ?3  and block_id = ?4 and pranth_id = ?5 and is_deleted = false ", nativeQuery = true)
	public List<Store> getStoreByNameAndStateAndDistrictAndBlockAndPranth(String name,Integer stateId, Integer districtId, Integer blockId, Long pranthId);
	
	@Query(value ="select u.user_id,s.id as store_id,s.name as store_name,su.pranth_id,concat(s.city,', ',d.name,', ',st.name,', ',c.name) as location,  " + 
			"			string_agg(b.name,',') as badges from users u  " + 
			"			left join master_district d on d.id=u.district_id " + 
			"			left join master_state st on st.id=u.state_id  " + 
			"			left join master_country c on c.id=u.country_id  " + 
			"			left join store_users su on u.id=su.user_id and su.is_deleted = false " + 
			"			left join store s on s.id=su.store_id  and s.is_deleted = false " + 
			"			left join store_badge sb on s.id=sb.store_id and sb.is_deleted = false " + 
			"			left join badge b on b.id=sb.badge_id   and b.is_deleted = false " + 
			"			where u.is_deleted = false and u.id=?1 and su.pranth_id =?2 " + 
			"			group by 1,2,3,4,5  order by 1,2 ", nativeQuery = true)
	public List<Map<String, Object>> getAllStoresForUser(Integer userId, Integer pranthId,Pageable pageable);

	@Query(value = "select s.name as store_name,s.id as store_id, concat(s.city,', ',d.name,', ',st.name,', ',c.name,' ,',s.pin) as location,b.name as badge, " + 
			"s.updated_on as lastupdated,u.user_id as updated_by,u.user_id as userid,concat(u.f_name,' ',u.l_name) as username, " + 
			"concat(u.f_name,' ',u.l_name,'[',u.user_id,']') as dis_name,s.latitude,s.longitude " + 
			"from store s " + 
			"left join master_district d on d.id=s.district_id left join master_state st on st.id=s.state_id " + 
			"left join master_country c on c.id=s.country_id " + 
			"left join store_badge sb on sb.store_id=s.id left join badge b on b.id=sb.badge_id  " + 
			"left join users u on u.id=s.created_by " + 
			"left join master_badge_type mbt on mbt.id=b.badge_type_id and mbt.name='Store' " + 
			"where s.pranth_id=?1 and s.id=?2", nativeQuery = true)
	public Map<String, Object> getAllStoreDataByStoreId(Integer pranthId, Integer storeId);

	@Query(value = "select s.id as store_id,s.name as store_name,sm.mapping_type,sm.mapped_store_id,s1.name as mapped_store_name,"
			+ " concat(coalesce(d.name,''),', ',coalesce(st.name,'')) as mapped_store_location "
			+ " from store s "
			+ "left join store_mappings sm on s.id=sm.store_id  and sm.is_deleted = false "
			+ "  join store s1 on s1.id=sm.mapped_store_id and s1.is_deleted = false "
			+ " left join master_district d on d.id=s.district_id "
			+ "left join master_state st on st.id=s.state_id "
			+ " where s.id=?1  and sm.mapping_type=?2 and s.is_deleted = false ", nativeQuery = true)
	public List<Map<String, Object>> getMappingStores(Integer storeId,String mapType);

	@Query(value =" select s.pranth_id,s.id as store_id,s.name as store_name,ib.product_id,p.name as product_name,  pr.id as producer_id," + 
			" ib.available_stock,ib.allocated_stock,ib.updated_on,ib.in_transit_stock, " + 
			" ib.batch_no,to_char(ib.manufactured_date, 'yyyy-MM-dd') as manufactured_date ,pr.name as batch_producer_name," + 
			" to_char(ib.expiry_date, 'yyyy-MM-dd') as expiry_date,ib.total_stock, " + 
			" case when ib.expiry_date<current_date then true else false end as expired" + 
			" from icatalogue_batch ib "
			+ " join icatalogue i on i.id=ib.icatalogue_id and i.is_deleted = false " + 
			" left join product p on ib.product_id=p.id and p.is_deleted = false "
			+ "left join store s on s.id=i.store_id and s.is_deleted = false " + 
			" left join producer pr on pr.id=ib.producer_id  " + 
			" where ib.is_deleted = false and ib.total_stock > 0 and s.id= ?1 " + 
			" order by expiry_date asc ", nativeQuery = true)
	public List<Map<String, Object>> getProductsByBacth(Long storeId, Pageable pageable);

	@Query(value =" select s.pranth_id,s.id as store_id,s.name as store_name,ib.product_id,p.name as product_name,  pr.id as producer_id," + 
			" ib.available_stock,ib.allocated_stock,ib.updated_on,ib.in_transit_stock, " + 
			" ib.batch_no,to_char(ib.manufactured_date, 'yyyy-MM-dd HH:mm:ss') as manufactured_date ,pr.name as batch_producer_name," + 
			" to_char(ib.expiry_date, 'yyyy-MM-dd HH:mm:ss') as expiry_date,ib.total_stock, " + 
			" case when ib.expiry_date<current_date then true else false end as expired" + 
			" from icatalogue_batch ib "
			+ " join icatalogue i on i.id=ib.icatalogue_id and i.is_deleted = false " + 
			" left join product p on ib.product_id=p.id and p.is_deleted = false "
			+ "left join store s on s.id=i.store_id and s.is_deleted = false " + 
			" left join producer pr on pr.id=ib.producer_id  " + 
			" where ib.is_deleted = false and ib.total_stock > 0 and ib.product_id= ?1 and s.id= ?2 " + 
			" order by expiry_date asc ", nativeQuery = true)
	public List<Map<String, Object>> getProductsByBacth(Long productId, Long storeId, Pageable pageable);
}