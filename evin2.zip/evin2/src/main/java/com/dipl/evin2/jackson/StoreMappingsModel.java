package com.dipl.evin2.jackson;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class StoreMappingsModel {
	@JsonProperty( "id")
	private Integer id;
	@JsonProperty( "mapping_type")
	private String mappingType;
	@JsonProperty( "created_on")
	private Date createdOn;
	@JsonProperty( "is_deleted")
	private Boolean isDeleted;
	@JsonProperty( "store_id")
	private Long storeId;
	@JsonProperty( "mapped_strore_ids")
	private List<Long>  mappedStroreIds;

}
