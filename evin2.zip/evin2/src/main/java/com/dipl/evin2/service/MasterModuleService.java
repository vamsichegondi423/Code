package com.dipl.evin2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterModule;
import com.dipl.evin2.repository.MasterModuleRepository;

@Service
public class MasterModuleService {

	@Autowired
	private MasterModuleRepository masterModuleRepository;

	@Cacheable(value = "master-module", key = "#id")
	public MasterModule getById(Integer id) {
		Optional<MasterModule> masterModuleOptional = masterModuleRepository.getById(id);
		if (masterModuleOptional.isPresent()) {
			return masterModuleOptional.get();
		} else {
			return null;
		}
	}

	@CachePut(value = "master-module", key = "#masterModule.id")
	public MasterModule save(MasterModule masterModule) {
		if (masterModule.getId() != null && masterModule.getId() > 0) {
			Optional<MasterModule> existingMasterModuleRecord = masterModuleRepository.getById(masterModule.getId());
			if (existingMasterModuleRecord.isPresent()) {
				return masterModuleRepository.save(masterModule);
			}
		} else {
			masterModule = masterModuleRepository.save(masterModule);
		}
		return masterModule;
	}

	@CacheEvict(value = "master-module", allEntries = true)
	public Integer deleteById(Integer id) {
		Optional<MasterModule> existingMasterModuleRecord = masterModuleRepository.getById(id);
		if (existingMasterModuleRecord.isPresent()) {
			masterModuleRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	@Cacheable(value = "master-module")
	public List<MasterModule> getAll() {
		return masterModuleRepository.findAll();
	}

	public List<MasterModule> saveAll(List<MasterModule> monitoringPointSensors) {
		return masterModuleRepository.saveAll(monitoringPointSensors);
	}

}