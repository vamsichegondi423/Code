package com.dipl.evin2.dto;

import org.springframework.beans.factory.annotation.Value;

public interface AllocatedStockDTO {
	@Value(("#{target.booking_id}"))
	Long getBookingId();

	@Value(("#{target.receiving_store_name}"))
	String getReceivingStore();

	@Value(("#{target.ordered_stock}"))
	Long getOrderedStock();

	@Value(("#{target.allocated_stock}"))
	Long getAllocatedStock();

	@Value(("#{target.shipped_stock}"))
	Long getShippedStock();

	@Value(("#{target.yet_to_ship}"))
	Long getYetToShip();
}
