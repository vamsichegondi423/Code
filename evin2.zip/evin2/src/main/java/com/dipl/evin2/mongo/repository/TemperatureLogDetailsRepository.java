package com.dipl.evin2.mongo.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.dipl.evin2.model.TemperatureLogDetails;

public interface TemperatureLogDetailsRepository extends MongoRepository<TemperatureLogDetails, String>{
	


	@Query(value = "{'dId' : ?0, 'assetDId' :?1, 'sId' : ?2,isDeleted : false }")
	List<TemperatureLogDetails> findByDIdAndAssetDIdAndSIdAndIsDeletedFalse(String mappedSerialNumber, String assetSerialNumber, String sensorName);

	@Query("{'dId' :  ?0,'sId' : ?1, 'temperatureLogTime' : {$gte :?2 ,$lt : ?3} ,'isDeleted' : false}")
	List<TemperatureLogDetails> findByDIdAndTemperatureLogTimeAndSId(String assetSerialNumber,String sensorName,Date fromDate, Date toDate);
	
	@Query(value = "{'dId' : ?0, 'assetDId' :?1, 'temperatureLogTime' : {$gte :?2 ,$lt : ?3}, 'sId' : ?4,isDeleted : false }")
	List<TemperatureLogDetails> findByDIdAndAssetDIdAndTemperatureLogTimeAndSId(String mappedSerialNumber, String assetSerialNumber, Date fromDate ,Date toDate,String sensorName);

	@Query("{'dId' :  ?0,'sId' : ?1 ,'isDeleted' : false}")
	List<TemperatureLogDetails> findByDIdAndSIdAndIsDeletedFalse(String assetSerialNumber, String sensorName);
}
