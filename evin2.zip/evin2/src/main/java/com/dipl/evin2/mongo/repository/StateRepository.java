package com.dipl.evin2.mongo.repository;

import java.util.List;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.dipl.evin2.model.MasterState;

@Repository
@EnableAutoConfiguration
public interface StateRepository extends MongoRepository<MasterState, String> {
	
	@Query(value = "{ 'stateId' : ?0}", fields = "{ \"districts.districtCode\" : 0}")
	List<MasterState> findByStateId(String stateId);

	@Query(value = "{ 'districts.blocks.blockCode' : ?0 }", fields = "{ \"districts.districtCode.$\" : 1}")
	List<MasterState> findByBlockCode(String blockCode);
}
