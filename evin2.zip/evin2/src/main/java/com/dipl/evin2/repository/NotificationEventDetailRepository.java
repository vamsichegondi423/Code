package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import com.dipl.evin2.entity.NotificationEventDetail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface NotificationEventDetailRepository extends JpaRepository<NotificationEventDetail, Integer> {

	@Query(value = "select * from notification_event_details where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<NotificationEventDetail> getById(Integer id);

	@Query(value = "select * from notification_event_details where is_deleted = false", nativeQuery = true)
	public List<NotificationEventDetail> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from notification_event_details where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);
	
	@Modifying
	@Transactional
	@Query(value = "update notification_event_details set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

	@Query(value = "select * from notification_event_details ned join notification_event ne on ne.id = ned.notification_event_id\n"
			+ "join master_notification_event_type mne on mne.id = ne.notification_event_type_id where ne.notification_event_type_id = ?1\n"
			+ "and ned.is_deleted = false;", nativeQuery = true)
	public List<NotificationEventDetail> getAllByNotificationEventType(Integer notificationEventTypeId);

	@Query(value = "select * from notification_event_details where pranth_id = ?1 and is_deleted = false", nativeQuery = true)
	public List<NotificationEventDetail> findAllByPranthId(Long pranthid);
	
}