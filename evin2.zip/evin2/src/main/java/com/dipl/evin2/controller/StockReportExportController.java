package com.dipl.evin2.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.dto.StockReportPayload;
import com.dipl.evin2.model.FileReportResponse;
import com.dipl.evin2.service.SendEmailService;
import com.dipl.evin2.service.UploadFileService;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/report")
public class StockReportExportController {
	
	
	@Autowired
	private SendEmailService sendEmailService;
	
	@Autowired
	private UploadFileService uploadFileService;
	
	@PostMapping(value = "v1/stock-report-export", consumes = "application/json", produces = "application/json")
	public ResponseBean exportStockReportExcel(@RequestBody StockReportPayload stockReportPayload,String userName, String email) throws IOException {
		log.info("Requesting the API for getting the Stores Activity report..");
			return exportStockReport(stockReportPayload, userName , email);
	}



	private ResponseBean exportStockReport(StockReportPayload storesActivityModel,String userName, String email) throws IOException {
		ResponseBean responsebean = new ResponseBean();
//		List<StoresActivityResponseModel> activityResponseModel = null;
		Object fileData;
		String url = null;
		Workbook workbook = null;
		Sheet sheet = null;
		FileOutputStream outputStream = null;
		try {
//			activityResponseModel = fetchActiveReportRecords(storesActivityModel);
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0,cellIndex2 = 0, cellIndex3 = 0;
			//Creating Headers/Columns
			Row headerRow = sheet.createRow(0);

//			headerRow.createCell(cellIndex++).setCellValue("S.no");
//			headerRow.createCell(cellIndex++).setCellValue("State");
//			headerRow.createCell(cellIndex++).setCellValue("Total CCP");
//			headerRow.createCell(cellIndex++).setCellValue("Total CCP performed transactions on eVIN ");
//			headerRow.createCell(cellIndex++).setCellValue("Adherence Rate (%)");
//
//			//Displaying data under headers
//			for (int i = 0; i < activityResponseModel.size(); i++) {
//				Float  per = activityResponseModel.get(i).getPercentage();
//				DecimalFormat df = new DecimalFormat("##.##");
//				df.setRoundingMode(RoundingMode.DOWN);
//				Row dataRow = sheet.createRow(i+1);
//				int rowIndex1 = 0;
//				dataRow.createCell(rowIndex1++).setCellValue(i+1);
//				dataRow.createCell(rowIndex1++).setCellValue(activityResponseModel.get(i).getStateName() == null ? "": activityResponseModel.get(i).getStateName() + "");
//				dataRow.createCell(rowIndex1++).setCellValue(activityResponseModel.get(i).getTotalStores() == null ? 0: activityResponseModel.get(i).getTotalStores());
//				dataRow.createCell(rowIndex1++).setCellValue(activityResponseModel.get(i).getActiveStores() == null ? 0: activityResponseModel.get(i).getActiveStores());
//				dataRow.createCell(rowIndex1++).setCellValue(df.format(per));
//			}
//			// creating temporary excel file
			File tempFile = null;
			tempFile = File.createTempFile("ActivtyReport", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
			workbook.write(outputStream);
			// upload excel file
			HttpResponse<String> response = uploadFileService.uploadFile(url, userName, tempFile,"StockReport");
			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();
			tempFile.delete();
			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";
			HashMap<String, Object> emailbody = sendEmailService.getStockReportEmail(link, userName, email);

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, userName, email,
					fileDownloadUrl, fileType, fileName, fileSystemPath);

			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
					+ email
					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
			responsebean.setReturnCode(1);
			responsebean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured while exporting transacton report : ", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting transacton report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		finally {
			workbook.close();
			outputStream.close();
		}
		return responsebean;
	}
}
