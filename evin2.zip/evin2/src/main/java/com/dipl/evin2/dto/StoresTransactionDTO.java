package com.dipl.evin2.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class StoresTransactionDTO {
	private StoresDTO storeDto;
	private ProductDTO productDto;
	private Long txnId;
	private String storeLocation;
	private String storeBadge;
	private String productBadge;
	private String transactionReason;
	private Long openingStock;
	private String transactionTypeOperation;
	private Long quantity;
	private Long closingStock;
	private Date timeStamp;
	private String userId;
	private String firstName;
	private String lastName;
	private Integer sourceType;
	private Date intialTxnDate;
	private Long storeCount;
	private String materialStatus;
	
	
}

