package com.dipl.evin2.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterOrderType;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterOrderTypeRepository;
import com.dipl.evin2.repository.StoreBadgeRepository;
import com.dipl.evin2.repository.UserBadgeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterOrderTypeService {

	@Autowired
	private MasterOrderTypeRepository masterOrderTypeRepository;
	@Autowired
	private  UserBadgeRepository UserBadgeRepository;

	@Cacheable(value = "order-type", key = "#id")
	public MasterOrderType getById(Integer id) throws CustomException {
		try {
			Optional<MasterOrderType> masterOrderTypeOptional = masterOrderTypeRepository.getById(id);
			if (masterOrderTypeOptional.isPresent()) {
				return masterOrderTypeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "order-type", key = "#masterOrderType.id")
	public MasterOrderType save(MasterOrderType masterOrderType) throws CustomException {
		try {
			if (masterOrderType.getId() != null && masterOrderType.getId() > 0) {
				Optional<MasterOrderType> existingMasterOrderTypeRecord = masterOrderTypeRepository
						.getById(masterOrderType.getId());
				if (existingMasterOrderTypeRecord.isPresent()) {
					return masterOrderTypeRepository.save(masterOrderType);
				}
			} else {
				masterOrderType = masterOrderTypeRepository.save(masterOrderType);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterOrderType;
	}

	@CacheEvict(value = "order-type", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterOrderType> existingMasterOrderTypeRecord = masterOrderTypeRepository.getById(id);
			if (existingMasterOrderTypeRecord.isPresent()) {
				masterOrderTypeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "order-type")
	public List<MasterOrderType> getAll(Long userId) throws Exception {
		List<MasterOrderType> result = null;
		List<String> badges = null;
		if (userId != null) {
			badges = UserBadgeRepository.getBadgeInfoByuid(userId);
			if (badges!= null && !badges.isEmpty()) {
				boolean isBadgeAvilable = badges.stream().anyMatch(badge -> badge.equals("SVFM"));
				boolean isBadge = badges.stream().anyMatch(badge -> badge.equals("CCH"));
				if (isBadgeAvilable) {
					result = masterOrderTypeRepository.findMasterOrderType();
				} else if (isBadge) {
					result = masterOrderTypeRepository.findMasterOrderTypeForCch();
				} else {
					result = masterOrderTypeRepository.findAll();
				}
			} else {
				result = masterOrderTypeRepository.findAll();
			}
		} else {
				 result = masterOrderTypeRepository.findAll();
			}
			return result;
	}
}