/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "bookings")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Bookings extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Long id;
	@Column(name = "order_type_id")
	private Integer orderTypeId;
	@Column(name = "issuing_store_id")
	private Long issuingStoreId;
	@Column(name = "receiving_store_id")
	private Long receivingStoreId;
	@Column(name = "pranth_id")
	private Long pranthId;
	@Column(name = "status_id")
	private Integer statusId;
	@Column(name = "arrival_date")
	@Temporal(TemporalType.DATE)
	private Date arrivalDate;
	@Column(name = "receipt_date")
	@Temporal(TemporalType.DATE)
	private Date receiptDate;
	@Column(name = "order_reference_no")
	private String orderReferenceNo;
	@Column(name = "comments")
	private String comments;
	@Column(name = "items_count")
	private Integer itemsCount;
	@Column(name = "badge_id")
	private Integer badgeId;
	@Column(name = "transfer_reference_no")
	private String transferReferenceNo;
	@Column(name = "source_type")
	private Integer srcType;
	@Column(name = "reason")
	private String reason;

	@Column(name = "confirm_start_date")
	@Temporal(TemporalType.DATE)
	private Date confirmStartDate;

	@Column(name = "confirm_end_date")
	@Temporal(TemporalType.DATE)
	private Date confirmEndDate;

	@Transient
	private Long bookingBadge;

	@Transient
	private List<ProductBooking> productBookings;

	@Transient
	private Integer transactionType;

	@Transient
	private String sourceType;

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper = false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ProductBooking {
		private Integer productId;
		private Long quantity;
		private String reason;
		private String modifiedReason;
		private Long recommendedQuantity;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class BookingProducts extends ProductBooking {
		private Long bookingItemId;
	}

	public static void main(String[] args) throws JsonProcessingException {
		System.out.println(new ObjectMapper().writeValueAsString(new Bookings()));
		System.out.println(new ObjectMapper().writeValueAsString(new ProductBooking()));
	}

}
