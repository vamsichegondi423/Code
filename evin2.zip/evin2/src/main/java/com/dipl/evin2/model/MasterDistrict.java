package com.dipl.evin2.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MasterDistrict implements Serializable {

    
    private static final long serialVersionUID = 1L;
    
    private Integer id;
    
    @JsonProperty("district_code")
    private String districtCode;
    
    @JsonProperty("district_name_eng")
    private String districtNameEng;
    
   
    @JsonProperty("district_short_name")
    private String districtShortName;
    
    private Integer Code1;
    
    private Integer Code2;
    
    @JsonProperty("pesa_status")
    private String pesaStatus;
    
    @JsonProperty("is_active")
    private Boolean isActive;
    
    private List<MasterBlock> blocks = new ArrayList<>();
    
}
