package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.NotificationEventDetail;
import com.dipl.evin2.service.NotificationEventDetailService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/notification-event-details")
public class NotificationEventDetailController {

	@Autowired
	private NotificationEventDetailService notificationEventDetailService;

	@ApiOperation("Use this api for saving or updating NotificationEventDetail. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody @Valid NotificationEventDetail notificationEventDetail, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				List<String> errors = result.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.toList());
				return ResponseBean.builder().data(StringUtils.collectionToCommaDelimitedString(errors)).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (notificationEventDetail.getId() != null && notificationEventDetail.getId() > 0) {
				NotificationEventDetail existingNotificationEventDetail = notificationEventDetailService.getById(notificationEventDetail.getId());
				if (existingNotificationEventDetail != null) {
					notificationEventDetail.setCreatedBy(existingNotificationEventDetail.getCreatedBy());
					notificationEventDetail.setCreatedOn(existingNotificationEventDetail.getCreatedOn());
					notificationEventDetail.setUpdatedOn(new Date());
					notificationEventDetail = notificationEventDetailService.save(notificationEventDetail);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(notificationEventDetail);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				notificationEventDetail.setCreatedBy(notificationEventDetail.getUpdatedBy());
				notificationEventDetail.setCreatedOn(new Date());
				notificationEventDetail.setUpdatedOn(new Date());
				notificationEventDetail = notificationEventDetailService.save(notificationEventDetail);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(notificationEventDetail);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching NotificationEventDetail record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			NotificationEventDetail notificationEventDetail = notificationEventDetailService.getById(id);
			if (notificationEventDetail != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(notificationEventDetail);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting NotificationEventDetail record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = notificationEventDetailService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all NotificationEventDetail records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<NotificationEventDetail> notificationEventDetailRecords = notificationEventDetailService.getAll();
			if (!notificationEventDetailRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(notificationEventDetailRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
	
	@ApiOperation("Use this api for fetching all NotificationEventDetail records by notification event type")
	@GetMapping(value = "/v1/get-all-by-notification-event-type/{notificationEventTypeId}", produces = "application/json")
	public ResponseBean getAllByNotificationEventType(@PathVariable("notificationEventTypeId") Integer notificationEventTypeId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<NotificationEventDetail> notificationEventDetailRecords = notificationEventDetailService.getAllByNotificationEventType(notificationEventTypeId);
			if (!notificationEventDetailRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(notificationEventDetailRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
	
	@ApiOperation("Use this api for updating system configurations to child pranth.")
	@GetMapping(value = "/v1/update-system-config-to-child/{userId}", produces = "application/json")
	public ResponseBean updateParentNotificationEventDetailsToChild(@PathVariable(value = "userId") Long userId,@RequestParam(value = "pranthId",required = false) Long pranthId , @RequestParam(value = "mappedPranthId") Long mappedPranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			responseBean = notificationEventDetailService.updateParentNotificationEventDetailsToChild(pranthId, mappedPranthId, userId);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occurred");
		}
		return responseBean;
	}
}