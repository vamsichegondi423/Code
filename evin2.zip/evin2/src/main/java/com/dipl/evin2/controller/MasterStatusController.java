package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.MasterStatus;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterStatusRepository;
import com.dipl.evin2.service.CacheEvictor;
import com.dipl.evin2.service.MasterStatusService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/master-status")
public class MasterStatusController {

	@Autowired
	private MasterStatusService masterStatusService;
	
	@Autowired
	private MasterStatusRepository masterStatusRepository;
	
	@Autowired
	private CacheEvictor cacheEvictor;

	@ApiOperation("Use this api for saving or updating MasterStatus. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody @Valid MasterStatus masterStatus, BindingResult result, @RequestParam("pranthId") Long pranthId) {
		masterStatus.setPranthId(pranthId);
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			Integer exstngMasterStatus = masterStatusRepository.getMasterStatus(masterStatus.getName(), masterStatus.getStatusType(), pranthId);
			if(exstngMasterStatus > 0) {
				log.info("Status name " + masterStatus.getName() + " with status type " + masterStatus.getStatusType() + " already exist");
				responseBean.setMessage("Status name " + masterStatus.getName() + " with status type " + masterStatus.getStatusType() + " already exist");
				return responseBean;
			}
			if (masterStatus.getId() != null && masterStatus.getId() > 0) {
				MasterStatus existingMasterStatus = masterStatusService.getById(masterStatus.getId());
				if (existingMasterStatus != null) {
					masterStatus.setCreatedBy(existingMasterStatus.getCreatedBy());
					masterStatus.setCreatedOn(existingMasterStatus.getCreatedOn());
					masterStatus.setUpdatedOn(new Date());
					masterStatus = masterStatusService.save(masterStatus,pranthId);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(masterStatus);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				masterStatus.setCreatedBy(masterStatus.getUpdatedBy());
				masterStatus.setCreatedOn(new Date());
				masterStatus.setUpdatedOn(new Date());
				masterStatus = masterStatusService.save(masterStatus,pranthId);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(masterStatus);
			}
			cacheEvictor.evictAllCacheValues("status");
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}


	@ApiOperation("Use this api for saving or updating list MasterStatus. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/save-or-update-list")
	@Transactional(rollbackFor = Exception.class)
	public ResponseBean saveList(@RequestBody @Valid List<MasterStatus> masterStatuses, BindingResult result, @RequestParam("pranthId") Long pranthId) throws CustomException{
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			masterStatuses.forEach(masterStatus -> {
				masterStatus.setPranthId(pranthId);
				masterStatus.setCreatedBy(masterStatus.getUpdatedBy());
				masterStatus.setCreatedOn(new Date());
				masterStatus.setUpdatedOn(new Date());
				masterStatus = masterStatusService.save(masterStatus,pranthId);
			});
			cacheEvictor.evictAllCacheValues("status");
			log.info("Record saved successfully");
			responseBean.setMessage("Record saved successfully");
			responseBean.setData(masterStatuses);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}


	@ApiOperation("Use this api for fetching MasterStatus record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			MasterStatus masterStatus = masterStatusService.getById(id);
			if (masterStatus != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterStatus);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting MasterStatus record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Integer id, @RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = masterStatusService.deleteById(id,pranthId);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all MasterStatus records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll(@RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<MasterStatus> masterStatusRecords = masterStatusService.getAll(pranthId);
			if (!masterStatusRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterStatusRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all MasterStatus records By status type. No params required.")
	@GetMapping(value = "/v1/getstatusbytype/{statustype}", produces = "application/json")
	public ResponseBean getStatusByType(@PathVariable("statustype") String statusType, @RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<MasterStatus> masterStatusRecords = masterStatusService.getStatusByType(statusType, pranthId);
			if (!masterStatusRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterStatusRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}


	@ApiOperation("Use this api for updating MasterStaus to child pranth.")
	@GetMapping(value = "/v1/update-status-to-child/{userId}", produces = "application/json")
	public ResponseBean updateParentStatusToChild(@PathVariable(value = "userId") Long userId,@RequestParam(value = "pranthId",required = false) Long pranthId , @RequestParam(value = "mappedPranthId") Long mappedPranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			responseBean = masterStatusService.updateParentStatusToChild(pranthId, mappedPranthId, userId);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occurred");
		}
		return responseBean;
	}

}