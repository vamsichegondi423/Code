/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "icatalogue")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(builderClassName = "IcatalogueBuilder") 
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Icatalogue extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Long id;
	@Column(name = "pranth_id")
	private Long pranthId;
	@Column(name = "store_id")
	private Long storeId;
	@Column(name = "product_id")
	private Integer productId;
	// @Max(value=?) @Min(value=?)//if you know range of your decimal fields
	// consider using these annotations to enforce field validation
	@Builder.Default
	@Column(name = "total_stock")
	private Long totalStock =  0L;
	@Builder.Default
	@Column(name = "current_stock")
	private Long currentStock =  0L;
	@Builder.Default
	@Column(name = "allocated_stock")
	private Long allocatedStock =  0L;
	@Builder.Default
	@Column(name = "in_transit_stock")
	private Long inTransitStock =  0L;
	@Builder.Default
	@Column(name = "days_of_stock")
	private Long daysOfStock =  0L;
	@Column(name = "min_stock")
	private Long minStock;
	@Column(name = "max_stock")
	private Long maxStock;
	@Transient
	private List<IcatalogueProductBadge> productBadges;
	@Transient
	private List<IcatalogueStoreBadge> storeBadges;
	@Transient
	private Integer txnTypeId;
	@Transient
	private Long txnId;
	@Transient
	private String notes;
	
}
