package com.dipl.evin2.dto;

import java.util.Date;

import com.dipl.evin2.util.Constants;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class ProductDTO {
	private Integer pranthId;
	private Integer storeId;
	private String storeName;
	private Integer productId;
	private String  productName;
	private String batchId;
	//@JsonFormat(pattern = Constants.DATE_FORMATE)
	private Date batchManufacturerDate;
	private String batchManufacturerName;
	//@JsonFormat(pattern = Constants.DATE_FORMATE)
	private Date batchExpiry;
	private Long totalStock;
	private Boolean isBatchEnabled;
}
