package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.entity.MasterCommunicationChannel;
import com.dipl.evin2.repository.MasterCommunicationChannelRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterCommunicationChannelService {

	@Autowired
	private MasterCommunicationChannelRepository masterCommunicationChannelRepository;

	@Cacheable(value = "communicaton-channel", key = "#id")
	public MasterCommunicationChannel getById(Integer id) {
		Optional<MasterCommunicationChannel> masterCommunicationChannelOptional = masterCommunicationChannelRepository
				.getById(id);
		if (masterCommunicationChannelOptional.isPresent()) {
			return masterCommunicationChannelOptional.get();
		} else {
			return null;
		}
	}

	@CachePut(value = "communicaton-channel", key = "#masterCommunicationChannel.id")
	public MasterCommunicationChannel save(MasterCommunicationChannel masterCommunicationChannel)
			throws CustomException {
		try {
			if (masterCommunicationChannel.getId() != null && masterCommunicationChannel.getId() > 0) {
				Optional<MasterCommunicationChannel> existingMasterCommunicationChannelRecord = masterCommunicationChannelRepository
						.getById(masterCommunicationChannel.getId());
				if (existingMasterCommunicationChannelRecord.isPresent()) {
					return masterCommunicationChannelRepository.save(masterCommunicationChannel);
				}
			} else {
				masterCommunicationChannel = masterCommunicationChannelRepository.save(masterCommunicationChannel);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterCommunicationChannel;
	}

	@CacheEvict(value = "communicaton-channel", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterCommunicationChannel> existingMasterCommunicationChannelRecord = masterCommunicationChannelRepository
					.getById(id);
			if (existingMasterCommunicationChannelRecord.isPresent()) {
				masterCommunicationChannelRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "communicaton-channel")
	public List<MasterCommunicationChannel> getAll() {
		try {
			return masterCommunicationChannelRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}