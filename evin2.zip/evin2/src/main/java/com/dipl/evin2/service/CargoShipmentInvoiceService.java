package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dipl.evin2.entity.Bookings;
import com.dipl.evin2.entity.Cargo;
import com.dipl.evin2.model.BookingInvoiceModel;
import com.dipl.evin2.model.BookingInvoiceModel.BookingInvoiceItemBatches;
import com.dipl.evin2.model.BookingInvoiceModel.BookingInvoiceItems;
import com.dipl.evin2.model.BookingInvoiceModel.Parameters;
import com.dipl.evin2.repository.BookingsRepository;
import com.dipl.evin2.repository.CargoItemBatchRepository;
import com.dipl.evin2.repository.CargoShipmentInvoiceRepository;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CargoShipmentInvoiceService {
	
	@Autowired
	private CargoShipmentInvoiceRepository cargoShipmentInvoiceRepository;
	
	@Autowired
	private CargoItemBatchRepository cargoItemBatchRepository;
	
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private BookingsRepository bookingsRepository;

	@Value("${BASE_URL}")
	private String baseUrl;
	
	
	public ResponseBean generateShipmentInvoice(String shippingId) {
		ResponseBean responseBean = new ResponseBean();

		BookingInvoiceModel shipmentInvoiceModel = new BookingInvoiceModel();

		List<Map<String, Object>> shipmentInvoiceData = cargoShipmentInvoiceRepository.getCargoShipmentInvoiceData(shippingId);

		Cargo bookingIdByCargoNumber =  cargoShipmentInvoiceRepository.getBookingIdByCargoNo(shippingId);
		
		Long bookingId = bookingIdByCargoNumber.getBookingId();
		
		Bookings bookingStatus =  bookingsRepository.getStatusByBookingId(bookingId);

		
		if (!shipmentInvoiceData.isEmpty()) {
			
			Set<BookingInvoiceItems> shipmentInvoiceItemsList = new HashSet<>();

			for (Map<String, Object> shipmentdata : shipmentInvoiceData) {
				BookingInvoiceItems shipmentInvoiceItem = new BookingInvoiceItems();

				shipmentInvoiceModel.setIssuingStoreName(shipmentdata.get("issuing_store_name")==null?"":shipmentdata.get("issuing_store_name").toString());
				shipmentInvoiceModel.setIssuingStoreState(shipmentdata.get("issuing_state_name")==null?"":shipmentdata.get("issuing_state_name").toString());

				shipmentInvoiceModel.setIssuingStoreDistrict(shipmentdata.get("issing_store_district")==null?"":shipmentdata.get("issing_store_district").toString());
				shipmentInvoiceModel.setReceievingStoreName(shipmentdata.get("receiving_store_name")==null?"":shipmentdata.get("receiving_store_name").toString());
				shipmentInvoiceModel.setReceievingStoreState(shipmentdata.get("receiving_state_name")==null?"":shipmentdata.get("receiving_state_name").toString());
				shipmentInvoiceModel.setReceievingStoreDistrict(shipmentdata.get("receiving_district_name")==null?"":shipmentdata.get("receiving_district_name").toString());
				shipmentInvoiceModel.setShipmentId(shipmentdata.get("cargo_no")==null?"":shipmentdata.get("cargo_no").toString());
				shipmentInvoiceModel.setIssueReference(shipmentdata.get("order_reference_no")==null?"":shipmentdata.get("order_reference_no").toString());
				shipmentInvoiceModel.setReceiptReference(shipmentdata.get("issue_reference_no") == null ? ""
						: shipmentdata.get("issue_reference_no").toString());
				shipmentInvoiceModel.setInvoiceDate(shipmentdata.get("invoice_date")==null?"":shipmentdata.get("invoice_date").toString());
				shipmentInvoiceModel.setDateOfSupply(
						shipmentdata.get("date_of_supply") == null ? null : shipmentdata.get("date_of_supply").toString());
				if(bookingStatus.getStatusId() == 2) {
				shipmentInvoiceModel.setDateOfReceipt(
						shipmentdata.get("date_of_receipt") == null ? null : shipmentdata.get("date_of_receipt").toString());
				}
				shipmentInvoiceItem.setName(shipmentdata.get("product_name")==null?"":shipmentdata.get("product_name").toString());

				shipmentInvoiceItem.setQuantity(shipmentdata.get("ordered_stock")==null?"":shipmentdata.get("ordered_stock").toString());
				shipmentInvoiceItem.setRecommended(shipmentdata.get("recommanded_stock")==null?"":shipmentdata.get("recommanded_stock").toString());
			
				shipmentInvoiceItem.setRemarks(shipmentdata.get("remarks")==null?"":shipmentdata.get("remarks").toString());
				List<BookingInvoiceItemBatches> shipmentItemBatches = new ArrayList<BookingInvoiceItemBatches>();
				if (shipmentdata.get("is_batch_enabled").toString() == "true") {
					Long cargoItemId = Long.parseLong(shipmentdata.get("cargo_item_id").toString());
					List<Map<String, Object>> batchDetails = cargoItemBatchRepository
							.getCargoItemBatchByCargoItemId(cargoItemId);
					for (Map<String, Object> details : batchDetails) {
						BookingInvoiceItemBatches shipmentInvoiceItemBatches = new BookingInvoiceItemBatches();
						shipmentInvoiceItemBatches.setBatchId(details.get("batch_no")==null?"":details.get("batch_no").toString());
						shipmentInvoiceItemBatches.setExpiryDate(details.get("batch_expiry_date")==null?"":details.get("batch_expiry_date").toString());
						shipmentInvoiceItemBatches.setQuantity(details.get("cargo_stock")==null?"":details.get("cargo_stock").toString());
						shipmentInvoiceItemBatches.setManufacturer(details.get("manufacturer") != null ? details.get("manufacturer").toString()
								:"");
						// add shipment invoice item batches into shipment item batches
						shipmentItemBatches.add(shipmentInvoiceItemBatches);
					}

				}
				// set shipment item batches into shipment invoice item
				shipmentInvoiceItem.setBookingItemBatches(shipmentItemBatches);
				// add shipment invoice item  into shipment invoice items
				shipmentInvoiceItemsList.add(shipmentInvoiceItem);

			}
			shipmentInvoiceModel.setBookingItems(new ArrayList<>(shipmentInvoiceItemsList));

		}
		// set shipment invoice items data into shipment invoice model
		// Shipment invoice pdf generate code
		Parameters parameters = new Parameters();
		parameters.setId(2);
		parameters.setFileType("pdf");
		shipmentInvoiceModel.setParameters(parameters);
		try {
			ObjectMapper mapper = new ObjectMapper();
			ResponseBean response= new ResponseBean();
			Object data;

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);			
			response.setData(shipmentInvoiceModel);
			String json = new Gson().toJson(response);
			log.info("json :"+json);
			HttpEntity<String> requestEntity = new HttpEntity<>(json, headers);
			String shipmentInvoiceResponse = restTemplate.postForObject(baseUrl + "jasper/nojwt/generate", requestEntity, String.class);
			HashMap<String, Object> responseObj = mapper.readValue(shipmentInvoiceResponse, HashMap.class);
			data = responseObj.get("data");
			String shipmentJson = new Gson().toJson(data);
			log.info("shipmentJson:"+shipmentJson);
			HashMap<String,Object> reportResponse = mapper.readValue(shipmentJson, HashMap.class);
			String shipmentInvoicePdfGenerationUrl = reportResponse.get("viewPath").toString();
			Map<String,Object> shipmentinvoicemap = new HashMap<>();
			shipmentinvoicemap.put("downloadurlpath", shipmentInvoicePdfGenerationUrl);
			responseBean.setData(shipmentinvoicemap);
			responseBean.setMessage("Shipment Invoice Generated Successfully");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);		
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
			responseBean.setMessage("Shipment Invoice Generation failed");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.BAD_REQUEST);
		}
		return responseBean;
	}

}