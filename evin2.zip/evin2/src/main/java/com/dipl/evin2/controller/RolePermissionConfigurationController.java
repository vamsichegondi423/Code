package com.dipl.evin2.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.RolePermissionConfiguration;
import com.dipl.evin2.service.RolePermissionConfigurationService;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/role-permission-configuration")
public class RolePermissionConfigurationController {

	@Autowired
	private RolePermissionConfigurationService rolePermissionConfigurationService;

	@ApiOperation("Use this api for saving or updating RolePermissionConfiguration. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody @Valid List<RolePermissionPayload> rolePermissionPayloadList, BindingResult result, @RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message(result.getAllErrors().get(0).getDefaultMessage()).status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occurred", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			RolePermissionConfiguration rolePermissionConfiguration = null;
			for(RolePermissionPayload rolePermissionPayload : rolePermissionPayloadList) {
				rolePermissionConfiguration = RolePermissionConfiguration.builder().pranthId(pranthId).configuredValue(rolePermissionPayload.getConfiguredValue()).permissionId(rolePermissionPayload.getPermissionId()).roleId(rolePermissionPayload.getRoleId()).build();
				RolePermissionConfiguration existingRolePermissionConfiguration = rolePermissionConfigurationService.getByRoleAndPermission(rolePermissionPayload.getRoleId(), rolePermissionPayload.getPermissionId(), pranthId);
				if (existingRolePermissionConfiguration != null) {
					rolePermissionConfiguration.setCreatedOn(existingRolePermissionConfiguration.getCreatedOn());
					rolePermissionConfiguration.setCreatedBy(existingRolePermissionConfiguration.getCreatedBy());
					rolePermissionConfiguration.setUpdatedOn(new Date());
					rolePermissionConfiguration.setUpdatedBy(rolePermissionPayload.getUpdatedBy());
					rolePermissionConfiguration.setId(existingRolePermissionConfiguration.getId());
					rolePermissionConfiguration = rolePermissionConfigurationService.save(rolePermissionConfiguration);
				} else {
					rolePermissionConfiguration.setCreatedBy(rolePermissionPayload.getUpdatedBy());
					rolePermissionConfiguration.setUpdatedOn(new Date());
					rolePermissionConfiguration.setCreatedOn(new Date());
					rolePermissionConfiguration.setUpdatedBy(rolePermissionPayload.getUpdatedBy());
					rolePermissionConfiguration = rolePermissionConfigurationService.save(rolePermissionConfiguration);
				}
			}
			responseBean.setMessage("Record saved successfully");
			responseBean.setData(rolePermissionConfiguration);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Exception Occurred");
		}
		return responseBean;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class RolePermissionPayload{
		private Integer id;
		private JsonNode configuredValue;
		private Integer permissionId;
		private Integer roleId;
		private Long updatedBy;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class RolePermissionDTO implements Serializable{

		private static final long serialVersionUID = -658416615597847680L;
		private Integer parentModuleId;
		private String parentModuleName;
		private Integer moduleId;
		private String moduleName;
		private Integer roleId;
		private Integer permissionId;
		private String permissionLabel;
		private String permissionCode;

		@JsonIgnore
		private String configuredValueString;
		public JsonNode getConfiguredValue(){
			try {
				return this.configuredValueString != null ? new ObjectMapper().readTree(this.configuredValueString) : null;
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			return null;
		}
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class RolePermissionGroupedDTO implements Serializable {

		private static final long serialVersionUID = 3226852252360057387L;
		private Integer parentModuleId;
		private String parentModuleName;

		List<ModulePermissionRoles> modulePermissionRoles;

		@Data
		@AllArgsConstructor
		@NoArgsConstructor
		@Builder
		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class ModulePermissionRoles implements Serializable{
			/**
			 * 
			 */
			private static final long serialVersionUID = 3671581123378445165L;
			private Integer moduleId;
			private String moduleName;

			List<PermissionRoles> permissionRoles;

			@Data
			@AllArgsConstructor
			@NoArgsConstructor
			@Builder
			@JsonIgnoreProperties(ignoreUnknown = true)
			public static class PermissionRoles implements Serializable{
				/**
				 * 
				 */
				private static final long serialVersionUID = 3645915663074645658L;
				private Integer roleId;
				private Integer permissionId;
				private String permissionLabel;
				private String permissionCode;
				private String inputType;
				@JsonIgnore
				private String configuredValueString;

				public JsonNode getConfiguredValue(){
					try {
						return this.configuredValueString != null ? new ObjectMapper().readTree(this.configuredValueString) : null;
					} catch (JsonProcessingException e) {
						e.printStackTrace();
					}
					return null;
				}
			}
		}


	}

	@ApiOperation("Use this api for fetching RolePermissionConfiguration record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			RolePermissionConfiguration rolePermissionConfiguration = rolePermissionConfigurationService.getById(id);
			if (rolePermissionConfiguration != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(rolePermissionConfiguration);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Exception Occurred");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting RolePermissionConfiguration record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = rolePermissionConfigurationService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception Occurred");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching expiry in days.")
	@GetMapping(value = "/v1/get-role-token-expiry-in-days", produces = "application/json")
	public ResponseBean getRoleTokenExpiry(@RequestParam(name = "userName")  String userName) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer expiryInDays = rolePermissionConfigurationService.getRoleTokenExpiry(userName);
			if(expiryInDays == null) {
				responseBean.setMessage("Setting not available.");
			}else {
				responseBean.setMessage("Fetched record successfully.");
			}
			
			responseBean.setData(expiryInDays);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occurred");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all RolePermissionConfiguration records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll(@RequestParam(name = "pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<RolePermissionConfiguration> rolePermissionConfigurationRecords = rolePermissionConfigurationService.getAll(pranthId);
			if (!rolePermissionConfigurationRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(rolePermissionConfigurationRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occurred");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all RolePermissionConfiguration records. No params required.")
	@GetMapping(value = "/v1/get-all-by-role/{roleid}", produces = "application/json")
	public ResponseBean getAllByRole(@PathVariable(value = "roleid") Integer roleId, @RequestParam(value = "pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<RolePermissionConfiguration> rolePermissionConfigurationRecords = rolePermissionConfigurationService.getAllByRole(roleId, pranthId);
			if (!rolePermissionConfigurationRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(rolePermissionConfigurationRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occurred");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all Permissions by role.")
	@GetMapping(value = "/v1/get-role-permissions-by-role/{roleid}", produces = "application/json")
	public ResponseBean getRolePermissionsByRole(@PathVariable(value = "roleid") Integer roleId, @RequestParam(value = "pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {

			List<RolePermissionGroupedDTO> rolesPermissionGroupedDTOs = rolePermissionConfigurationService.getRolePermissions(roleId, pranthId);

			if (!rolesPermissionGroupedDTOs.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(rolesPermissionGroupedDTOs);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occurred");
		}
		return responseBean;
	}
	
	@ApiOperation("Use this api for updating system configurations to child pranth.")
	@GetMapping(value = "/v1/update-role-permission-config-to-child/{userId}", produces = "application/json")
	public ResponseBean updateParentRolePermissionConfigurationToChild(@PathVariable(value = "userId") Long userId,@RequestParam(value = "pranthId",required = false) Long pranthId , @RequestParam(value = "mappedPranthId") Long mappedPranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			responseBean = rolePermissionConfigurationService.updateParentRoleToChild(pranthId, mappedPranthId, userId);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occurred");
		}
		return responseBean;
	}

}