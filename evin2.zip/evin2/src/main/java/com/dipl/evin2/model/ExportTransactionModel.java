package com.dipl.evin2.model;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExportTransactionModel {
	ExportTxnModel exportTxnModel;
	Long pranthId;
	Long userId;
	String userName;
	String email;
	List<Long> offsetStoreIds;
}
