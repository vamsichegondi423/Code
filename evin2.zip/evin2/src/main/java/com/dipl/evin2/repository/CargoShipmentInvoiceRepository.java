package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.dipl.evin2.entity.Cargo;

@Repository
public interface CargoShipmentInvoiceRepository extends JpaRepository<Cargo, Long>{
	
	@Query(value = "select DISTINCT s.name as issuing_store_name,st.name as issuing_state_name,bi.ordered_stock, \r\n" + 
			" d.name as issing_store_district,\r\n" + 
			" r.name as receiving_store_name,rt.name as receiving_state_name,\r\n" + 
			" rd.name as receiving_district_name,\r\n" + 
			" current_date as invoice_date,c.cargo_no,c.order_reference_no, cast(bt.created_on as date) as date_of_supply,\r\n" + 
			" cast(bt.created_on as date) as date_of_receipt,c.booking_id,p.name as product_name,p.is_batch_enabled,\r\n" + 
			" cib.batch_no,pr.name as producer_name,cib.batch_expiry_date,cib.cargo_stock,cib.cargo_item_id,\r\n" + 
			" bi.recommanded_stock,b.comments as remarks\r\n" + 
			" from cargo c join cargo_item ci on c.id=ci.cargo_id left join cargo_item_batch cib on ci.id=cib.cargo_item_id\r\n" + 
			" join bookings b on c.booking_id=b.id join booking_tracking bt on bt.booking_id=b.id  and  b.status_id=bt.status_id  " + 
			" join booking_items bi on bi.booking_id=b.id and bi.product_id=ci.product_id\r\n" + 
			" left join icatalogue i on bi.store_id=i.store_id and bi.product_id=i.product_id \r\n" + 
			" left join icatalogue_batch ib on i.id=ib.icatalogue_id and ib.batch_no=cib.batch_no and ib.product_id=ci.product_id\r\n" + 
			" left join producer pr on ib.producer_id=pr.id\r\n" + 
			" join store s on b.issuing_store_id=s.id join master_state st on st.id=s.state_id left join master_district d on d.id=s.district_id\r\n" + 
			" join store r on b.receiving_store_id=r.id join master_state rt on rt.id=r.state_id left join master_district rd on rd.id=r.district_id\r\n" + 
			" join product p on ci.product_id=p.id where c.is_deleted=false and b.is_deleted=false and bi.is_deleted=false\r\n" + 
			" and c.cargo_no= ?1 ", nativeQuery = true)
	public List<Map<String, Object>> getCargoShipmentInvoiceData(String shippingId);
	
	@Query(value = "select *  from bookings b  JOIN cargo c on b.id=c.booking_id  and  c.cargo_no= ?1 and b.is_deleted = false and c.is_deleted = false  ", nativeQuery = true)
	public Cargo getBookingIdByCargoNo(String cargoNo);

}
