package com.dipl.evin2.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.dipl.evin2.controller.BookingsController.BookingsByFilterPayload;
import com.dipl.evin2.service.ExportBookingService;
import com.dipl.evin2.service.StoreService;
import com.dipl.evin2.util.ResponseBean;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/bookings")
public class ExportExcelBookingsController {

	@Autowired
	private ExportBookingService exportBookingService;

	@Autowired
	private StoreService storeService;

	@PostMapping(value = "/v1/export-bookings")
	public ResponseBean getBookings(@RequestBody BookingsByFilterPayload bookingsByFilterPayload,
			@RequestParam("pranthId") Long pranthId, @RequestParam("userId") Long userId,
			@RequestParam("userName") String userName, @RequestParam("email") String email) {
		try {
			List<Long> totalStoreIds = storeService.getToatalStoreIds(pranthId, userId);
			return exportBookingService.getBookingService(bookingsByFilterPayload, pranthId, userId, userName, email,
					totalStoreIds);
		} catch (Exception e) {
			log.error("Exception occured while fetching all Order : {}", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
	}

}