package com.dipl.evin2.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssetConfigurationPullModel {

	@JsonProperty("data")
	private ConfData data;

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Comm {

		@JsonProperty("chnl")
		private Integer chnl;
		@JsonProperty("tmpUrl")
		private String tmpUrl;
		@JsonProperty("cfgUrl")
		private String cfgUrl;
		@JsonProperty("alrmUrl")
		private String alrmUrl;
		@JsonProperty("statsUrl")
		private String statsUrl;
		@JsonProperty("devRyUrl")
		private String devRyUrl;
		@JsonProperty("smsGyPh")
		private String smsGyPh;
		@JsonProperty("senderId")
		private String senderId;
		@JsonProperty("smsGyKey")
		private String smsGyKey;
		@JsonProperty("tmpNotify")
		private Boolean tmpNotify;
		@JsonProperty("incExcNotify")
		private Boolean incExcNotify;
		@JsonProperty("statsNotify")
		private Boolean statsNotify;
		@JsonProperty("devAlrmsNotify")
		private Boolean devAlrmsNotify;
		@JsonProperty("tmpAlrmsNotify")
		private Boolean tmpAlrmsNotify;
		@JsonProperty("samplingInt")
		private Integer samplingInt;
		@JsonProperty("pushInt")
		private Integer pushInt;
		@JsonProperty("usrPhones")
		private List<String> usrPhones;
		@JsonProperty("wifi")
		private Wifi wifi;

	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class SensorComm {

		@JsonProperty("tmpNotify")
		private Boolean tmpNotify;
		@JsonProperty("incExcNotify")
		private Boolean incExcNotify;
		@JsonProperty("statsNotify")
		private Boolean statsNotify;
		@JsonProperty("devAlrmsNotify")
		private Boolean devAlrmsNotify;
		@JsonProperty("tmpAlrmsNotify")
		private Boolean tmpAlrmsNotify;
		@JsonProperty("samplingInt")
		private Integer samplingInt;
		@JsonProperty("pushInt")
		private Integer pushInt;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ConfData {

		@JsonProperty("comm")
		private Comm comm;
		@JsonProperty("highAlarm")
		private HighAlarm highAlarm;
		@JsonProperty("lowAlarm")
		private LowAlarm lowAlarm;
		@JsonProperty("highWarn")
		private HighWarn highWarn;
		@JsonProperty("lowWarn")
		private LowWarn lowWarn;
		@JsonProperty("sensors")
		private List<Sensor> sensors;
		@JsonProperty("notf")
		private Notf notf;
		@JsonProperty("locale")
		private Locale locale;
		@JsonProperty("poa")
		private Poa poa;
		@JsonProperty("lba")
		private Lba lba;

	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class HighAlarm {

		@JsonProperty("temp")
		private Double temp;
		@JsonProperty("dur")
		private Integer dur;

	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class SensorHighAlarm {

		@JsonProperty("temp")
		private Double temp;
		@JsonProperty("dur")
		private Integer dur;

	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class HighWarn {

		@JsonProperty("temp")
		private Double temp;
		@JsonProperty("dur")
		private Integer dur;

	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class SensorHighWarn {

		@JsonProperty("temp")
		private Double temp;
		@JsonProperty("dur")
		private Integer dur;

	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Lba {

		@JsonProperty("lmt")
		private Integer lmt;

	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Locale {

		@JsonProperty("tz")
		private Integer tz;
		@JsonProperty("cn")
		private String cn;
		@JsonProperty("ln")
		private String ln;

	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class LowAlarm {

		@JsonProperty("temp")
		private Double temp;
		@JsonProperty("dur")
		private Integer dur;

	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class SensorLowAlarm {

		@JsonProperty("temp")
		private Double temp;
		@JsonProperty("dur")
		private Integer dur;

	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class LowWarn {

		@JsonProperty("temp")
		private Double temp;
		@JsonProperty("dur")
		private Integer dur;

	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class SensorLowWarn {

		@JsonProperty("temp")
		private Double temp;
		@JsonProperty("dur")
		private Integer dur;

	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class SensorNotf {

		@JsonProperty("dur")
		private Integer dur;
		@JsonProperty("num")
		private Integer num;
	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Notf {

		@JsonProperty("dur")
		private Integer dur;
		@JsonProperty("num")
		private Integer num;

	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Poa {

		@JsonProperty("dur")
		private Integer dur;

	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Sensor {

		@JsonProperty("sId")
		private String sId;
		@JsonProperty("comm")
		private SensorComm comm;
		@JsonProperty("highAlarm")
		private SensorHighAlarm highAlarm;
		@JsonProperty("lowAlarm")
		private SensorLowAlarm lowAlarm;
		@JsonProperty("highWarn")
		private SensorHighWarn highWarn;
		@JsonProperty("lowWarn")
		private SensorLowWarn lowWarn;
		@JsonProperty("notf")
		private SensorNotf notf;

	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Wifi {

		@JsonProperty("ssid")
		private String ssid;
		@JsonProperty("pwd")
		private String pwd;
		@JsonProperty("security")
		private String security;


	}

}
