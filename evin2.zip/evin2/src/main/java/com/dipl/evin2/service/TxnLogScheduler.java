package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dipl.evin2.entity.MasterTxnType;
import com.dipl.evin2.entity.TxnLog;
import com.dipl.evin2.model.TxnLogDetails;
import com.dipl.evin2.mongo.repository.TxnLogDetailsRepository;
import com.dipl.evin2.repository.TxnLogRepository;
import com.dipl.evin2.service.ProductService.ProductBadgeDetails;
import com.dipl.evin2.service.StoreService.StoreBadgeDetails;

@Service
@RequestMapping("txn-log-scheduler")
public class TxnLogScheduler {

	@Autowired
	private TxnLogRepository txnLogRepository;

	@Autowired
	private TxnLogDetailsRepository txnLogDetailsRepository;

	@Autowired
	private StoreService storeService;

	@Autowired
	private ProductService productService;

	@Autowired
	private MasterTxnTypeService masterTxnTypeService;

	//@Scheduled(fixedDelay = 120000)
	@Transactional(rollbackFor = Exception.class)
	@GetMapping("run")
	public void populateTxnLogs() {

		List<TxnLog> txnLogs = txnLogRepository.getTxnLogsForscheduler();
		Set<Long> storeIds = txnLogs.stream().map(TxnLog::getStoreId).collect(Collectors.toSet());
		if (!storeIds.isEmpty()) {
			List<StoreBadgeDetails> storeBadgeDetailsList = storeService.getStoreBadgeDetails(storeIds);
			if (!storeBadgeDetailsList.isEmpty()) {
				Map<Long, StoreBadgeDetails> storesMap = storeBadgeDetailsList.stream()
						.filter(store -> store != null).collect(Collectors
								.toMap(StoreBadgeDetails::getStoreId, StoreBadgeDetails -> StoreBadgeDetails));

				Set<Long> productIds = txnLogs.stream().map(TxnLog::getProductId).collect(Collectors.toSet());
				List<ProductBadgeDetails> productBadgeDetailsList = productService.getProductBadgeDetails(productIds);
				Map<Long, ProductBadgeDetails> productsMap = productBadgeDetailsList.stream().collect(Collectors
						.toMap(ProductBadgeDetails::getProductId, ProductBadgeDetails -> ProductBadgeDetails));

				List<MasterTxnType> masterTxnTypes = masterTxnTypeService.getAll();
				Map<Integer, MasterTxnType> masterTxnTypesMap = masterTxnTypes.stream()
						.collect(Collectors.toMap(MasterTxnType::getId, MasterTxnType -> MasterTxnType));

				List<TxnLogDetails> txnLogDetailsList = new ArrayList<>();
				for (TxnLog txnLog : txnLogs) {
					TxnLogDetails txnLogDetails = TxnLogDetails.builder()
							.productBadgeId(productsMap.containsKey(txnLog.getProductId())
									? productsMap.get(txnLog.getProductId()).getBadgeId()
									: null)
							.productBadgeName(productsMap.containsKey(txnLog.getProductId())
									? productsMap.get(txnLog.getProductId()).getBadgeName()
									: null)
							.productId(txnLog.getProductId())
							.productName(productsMap.containsKey(txnLog.getProductId())
									? productsMap.get(txnLog.getProductId()).getProductName()
									: null)
							.storeBadgeId(storesMap.containsKey(txnLog.getStoreId())
									? storesMap.get(txnLog.getStoreId()).getBadgeId()
									: null)
							.storeBadgeName(storesMap.containsKey(txnLog.getStoreId())
									? storesMap.get(txnLog.getStoreId()).getBadgeName()
									: null)
							.storeId(txnLog.getStoreId())
							.storeName(storesMap.containsKey(txnLog.getStoreId())
									? storesMap.get(txnLog.getStoreId()).getStoreName()
									: null)
							.txnDate(txnLog.getTxnDate()).txnId(txnLog.getTxnId()).txnTypeId(txnLog.getTxnTypeId())
							.txnTypeName(masterTxnTypesMap.containsKey(txnLog.getTxnTypeId())
									? masterTxnTypesMap.get(txnLog.getTxnTypeId()).getName()
									: null)
							.stateId(storesMap.containsKey(txnLog.getStoreId())
									? storesMap.get(txnLog.getStoreId()).getStateId()
									: null)
							.stateName(storesMap.containsKey(txnLog.getStoreId())
									? storesMap.get(txnLog.getStoreId()).getStateName()
									: null)
							.districtId(storesMap.containsKey(txnLog.getStoreId())
									? storesMap.get(txnLog.getStoreId()).getDistrictId()
									: null)
							.districtIdName(storesMap.containsKey(txnLog.getStoreId())
									? storesMap.get(txnLog.getStoreId()).getDistrictName()
									: null)
							.blockId(storesMap.containsKey(txnLog.getStoreId())
									? storesMap.get(txnLog.getStoreId()).getBlockId()
									: null)
							.blockName(storesMap.containsKey(txnLog.getStoreId())
									? storesMap.get(txnLog.getStoreId()).getBlockName()
									: null)
							.build();
					txnLog.setIsActivityRead(true);
					txnLogDetailsList.add(txnLogDetails);
				}
				txnLogDetailsRepository.saveAll(txnLogDetailsList);
				txnLogRepository.saveAll(txnLogs);
			}
		}
	}
}
