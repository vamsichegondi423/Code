/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReportTxns implements Serializable {
    @Basic(optional = false)
    @Column(name = "pranth_id")
    private long pranthId;
    @Basic(optional = false)
    @Column(name = "product_id")
    private long productId;
    @Basic(optional = false)
    @Column(name = "store_id")
    private long storeId;
    private String txnDate;
    @Column(name = "is_active")
    private Boolean isActive;
    @Column(name = "txn_type_id")
    private Integer txnsTypeId;
    
    

    
}
