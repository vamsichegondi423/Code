package com.dipl.evin2.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExportStockReportByOneStoreModel extends ExportStockReportModel{
	
	private Long rstoreId;
	private Integer type;
	private Long storeId;
}
