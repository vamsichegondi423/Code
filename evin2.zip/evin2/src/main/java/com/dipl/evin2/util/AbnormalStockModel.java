package com.dipl.evin2.util;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AbnormalStockModel {
	private Long storeId;
	private Long productId;
	private Integer abnormalStockTypeId;
	private String abnormalStockDate;
	private String abnormalStockMonth;
	private String abnormalStockYear;
	private Long durationDays;
}
