package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.MasterBlock;

@Repository
public interface MasterBlockRepository extends JpaRepository<MasterBlock, Integer> {

	@Query(value = "select * from master_block where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterBlock> getById(Integer id);

	@Query(value = "select * from master_block where is_deleted = false", nativeQuery = true)
	public List<MasterBlock> findAll();
	
	@Query(value = "select * from master_block where district_id = ?1 and \"name\" = ?2 and is_deleted = false", nativeQuery = true)
	public MasterBlock getMasterBlock(Integer districtId, String name);

	@Modifying
	@Transactional
	@Query(value = "delete from master_block where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);

	@Modifying
	@Transactional
	@Query(value = "update master_block set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

}