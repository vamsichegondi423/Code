package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.NotificationEventDetail;
import com.dipl.evin2.entity.PranthHierarchy;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.NotificationEventDetailRepository;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class NotificationEventDetailService {

	@Autowired
	private NotificationEventDetailRepository notificationEventDetailRepository;
	
	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	public NotificationEventDetail getById(Integer id) {
			Optional<NotificationEventDetail> notificationEventDetailOptional = notificationEventDetailRepository.getById(id);
			if (notificationEventDetailOptional.isPresent()) {
				return notificationEventDetailOptional.get();
			} else {
				return null;
			}
	}

	public NotificationEventDetail save(NotificationEventDetail notificationEventDetail) {
		if (notificationEventDetail.getId() != null && notificationEventDetail.getId() > 0) {
			Optional<NotificationEventDetail> existingNotificationEventDetailRecord = notificationEventDetailRepository.getById(notificationEventDetail.getId());
			if (existingNotificationEventDetailRecord.isPresent()) {
				return notificationEventDetailRepository.save(notificationEventDetail);
			}
		} else {
			notificationEventDetail = notificationEventDetailRepository.save(notificationEventDetail);
		}
		return notificationEventDetail;
	}

	public Integer deleteById(Integer id) {
			Optional<NotificationEventDetail> existingNotificationEventDetailRecord = notificationEventDetailRepository.getById(id);
			if (existingNotificationEventDetailRecord.isPresent()) {
				notificationEventDetailRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
	}

	public List<NotificationEventDetail> getAll() {
			return notificationEventDetailRepository.findAll();
	}

	public List<NotificationEventDetail> getAllByNotificationEventType(Integer notificationEventTypeId) {
		return notificationEventDetailRepository.getAllByNotificationEventType(notificationEventTypeId);
	}

	@Transactional(rollbackOn =  Exception.class)
	public ResponseBean updateParentNotificationEventDetailsToChild(Long pranthId, Long mappedPranthId, Long userId) throws CustomException {
		ResponseBean responseBean  = new ResponseBean();
		Long pranthid = 0L;
		List<NotificationEventDetail> mrList= new ArrayList<>();
		Optional<PranthHierarchy> pranthHierarchy = pranthHierarchyService.getByMappingId(mappedPranthId);
		try {
			if(pranthHierarchy.isPresent()) {
				if(pranthId != null && pranthId != 0) {
					pranthid = pranthId;
				} else {
					pranthid = pranthHierarchy.get().getPranthId();
				}
				List<NotificationEventDetail> systemConfigurationsList = notificationEventDetailRepository.findAllByPranthId(pranthid);
				for(NotificationEventDetail sc: systemConfigurationsList) {
					NotificationEventDetail configuration = NotificationEventDetail.builder().bookingBadge(sc.getBookingBadge())
							.createdOn(new Date()).notificationEventId(sc.getNotificationEventId()).postOnBulletinBoard(sc.getPostOnBulletinBoard())
							.postOnBulletinBoardBadge(sc.getPostOnBulletinBoardBadge()).pranthId(sc.getPranthId()).productBadge(sc.getProductBadge())
							.reasonId(sc.getReasonId()).statusId(sc.getStatusId()).storeBadge(sc.getStoreBadge()).timePeriod(sc.getTimePeriod())
							.whomToNotify(sc.getWhomToNotify()).updatedOn(new Date()).build();
					configuration.setCreatedBy(userId);
					configuration.setUpdatedBy(userId);
					mrList.add(configuration);
				}
				notificationEventDetailRepository.saveAll(mrList);
				responseBean.setMessage("Notification Events Details has been updated for child");
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
			} else {
				responseBean.setMessage("No Record found with mappedPranthId");
				responseBean.setReturnCode(0);
				responseBean.setStatus(HttpStatus.NO_CONTENT);
			}
		}catch(Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseBean;
	}
}