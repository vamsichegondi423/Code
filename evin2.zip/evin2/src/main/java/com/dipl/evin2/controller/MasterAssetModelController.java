package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.dto.AssetModelDTO;
import com.dipl.evin2.entity.AssetModelSensorMapping;
import com.dipl.evin2.entity.MasterAssetModel;
import com.dipl.evin2.entity.MasterAssetType;
import com.dipl.evin2.service.AssetModelSensorMappingService;
import com.dipl.evin2.service.CacheEvictor;
import com.dipl.evin2.service.MasterAssetModelService;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/master-asset-model")
public class MasterAssetModelController {

	@Autowired
	private MasterAssetModelService masterAssetModelService;

	@Autowired
	private AssetModelSensorMappingService assetModelSensorMappingService;

	@Autowired
	private CacheEvictor cacheEvictor;

	@ApiOperation("Use this api for saving or updating MasterAssetModel. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody MasterAssetModel masterAssetModel, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (masterAssetModel.getId() != null && masterAssetModel.getId() > 0) {
				MasterAssetModel existingMasterAssetModel = masterAssetModelService.getById(masterAssetModel.getId());
				if (existingMasterAssetModel != null) {
					masterAssetModel = masterAssetModelService.save(masterAssetModel);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(masterAssetModel);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				masterAssetModel = masterAssetModelService.save(masterAssetModel);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(masterAssetModel);
			}
			cacheEvictor.evictAllCacheValues("master-asset-model");
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching MasterAssetModel record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			MasterAssetModel masterAssetModel = masterAssetModelService.getById(id);
			if (masterAssetModel != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterAssetModel);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching MasterAssetModel record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyvendor", produces = "application/json")
	public ResponseBean getByVendor(@RequestParam(value = "vendorid") Long vendorId, @RequestParam(value = "isActive", required = false) Optional<Boolean> isActive) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<MasterAssetModel> masterAssetModels = masterAssetModelService.getByVendorId(vendorId, isActive);
			if (masterAssetModels != null && !masterAssetModels.isEmpty()) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterAssetModels);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting MasterAssetModel record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = masterAssetModelService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all MasterAssetModel records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<MasterAssetModel> masterAssetModelRecords = masterAssetModelService.getAll();
			if (!masterAssetModelRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterAssetModelRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching AssetModel records. Provide Asset Type id as path param.")
	@GetMapping(value = "/v1/getassetmodelbytype/{assetTypeId}", produces = "application/json")
	public ResponseBean fetchAssetModelsByType(@PathVariable(value = "assetTypeId") Long assestTypeId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<?> masterAssetModelRecords = masterAssetModelService.fetchAssetModelsByType(assestTypeId);
			if (!masterAssetModelRecords.isEmpty()) {
				if(assestTypeId.equals(Long.valueOf(Constants.ASSET_TYPE_TEMPERATURE_LOGGER))) {
					for (Iterator<?> iterator = masterAssetModelRecords.iterator(); iterator.hasNext();) {
						AssetModelDTO assetModelDTO  = (AssetModelDTO) iterator.next();
						List<AssetModelSensorMapping> assetModelSensorMappings = assetModelSensorMappingService.getByAssetModel(assetModelDTO.getModelId());
						assetModelDTO.setAssetModelSensorMappings(assetModelSensorMappings);
					}
				}
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterAssetModelRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
	
	@ApiOperation("Use this api for fetching AssetModel records. Provide Asset Type id as path param.")
	@GetMapping(value = "/v1/getmodelbytype/{assetTypeId}", produces = "application/json")
	public ResponseBean fetchAssetModels(@PathVariable(value = "assetTypeId") Long assestTypeId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			AssetTypeDetais masterAssetModelRecords = masterAssetModelService.fetchAssetModel(assestTypeId);
			if(masterAssetModelRecords != null) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterAssetModelRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class AssetVendorDTO{

		private String vendorName;
		private Integer assetVendorId;
		private Boolean vendorIsActive;
		private Integer assetTypeId;
		private String assetTypeName;


	}

	@ApiOperation("Use this api for saving or updating MasterAssetVendor. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/save-or-update-list")
	@Transactional(rollbackFor	 = Exception.class)
	public ResponseBean saveList(@RequestBody List<AssetModelJackson> modelJacksons, BindingResult result) {
		List<MasterAssetModel> assetVendorList = new ArrayList<>();
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message(result.getAllErrors().get(0).getDefaultMessage()).status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			assetVendorList = masterAssetModelService.saveList(modelJacksons);
			cacheEvictor.evictAllCacheValues("master-asset-model");
			cacheEvictor.evictAllCacheValues("master-asset-vendor");
			log.info("Record saved successfully");
			responseBean.setMessage("Record saved successfully");
			responseBean.setData(assetVendorList);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class AssetModelJackson{

		private Long vendorId;
		private Boolean vendorIsActive;
		private Long assetModelId;
		private Boolean assetModelIsActive;
		private Character defaultSensor;
		private Long updatedBy;

	}
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class AssetTypeDetais{
		private Integer assetTypeId;
		private String assetTypeName;
		private String monitoringPoint;
		private Integer monitoringId;
		List<AssetVendorDetails> assetVendorDetailsList;

		@Data
		@AllArgsConstructor
		@NoArgsConstructor
		@Builder
		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class AssetVendorDetails{
			private Integer assetVendorId;
			private String vendorName;
			private Boolean vendorIsActive;
			List<AssetModelDetails> assetModelDetailsList;

			@Data
			@AllArgsConstructor
			@NoArgsConstructor
			@Builder
			@JsonIgnoreProperties(ignoreUnknown = true)
			public static class AssetModelDetails{
				private Boolean modelIsActive;
				private String modelName;
				private Long modelId;
				private String defaultCensor;
				private List<AssetModelSensorMapping> assetModelSensorMappings;
			}
		}
	}
}