package com.dipl.evin2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.controller.StoreController.TxnPayload;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.model.ExportTxnModel;
import com.dipl.evin2.service.ExportTransactionService;
import com.dipl.evin2.service.StoreService;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/store")
public class ExportExcelTransactionsController {

	@Autowired
	private ExportTransactionService trasactionService;

	@Autowired
	private StoreService storeService;

	@PostMapping(value = "/v1/export-transaction", produces = "application/json")
	public ResponseBean getTransactionReport(@RequestBody ExportTxnModel txnPayload,
			@RequestParam("pranthId") Long pranthId, @RequestParam("userId") Long userId,
			@RequestParam("userName") String userName, @RequestParam(value = "email") String email, Pageable pageable)
			throws CustomException {

		List<Long> totalStoreIds = storeService.getTotalStoreIdsWithLocationFilters(pranthId, userId,txnPayload.getState(),txnPayload.getDistrict(),txnPayload.getBlock());
		
		try {
			if (txnPayload.getTxnsFromDate() == null) {

				return ResponseBean.builder().data(null).message("Please send Transaction from date")
						.status(HttpStatus.BAD_REQUEST).returnCode(0).build();
			} else if (txnPayload.getTxnsToDate() == null) {

				return ResponseBean.builder().data(null).message("Please send Transaction to date")
						.status(HttpStatus.BAD_REQUEST).returnCode(0).build();
			}
			return trasactionService.getTransactionService(txnPayload, pranthId, userId, userName, email, totalStoreIds);

		} catch (Exception e) {
			log.error("Exception occured while for fetch store level pranth level transaction details: {}", e);
			return ResponseBean.builder().data(null).message(
					"Exception occured while for fetch store level pranth level transaction details:" + e.getMessage())
					.status(HttpStatus.INTERNAL_SERVER_ERROR).returnCode(0).build();
			
		}
	}

	@PostMapping(value = "/v1/export-transaction-with-batch", produces = "application/json")
	public ResponseBean getTransactionReportWithBatch(@RequestBody ExportTxnModel txnPayload,
			@RequestParam("pranthId") Long pranthId, @RequestParam("userId") Long userId,
			@RequestParam("userName") String userName, @RequestParam(value = "email") String email)
			throws CustomException {
		
		List<Long> totalStoreIds = storeService.getTotalStoreIdsWithLocationFilters(pranthId, userId,txnPayload.getState(),txnPayload.getDistrict(),txnPayload.getBlock());
		
		try {
			if (txnPayload.getTxnsFromDate() == null) {

				return ResponseBean.builder().data(null).message("Please send Transaction from date")
						.status(HttpStatus.BAD_REQUEST).returnCode(0).build();
			} else if (txnPayload.getTxnsToDate() == null) {

				return ResponseBean.builder().data(null).message("Please send Transaction to date")
						.status(HttpStatus.BAD_REQUEST).returnCode(0).build();
			}
			return trasactionService.getTransactionWithBatchService(txnPayload, userName, email, pranthId, userId,
					totalStoreIds);

		} catch (Exception e) {
			log.error("Exception occured while for fetch store level pranth level transaction details: {}", e);
			return ResponseBean.builder().data(null).message(
					"Exception occured while for fetch store level pranth level transaction details:" + e.getMessage())
					.status(HttpStatus.INTERNAL_SERVER_ERROR).returnCode(0).build();
		}
	}

}