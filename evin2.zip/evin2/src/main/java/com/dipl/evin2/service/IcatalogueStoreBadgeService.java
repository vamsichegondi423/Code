package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.IcatalogueStoreBadge;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.IcatalogueStoreBadgeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class IcatalogueStoreBadgeService {

	@Autowired
	private IcatalogueStoreBadgeRepository icatalogueStoreBadgeRepository;

	public IcatalogueStoreBadge getById(Long id) throws CustomException {
		try {
			Optional<IcatalogueStoreBadge> icatalogueStoreBadgeOptional = icatalogueStoreBadgeRepository.getById(id);
			if (icatalogueStoreBadgeOptional.isPresent()) {
				return icatalogueStoreBadgeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public IcatalogueStoreBadge save(IcatalogueStoreBadge icatalogueStoreBadge) throws CustomException {
		try {
			if (icatalogueStoreBadge.getId() != null && icatalogueStoreBadge.getId() > 0) {
				Optional<IcatalogueStoreBadge> existingIcatalogueStoreBadgeRecord = icatalogueStoreBadgeRepository
						.getById(icatalogueStoreBadge.getId());
				if (existingIcatalogueStoreBadgeRecord.isPresent()) {
					return icatalogueStoreBadgeRepository.save(icatalogueStoreBadge);
				}
			} else {
				icatalogueStoreBadge = icatalogueStoreBadgeRepository.save(icatalogueStoreBadge);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return icatalogueStoreBadge;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<IcatalogueStoreBadge> existingIcatalogueStoreBadgeRecord = icatalogueStoreBadgeRepository
					.getById(id);
			if (existingIcatalogueStoreBadgeRecord.isPresent()) {
				icatalogueStoreBadgeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<IcatalogueStoreBadge> getAll() {
		try {
			return icatalogueStoreBadgeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public List<IcatalogueStoreBadge> getByIcatalogueId(Long id) {
		try {
			return icatalogueStoreBadgeRepository.findByIcatalogueId(id);
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}