package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.dto.BookingDetailDTO;
import com.dipl.evin2.entity.Bookings;
import com.dipl.evin2.service.BookingsService;
import com.dipl.evin2.service.StoreService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/new")
public class StatusIdController {
	
	@Autowired
	private BookingsService bookingsService;

	@Autowired
	private StoreService storeService;
	
	@ApiOperation("Use this api for fetching Bookings record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{status_id}", produces = "application/json")
	public ResponseBean getBystatusId(@PathVariable(value = "status_id") int status_id,Pageable pagination) {
		 ResponseBean responseBean = new ResponseBean();
		try {
			List<Map<String, Object>> bookings = bookingsService.getBystatusId(status_id,pagination);
			if (bookings != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(bookings);
				responseBean.setBookings_count(bookings.size());
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}
	
	
}
