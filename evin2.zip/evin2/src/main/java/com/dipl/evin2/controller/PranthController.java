package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.Pranth;
import com.dipl.evin2.repository.PranthRepository;
import com.dipl.evin2.service.PranthService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/pranth")
public class PranthController {

	@Autowired
	private PranthService pranthService;
	@Autowired
	private PranthRepository pranthRepository;

	@ApiOperation("Use this api for saving or updating Pranth. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody Pranth pranth, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			Optional<Pranth> exstngPranth = pranthRepository.getByNameAndGovernorNo(pranth.getName(),pranth.getGovernorNo());
			if(exstngPranth.isPresent()) {
				log.info("Pranth name " + pranth.getName() + " with governor number " + pranth.getGovernorNo() + " already exist");
				responseBean.setMessage("Pranth name " + pranth.getName() + " with governor number " + pranth.getGovernorNo() + " already exist");
				return responseBean;
			}
			if (pranth.getId() != null && pranth.getId() > 0) {
				Pranth existingPranth = pranthService.getById(pranth.getId());
				if (existingPranth != null) {
					pranth.setCreatedOn(existingPranth.getCreatedOn());
					pranth = pranthService.save(pranth);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(pranth);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				Optional<Pranth> existingPranthRecord = pranthRepository.getByNameAndGovernorNo(pranth.getName(),pranth.getGovernorNo());
				if(!existingPranthRecord.isPresent()) {
					pranth = pranthService.save(pranth);
					log.info("Record saved successfully");
					responseBean.setMessage("Record saved successfully");
					responseBean.setData(pranth);
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setReturnCode(1);
				} else {
					log.info("Record already exists");
					responseBean.setMessage("Record already exists");
					responseBean.setData(null);
					responseBean.setStatus(HttpStatus.FORBIDDEN);
					responseBean.setReturnCode(0);
				}
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching Pranth record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Pranth pranth = pranthService.getById(id);
			if (pranth != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(pranth);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}
	
	@ApiOperation("Use this api for fetching Pranth record by pranthname. Provide pranth name as path param.")
	@GetMapping(value = "/v1/getbypranthname/{pranthName}", produces = "application/json")
	public ResponseBean getByPranthName(@PathVariable(value = "pranthName") String pranthName) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Pranth pranth = pranthService.getByPranthName(pranthName);
			if (pranth != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(pranth);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting Pranth record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = pranthService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all Pranth records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Pranth> pranthRecords = pranthService.getAll();
			if (!pranthRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(pranthRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
}