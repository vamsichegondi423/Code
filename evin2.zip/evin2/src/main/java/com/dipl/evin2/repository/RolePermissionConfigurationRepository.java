package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.RolePermissionConfiguration;

@Repository
public interface RolePermissionConfigurationRepository extends JpaRepository<RolePermissionConfiguration, Integer> {

	@Query(value = "select * from role_permission_configuration where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<RolePermissionConfiguration> getById(Integer id);

	@Query(value = "select * from role_permission_configuration where is_deleted = false", nativeQuery = true)
	public List<RolePermissionConfiguration> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from role_permission_configuration where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);
	
	@Modifying
	@Transactional
	@Query(value = "update role_permission_configuration set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

	@Query(value = "select * from role_permission_configuration where role_id = ?1 and permission_id = ?2 and pranth_id = ?3 and is_deleted = false", nativeQuery = true)
	public RolePermissionConfiguration getByRoleAndPermission(Integer roleId, Integer permissionId, Long pranthId);

	@Query(value = "select * from role_permission_configuration where role_id = ?1 and pranth_id = ?2 and is_deleted = false", nativeQuery = true)
	public List<RolePermissionConfiguration> getAllByRole(Integer roleId, Long pranthId);

	@Query(value = "select * from role_permission_configuration where pranth_id = ?1 and is_deleted = false", nativeQuery = true)
	public List<RolePermissionConfiguration> findAllByPranth(Long pranthId);
	
	@Query(value = "select * from role_permission_configuration rpc join master_permission mp on mp.id = rpc.permission_id \r\n"
			+ "			where mp.permission_code like in (?1) and rpc.pranth_id = ?2 and rpc.role_id = ?3", nativeQuery = true)
	public List<RolePermissionConfiguration> findAllByPermissionCodeAndRole(List<String> permissionCodes, Long roleId, Long pranthId);

}