/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "asset_configuration")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssetConfiguration extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Long id;
	@Column(name = "temperature_push_url")
	private String temperaturePushUrl;
	@Column(name = "configuration_pull_url")
	private String configurationPullUrl;
	@Column(name = "alarm_push_url")
	private String alarmPushUrl;
	@Column(name = "stats_push_url")
	private String statsPushUrl;
	@Column(name = "device_ready_status_push_url")
	private String deviceReadyStatusPushUrl;
	@Column(name = "sms_gateway_phone_number")
	private String smsGatewayPhoneNumber;
	@Column(name = "sms_gateway_keyword")
	private String smsGatewayKeyword;
	@Column(name = "sms_gateway_sender_id")
	private String smsGatewaySenderId;
	@Column(name = "sampling_interval")
	private Integer samplingInterval;
	@Column(name = "push_interval")
	private Integer pushInterval;
	@Column(name = "phone_numbers_to_send_sms_notification")
	private String phoneNumbersToSendSmsNotification;
	@Column(name = "temperature_push_notification")
	private Boolean temperaturePushNotification;
	@Column(name = "temperature_incursion_excursion_push_notification")
	private Boolean temperatureIncursionExcursionPushNotification;
	@Column(name = "device_alarm_push_notification")
	private Boolean deviceAlarmPushNotification;
	@Column(name = "stats_push_notification")
	private Boolean statsPushNotification;
	@Column(name = "temperature_alarm_push_notifications")
	private Boolean temperatureAlarmPushNotifications;
	@Column(name = "power_outage_alarm_duration")
	private Integer powerOutageAlarmDuration;
	@Column(name = "low_battery_alarm_threshold_limit")
	private Integer lowBatteryAlarmThresholdLimit;
	// @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
	@Column(name = "high_alarm_temperature")
	private Double highAlarmTemperature;
	@Column(name = "high_alarm_temperature_duration")
	private Integer highAlarmTemperatureDuration;
	@Column(name = "low_alarm_temperature")
	private Double lowAlarmTemperature;
	@Column(name = "low_alarm_temperature_duration")
	private Integer lowAlarmTemperatureDuration;
	@Column(name = "high_warning_temperature")
	private Double highWarningTemperature;
	@Column(name = "high_warning_temperature_duration")
	private Integer highWarningTemperatureDuration;
	@Column(name = "low_warning_temperature")
	private Double lowWarningTemperature;
	@Column(name = "low_warning_temperature_duration")
	private Integer lowWarningTemperatureDuration;
	@Column(name = "alarm_frequency_notification_duration")
	private Integer alarmFrequencyNotificationDuration;
	@Column(name = "alarm_frequency_notification_number")
	private Integer alarmFrequencyNotificationNumber;
	@Column(name = "wifi_ssid")
	private String wifiSsid;
	@Column(name = "wifi_password")
	private String wifiPassword;
	@Column(name = "wifi_security")
	private String wifiSecurity;
	@Column(name = "sensor_id")
	private String sensorId;
	@Column(name = "asset_id")
	private Long assetId;
	@Column(name = "communication_channel_id")
	private Integer communicationChannelId;
	@Column(name = "country_id")
	private Integer countryId;
	@Column(name = "language_id")
	private Integer languageId;
	@Column(name = "time_zone_id")
	private Integer timeZoneId;
	@Column(name = "name_space")
	private String nameSpace;

	@Transient
	private Asset asset;

	@Transient
	private List<AssetSensorConfiguration> assetSensorConfigurationList;

	public AssetConfiguration(AssetDefaultConfiguration assetDefaultConfiguration) {
		super();
		this.id = assetDefaultConfiguration.getId();
		this.temperaturePushUrl = assetDefaultConfiguration.getTemperaturePushUrl();
		this.configurationPullUrl = assetDefaultConfiguration.getConfigurationPullUrl();
		this.alarmPushUrl = assetDefaultConfiguration.getAlarmPushUrl();
		this.statsPushUrl = assetDefaultConfiguration.getStatsPushUrl();
		this.deviceReadyStatusPushUrl = assetDefaultConfiguration.getDeviceReadyStatusPushUrl();
		this.smsGatewayPhoneNumber = assetDefaultConfiguration.getSmsGatewayPhoneNumber();
		this.smsGatewayKeyword = assetDefaultConfiguration.getSmsGatewayKeyword();
		this.smsGatewaySenderId = assetDefaultConfiguration.getSmsGatewaySenderId();
		this.samplingInterval = assetDefaultConfiguration.getSamplingInterval();
		this.pushInterval = assetDefaultConfiguration.getPushInterval();
		this.phoneNumbersToSendSmsNotification = assetDefaultConfiguration.getPhoneNumbersToSendSmsNotification();
		this.temperaturePushNotification = assetDefaultConfiguration.getTemperaturePushNotification();
		this.temperatureIncursionExcursionPushNotification = assetDefaultConfiguration.getTemperatureIncursionExcursionPushNotification();
		this.deviceAlarmPushNotification = assetDefaultConfiguration.getDeviceAlarmPushNotification();
		this.statsPushNotification = assetDefaultConfiguration.getStatsPushNotification();
		this.temperatureAlarmPushNotifications = assetDefaultConfiguration.getTemperatureAlarmPushNotifications();
		this.powerOutageAlarmDuration = assetDefaultConfiguration.getPowerOutageAlarmDuration();
		this.lowBatteryAlarmThresholdLimit = assetDefaultConfiguration.getLowBatteryAlarmThresholdLimit();
		this.highAlarmTemperature = assetDefaultConfiguration.getHighAlarmTemperature();
		this.highAlarmTemperatureDuration = assetDefaultConfiguration.getHighAlarmTemperatureDuration();
		this.lowAlarmTemperature = assetDefaultConfiguration.getLowAlarmTemperature();
		this.lowAlarmTemperatureDuration = assetDefaultConfiguration.getLowAlarmTemperatureDuration();
		this.highWarningTemperature = assetDefaultConfiguration.getHighWarningTemperature();
		this.highWarningTemperatureDuration = assetDefaultConfiguration.getHighWarningTemperatureDuration();
		this.lowWarningTemperature = assetDefaultConfiguration.getLowWarningTemperature();
		this.lowWarningTemperatureDuration = assetDefaultConfiguration.getLowWarningTemperatureDuration();
		this.alarmFrequencyNotificationDuration = assetDefaultConfiguration.getAlarmFrequencyNotificationDuration();
		this.alarmFrequencyNotificationNumber = assetDefaultConfiguration.getAlarmFrequencyNotificationNumber();
		this.wifiSsid = assetDefaultConfiguration.getWifiSsid();
		this.wifiPassword = assetDefaultConfiguration.getWifiPassword();
		this.wifiSecurity = assetDefaultConfiguration.getWifiSecurity();
		this.communicationChannelId = assetDefaultConfiguration.getCommunicationChannelId();
		this.countryId = assetDefaultConfiguration.getCountryId();
		this.languageId = assetDefaultConfiguration.getLanguageId();
		this.timeZoneId = assetDefaultConfiguration.getTimeZoneId();
		this.nameSpace = assetDefaultConfiguration.getNameSpace();
	}

}
