package com.dipl.evin2.util;

import com.fasterxml.jackson.databind.node.ArrayNode;

public class ArrayNodeUserType extends JSONUserType<ArrayNode> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ArrayNodeUserType() {
		super(ArrayNode.class);
	}
}