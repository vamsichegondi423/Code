package com.dipl.evin2.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.dipl.evin2.entity.AssetMapping;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.AssetMappingRepository;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AssetMappingService {

	@Autowired
	private AssetMappingRepository assetMappingRepository;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public AssetMapping getById(Long id) throws CustomException {
		Optional<AssetMapping> assetMappingOptional = assetMappingRepository.getById(id);
		if (assetMappingOptional.isPresent()) {
			return assetMappingOptional.get();
		} else {
			return null;
		}
	}

	public AssetMapping save(AssetMapping assetMapping) throws CustomException {
		if (assetMapping.getId() != null && assetMapping.getId() > 0) {
			Optional<AssetMapping> existingAssetMappingRecord = assetMappingRepository.getById(assetMapping.getId());
			if (existingAssetMappingRecord.isPresent()) {
				return assetMappingRepository.save(assetMapping);
			}
		} else {
			assetMapping = assetMappingRepository.save(assetMapping);
		}
		return assetMapping;
	}

	public Integer deleteById(Long id) throws CustomException {
		Optional<AssetMapping> existingAssetMappingRecord = assetMappingRepository.getById(id);
		if (existingAssetMappingRecord.isPresent()) {
			assetMappingRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	public List<AssetMapping> getAll() {
		return assetMappingRepository.findAll();
	}

	public List<AssetMapping> getAllMappedAssetsByAssetIds(List<Long> assetIds) {
		return assetMappingRepository.getAllMappedAssetsByAssetIds(assetIds);
	}

	public List<AssetMapping> getAllMappedAssetsBySerialNos(List<String> otherSerialNos) {
		return assetMappingRepository.getAllMappedAssetsBySerialNos(otherSerialNos);
	}
	
	public List<AssetMappingDTO> getMappedAssetByAssetId(Set<Long> assetIds) {
		Set<String> assetIdsSet = assetIds.stream().map(a -> a+"").collect(Collectors.toSet());
		String assetIdsString = StringUtils.collectionToCommaDelimitedString(assetIdsSet);
		String q = "select a.asset_id as assetId,b.serial_number as serialNumber,a.mapped_asset_id as mappedAssetId,c.serial_number as mappedSerialNumber\r\n"
				+ "from asset_mapping a\r\n"
				+ "left join asset b on b.id = a.asset_id \r\n"
				+ "left join asset c on c.id = a.mapped_asset_id where a.asset_id in ("+assetIdsString+")";
		log.info(q);
		return jdbcTemplate.query(q, new BeanPropertyRowMapper<AssetMappingDTO>(AssetMappingDTO.class));
	}
	
	public AssetMappingDTO getMappedAssetByAssetId(Long assetId) {
		String q = "select a.asset_id as assetId,b.serial_number as serialNumber,a.mapped_asset_id as mappedAssetId,c.serial_number as mappedSerialNumber\r\n"
				+ "from asset_mapping a\r\n"
				+ "left join asset b on b.id = a.asset_id \r\n"
				+ "left join asset c on c.id = a.mapped_asset_id where a.asset_id = "+assetId;
		log.info(q);
		List<AssetMappingDTO> assetMappingDTOs = jdbcTemplate.query(q, new BeanPropertyRowMapper<AssetMappingDTO>(AssetMappingDTO.class));
		return !assetMappingDTOs.isEmpty() ? assetMappingDTOs.iterator().next() : null;
	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class AssetMappingDTO{
		private Long assetId;
		private Long mappedAssetId;
		private String serialNumber;
		private String mappedSerialNumber;
	}

	public AssetMapping getAssetMapping(Long assetId, Long mappedAssetId) {
		return assetMappingRepository.getAssetMapping(assetId, mappedAssetId);
	}
	
}