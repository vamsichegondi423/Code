package com.dipl.evin2.util;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IcatalogueModel {
	
	private String storeId;
	private String storeName;
	private String stateName;
	private String districtName;
	private String blockName;
	private String pranthId;
	private String materialName;
	private String maxStock;
	private String minStock;
	private String remarks;
	
}