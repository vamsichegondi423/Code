package com.dipl.evin2.exceptions;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.dipl.evin2.util.ResponseBean;

@ControllerAdvice
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	private static final Logger LOG = LoggerFactory.getLogger(RestResponseEntityExceptionHandler.class);

	@ExceptionHandler(value = { RuntimeException.class })
	protected ResponseEntity<Object> handleConflict(RuntimeException ex, WebRequest request) {
		String bodyOfResponse = "Internal server error occurred. Please contact admin.";
		LOG.error("Internal server error", ex);
		ResponseBean bean = ResponseBean.builder().data("").message(bodyOfResponse)
				.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(bean);
	}

	@ExceptionHandler(EvinException.class)
	public ResponseEntity<?> handleException(EvinException exception) {
		return ResponseEntity.status(exception.getHttpStatus())
				.body(this.processErrors(exception.getBindingResult(), exception.getHttpStatus()));
	}

	private BeanError processErrors(BindingResult bindingResult, HttpStatus status) {
		BeanError beanError = new BeanError();
		beanError.setStatus(status);
		Map<String, String> errors = beanError.getErrors();

		bindingResult.getFieldErrors().stream()
				.forEach((error) -> errors.put(error.getField(), error.getDefaultMessage()));

		return beanError;

	}

	@ExceptionHandler(CustomException.class)
	public ResponseBean handleCustomException(HttpServletResponse res, CustomException ex) throws IOException {
		ResponseBean bean = ResponseBean.builder().data("").message(ex.getMessage()).status(ex.getHttpStatus()).build();
		return bean;
	}
	
	@ExceptionHandler(CustomRollBackException.class)
	public ResponseBean handleCustomRollBackException( CustomRollBackException ex,WebRequest request)  {
		ResponseBean bean = ResponseBean.builder().data(null).message(ex.getMessage()).status(ex.getHttpStatus()).build();
		return bean;
	}

}