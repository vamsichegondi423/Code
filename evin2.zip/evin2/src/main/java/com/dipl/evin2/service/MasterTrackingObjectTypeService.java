package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterTrackingObjectType;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterTrackingObjectTypeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterTrackingObjectTypeService {
	
	@Autowired
	private MasterTrackingObjectTypeRepository masterTrackingObjectTypeRepository;

	public MasterTrackingObjectType getById(Integer id) throws CustomException {
		try {
			Optional<MasterTrackingObjectType> masterTrackingObjectTypeOptional = masterTrackingObjectTypeRepository.getById(id);
			if (masterTrackingObjectTypeOptional.isPresent()) {
				return masterTrackingObjectTypeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public MasterTrackingObjectType save(MasterTrackingObjectType masterTrackingObjectType) throws CustomException {
		try {
			if (masterTrackingObjectType.getId() != null && masterTrackingObjectType.getId() > 0) {
				Optional<MasterTrackingObjectType> existingMasterTrackingObjectTypeRecord = masterTrackingObjectTypeRepository.getById(masterTrackingObjectType.getId());
				if (existingMasterTrackingObjectTypeRecord.isPresent()) {
					return masterTrackingObjectTypeRepository.save(masterTrackingObjectType);
				}
			} else {
				masterTrackingObjectType = masterTrackingObjectTypeRepository.save(masterTrackingObjectType);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterTrackingObjectType;
	}

	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterTrackingObjectType> existingMasterTrackingObjectTypeRecord = masterTrackingObjectTypeRepository.getById(id);
			if (existingMasterTrackingObjectTypeRecord.isPresent()) {
				masterTrackingObjectTypeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<MasterTrackingObjectType> getAll() {
		try {
			return masterTrackingObjectTypeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}