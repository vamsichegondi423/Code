package com.dipl.evin2.dto;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

public interface CargoDTO {
	@Value(("#{target.cargo_id}"))
	Long getCargoId();
	@Value(("#{target.cargo_no}"))
	String getCargoNo();

	@Value(("#{target.booking_id}"))
	Long getBookingId();

	@Value(("#{target.status}"))
	String getStatus();

	@Value(("#{target.booking_reference_no}"))
	String getBookingReferenceNo();

	@Value(("#{target.created_on}"))
	Date getCreatedOn();

	@Value(("#{target.created_name}"))
	String getCreatedName();

	@Value(("#{target.user_id}"))
	String getUserId();

	@Value(("#{target.updated_on}"))
	Date getUpdatedOn();

	@Value(("#{target.updated_name}"))
	String getUpdatedName();

	@Value(("#{target.booking_badge}"))
	String getBookingBadge();

	@Value(("#{target.receiving_store_id}"))
	Long getReceivingStoreId();

	@Value(("#{target.receiving_store_name}"))
	String getSeceivingStoreName();

	@Value(("#{target.receiving_store_location}"))
	String getReceivingStoreLocation();

	@Value(("#{target.issuing_store_id}"))
	Long getIssuingStoreId();

	@Value(("#{target.issuing_store_name}"))
	String getIssuingStoreName();

	@Value(("#{target.issuing_store_location}"))
	String getIssuingStoreLocation();

	@Value(("#{target.package_quantity}"))
	Long getNoOfPackages();

	@Value(("#{target.weight}"))
	Long getTotalWeight();

	@Value(("#{target.Volume}"))
	String getVolume();

	@Value(("#{target.remarks}"))
	String getRemarks();

	@Value(("#{target.package_cost}"))
	Integer getPackageCost();

	@Value(("#{target.order_reference_no}"))
	String getTrackingId();

	@Value(("#{target.carrier_name}"))
	String getTransporter();

	@Value(("#{target.arrival_date}"))
	Date getEstimatedDateOfArrival();

	@Value(("#{target.carrier_contact_no}"))
	String getTransporterPhone();

	@Value(("#{target.vehicle_info}"))
	String getVehicle();
	@Value(("#{target.source_type}"))
	Integer getSourceType();
}
