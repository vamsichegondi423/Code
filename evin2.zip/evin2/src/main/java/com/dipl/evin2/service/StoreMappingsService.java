package com.dipl.evin2.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.dipl.evin2.dto.LinkedStoreDTO;
import com.dipl.evin2.entity.StoreMappings;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.StoreMappingsRepository;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StoreMappingsService {

	@Autowired
	private StoreMappingsRepository storeMappingsRepository;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public StoreMappings getById(Integer id) throws CustomException {
		try {
			Optional<StoreMappings> storeMappingsOptional = storeMappingsRepository.getById(id);
			if (storeMappingsOptional.isPresent()) {
				return storeMappingsOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public StoreMappings createStoreRelation(StoreMappings storeMappings) throws Exception {
		ResponseBean responseBean = new ResponseBean();
		try {
				List<Long> mappedStores = storeMappings.getMappedStoreIds();
				for (Long storeId : mappedStores) {
					Optional<StoreMappings> existingStoreMappingsRecord = storeMappingsRepository
							.getByStoreIdAndMappedId(storeMappings.getStoreId(), storeId,storeMappings.getMappingType());
					if (existingStoreMappingsRecord.isPresent()) {
						responseBean.setMessage("Record already exits with this store id " +storeMappings.getStoreId() 
						+" and mapping store id is " + storeId  );
					} else {
						storeMappings = createStoreMapping(storeMappings);
					}
				}
				return storeMappings;
			
		} catch (Exception e) {
			log.error("Exception occured while mapping the stores : ", e);
			 throw new Exception("Exception occured while mapping the stores  "  + e.getCause());
		}
	}

	private StoreMappings createStoreMapping(StoreMappings storeMappings) {
		List<Long> mappedStoreIds = storeMappings.getMappedStoreIds();
		for (Long storeId : mappedStoreIds) {
			StoreMappings stm = new StoreMappings();
			stm.setStoreId(storeMappings.getStoreId());
			stm.setMappingType(storeMappings.getMappingType());
			stm.setMappedStoreId(storeId);
			stm.setUpdatedOn(new Date());
			stm.setCreatedBy(storeMappings.getCreatedBy());
			stm.setUpdatedBy(storeMappings.getUpdatedBy());
			storeMappings = storeMappingsRepository.save(stm);
		}
		return storeMappings;
	}

	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<StoreMappings> existingStoreMappingsRecord = storeMappingsRepository.getById(id);
			if (existingStoreMappingsRecord.isPresent()) {
				storeMappingsRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<StoreMappings> getAll() {
		try {
			return storeMappingsRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
	@Deprecated
	public List<LinkedStoreDTO> getLinkedStores(Long storeId, String mappingType) {

		String query = "select s.id as storeId, s.name as storeName,sm.mapped_store_id as mappedStoreId,sm.mapping_type as mappingType, " + 
				"mst.name as mappedStoreName,concat(mst.city,', ',md.name,', ',mst1.name,', ',mc.name) as mappedLocation , " + 
				" concat(s.city,', ',d.name,', ',st.name,', ',c.name) as storeLocation " + 
				" from store s " + 
				" left join master_district d on d.id=s.district_id " + 
				" left join master_state st on st.id=s.state_id " + 
				" left join master_country c on c.id=s.country_id " + 
				" left join store_mappings sm on sm.store_id = s.id " + 
				" left join store mst on mst.id = sm.mapped_store_id " + 
				" left join master_district md on md.id=mst.district_id " + 
				" left join master_state mst1 on mst1.id=mst.state_id " + 
				" left join master_country mc on mc.id=mst.country_id where s.id = " + storeId  ;
				if( mappingType != null && !mappingType.isEmpty()) {
					query =query + " and sm.mapping_type = '" + mappingType + "' ";
				}
						
		log.info(query);
		List<LinkedStoreDTO> linkedStoreDTOs = jdbcTemplate.query(query, new BeanPropertyRowMapper<LinkedStoreDTO>(LinkedStoreDTO.class)); 
		return linkedStoreDTOs;
	}
}