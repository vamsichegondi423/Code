package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.CargoItemBatch;

@Repository
public interface CargoItemBatchRepository extends JpaRepository<CargoItemBatch, Long> {

	@Query(value = "select * from cargo_item_batch where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<CargoItemBatch> getById(Long id);

	@Query(value = "select * from cargo_item_batch where cargo_item_id = ?1 and batch_no = ?2 and is_deleted = false;", nativeQuery = true)
	public CargoItemBatch getCargoItemBatch(Long cargoItemId, String batchNo);

	@Query(value = "select * from cargo_item_batch where is_deleted = false", nativeQuery = true)
	public List<CargoItemBatch> findAll();

	@Query(value = "select sum(cargo_stock) :::: bigint as cargo_stock from cargo_item_batch where cargo_item_id=?1 and is_deleted = false", nativeQuery = true)
	public Long findByCargoItemId(Long cargoItemId);

	@Modifying
	@Transactional
	@Query(value = "delete from cargo_item_batch where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update cargo_item_batch set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select c.id as cargo_id,p.id as product_id,p.name as product_name,bib.batch_no,\n"
			+ "bib.batch_mf_date,bib.batch_expiry_date,bib.quantity,\n"
			+ "bi.reason,bi.shipped_stock,bi.ordered_stock,bi.fulfilled_stock from cargo c left join booking_items bi on bi.booking_id=c.booking_id\n"
			+ "left join booking_item_batch bib on bi.id=bib.booking_item_id left join product p on bi.product_id=p.id\n"
			+ "where c.booking_id=?1 and bi.product_id=?2 ", nativeQuery = true)
	public List<Map<String, Object>> getMaterialBatches(Long bookingId, Long productId);

	@Query(value = "select * from cargo_item_batch where cargo_item_id=?1 and batch_no =?2 and producer_id =?3 and is_deleted = false", nativeQuery = true)
	public List<CargoItemBatch> getProductBatchBycIdAndpid(Long cargoId, String batchNo,Integer producerId);

	@Query(value = "select batch_no,batch_expiry_date,fulfilled_stock from cargo_item_batch where cargo_item_id=?1 and fulfilled_stock > 0 and is_deleted = false", nativeQuery = true)
	public List<Map<String, Object>> findFulfilledOrderBatchesDetails(Long cargoItemId);

	@Query(value = " select sum(fulfilled_stock) from cargo_item_batch where cargo_item_id=?1 and is_deleted = false", nativeQuery = true)
	public Long findSumOfCargoFulfill(Long id);

	@Query(value = "select cib.batch_no,cib.batch_expiry_date,cib.cargo_stock,pr.name as manufacturer "
			+ " from cargo c join cargo_item ci on c.id=ci.cargo_id left join cargo_item_batch cib on ci.id=cib.cargo_item_id "
			+ " join bookings b on c.booking_id=b.id "
			+ " join booking_items bi on bi.booking_id=b.id and bi.product_id=ci.product_id "
			+ " left join icatalogue i on bi.store_id=i.store_id and bi.product_id=i.product_id "
			+ " left join icatalogue_batch ib on i.id=ib.icatalogue_id and ib.batch_no=cib.batch_no "
			+ " and ib.product_id=ci.product_id " + " left join producer pr on ib.producer_id=pr.id "
			+ " where c.is_deleted=false and b.is_deleted=false and bi.is_deleted=false "
			+ " and cib.cargo_item_id= ?1", nativeQuery = true)
	public List<Map<String, Object>> getCargoItemBatchByCargoItemId(Long cargoItemId);

	@Query(value = "select * from cargo_item_batch where cargo_item_id=?1 and is_deleted = false", nativeQuery = true)
	public List<CargoItemBatch> findCargoItemBatchDetails(Long cargoItemId);

}