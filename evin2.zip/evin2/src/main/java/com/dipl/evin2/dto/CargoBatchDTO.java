package com.dipl.evin2.dto;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

public interface CargoBatchDTO {
	@Value(("#{target.cargo_id}"))
	Long getCargoId();

	@Value(("#{target.product_id}"))
	Long getProductId();

	@Value(("#{target.product_name}"))
	String getProductName();

	@Value(("#{target.batch_no}"))
	String getBatchNo();

	@Value(("#{target.batch_expiry_date}"))
	Date getBatchExpiry();

	@Value(("#{target.batch_quantity}"))
	Long getBatchQuantity();

	@Value(("#{target.reason}"))
	String getReason();

	@Value(("#{target.fulfilled_stock}"))
	Long getFulfiledQuantity();

	@Value(("#{target.ordered_stock}"))
	Long getOrderedQuantity();
	
	@Value(("#{target.manufactured_date}"))
	String getManufacturedDate();
	
	@Value(("#{target.producer_name}"))
	String getProducerName();
	
	@Value(("#{target.producer_id}"))
	Integer getProducerId();
	
	@Value(("#{target.cargo_stock}"))
	Long getCargoQuantity(); 
	
//	@Value(("#{target.allocated_stock}"))
//	Long getAllocatedQuantity();
}
