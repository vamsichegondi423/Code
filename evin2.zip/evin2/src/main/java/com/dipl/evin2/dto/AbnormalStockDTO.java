package com.dipl.evin2.dto;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

public interface AbnormalStockDTO {
	@Value(("#{target.store_id}"))
	Long storeId();

	@Value(("#{target.product_id}"))
	Long productId();

	@Value(("#{target.created_on}"))
	Date createdOn();

	@Value(("#{target.date_start}"))
	String dateStart();

	@Value(("#{target.date_end}"))
	String dateEnd();

	@Value(("#{target.abnormal_type_id}"))
	Integer abnormalTypeId();

}
