package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import com.dipl.evin2.entity.SystemConfiguration;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface SystemConfigurationRepository extends JpaRepository<SystemConfiguration, Integer> {

	@Query(value = "select * from system_configuration where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<SystemConfiguration> getById(Integer id);

	@Query(value = "select * from system_configuration where  pranth_id = ?1 and version_no in (select max(version_no) from system_configuration where pranth_id = ?1 and is_deleted = false\n"
			+ "group by config_type_id)", nativeQuery = true)
	public List<SystemConfiguration> findAll(Long pranthId);

	@Modifying
	@Transactional
	@Query(value = "delete from system_configuration where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);
	
	@Modifying
	@Transactional
	@Query(value = "update system_configuration set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

	@Query(value = "select * from system_configuration where config_type_id = ?1 and pranth_id = ?2 and is_deleted = false order by version_no desc limit 1", nativeQuery = true)
	public Optional<SystemConfiguration> getByConfigutationType(Integer configutationTypeId, Long pranthId);
	
}