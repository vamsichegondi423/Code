package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dipl.evin2.entity.ReportSyncStatus;

@Repository
public interface ReportSyncStatusRepository extends JpaRepository<ReportSyncStatus, Long> {
	@Query(value = "select CAST(id as varchar) as id,TO_CHAR(created_on,'YYYY-MM-DD HH:MM:SS') as created_on ,TO_CHAR(updated_on,'YYYY-MM-DD HH:MM:SS') as updated_on from txn where id> (select coalesce(max(table_id),0) from report_sync_status where name_table='txn')", nativeQuery = true)
	public List<Map<String, String>> insertRecordsIntoDB();

}
