package com.dipl.evin2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterAssetType;
import com.dipl.evin2.repository.MasterAssetTypeRepository;

@Service
public class MasterAssetTypeService {

	@Autowired
	private MasterAssetTypeRepository masterAssetTypeRepository;

	@Cacheable(value = "master-asset-type", key = "#id")
	public MasterAssetType getById(Long id) {
		Optional<MasterAssetType> masterAssetTypeOptional = masterAssetTypeRepository.getById(id);
		if (masterAssetTypeOptional.isPresent()) {
			return masterAssetTypeOptional.get();
		} else {
			return null;
		}
	}

	@CachePut(value = "master-asset-type", key = "#masterAssetType.id")
	public MasterAssetType save(MasterAssetType masterAssetType) {
		if (masterAssetType.getId() != null && masterAssetType.getId() > 0) {
			Optional<MasterAssetType> existingMasterAssetTypeRecord = masterAssetTypeRepository
					.getById(masterAssetType.getId());
			if (existingMasterAssetTypeRecord.isPresent()) {
				return masterAssetTypeRepository.save(masterAssetType);
			}
		} else {
			masterAssetType = masterAssetTypeRepository.save(masterAssetType);
		}
		return masterAssetType;
	}

	@CacheEvict(value = "master-asset-type", allEntries = true)
	public Integer deleteById(Long id) {
		Optional<MasterAssetType> existingMasterAssetTypeRecord = masterAssetTypeRepository.getById(id);
		if (existingMasterAssetTypeRecord.isPresent()) {
			masterAssetTypeRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	@Cacheable(value = "master-asset-type")
	public List<MasterAssetType> getAll() {
		return masterAssetTypeRepository.findAll();
	}

	public List<MasterAssetType> saveAll(List<MasterAssetType> masterAssetTypes) {
		if (!masterAssetTypes.isEmpty()) {
			masterAssetTypes = masterAssetTypeRepository.saveAll(masterAssetTypes);
		}
		return masterAssetTypes;
	}
}