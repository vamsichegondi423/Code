package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterRole;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterRoleRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterRoleService {

	@Autowired
	private MasterRoleRepository masterRoleRepository;

	@Cacheable(value = "role", key = "#id")
	public MasterRole getById(Integer id) throws CustomException {
		try {
			Optional<MasterRole> masterRoleOptional = masterRoleRepository.getById(id);
			if (masterRoleOptional.isPresent()) {
				return masterRoleOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "role", key = "#masterRole.id")
	public MasterRole save(MasterRole masterRole) throws CustomException {
		try {
			if (masterRole.getId() != null && masterRole.getId() > 0) {
				Optional<MasterRole> existingMasterRoleRecord = masterRoleRepository.getById(masterRole.getId());
				if (existingMasterRoleRecord.isPresent()) {
					masterRole = masterRoleRepository.save(masterRole);
				}
			} else {
				masterRole = masterRoleRepository.save(masterRole);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterRole;
	}

	@CacheEvict(value = "role", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterRole> existingMasterRoleRecord = masterRoleRepository.getById(id);
			if (existingMasterRoleRecord.isPresent()) {
				masterRoleRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "role")
	public List<MasterRole> getAll(Optional<String> moduleNameOptional) {
		try {
			if (moduleNameOptional.isPresent()) {
				return masterRoleRepository.findByModuleName(moduleNameOptional.get());
			}
			return masterRoleRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}