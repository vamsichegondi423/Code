package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.entity.MasterDeviceType;
import com.dipl.evin2.repository.MasterDeviceTypeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterDeviceTypeService {

	@Autowired
	private MasterDeviceTypeRepository masterDeviceTypeRepository;

	@Cacheable(value = "device-type", key = "#id")
	public MasterDeviceType getById(Long id) throws CustomException {
		try {
			Optional<MasterDeviceType> masterDeviceTypeOptional = masterDeviceTypeRepository.getById(id);
			if (masterDeviceTypeOptional.isPresent()) {
				return masterDeviceTypeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "device-type", key = "#masterDeviceType.id")
	public MasterDeviceType save(MasterDeviceType masterDeviceType) throws CustomException {
		try {
			if (masterDeviceType.getId() != null && masterDeviceType.getId() > 0) {
				Optional<MasterDeviceType> existingMasterDeviceTypeRecord = masterDeviceTypeRepository
						.getById(masterDeviceType.getId());
				if (existingMasterDeviceTypeRecord.isPresent()) {
					return masterDeviceTypeRepository.save(masterDeviceType);
				}
			} else {
				masterDeviceType = masterDeviceTypeRepository.save(masterDeviceType);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterDeviceType;
	}

	@CacheEvict(value = "device-type", allEntries = true)
	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<MasterDeviceType> existingMasterDeviceTypeRecord = masterDeviceTypeRepository.getById(id);
			if (existingMasterDeviceTypeRecord.isPresent()) {
				masterDeviceTypeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "device-type")
	public List<MasterDeviceType> getAll() {
		try {
			return masterDeviceTypeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}