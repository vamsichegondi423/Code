package com.dipl.evin2.model;

import java.math.BigInteger;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpdateOrderModel {
	@JsonProperty("status")
	private String status;
	@JsonProperty("orderUpdatedAt")
	private Date OrderUpdatedAt;
	@JsonProperty("userId")
	private Long userId;
	private BigInteger pranthId;
	@JsonProperty("comments")
	private String comments;
	
	
}
