package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.MasterTimeZone;

@Repository
public interface MasterTimeZoneRepository extends JpaRepository<MasterTimeZone, Integer> {

	@Query(value = "select * from master_time_zone where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterTimeZone> getById(Integer id);

	@Query(value = "select * from master_time_zone where is_deleted = false", nativeQuery = true)
	public List<MasterTimeZone> findAll();
	
	@Query(value = "select * from master_time_zone where \"name\" = ? and  is_deleted = false", nativeQuery = true)
	public MasterTimeZone getMasterTimeZoneByName(String name);
	
	@Query(value = "select * from master_time_zone where short_name = ? and   is_deleted = false", nativeQuery = true)
	public MasterTimeZone getMasterTimeZone(String shortName);


	@Modifying
	@Transactional
	@Query(value = "delete from master_time_zone where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);

	@Modifying
	@Transactional
	@Query(value = "update master_time_zone set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

}