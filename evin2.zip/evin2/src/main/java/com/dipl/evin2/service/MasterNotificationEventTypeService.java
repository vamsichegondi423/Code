package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.entity.MasterNotificationEventType;
import com.dipl.evin2.repository.MasterNotificationEventTypeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterNotificationEventTypeService {

	@Autowired
	private MasterNotificationEventTypeRepository masterNotificationEventTypeRepository;

	@Cacheable(value = "notification-event-type", key = "#id")
	public MasterNotificationEventType getById(Integer id) throws CustomException {
		try {
			Optional<MasterNotificationEventType> masterNotificationEventTypeOptional = masterNotificationEventTypeRepository
					.getById(id);
			if (masterNotificationEventTypeOptional.isPresent()) {
				return masterNotificationEventTypeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "notification-event-type", key = "#masterNotificationEventType.id")
	public MasterNotificationEventType save(MasterNotificationEventType masterNotificationEventType)
			throws CustomException {
		try {
			if (masterNotificationEventType.getId() != null && masterNotificationEventType.getId() > 0) {
				Optional<MasterNotificationEventType> existingMasterNotificationEventTypeRecord = masterNotificationEventTypeRepository
						.getById(masterNotificationEventType.getId());
				if (existingMasterNotificationEventTypeRecord.isPresent()) {
					return masterNotificationEventTypeRepository.save(masterNotificationEventType);
				}
			} else {
				masterNotificationEventType = masterNotificationEventTypeRepository.save(masterNotificationEventType);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterNotificationEventType;
	}

	@CacheEvict(value = "notification-event-type", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterNotificationEventType> existingMasterNotificationEventTypeRecord = masterNotificationEventTypeRepository
					.getById(id);
			if (existingMasterNotificationEventTypeRecord.isPresent()) {
				masterNotificationEventTypeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "notification-event-type")
	public List<MasterNotificationEventType> getAll() {
		try {
			return masterNotificationEventTypeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}