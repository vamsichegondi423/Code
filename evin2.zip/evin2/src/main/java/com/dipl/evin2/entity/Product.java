/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "product")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Product extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	@Basic(optional = false)
	@Column(name = "name")
	private String name;
	@Column(name = "is_batch_enabled")
	private Boolean isBatchEnabled;
	@Column(name = "short_name")
	private String shortName;
	@Column(name = "description")
	private String description;
	@Column(name = "is_seasonal")
	private Boolean isSeasonal;
	@Column(name = "is_temperature_sensitive")
	private Boolean isTemperatureSensitive;
	@Column(name = "minimum_temperature")
	private Double minimumTemperature;
	@Column(name = "maximum_temperature")
	private Double maximumTemperature;
	@Column(name = "handling_unit")
	private Integer handlingUnit;
	

}
