package com.dipl.evin2.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.dipl.evin2.dto.AbnormalStockDTO;
import com.dipl.evin2.entity.IcatalogueLog;
import com.dipl.evin2.entity.ReportSyncStatus;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.IcatalogueLogRepository;
import com.dipl.evin2.repository.ReportSyncStatusRepository;
import com.dipl.evin2.util.AbnormalStockModel;
import com.dipl.evin2.util.KafkaProducer;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class IcatalogueLogService {

	@Autowired
	private IcatalogueLogRepository icatalogueLogRepository;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private KafkaProducer kafkaProducer;
	@Autowired
	private ReportSyncStatusRepository reportSyncStatusRepository;

	public IcatalogueLog getById(Long id) throws CustomException {
		try {
			Optional<IcatalogueLog> icatalogueLogOptional = icatalogueLogRepository.getById(id);
			if (icatalogueLogOptional.isPresent()) {
				return icatalogueLogOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public IcatalogueLog save(IcatalogueLog icatalogueLog) throws CustomException {
		try {
			if (icatalogueLog.getId() != null && icatalogueLog.getId() > 0) {
				Optional<IcatalogueLog> existingIcatalogueLogRecord = icatalogueLogRepository
						.getById(icatalogueLog.getId());
				if (existingIcatalogueLogRecord.isPresent()) {
					return icatalogueLogRepository.save(icatalogueLog);
				}
			} else {
				icatalogueLog = icatalogueLogRepository.save(icatalogueLog);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return icatalogueLog;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<IcatalogueLog> existingIcatalogueLogRecord = icatalogueLogRepository.getById(id);
			if (existingIcatalogueLogRecord.isPresent()) {
				icatalogueLogRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<IcatalogueLog> getAll() {
		try {
			return icatalogueLogRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public void fetchAllAbnormalStockDetails() {
		List<AbnormalStockDTO> abnormalStockDetails = icatalogueLogRepository.findAbnormalStocks();

		AbnormalStockDTO anst = abnormalStockDetails.get(abnormalStockDetails.size() - 1);

		for (AbnormalStockDTO dto : abnormalStockDetails) {
			AbnormalStockModel asm = null;
			String fromDate = dto.dateStart();
			String toDate = dto.dateEnd();
			int abnormalityType = dto.abnormalTypeId();
			Map<String, Long> datesMap = findDifference(fromDate, toDate);
			Long noDays = 1l;
			if (datesMap.get("days") > 0) {
				noDays = datesMap.get("days");
			}
			Map<String, String> dateParsemap = parseDate(dto.createdOn().toString());
			asm = new AbnormalStockModel().builder().storeId(dto.storeId()).productId(dto.productId())
					.abnormalStockDate(dateParsemap.get("date")).abnormalStockMonth(dateParsemap.get("month"))
					.abnormalStockYear(dateParsemap.get("year")).abnormalStockTypeId(dto.abnormalTypeId())
					.durationDays(noDays).build();
			kafkaProducer.saveAbnormalStockIntoQueue(asm);
		}

		ReportSyncStatus rss = new ReportSyncStatus().builder().nameTable("abnormal_stock").createdOn(anst.createdOn())
				.tableId(12).isSynyced(true).build();

		reportSyncStatusRepository.save(rss);
	}

	private Map<String, Long> findDifference(String start_date, String end_date) {
		Map<String, Long> dateMap = new HashMap<String, Long>();
		// SimpleDateFormat converts the
		// string format to date object
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			// parse method is used to parse
			// the text from a string to
			// produce the date
			Date d1 = sdf.parse(start_date);
			Date d2 = sdf.parse(end_date != null ? end_date : start_date);

			// Calucalte time difference
			// in milliseconds
			long difference_In_Time = d2.getTime() - d1.getTime();

			// Calucalte time difference in
			// seconds, minutes, hours, years,
			// and days

			long difference_In_Minutes = (difference_In_Time / (1000 * 60)) % 60;

			long difference_In_Hours = (difference_In_Time / (1000 * 60 * 60)) % 24;

			long difference_In_Years = (difference_In_Time / (1000l * 60 * 60 * 24 * 365));

			long difference_In_Days = (difference_In_Time / (1000 * 60 * 60 * 24)) % 365;

			dateMap.put("hours", difference_In_Hours);
			dateMap.put("days", difference_In_Days);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dateMap;
	}

	private Map<String, String> parseDate(String date) {
		Map<String, String> dateParsingMap = new HashMap<String, String>();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date consumptionDate;
		try {
			consumptionDate = simpleDateFormat.parse(date);
			String dte = simpleDateFormat.format(consumptionDate);
			SimpleDateFormat month = new SimpleDateFormat("MM");
			SimpleDateFormat day = new SimpleDateFormat("dd");
			SimpleDateFormat year = new SimpleDateFormat("yyyy");
			dateParsingMap.put("year", year.format(consumptionDate));
			dateParsingMap.put("month", month.format(consumptionDate));
			dateParsingMap.put("date", dte);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dateParsingMap;
	}
	
	public void saveIcatalogueLog(Integer productId, Long storeId, Long pranthId, Integer txnTypeId, Long txnId,
			Long icatId, Long createdBy, Boolean isDeleted, Integer abnormalTypeId) {
		IcatalogueLog requestLog = IcatalogueLog.builder().storeId(storeId).productId(productId).pranthId(pranthId)
				.txnTypeId(txnTypeId).txnId(txnId).icatalogueId(icatId).abnormalTypeId(abnormalTypeId).build();
		requestLog.setCreatedBy(createdBy);
		requestLog.setIsDeleted(isDeleted);
		
		IcatalogueLog icatalogueLog = icatalogueLogRepository.getIcatalogueDetails(requestLog.getIcatalogueId(),
				requestLog.getProductId(), requestLog.getStoreId());
		if (icatalogueLog == null) {
			requestLog.setDateStart(new Date());
			requestLog.setUpdatedBy(requestLog.getCreatedBy());
			icatalogueLogRepository.save(requestLog);
		} else if (icatalogueLog.getAbnormalTypeId().equals(requestLog.getAbnormalTypeId())) {
			icatalogueLogRepository.save(icatalogueLog);
		} else {
			icatalogueLog.setDateEnd(new Date());
			icatalogueLog.setUpdatedBy(requestLog.getCreatedBy());
			icatalogueLog.setUpdatedOn(new Date());
			IcatalogueLog icatLog = icatalogueLogRepository.save(icatalogueLog);
			requestLog.setDateStart(icatLog.getDateEnd());
			requestLog.setUpdatedBy(requestLog.getCreatedBy());
			icatalogueLogRepository.save(requestLog);
		}
	}
}