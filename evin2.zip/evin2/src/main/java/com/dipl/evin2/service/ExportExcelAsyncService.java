package com.dipl.evin2.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.dipl.evin2.controller.BookingsController.BookingsByFilterPayload;
import com.dipl.evin2.controller.CargoController.CargoFilterModel;
import com.dipl.evin2.controller.CargoController.ShipmenByFiltertDTO;
import com.dipl.evin2.controller.IcatalogueController;
import com.dipl.evin2.controller.IcatalogueController.IcatalogueDetails;
import com.dipl.evin2.dto.ExportBookingsDTO;
import com.dipl.evin2.dto.ExportStockReportDTO;
import com.dipl.evin2.dto.TxnWithBatchDTO;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.model.ExportStockDeviantPayload;
import com.dipl.evin2.model.ExportStockReportModel;
import com.dipl.evin2.model.ExportTxnModel;
import com.dipl.evin2.model.FileReportResponse;
import com.dipl.evin2.service.RolePermissionConfigurationService.RolePermissionConfigurationModel;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.JdbcTemplateHelper;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ExportExcelAsyncService {
	@Autowired
	private BookingsService bookingsService;
	@Autowired
	private SendEmailService sendEmailService;
	@Autowired
	private UploadFileService uploadFileService;
	@Autowired
	private PranthHierarchyService pranthHierarchyService;
	@Autowired
	private UsersService usersService;
	@Autowired
	private RolePermissionConfigurationService rolePermissionConfigurationService;
	@Autowired
	private JdbcTemplateHelper jdbcTemplateHelper;
	@Autowired
	private IcatalogueController icatalogueController;
	@Autowired
	private ExportBookingService exportBookingService;
	@Autowired
	private ExportShimpentService exportShimpentService;
	@Autowired
	private ExportStockReportService exportStockReportService;
	@Autowired
	private ExportTransactionService exportTransactionService;
	@Autowired
	private ExportStockDeviantService exportStockDeviantService;
	
	
	@Async
	public void getBookingsExportData(BookingsByFilterPayload bookingsByFilterPayload, Long pranthId, Long userId,
			String userName, String email, List<Long> offsetStoreIds) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<ExportBookingsDTO> bookings = null;
		Object fileData;
		StringBuilder builder = new StringBuilder();
		String url = null;
		Workbook workbook = null;
		Sheet sheet = null;
		FileOutputStream outputStream = null;

		try {

			Set<Long> consolidatedDomainIds = pranthHierarchyService
					.getConsolidatedPranthIds(bookingsByFilterPayload.getPranthId());
			String queryForConsolidatedDomainIds = pranthHierarchyService.buildQuery(consolidatedDomainIds);

			// fetching booking details from query
			bookings = exportBookingService.getBookingsData(bookingsByFilterPayload, builder, queryForConsolidatedDomainIds, null, userId,
					offsetStoreIds, pranthId);
			//creating workbook
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0, cellIndex3 = 0;
			// Creating row
			Row row = sheet.createRow(0);

			row.createCell(cellIndex++).setCellValue("Title");
			row.createCell(cellIndex++).setCellValue("" + Constants.booking + "");
			Row row1 = sheet.createRow(1);
			row1.createCell(cellIndex1++).setCellValue("Generated on");
			row1.createCell(cellIndex1++).setCellValue("" + uploadFileService.dateWithHoursMinutes());

			// creating headers/columns
			Row row3 = sheet.createRow(3);
			row3.createCell(cellIndex3++).setCellValue("Booking Id");
			row3.createCell(cellIndex3++).setCellValue("Booking Items Count");
			row3.createCell(cellIndex3++).setCellValue("Booking Badge");
			row3.createCell(cellIndex3++).setCellValue("Booking Ref No");
			row3.createCell(cellIndex3++).setCellValue("Status");
			row3.createCell(cellIndex3++).setCellValue("Issuing Store Name");
			row3.createCell(cellIndex3++).setCellValue("Issuing Store Tag");
			row3.createCell(cellIndex3++).setCellValue("Country");
			row3.createCell(cellIndex3++).setCellValue("State");
			row3.createCell(cellIndex3++).setCellValue("District");
			// row3.createCell(cellIndex3++).setCellValue("Taluk/Block");
			row3.createCell(cellIndex3++).setCellValue("Village/City");
			row3.createCell(cellIndex3++).setCellValue("Receiving Store Name");
			row3.createCell(cellIndex3++).setCellValue("Receiving Store Tag");
			row3.createCell(cellIndex3++).setCellValue("Country");
			row3.createCell(cellIndex3++).setCellValue("State");
			row3.createCell(cellIndex3++).setCellValue("District");
			// row3.createCell(cellIndex3++).setCellValue("Taluk/Block");
			row3.createCell(cellIndex3++).setCellValue("Village/City");

			// row3.createCell(cellIndex3++).setCellValue("Products");
			row3.createCell(cellIndex3++).setCellValue("Product Tag");
			row3.createCell(cellIndex3++).setCellValue("Recommended Quantity");
			row3.createCell(cellIndex3++).setCellValue("Ordered Quantity");
			row3.createCell(cellIndex3++).setCellValue("Reason");
			row3.createCell(cellIndex3++).setCellValue("CreatedBy");
			row3.createCell(cellIndex3++).setCellValue("CreatedOn");
			row3.createCell(cellIndex3++).setCellValue("UpdatedBy");
			row3.createCell(cellIndex3++).setCellValue("UpdatedOn");

			// displaying data under headers
			for (int i = 0; i < bookings.size(); i++) {
				Row dataRow = sheet.createRow(i + 4);
				int rowIndex1 = 0;
				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getBookingId() == null ? "" : bookings.get(i).getBookingId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getBookingItemsCount() == null ? 0
						: bookings.get(i).getBookingItemsCount());
				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getBookingBadge() == null ? "" : bookings.get(i).getBookingBadge() + "");

				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getOrderReferenceNo() == null ? ""
						: bookings.get(i).getOrderReferenceNo() + "");
				dataRow.createCell(rowIndex1++)
						.setCellValue(bookings.get(i).getStatus() == null ? "" : bookings.get(i).getStatus() + "");

				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getIssuingStoreName() == null ? ""
						: bookings.get(i).getIssuingStoreName() + "");

				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getIssuingStoreBadge() == null ? ""
						: bookings.get(i).getIssuingStoreBadge() + "");

				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getIsCountry() == null ? "" : bookings.get(i).getIsCountry() + "");
				dataRow.createCell(rowIndex1++)
						.setCellValue(bookings.get(i).getIsState() == null ? "" : bookings.get(i).getIsState() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getIsDistrict() == null ? "" : bookings.get(i).getIsDistrict() + "");
				dataRow.createCell(rowIndex1++)
						.setCellValue(bookings.get(i).getIsCity() == null ? "" : bookings.get(i).getIsCity() + "");
				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getRecevingStoreName() == null ? ""
						: bookings.get(i).getRecevingStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getReceivingStoreBadge() == null ? ""
						: bookings.get(i).getReceivingStoreBadge() + "");

				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getRsCountry() == null ? "" : bookings.get(i).getRsCountry() + "");
				dataRow.createCell(rowIndex1++)
						.setCellValue(bookings.get(i).getRsState() == null ? "" : bookings.get(i).getRsState() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getRsDistrict() == null ? "" : bookings.get(i).getRsDistrict() + "");
				dataRow.createCell(rowIndex1++)
						.setCellValue(bookings.get(i).getRsCity() == null ? "" : bookings.get(i).getRsCity() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getProductBadge() == null ? "" : bookings.get(i).getProductBadge() + "");

				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getRecommandedStock() == null ? 0
						: bookings.get(i).getRecommandedStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getOrderedQuantity() == null ? 0 : bookings.get(i).getOrderedQuantity());

				dataRow.createCell(rowIndex1++)
						.setCellValue(bookings.get(i).getReason() == null ? "" : bookings.get(i).getReason() + "");

				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getCreatedBy() == null ? "" : bookings.get(i).getCreatedBy() + "");

				Cell cell = dataRow.createCell(rowIndex1++);
				cell.setCellValue(
						bookings.get(i).getCreatedOn() == null ? null : bookings.get(i).getCreatedOn());
				cell.setCellStyle(dateCellStyle);

				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getUpdatedBy() == null ? "" : bookings.get(i).getUpdatedBy() + "");

				Cell cell1 = dataRow.createCell(rowIndex1++);

				cell1.setCellValue(
						bookings.get(i).getUpdatedOn() == null ? null : bookings.get(i).getUpdatedOn());
				cell1.setCellStyle(dateCellStyle);

			}

			// creatng temporary excel file
			File tempFile = null;
			tempFile = File.createTempFile("BookingsReport", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
			workbook.write(outputStream);
			sheet.getWorkbook().close();
			// uploading file
			HttpResponse<String> response = uploadFileService.uploadFile(url,userName, tempFile, "Bookings");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			// deleting temporary excel file
			tempFile.delete();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";
			// sending email to particular user
			HashMap<String, Object> emailbody = new HashMap<>();
			emailbody = sendEmailService.getBookngEmail(link, userName, email);

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, email, userName,
					fileDownloadUrl, fileType, fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ email
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured while exporting booking report : " + e.getStackTrace());
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting booking report ");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		finally{
			
			outputStream.close();
			workbook.close();
		}
//		return responsebean;
	}
	@Async
	public void getShipmentExportData(CargoFilterModel shipmentPayload, Long pranthId,
			Long userId, String userName, String email, List<Long> offsetStoreIds) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<ShipmenByFiltertDTO> shipments = null;
		FileOutputStream outputStream = null;
		Workbook workbook = null;
		Sheet sheet = null;
		Object fileData;
		String url = null;
		try {
			StringBuilder builder = new StringBuilder();
			Set<Long> consolidatedDomainIds = pranthHierarchyService
					.getConsolidatedPranthIds(shipmentPayload.getPranthId());
			String queryForConsolidatedDomainIds = pranthHierarchyService.buildQuery(consolidatedDomainIds);
			shipments = exportShimpentService.getCargoDataByQuery(shipmentPayload, builder, queryForConsolidatedDomainIds, offsetStoreIds);
			//creating workbook
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0, cellIndex3 = 0;
			// Creating row
			Row row = sheet.createRow(0);

			row.createCell(cellIndex++).setCellValue("Title");
			row.createCell(cellIndex++).setCellValue("" + Constants.shipment + "");
			Row row1 = sheet.createRow(1);
			row1.createCell(cellIndex1++).setCellValue("Generated on");
			row1.createCell(cellIndex1++).setCellValue("" + uploadFileService.dateWithHoursMinutes());

			Row row3 = sheet.createRow(3);
			row3.createCell(cellIndex3++).setCellValue("ShipmentId");
			row3.createCell(cellIndex3++).setCellValue("IndentId");
			row3.createCell(cellIndex3++).setCellValue("NoOfShipments");
			row3.createCell(cellIndex3++).setCellValue("ReceivingStoreName");
			row3.createCell(cellIndex3++).setCellValue("ReceivingStoreLocation");
			row3.createCell(cellIndex3++).setCellValue("IssuingStoreName");
			row3.createCell(cellIndex3++).setCellValue("IssuingStoreLocation");
			row3.createCell(cellIndex3++).setCellValue("Status");
			row3.createCell(cellIndex3++).setCellValue("CreatedName");
			row3.createCell(cellIndex3++).setCellValue("CreatedOn");
			row3.createCell(cellIndex3++).setCellValue("Transporter");
			row3.createCell(cellIndex3++).setCellValue("UserName");
			row3.createCell(cellIndex3++).setCellValue("ExpectedDateArrival");

			for (int i = 0; i < shipments.size(); i++) {
				Row dataRow = sheet.createRow(i + 4);
				int rowIndex1 = 0;
				dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getCargoNo() == null ? "" : shipments.get(i).getCargoNo() + "");
				
				dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getBookingId() == null ? "" : shipments.get(i).getBookingId() + "");
				
				dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getNoOfItems() == null ? 0 : shipments.get(i).getNoOfItems());
				
				dataRow.createCell(rowIndex1++).setCellValue(shipments.get(i).getReceivingStoreName() == null ? ""
						: shipments.get(i).getReceivingStoreName() + "");
				
				dataRow.createCell(rowIndex1++)
						.setCellValue(shipments.get(i).getReceivingStoreLocation() == null ? ""
								: shipments.get(i).getReceivingStoreLocation() + "");
				
				dataRow.createCell(rowIndex1++).setCellValue(shipments.get(i).getIssuingStoreName() == null ? ""
						: shipments.get(i).getIssuingStoreName()+ "");
				
				dataRow.createCell(rowIndex1++).setCellValue(shipments.get(i).getIssuingStoreLocation() == null ? ""
						: shipments.get(i).getIssuingStoreLocation() + "");
				
				dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getStatus() == null ? "" : shipments.get(i).getStatus() + "");
				
				dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getCreatedName() == null ? "" : shipments.get(i).getCreatedName() + "");	
				
				Cell cell = dataRow.createCell(rowIndex1++);
				cell.setCellValue(
						shipments.get(i).getCreatedOn() == null ? null : shipments.get(i).getCreatedOn());
				cell.setCellStyle(dateCellStyle);
				
				dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getTransporter() == null ? "" : shipments.get(i).getTransporter() + "");
				
					dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getUserId() == null ? "" : shipments.get(i).getUserId() + "");
				
			   Cell cell1 = dataRow.createCell(rowIndex1++);
				cell1.setCellValue(
						shipments.get(i).getExpectedDateArrvl() == null ? null : shipments.get(i).getExpectedDateArrvl());
				cell1.setCellStyle(dateCellStyle);

			}

			File tempFile = null;
			tempFile = File.createTempFile("ShipmentReport", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
			workbook.write(outputStream);
			HttpResponse<String> response = uploadFileService.uploadFile(url, userName, tempFile,"Shipment");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			tempFile.delete();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";

			HashMap<String, Object> emailbody = new HashMap<>();
			emailbody = sendEmailService.getShipmentEmail(link, userName, email);

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, email, userName,
					fileDownloadUrl, fileType, fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ email
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting shipment report : " + e.getStackTrace());
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting shipment report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		finally {
			
			outputStream.close();
			workbook.close();
		}
//		return responsebean;
	}
	@Async
	public void getStockWithoutBatch(ExportStockReportModel exportStockReportModel) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<ExportStockReportDTO> stockReports = null;
		Object fileData;
		String url = null;
		File file = File.createTempFile("StockReport", ".csv");
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
	//	Writer writer = Files.newBufferedWriter(file.toPath());
		bw.write("Title," + Constants.stock_report);
		bw.newLine();
		bw.write("Generated on," + uploadFileService.dateWithHoursMinutes());
		bw.newLine();
		bw.newLine();

		CSVPrinter csvPrinter = new CSVPrinter(bw,
				CSVFormat.DEFAULT.withHeader("Material Name", "Material Tags", "Store Name", "Store Tags", "Country",
						"State", "District/County", "Taluk/Block", "Village/City", "Total Stock", "Days Of Stock",
						"Allocated Stock", "In Transit Stock", "Min Stock", "Max Stock", "Abnormality Type",
						"Abnormality Duration-Days", "Updated On"));
		

		Users users = usersService.getById(exportStockReportModel.getUserId());
		RolePermissionConfigurationModel permissionConfigurationModel = rolePermissionConfigurationService
				.getPermissionCodeValue("mnstomtbhfiv29", users.getRoleId(), exportStockReportModel.getPranthId());
		
		Set<Long> consolidatedPranthIds = pranthHierarchyService
				.getConsolidatedPranthIds(exportStockReportModel.getPranthId());
		List<Long> totalKioskIdsWithOutPagination = icatalogueController.getToatalStoreIdsWithoutPagination(
				consolidatedPranthIds, exportStockReportModel.getUserId(), exportStockReportModel.getState(),
				exportStockReportModel.getDistrict(), exportStockReportModel.getBlock());
		stockReports = exportStockReportService.getAllProductsBasedOnPranth(totalKioskIdsWithOutPagination, consolidatedPranthIds,
				 exportStockReportModel);
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/mm/dd hh:mm:ss");		

		stockReports.stream().forEach(s -> {
			// Writing records in the generated CSV file
			try {
				csvPrinter.printRecord(
						s.getProductName() == null ? "" : s.getProductName(),
						s.getProductBadge() == null ? "" : s.getProductBadge(),
						s.getStoreName() == null ? "" : s.getStoreName(),
						s.getStoreBadge() == null ? "" : s.getStoreBadge(),
						s.getCountryName() == null ? "" : s.getCountryName(),
						s.getStateName() == null ? "" : s.getStateName(),
						s.getDistrictName() == null ? "" : s.getDistrictName(),
						s.getBlock_name() == null ? "" : s.getBlock_name(),
						s.getCity() == null ? "" : s.getCity(),
						s.getTotalStock() == null ? 0 : s.getTotalStock(),
						s.getDaysOfStock() == null ? 0 : s.getDaysOfStock(),
						s.getAllocatedStock() == null ? 0 : s.getAllocatedStock(),
						s.getInTransitStock() == null ? 0 : s.getInTransitStock(),
						s.getMinStock() == null ? 0 : s.getMinStock(),
						s.getMaxStock() == null ? 0 : s.getMaxStock(),
						s.getAbnormalityType() == null ? "" : s.getAbnormalityType(),
						s.getAbnormalityDurationDays() == null ? 0 : s.getAbnormalityDurationDays(),
						s.getUpdatedOn() == null ? "": dateFormat.format(s.getUpdatedOn()));
				        
			} catch (IOException e) {
				e.printStackTrace();
			}
		});

		csvPrinter.flush();
		csvPrinter.close();
		log.info("File path {}", file.getAbsolutePath());
			// uploading excel file
			HttpResponse<String> response = uploadFileService.uploadFile(url, exportStockReportModel.getUserName(),
					file, "StockReport");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			Map<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			file.delete();

			HashMap<String, Object> emailbody = new HashMap<>();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";

			// sending excel file to particular user's email
			emailbody = sendEmailService.getStockReportEmail(link, exportStockReportModel.getUserName(),
					exportStockReportModel.getEmail());

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody,
					exportStockReportModel.getEmail(), exportStockReportModel.getUserName(), fileDownloadUrl, fileType,
					fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ exportStockReportModel.getEmail()
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting stock report : {}", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		} 
		bw.close();
//		return responsebean;
	}
	@Async
	public void getStockWithBatch(ExportStockReportModel exportStockReportModel) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<ExportStockReportDTO> stockReports = null;
		Object fileData;
		String url = null;
		File file = File.createTempFile("StockReport", ".csv");
		BufferedWriter bw = null;

		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
			//Writer writer = Files.newBufferedWriter(file.toPath());
			bw.write("Title," + Constants.stock_report);
			bw.newLine();
			bw.write("Generated on," + uploadFileService.dateWithHoursMinutes());
			bw.newLine();
			bw.newLine();
			CSVPrinter csvPrinter = new CSVPrinter(bw,
					CSVFormat.DEFAULT.withHeader("Material Name", "Material Tags", "Store Name", "Store Tags", "Country",
							"State", "District/County", "Taluk/Block", "Village/City", "Batch ID","Stock In Batch","Batch Expiry","Batch Manufacturer","Batch Manufactured Date","Batch Updated On","Total Stock", "Days Of Stock",
							"Allocated Stock", "In Transit Stock", "Min Stock", "Max Stock", "Abnormality Type",
							"Abnormality Duration-Days", "Updated On"));
			
            // getting stock reports from query
			Users users = usersService.getById(exportStockReportModel.getUserId());
			RolePermissionConfigurationModel permissionConfigurationModel = rolePermissionConfigurationService.getPermissionCodeValue("mnstomtbhfiv29", users.getRoleId(), exportStockReportModel.getPranthId());
			Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(exportStockReportModel.getPranthId());
			List<Long> totalKioskIdsWithOutPagination = icatalogueController.getToatalStoreIdsWithoutPagination(consolidatedPranthIds, exportStockReportModel.getUserId(), exportStockReportModel.getState(), exportStockReportModel.getDistrict(), exportStockReportModel.getBlock());
			stockReports = exportStockReportService.getAllProductsBasedOnPranthWithBatch(totalKioskIdsWithOutPagination,consolidatedPranthIds,exportStockReportModel);
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/mm/dd hh:mm:ss");		

			stockReports.stream().forEach(s -> {
					// Writing records in the generated CSV file
					try {
						csvPrinter.printRecord(
								s.getProductName() == null ? "" : s.getProductName(),
								s.getProductBadge() == null ? "" : s.getProductBadge(),
								s.getStoreName() == null ? "" : s.getStoreName(),
								s.getStoreBadge() == null ? "" : s.getStoreBadge(),
								s.getCountryName() == null ? "" : s.getCountryName(),
								s.getStateName() == null ? "" : s.getStateName(),
								s.getDistrictName() == null ? "" : s.getDistrictName(),
								s.getBlock_name() == null ? "" : s.getBlock_name(),
								s.getCity() == null ? "" : s.getCity(),
										
								s.getBatchNo() == null ? "" : s.getBatchNo(),
								s.getStockInBatch() == null ? 0 : s.getStockInBatch(),
								s.getBatchExpiry() == null ? "" : s.getBatchExpiry(),
								s.getBatchManufacturer() == null ? "" : s.getBatchManufacturer(),
								s.getBatchManufacturedDate() == null ? "" : s.getBatchManufacturedDate(),
								s.getBatchUpdatedOn() == null ? "" :  dateFormat.format(s.getBatchUpdatedOn()),

								s.getTotalStock() == null ? 0 : s.getTotalStock(),
								s.getDaysOfStock() == null ? 0 : s.getDaysOfStock(),
								s.getAllocatedStock() == null ? 0 : s.getAllocatedStock(),
								s.getInTransitStock() == null ? 0 : s.getInTransitStock(),
								s.getMinStock() == null ? 0 : s.getMinStock(),
								s.getMaxStock() == null ? 0 : s.getMaxStock(),
								s.getAbnormalityType() == null ? "" : s.getAbnormalityType(),
								s.getAbnormalityDurationDays() == null ? 0 : s.getAbnormalityDurationDays(),
								s.getUpdatedOn() == null ? "": dateFormat.format(s.getUpdatedOn()));
					} catch (IOException e) {
						e.printStackTrace();
					}
				});

			
			csvPrinter.flush();
			csvPrinter.close();
			
            //uploading excel file
			HttpResponse<String> response = uploadFileService.uploadFile(url,exportStockReportModel.getUserName(), file, "StockReport");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			file.delete();

			HashMap<String, Object> emailbody = new HashMap<>();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";

			//sending excel file to particular user's email
			emailbody = sendEmailService.getStockReportEmail(link, exportStockReportModel.getUserName(), exportStockReportModel.getEmail());

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, exportStockReportModel.getEmail(), exportStockReportModel.getUserName(),
					fileDownloadUrl, fileType, fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ exportStockReportModel.getEmail()
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting stock report : {}", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		bw.close();
//		return responsebean;
	}
	@Async
	public void getTransactionDataWithBatch(ExportTxnModel txnPayload, 	String userName, String email,Long pranthId, Long userId, List<Long> offsetStoreIds) throws IOException {
		ResponseBean responsebean = new ResponseBean();
		List<TxnWithBatchDTO> transactions = null;
		Object fileData;
		String url = null;
		Workbook workbook = null;
		Sheet sheet = null;
		FileOutputStream outputStream = null;
		try {
			transactions = exportTransactionService.getAllStoresByTransactionLevelWithBatch(txnPayload,userName, email, pranthId, userId, offsetStoreIds);
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0,cellIndex2 = 0, cellIndex3 = 0;
			// Creating row
			Row titleRow = sheet.createRow(0);

			titleRow.createCell(cellIndex++).setCellValue("Title");
			titleRow.createCell(cellIndex++).setCellValue(""+Constants.transaction+"");

			Row dateRow = sheet.createRow(1);
			dateRow.createCell(cellIndex1++).setCellValue("Generated on");
			dateRow.createCell(cellIndex1++).setCellValue("" + uploadFileService.dateWithHoursMinutes());

			StringBuilder filterString = new StringBuilder();
			if (txnPayload.getTxnType() != null && !txnPayload.getTxnType().isEmpty()) {
				filterString.append("Type : " + txnPayload.getTxnType());
			}
			String storeTagNames = null;
			Set<String> storeBadges = new HashSet<>()	;

			for(TxnWithBatchDTO txns : transactions ) {
				storeTagNames = txns.getStoreBadges();
				storeBadges.add(storeTagNames);

			}	
			if (txnPayload.getStoreBadge() != null) {
				filterString.append(" Facility Tag : "+ StringUtils.join(storeBadges, ",") + "  ");
			}
			
			log.info(""+storeBadges);

			String materialTagNames = null;
			Set<String> uniqueMaterialBadges = new HashSet<>();

			for(TxnWithBatchDTO txns : transactions ) {
			 materialTagNames = txns.getMaterialBadges();
			 uniqueMaterialBadges.add(materialTagNames);

			}			
			log.info(""+uniqueMaterialBadges);
			if (txnPayload.getProductBadge() != null) {
				
				filterString.append("Material Tag :  " + StringUtils.join(uniqueMaterialBadges, ",") + "  ");

			}
			if (txnPayload.getTxnReason() != null) {
				filterString.append(" Txn Reason :" + txnPayload.getTxnReason());
			}
			if (txnPayload.getIsActualTxn() != null && txnPayload.getIsActualTxn() == true) {
				filterString.append(" Filter by date of actual transaction : " +txnPayload.getIsActualTxn() );
			}else {
				filterString.append(" Filter by date of actual transaction : " +false );
			}
			if (txnPayload.getTxnsFromDate() != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				filterString.append(
						" From Date : " + dateFormat.format(txnPayload.getTxnsFromDate()));
			}
			if (txnPayload.getTxnsToDate() != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				filterString.append(
						" To Date : " + dateFormat.format(txnPayload.getTxnsToDate()));
			}
			if (txnPayload.getState() != null) {
				filterString.append(" State : " + txnPayload.getState());
			}
			if (txnPayload.getDistrict() != null) {
				filterString.append(" District : " + txnPayload.getDistrict());

			}
			if (txnPayload.getBlock() != null) {
				filterString.append(" Block : " +"");

			}			
			
			Row filterRow = sheet.createRow(2);
			filterRow.createCell(cellIndex2++).setCellValue("filter");
			filterRow.createCell(cellIndex2++).setCellValue(""+filterString);

			//Creating Headers/Columns
			Row headerRow = sheet.createRow(4);

			headerRow.createCell(cellIndex3++).setCellValue("Transaction ID");
			headerRow.createCell(cellIndex3++).setCellValue("Transaction Type");
			headerRow.createCell(cellIndex3++).setCellValue("Tracking Object Type");
			headerRow.createCell(cellIndex3++).setCellValue("Tracking No");
			headerRow.createCell(cellIndex3++).setCellValue("Store id");	
			headerRow.createCell(cellIndex3++).setCellValue("Store Name");
			headerRow.createCell(cellIndex3++).setCellValue("Store tag");	
			headerRow.createCell(cellIndex3++).setCellValue("Material ID");
			headerRow.createCell(cellIndex3++).setCellValue("Material Name");
			headerRow.createCell(cellIndex3++).setCellValue("Material Tag");
			headerRow.createCell(cellIndex3++).setCellValue("Opening Stock");
			headerRow.createCell(cellIndex3++).setCellValue("Qunaity");
			headerRow.createCell(cellIndex3++).setCellValue("Closing Stock");
			headerRow.createCell(cellIndex3++).setCellValue("Reason");
			headerRow.createCell(cellIndex3++).setCellValue("Material Status");	
			headerRow.createCell(cellIndex3++).setCellValue("updated on");
			headerRow.createCell(cellIndex3++).setCellValue("Date of actual transaction");
			headerRow.createCell(cellIndex3++).setCellValue("Receiving Store ID");
			headerRow.createCell(cellIndex3++).setCellValue("Receiving store name");
			headerRow.createCell(cellIndex3++).setCellValue("Batch ID");
			headerRow.createCell(cellIndex3++).setCellValue("Batch Expiry");		
			headerRow.createCell(cellIndex3++).setCellValue("Batch Manufacturer");
			headerRow.createCell(cellIndex3++).setCellValue("Batch Manufacture date");	
			headerRow.createCell(cellIndex3++).setCellValue("Opening stock of batch");
			headerRow.createCell(cellIndex3++).setCellValue("Closing stock of batch");	
			headerRow.createCell(cellIndex3++).setCellValue("Country");
			headerRow.createCell(cellIndex3++).setCellValue("State");
			headerRow.createCell(cellIndex3++).setCellValue("District");
			headerRow.createCell(cellIndex3++).setCellValue("Taluk/Block");	
			headerRow.createCell(cellIndex3++).setCellValue("Village/City");
			headerRow.createCell(cellIndex3++).setCellValue("Zip/PIN code");
			headerRow.createCell(cellIndex3++).setCellValue("Latitude");
			headerRow.createCell(cellIndex3++).setCellValue("Longitude");	
			headerRow.createCell(cellIndex3++).setCellValue("Transaction source");
			headerRow.createCell(cellIndex3++).setCellValue("Created by ID");	
			headerRow.createCell(cellIndex3++).setCellValue("Created by full name");
			//Displaying data under headers
			for (int i = 0; i < transactions.size(); i++) {
				Row dataRow = sheet.createRow(i + 5);
				int rowIndex1 = 0;

				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTransactionId() == null ? "": transactions.get(i).getTransactionId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTransactionType() == null ? "": transactions.get(i).getTransactionType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTrackingObjectType() == null ? "": transactions.get(i).getTrackingObjectType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTrackingNo() == null ? "": transactions.get(i).getTrackingNo() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getStoreId() == null ? "": transactions.get(i).getStoreId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getStoreName() == null ? "": transactions.get(i).getStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getStoreBadges() == null ? "": transactions.get(i).getStoreBadges() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getProductId() == null ? "": transactions.get(i).getProductId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getProductName() == null ? "": transactions.get(i).getProductName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getMaterialBadges() == null ? "": transactions.get(i).getMaterialBadges() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getOpeningStock() == null ? 0: transactions.get(i).getOpeningStock());
				dataRow.createCell(rowIndex1++).setCellValue( transactions.get(i).getQuantity() == null ? 0: transactions.get(i).getQuantity());
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getClosingStock() == null ? 0: transactions.get(i).getClosingStock());
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTransactionReason() == null ? "": transactions.get(i).getTransactionReason() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getMaterialReason() == null ? "": transactions.get(i).getMaterialReason() + "");
				Cell cell = dataRow.createCell(rowIndex1++);
				cell.setCellValue(
						transactions.get(i).getUpdatedOn() == null ? null : transactions.get(i).getUpdatedOn());
				cell.setCellStyle(dateCellStyle);
				
				Cell cell1 = dataRow.createCell(rowIndex1++);
				cell1.setCellValue(
						transactions.get(i).getActualTransactionDate() == null ? null : transactions.get(i).getActualTransactionDate());
				cell1.setCellStyle(dateCellStyle);
				
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getReceivingStoreId() == null ? "": transactions.get(i).getReceivingStoreId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getReceivingStoreName() == null ? "": transactions.get(i).getReceivingStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getBatchId() == null ? "": transactions.get(i).getBatchId() + "");
				Cell cell2 = dataRow.createCell(rowIndex1++);
				cell2.setCellValue(
						transactions.get(i).getExpriedDate() == null ? null : transactions.get(i).getExpriedDate());
				cell2.setCellStyle(dateCellStyle);				
				
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getBatchManufacturerName() == null ? "": transactions.get(i).getBatchManufacturerName() + "");
				
				Cell cell3 = dataRow.createCell(rowIndex1++);
				cell3.setCellValue(
						transactions.get(i).getManufacturedDate() == null ? null : transactions.get(i).getManufacturedDate());
				cell3.setCellStyle(dateCellStyle);
				
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getOpeningStockBatch() == null ? 0: transactions.get(i).getOpeningStockBatch());
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getClosingStockBatch() == null ? 0: transactions.get(i).getClosingStockBatch());
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getCountryName() == null ? "": transactions.get(i).getCountryName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getStateName() == null ? "": transactions.get(i).getStateName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getDistrictName() == null ? "": transactions.get(i).getDistrictName() + "");
				dataRow.createCell(rowIndex1++).setCellValue( "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getCity() == null ? "": transactions.get(i).getCity() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getPin() == null ? "": transactions.get(i).getPin() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getLatitude() == null ? "": transactions.get(i).getLatitude() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getLongitude() == null ? "": transactions.get(i).getLongitude() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getSourceType() == null ? "": transactions.get(i).getSourceType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getCreatedBy() == null ? "": transactions.get(i).getCreatedBy() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getFullName() == null ? "": transactions.get(i).getFullName() + "");

			}
			// creating temporary excel file
			File tempFile = null;
			tempFile = File.createTempFile("TransactionWithBatchReport", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
			workbook.write(outputStream);
			// upload excel file
			HttpResponse<String> response = uploadFileService.uploadFile(url,userName, tempFile, "Transactions");		

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			//deleting temporary excel file
			tempFile.delete();

			HashMap<String, Object> emailbody = new HashMap<>();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";
			// sending excel file to user's email
			emailbody = sendEmailService.getTransactionEmail(link, userName, email);

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, email, userName,
					fileDownloadUrl, fileType, fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ email
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting transacton report : ", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting transacton report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		finally {
			workbook.close();
			outputStream.close();
		}
//		return responsebean;
	}
	@Async
	public void getTransactionDataWithoutBatch(ExportTxnModel transactionsPayload,Long pranthId,
			Long userId, String userName, String email, List<Long> offsetStoreIds) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<TxnWithBatchDTO> transactions = null;
		Object fileData;
		String url =  null;
		Workbook workbook = null;
		Sheet sheet = null;
		FileOutputStream outputStream = null;
		try {
			transactions = exportTransactionService.getAllStoresByTransactionLevelWithOutBatch(transactionsPayload, userName, email, pranthId, userId, offsetStoreIds);
			//creating workbook
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0,cellIndex2 = 0, cellIndex3 = 0;
			// Creating row
			Row row = sheet.createRow(0);

			row.createCell(cellIndex++).setCellValue("Title");
			row.createCell(cellIndex++).setCellValue(""+Constants.transaction+"");
			Row row1 = sheet.createRow(1);
			row1.createCell(cellIndex1++).setCellValue("Generated on");
			row1.createCell(cellIndex1++).setCellValue("" + uploadFileService.dateWithHoursMinutes());
			
			StringBuilder filterString = new StringBuilder();
			if (transactionsPayload.getTxnType() != null && !transactionsPayload.getTxnType().isEmpty()) {
				filterString.append("Type : " + transactionsPayload.getTxnType());
			}
			String storeTagNames = null;
			Set<String> storeBadges = new HashSet<>()	;

			for(TxnWithBatchDTO txns : transactions ) {
				storeTagNames = txns.getStoreBadges();
				storeBadges.add(storeTagNames);

			}	
			if (transactionsPayload.getStoreBadge() != null) {
				filterString.append(" Facility Tag : "+ StringUtils.join(storeBadges, ",") + "  ");
			}
			
			log.info(""+storeBadges);

			String materialTagNames = null;
			Set<String> uniqueMaterialBadges = new HashSet<>();

			for(TxnWithBatchDTO txns : transactions ) {
			 materialTagNames = txns.getMaterialBadges();
			 uniqueMaterialBadges.add(materialTagNames);

			}			
			log.info(""+uniqueMaterialBadges);
			if (transactionsPayload.getProductBadge() != null) {
				
				filterString.append("Material Tag :  " + StringUtils.join(uniqueMaterialBadges, ",") + "  ");

			}
			if (transactionsPayload.getTxnReason() != null) {
				filterString.append(" Txn Reason :" + transactionsPayload.getTxnReason());
			}
			if (transactionsPayload.getIsActualTxn() != null && transactionsPayload.getIsActualTxn() == true) {
				filterString.append(" Filter by date of actual transaction : " +transactionsPayload.getIsActualTxn() );
			}else {
				filterString.append(" Filter by date of actual transaction : " +false );
			}
			if (transactionsPayload.getTxnsFromDate() != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				filterString.append(
						" From Date : " + dateFormat.format(transactionsPayload.getTxnsFromDate()));
			}
			if (transactionsPayload.getTxnsToDate() != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				filterString.append(
						" To Date : " + dateFormat.format(transactionsPayload.getTxnsToDate()));
			}
			if (transactionsPayload.getState() != null) {
				filterString.append(" State : " + transactionsPayload.getState());
			}
			if (transactionsPayload.getDistrict() != null) {
				filterString.append(" District : " + transactionsPayload.getDistrict());

			}
			if (transactionsPayload.getBlock() != null) {
				filterString.append(" Block : " +"");

			}			
			
			Row filterRow = sheet.createRow(2);
			filterRow.createCell(cellIndex2++).setCellValue("filter");
			filterRow.createCell(cellIndex2++).setCellValue(""+filterString);

			//Creating Headers/Columns
			Row row3 = sheet.createRow(4);

			row3.createCell(cellIndex3++).setCellValue("Transaction ID");
			row3.createCell(cellIndex3++).setCellValue("Transaction Type");
			row3.createCell(cellIndex3++).setCellValue("Tracking Object Type");
			row3.createCell(cellIndex3++).setCellValue("Tracking No");
			row3.createCell(cellIndex3++).setCellValue("Store id");	
			row3.createCell(cellIndex3++).setCellValue("Store Name");
			row3.createCell(cellIndex3++).setCellValue("Store tag");	
			row3.createCell(cellIndex3++).setCellValue("Material ID");
			row3.createCell(cellIndex3++).setCellValue("Material Name");
			row3.createCell(cellIndex3++).setCellValue("Material Tag");
			row3.createCell(cellIndex3++).setCellValue("Opening Stock");
			row3.createCell(cellIndex3++).setCellValue("Qunaity");
			row3.createCell(cellIndex3++).setCellValue("Closing Stock");
			row3.createCell(cellIndex3++).setCellValue("Reason");
			row3.createCell(cellIndex3++).setCellValue("Material Status");	
			row3.createCell(cellIndex3++).setCellValue("updated on");
			row3.createCell(cellIndex3++).setCellValue("Date of actual transaction");
			row3.createCell(cellIndex3++).setCellValue("Receiving Store ID");
			row3.createCell(cellIndex3++).setCellValue("Receiving store name");
			row3.createCell(cellIndex3++).setCellValue("Country");
			row3.createCell(cellIndex3++).setCellValue("State");
			row3.createCell(cellIndex3++).setCellValue("District");
			row3.createCell(cellIndex3++).setCellValue("Taluk/Block");	
			row3.createCell(cellIndex3++).setCellValue("Village/City");
			row3.createCell(cellIndex3++).setCellValue("Zip/PIN code");
			row3.createCell(cellIndex3++).setCellValue("Latitude");
			row3.createCell(cellIndex3++).setCellValue("Longitude");	
			row3.createCell(cellIndex3++).setCellValue("Transaction source");
			row3.createCell(cellIndex3++).setCellValue("Created by ID");	
			row3.createCell(cellIndex3++).setCellValue("Created by full name");



			//Displaying data under headers
			for (int i = 0; i < transactions.size(); i++) {
				Row dataRow = sheet.createRow(i + 5);
				int rowIndex1 = 0;

				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTransactionId() == null ? "": transactions.get(i).getTransactionId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTransactionType() == null ? "": transactions.get(i).getTransactionType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTrackingObjectType() == null ? "": transactions.get(i).getTrackingObjectType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTrackingNo() == null ? "": transactions.get(i).getTrackingNo() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getStoreId() == null ? "": transactions.get(i).getStoreId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getStoreName() == null ? "": transactions.get(i).getStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getStoreBadges() == null ? "": transactions.get(i).getStoreBadges() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getProductId() == null ? "": transactions.get(i).getProductId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getProductName() == null ? "": transactions.get(i).getProductName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getMaterialBadges() == null ? "": transactions.get(i).getMaterialBadges() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getOpeningStock() == null ? 0: transactions.get(i).getOpeningStock());
				dataRow.createCell(rowIndex1++).setCellValue( transactions.get(i).getQuantity() == null ? 0: transactions.get(i).getQuantity());
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getClosingStock() == null ? 0: transactions.get(i).getClosingStock());
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTransactionReason() == null ? "": transactions.get(i).getTransactionReason() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getMaterialReason() == null ? "": transactions.get(i).getMaterialReason() + "");
				
				Cell cell = dataRow.createCell(rowIndex1++);
				cell.setCellValue(
						transactions.get(i).getUpdatedOn() == null ? null : transactions.get(i).getUpdatedOn());
				cell.setCellStyle(dateCellStyle);
				
				Cell cell1 = dataRow.createCell(rowIndex1++);
				cell1.setCellValue(
						transactions.get(i).getActualTransactionDate() == null ? null : transactions.get(i).getActualTransactionDate());
				cell1.setCellStyle(dateCellStyle);
				
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getReceivingStoreId() == null ? "": transactions.get(i).getReceivingStoreId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getReceivingStoreName() == null ? "": transactions.get(i).getReceivingStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getCountryName() == null ? "": transactions.get(i).getCountryName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getStateName() == null ? "": transactions.get(i).getStateName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getDistrictName() == null ? "": transactions.get(i).getDistrictName() + "");
				dataRow.createCell(rowIndex1++).setCellValue( "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getCity() == null ? "": transactions.get(i).getCity() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getPin() == null ? "": transactions.get(i).getPin() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getLatitude() == null ? "": transactions.get(i).getLatitude() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getLongitude() == null ? "": transactions.get(i).getLongitude() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getSourceType() == null ? "": transactions.get(i).getSourceType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getCreatedBy() == null ? "": transactions.get(i).getCreatedBy() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getFullName() == null ? "": transactions.get(i).getFullName() + "");
			}
			// creating temporary excel file
			File tempFile = null;
			tempFile = File.createTempFile("TransactionReport", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
			workbook.write(outputStream);
			
			// upload excel file
			HttpResponse<String> response = uploadFileService.uploadFile(url,userName, tempFile, "Transactions");		

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			//deleting temporary excel file
			tempFile.delete();

			HashMap<String, Object> emailbody = new HashMap<>();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";
			// sending excel file to user's email
			emailbody = sendEmailService.getTransactionEmail(link, userName, email);

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, email, userName,
					fileDownloadUrl, fileType, fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ email
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting transacton report : ", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting transacton report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		finally {
			
			outputStream.close();
			workbook.close();
		}
//		return responsebean;
	}
	@Async
	public void getStockDeviantDataToExport(ExportStockDeviantPayload detailsPayload,Long pranthId,Long userId,
			String userName,String email,List<Integer> materialTagsToHide,List<Long> totalStoreIds)
			throws CustomException, IOException {

		ResponseBean responsebean = new ResponseBean();
		List<IcatalogueDetails> stockdeviant = null;
		
		Object fileData;
		String url = null;
		Workbook workbook =  null;
		FileOutputStream outputStream = null;
		
		try {
			StringBuilder builder = new StringBuilder();
			Set<Long> consolidatePranthIds = pranthHierarchyService.getConsolidatedPranthIds(detailsPayload.getPranthId());
			stockdeviant = exportStockDeviantService.getStockDeviantData(detailsPayload, builder, consolidatePranthIds, materialTagsToHide, totalStoreIds);
			//creating workbook
			workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0, cellIndex3 = 0;
			// Creating row
			Row row = sheet.createRow(0);

			row.createCell(cellIndex++).setCellValue("Title");
			row.createCell(cellIndex++).setCellValue("" + Constants.stock_deviannt + "");
			Row row1 = sheet.createRow(1);
			row1.createCell(cellIndex1++).setCellValue("Generated on");
			row1.createCell(cellIndex1++).setCellValue("" + uploadFileService.dateWithHoursMinutes());

			Row row3 = sheet.createRow(3);

			row3.createCell(cellIndex3++).setCellValue("ProductName");
			row3.createCell(cellIndex3++).setCellValue("BatchManagement");
			row3.createCell(cellIndex3++).setCellValue("Country");
			row3.createCell(cellIndex3++).setCellValue("State");
			row3.createCell(cellIndex3++).setCellValue("District");
			row3.createCell(cellIndex3++).setCellValue("Block");
			row3.createCell(cellIndex3++).setCellValue("City");
			row3.createCell(cellIndex3++).setCellValue("StorageBadge");
			row3.createCell(cellIndex3++).setCellValue("StoreName");
			row3.createCell(cellIndex3++).setCellValue("TotalStock");
			row3.createCell(cellIndex3++).setCellValue("MinStock");
			row3.createCell(cellIndex3++).setCellValue("MaxStock");
			row3.createCell(cellIndex3++).setCellValue("Duration");
			row3.createCell(cellIndex3++).setCellValue("Since");

			for (int i = 0; i < stockdeviant.size(); i++) {
				Row dataRow = sheet.createRow(i + 4);
				int rowIndex1 = 0;

				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getProductName() == null ? ""
						: stockdeviant.get(i).getProductName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getBatchManagement() == null ? ""
						: stockdeviant.get(i).getBatchManagement() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getCountry() == null ? ""
						: stockdeviant.get(i).getCountry() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getState() == null ? ""
						: stockdeviant.get(i).getState()+ "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getDistrict() == null ? ""
						: stockdeviant.get(i).getDistrict() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getBlock() == null ? ""
						: stockdeviant.get(i).getBlock() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						stockdeviant.get(i).getCity() == null ? "" : stockdeviant.get(i).getCity() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getStorageBadge() == null ? ""
						: stockdeviant.get(i).getStorageBadge() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getStoreName() == null ? ""
						: stockdeviant.get(i).getStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getCurrentStock() == null ? 0
						: stockdeviant.get(i).getCurrentStock());
				log.info(""+stockdeviant.get(i).getCurrentStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						stockdeviant.get(i).getInvMax() == null ? 0 : stockdeviant.get(i).getInvMax());
				dataRow.createCell(rowIndex1++).setCellValue(
						stockdeviant.get(i).getInvMin() == null ? 0 : stockdeviant.get(i).getInvMin());
				dataRow.createCell(rowIndex1++).setCellValue(
						stockdeviant.get(i).getDuration() == null ? "" : stockdeviant.get(i).getDuration() + "");
				
				Cell cell = dataRow.createCell(rowIndex1++);
				cell.setCellValue(
						stockdeviant.get(i).getUntil() == null ? null : stockdeviant.get(i).getUntil());
				cell.setCellStyle(dateCellStyle);			

			}

			File tempFile = null;
			tempFile = File.createTempFile("StockDeviantReport", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
		    workbook.write(outputStream);
			HttpResponse<String> response = uploadFileService.uploadFile(url,userName, tempFile, "StockDeviant");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			tempFile.delete();
			HashMap<String, Object> emailbody = new HashMap<>();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";

			emailbody = sendEmailService.getStockDeviantEmail(link, userName, email);

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, email, userName,
					fileDownloadUrl, fileType, fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ email
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting stock deviant report : " + e.getStackTrace());
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock deviant report ");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		finally {
			
			 outputStream.close();
			 workbook.close();
		}
//		return responsebean;
	}
	
}
