package com.dipl.evin2.dto;

import org.springframework.beans.factory.annotation.Value;

public interface CargoProductsDTO {

	@Value(("#{target.cargo_id}"))
	Long getCargoId();

	@Value(("#{target.cargo_no}"))
	String getCargoNo();

	@Value(("#{target.product_id}"))
	Long getProductId();

	@Value(("#{target.product_name}"))
	String getProductName();

	@Value(("#{target.is_batch_enabled}"))
	Boolean getEnableBatchManagement();

	@Value(("#{target.ordered_stock}"))
	Long getBookingQuantity();

	@Value(("#{target.cargo_stock}"))
	Long getCargoQuantity();

	@Value(("#{target.fulfilled_stock}"))
	Long getFulfiledQuantity();

	@Value(("#{target.min_stock}"))
	Long getMin();

	@Value(("#{target.max_stock}"))
	Long getMax();

	@Value(("#{target.handling_unit}"))
	Long getHandlingUint();

	@Value(("#{target.booking_item_id}"))
	Long getBookingItemId();
}
