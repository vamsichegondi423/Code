package com.dipl.evin2.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.IcatalogueLog;
import com.dipl.evin2.repository.IcatalogueLogRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/evin2-kafka")
public class IcatalogueLogKafkaConsumer {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private IcatalogueLogRepository icatalogueLogRepository;

	@KafkaListener(topics = "ICATALOGUE_LOG_TOPIC", groupId = "group_id")
	public void saveReportTxn(String icatalogueLogModel) throws JsonMappingException, JsonProcessingException {
		ObjectMapper obj = new ObjectMapper();
		try {
			IcatalogueLog requestLog = obj.readValue(icatalogueLogModel, IcatalogueLog.class);
			IcatalogueLog icatalogueLog = icatalogueLogRepository.getIcatalogueDetails(requestLog.getIcatalogueId(),
					requestLog.getProductId(), requestLog.getStoreId());
			if (icatalogueLog == null) {
				requestLog.setDateStart(new Date());
				requestLog.setUpdatedBy(requestLog.getCreatedBy());
				icatalogueLogRepository.save(requestLog);
			} else if (icatalogueLog.getAbnormalTypeId() == requestLog.getAbnormalTypeId()) {
				icatalogueLogRepository.save(icatalogueLog);
			} else {
				icatalogueLog.setDateEnd(new Date());
				icatalogueLog.setUpdatedBy(requestLog.getCreatedBy());
				icatalogueLog.setUpdatedOn(new Date());
				IcatalogueLog icatLog = icatalogueLogRepository.save(icatalogueLog);
				requestLog.setDateStart(icatLog.getDateEnd());
				requestLog.setUpdatedBy(requestLog.getCreatedBy());
				icatalogueLogRepository.save(requestLog);
			}

		} catch (Exception e) {
			logger.error(e + " Exception occured while saving data in icatalogueLog topic");
			e.printStackTrace();
		}
	}
}
