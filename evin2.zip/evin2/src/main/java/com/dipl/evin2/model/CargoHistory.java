package com.dipl.evin2.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Document(collection = "CargoHistory")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CargoHistory {

	@Id
	private String id;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "IST")
	private Date time;
	@JsonProperty("order_id")
	private String orderId;
	@JsonProperty("cargo_id")
	private String cargoId;
	private String cargoNo;
	private String status;
	private String message;
	@JsonProperty("user_id")
	private String userID;

}
