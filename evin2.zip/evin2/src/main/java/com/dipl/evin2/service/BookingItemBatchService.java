package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.BookingItemBatch;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.BookingItemBatchRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BookingItemBatchService {

	@Autowired
	private BookingItemBatchRepository bookingItemBatchRepository;

	public BookingItemBatch getById(Long id) throws CustomException {
		try {
			Optional<BookingItemBatch> bookingItemBatchOptional = bookingItemBatchRepository.getById(id);
			if (bookingItemBatchOptional.isPresent()) {
				return bookingItemBatchOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public BookingItemBatch save(BookingItemBatch bookingItemBatch) throws CustomException {
		try {
			if (bookingItemBatch.getId() != null && bookingItemBatch.getId() > 0) {
				Optional<BookingItemBatch> existingBookingItemBatchRecord = bookingItemBatchRepository
						.getById(bookingItemBatch.getId());
				if (existingBookingItemBatchRecord.isPresent()) {
					return bookingItemBatchRepository.save(bookingItemBatch);
				}
			} else {
				bookingItemBatch = bookingItemBatchRepository.save(bookingItemBatch);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return bookingItemBatch;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<BookingItemBatch> existingBookingItemBatchRecord = bookingItemBatchRepository.getById(id);
			if (existingBookingItemBatchRecord.isPresent()) {
				bookingItemBatchRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<BookingItemBatch> getAll() {
		try {
			return bookingItemBatchRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

}