package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.dto.UserAccountFilterModel;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.service.UsersService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/users")
public class UsersController {

	@Autowired
	private UsersService usersService;

	@ApiOperation("Use this api for saving or updating Users. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody Users users, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (users.getId() != null && users.getId() > 0) {
				Users existingUsers = usersService.getById(users.getId());
				if (existingUsers != null) {
					users = usersService.save(users);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(users);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				users = usersService.save(users);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(users);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching Users record by id. Provide id as path param.")
	@GetMapping(value = "/v1/get-user-by-id")
	public ResponseBean getById(@RequestParam (value = "userId") Long userId) {
		ResponseBean responseBean = new ResponseBean();
		List<Map<String, Object>> userDetails = null;
		try {
			userDetails = usersService.getUserDetails(userId);
			if (userDetails != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(userDetails);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured while finding user details", e.getMessage());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Exception occured while finding user details" + e.getCause());
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting Users record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = usersService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all Users records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Users> usersRecords = usersService.getAll();
			if (!usersRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(usersRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
	@ApiOperation("Use this api for fetching all Useraccount records by domain id. Provide id as path param.")
	@PostMapping(value = "/v1/get-all-users-filter")
	public ResponseBean getAllUsersByPranthId(@RequestBody UserAccountFilterModel userPayLoad, Pageable pageable) {
		log.debug(" get all useraccounts by domain id ");
		List<Map<String, Object>> userDTO = null;
		UserFilterDetials userDetials = null;
		try {
			userDTO = usersService.getAllUsersByPranthId(userPayLoad, pageable);
			Long totalRcrdCount = usersService.findAllUserCount(userPayLoad);
			userDetials = UserFilterDetials.builder().result(userDTO).totalRecordCount(totalRcrdCount).build();
			
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		if (userDTO.isEmpty()) {
			return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message("No records found")
					.build();
		}
		return ResponseBean.builder().data(userDetials).status(HttpStatus.OK).returnCode(1)
				.message("Successfully fetched details").build();
			
	}
	
	@ApiOperation("Use this api for fetching Users existing or not .")
	@GetMapping(value = "/v1/find-user-by-user-name")
	public ResponseBean findByUserName(@RequestParam (value = "userName") String userName) {
		ResponseBean responseBean = new ResponseBean();
		Users userDetails = null;
		try {
			userDetails = usersService.findUserDetailsByName(userName);
			if (userDetails != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage( "this "+ userName + " is already exists with this name ");
				responseBean.setData(userDetails.getUserId());
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured while finding user details", e.getMessage());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Exception occured while finding user details" + e.getCause());
		}
		return responseBean;
	}
	
	@ApiOperation("Use this api for fetching all Users records. No params required.")
	@GetMapping(value = "/v1/get-all-users-by-role", produces = "application/json")
	public ResponseBean getAllUsersBasedOnRole(@RequestParam (required =false , value = "roleId") Integer roleId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Users> usersRecords = usersService.getAllUsersBasedOnRole(roleId);
			if (!usersRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(usersRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
	
	@Data
	@Builder
	public static class UserFilterDetials{
		private List<Map<String, Object>> result;
		private Long totalRecordCount;
	}
}