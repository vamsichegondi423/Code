package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterBlock;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterBlockRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterBlockService {

	@Autowired
	private MasterBlockRepository masterBlockRepository;

	@Cacheable(value = "block", key = "#id")
	public MasterBlock getById(Integer id) throws CustomException {
		try {
			Optional<MasterBlock> masterBlockOptional = masterBlockRepository.getById(id);
			if (masterBlockOptional.isPresent()) {
				return masterBlockOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "block", key = "#masterBlock.id")
	public MasterBlock save(MasterBlock masterBlock) throws CustomException {
		try {
			if (masterBlock.getId() != null && masterBlock.getId() > 0) {
				Optional<MasterBlock> existingMasterBlockRecord = masterBlockRepository.getById(masterBlock.getId());
				if (existingMasterBlockRecord.isPresent()) {
					masterBlock = masterBlockRepository.save(masterBlock);
				}
			} else {
				masterBlock = masterBlockRepository.save(masterBlock);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterBlock;
	}

	@CacheEvict(value = "block", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterBlock> existingMasterBlockRecord = masterBlockRepository.getById(id);
			if (existingMasterBlockRecord.isPresent()) {
				masterBlockRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "block")
	public List<MasterBlock> getAll() {
		try {
			return masterBlockRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}