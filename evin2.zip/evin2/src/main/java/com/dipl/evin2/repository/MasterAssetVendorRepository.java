package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import com.dipl.evin2.entity.MasterAssetVendor;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface MasterAssetVendorRepository extends JpaRepository<MasterAssetVendor, Long> {

	@Query(value = "select * from master_asset_vendor where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterAssetVendor> getById(Long id);

	@Query(value = "select * from master_asset_vendor where is_deleted = false", nativeQuery = true)
	public List<MasterAssetVendor> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from master_asset_vendor where id = ?1", nativeQuery = true)
	public void deleteById(Long id);
	
	@Modifying
	@Transactional
	@Query(value = "update master_asset_vendor set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);
	
	@Query(value = "select * from master_asset_vendor where name = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterAssetVendor> getByName(String name);

	@Query(value = "select distinct mav.* from master_asset_vendor mav join master_asset_model mam on mam.asset_vendor_id = mav.id\n"
			+ "join master_asset_type mat on mat.id = mam.asset_type_id where mat.id = ?1 and \n"
			+ "mav.is_deleted = false", nativeQuery = true)
	public List<MasterAssetVendor> getByAssetType(Long assetTypeid);
	
	@Query(value = "select distinct mav.* from master_asset_vendor mav join master_asset_model mam on mam.asset_vendor_id = mav.id\n"
			+ "join master_asset_type mat on mat.id = mam.asset_type_id where mat.id = ?1 and \n"
			+ "mav.is_deleted = false and mav.is_active = ?2", nativeQuery = true)
	public List<MasterAssetVendor> getActiveVendorsByAssetType(Long assetTypeid, Boolean isActive);
	
}