package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.dto.LinkedStoreDTO;
import com.dipl.evin2.entity.StoreMappings;
import com.dipl.evin2.repository.StoreMappingsRepository;
import com.dipl.evin2.service.StoreMappingsService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/store-mappings")
public class StoreMappingsController {

	@Autowired
	private StoreMappingsService storeMappingsService;

	@Autowired
	private StoreMappingsRepository storeMappingsRepository;

	@ApiOperation("Use this api for saving or updating StoreMappings. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/create-store-relation")
	public ResponseBean save(@RequestBody StoreMappings storeMappingsPayload, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		StoreMappings storeMappings = null;
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (storeMappingsPayload.getId() != null && storeMappingsPayload.getId() > 0) {
				StoreMappings existingStoreMappings = storeMappingsService.getById(storeMappingsPayload.getId());
				if (existingStoreMappings != null) {
					storeMappings = storeMappingsService.createStoreRelation(storeMappingsPayload);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(storeMappings);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				storeMappings = storeMappingsService.createStoreRelation(storeMappingsPayload);
				if (storeMappings != null) {
					log.info("Record saved successfully");
					responseBean.setMessage("Record saved successfully");
					responseBean.setData(storeMappings);
					responseBean.setReturnCode(1);
					responseBean.setStatus(HttpStatus.OK);
				} else {
					responseBean.setMessage("Record not saved");
					responseBean.setStatus(HttpStatus.OK);
				}
			}
		} catch (Exception e) {
			log.error("Exception occured while mapping the stores", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured while mapping the stores" + e);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching StoreMappings record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			StoreMappings storeMappings = storeMappingsService.getById(id);
			if (storeMappings != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(storeMappings);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting StoreMappings record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = storeMappingsService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all StoreMappings records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<StoreMappings> storeMappingsRecords = storeMappingsService.getAll();
			if (!storeMappingsRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(storeMappingsRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}

	/*
	 * we are not using this API please ignore same API is available in StoreController
	 * please do refer if you want to make any changes
	 */
	@ApiOperation("Use this api for fetching mapping kiosks. Provide kioskId and mappingType as Request Params.")
	@GetMapping(value = "/v1/get-mapping-stores", produces = "application/json")
	@Deprecated
	public ResponseBean getLinkedKiosks(@RequestParam(value = "storeId") Long storeId,
			@RequestParam(required = false, value = "mappingType") String mappingType) {
		List<LinkedStoreDTO> LinkedStoreDTOs = null;
		try {
			LinkedStoreDTOs = storeMappingsService.getLinkedStores(storeId, mappingType);
		} catch (Exception e) {
			log.error("Exception occured while fetching mapping stores : {}", e);
			return ResponseBean.builder().message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR).returnCode(0)
					.build();
		}
		if (LinkedStoreDTOs.isEmpty()) {
			return ResponseBean.builder().returnCode(1).status(HttpStatus.OK).message("mapping stores not found")
					.build();
		}
		return ResponseBean.builder().data(LinkedStoreDTOs).status(HttpStatus.OK).returnCode(1)
				.message("mapping stores fetched successfully").build();
	}
}