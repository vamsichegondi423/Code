package com.dipl.evin2.util;

import java.text.DecimalFormat;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.util.CollectionUtils;

public class EvinUtility {

	private EvinUtility() {

	}

	public static Integer renderAbnormalityType(Long minValue, Long maxValue, Long stockValue) {
		if (stockValue.equals(Long.valueOf(0))) {
			return 200;
		} else if (stockValue < minValue) {
			return 201;
		} else if (stockValue > maxValue) {
			return 202;
		}
		return null;
	}

	public static Integer getTimeZoneIntegerValue(Float timzeZoneFloatValue) {
		if(timzeZoneFloatValue != null) {
			DecimalFormat decimalFormat = new DecimalFormat("#.00");
			String numberString = decimalFormat.format(timzeZoneFloatValue);
			return Integer.parseInt(numberString.replace(".", ""));
		}
		return null;
	}
	
	public static <T> List<T> getPageLimit(List<T> dataList, Pageable pageable){
		if(CollectionUtils.isEmpty(dataList)){
			return dataList;
		}
		int from = (int) pageable.getOffset();
		int to = (int) pageable.getOffset()+pageable.getPageSize();
		return dataList.subList(from < 0 ? 0 : from, to > dataList.size() ? dataList.size() : to );
	}

}
