package com.dipl.evin2.jackson;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductModel {
	@JsonProperty("id")
	private Integer id;
	@JsonProperty("name")
	private String name;
	@JsonProperty("is_batch_enabled")
	private Boolean isBatchEnabled;
	@JsonProperty("short_name")
	private String shortName;
	@JsonProperty( "description")
	private String description;
	@JsonProperty("is_seasonal")
	private Boolean isSeasonal;
	@JsonProperty("is_temperature_sensitive")
	private Boolean isTemperatureSensitive;
	@JsonProperty("minimum_temperature")
	private Double minimumTemperature;
	@JsonProperty("maximum_temperature")
	private Double maximumTemperature;
	@JsonProperty("user_id")
	private String userId;
	@JsonProperty("product_badge_ids")
	List<Integer> productBadgeIds;
	@JsonProperty("handling_unit")
	private Integer handlingUnit;
}
