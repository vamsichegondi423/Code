package com.dipl.evin2.service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExecutorUtil {
	
	private ExecutorUtil(){
		
	}

	public static void shutdownAndAwaitTermination(ExecutorService service) {
	    service.shutdown(); 
	    try {
	        if (!service.awaitTermination(60, TimeUnit.SECONDS)) {
	            service.shutdownNow(); 
	            if (!service.awaitTermination(60, TimeUnit.SECONDS))
	                log.error("Pool did not terminate");
	        }
	    } catch (InterruptedException ie) {
	        service.shutdownNow();
	        Thread.currentThread().interrupt();
	    }
	    log.info("executor service terminated successfully.");
	}
	
}
