package com.dipl.evin2.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Document(collection = "MasterState")
@NoArgsConstructor
@AllArgsConstructor
public class MasterState {

	@Id
	private String id;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "IST")
	private LocalDateTime time;

	@JsonProperty("state_id")
	private String stateId;

	private String status;

	private String message;

	@JsonProperty("user_id")
	private String userID;

	private List<MasterDistrict> districts = new ArrayList<>();

}
