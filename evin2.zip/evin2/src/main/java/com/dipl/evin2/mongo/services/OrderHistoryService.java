package com.dipl.evin2.mongo.services;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.dipl.evin2.model.OrderHistory;
import com.dipl.evin2.mongo.repository.OrderHistoryRepository;

@Service
public class OrderHistoryService {

	/**
	 * Atrribute logger for current class
	 */
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private OrderHistoryRepository orderHistoryRepository;
	
	@Autowired
	MongoTemplate mongoTemplate;

	public OrderHistory save(OrderHistory orderHistory) {
		System.out.println("time : " + orderHistory.getTime());
		orderHistory.setTime(new Date());
		return orderHistoryRepository.save(orderHistory);
	}

	public List<OrderHistory> getAll() {
		return orderHistoryRepository.findAll();
	}

	public List<OrderHistory> get(String orderId) {
		return orderHistoryRepository.findByOrderIdOrderByIdAsc(orderId);
	}

	public String getDuration(String orderId) {
		String duration = null;
		try {
			List<OrderHistory> orders = orderHistoryRepository.findByOrderIdOrderByIdAsc(orderId);
			duration = this.getOrderDuration(orders);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return duration;
	}

	private String getOrderDuration(List<OrderHistory> orders) {
		String durationInMintues = "";
		long durationInSeconds = 0;
		for (int i = 0; i <= orders.size(); i++) {
			if (orders.size() > i + 1) {
				durationInSeconds += getDuration(orders.get(i).getTime(), orders.get(i + 1).getTime());
			}
		}
		if (durationInSeconds > 0) {
			long numberOfMinutes = (durationInSeconds) / 60;
			durationInMintues = numberOfMinutes + " Mintues";
		}
		return durationInMintues;
	}

	private long getDuration(Date time, Date time2) {
		// TODO Auto-generated method stub
		return 0;
	}

	private static long getDuration(Instant date, Temporal date2) {
		Date tempDateTime = Date.from(date);
		long seconds = ((Temporal) tempDateTime).until(date2, ChronoUnit.SECONDS);
		return seconds;
	}

	public Long getcount(String orderId) {
		return orderHistoryRepository.countByOrderId(orderId);
	}

	public List<OrderHistory> findByStatus(String status) {
		return orderHistoryRepository.findByStatus(status);
	}

	public OrderHistory update(OrderHistory orderHistory) {
		Query query = new Query();
		query.addCriteria(Criteria.where("orderId").is(orderHistory.getOrderId()));
		Update update = new Update();
		update.set("status", orderHistory.getStatus());
		update.set("message", orderHistory.getMessage());
		orderHistory.setTime(new Date());
		return mongoTemplate.findAndModify(query, update, OrderHistory.class);
	}

}
