package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {

	@Query(value = "select * from product where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<Product> getById(Integer id);

	@Query(value = "select * from product where is_deleted = false", nativeQuery = true)
	public List<Product> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from product where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);

	@Modifying
	@Transactional
	@Query(value = "update product set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

	@Query(value = "select * from product where name =?1 and is_deleted = false", nativeQuery = true)
	public Product findProductByName(String name);

	@Query(value = "select s.id as store_id,s.name as store_name,concat(s.city,', ',d.name,', ',st.name,', ',c.name) as location, " + 
			"il.product_id,p.name as product_name,p.name,mtt.name as event_type,il.date_start,il.date_end, " + 
			"EXTRACT(epoch from age(coalesce(il.date_end, now()), il.date_start)/ 86400) as days " + 
			"from icatalogue_log il "
			+ "left join store s on il.store_id=s.id and s.is_deleted = false "
			+ "left join product p on p.id=il.product_id and p.is_deleted = false " + 
			"left join master_district d on d.id=s.district_id  "
			+ "left join master_state st on st.id=s.state_id " + 
			"left join master_country c on c.id=s.country_id "
			+ "left join master_txn_type mtt on mtt.id=il.txn_type_id " + 
			"inner join (select store_id,product_id, " + 
			"case when total_stock between min_stock and max_stock then 201  " + 
			"when total_stock < min_stock then 201  " + 
			"when total_stock = 0 then 200 when total_stock > max_stock then 202 end as event_type from icatalogue where is_deleted = false )i " + 
			"on i.store_id=il.store_id and i.product_id=il.product_id and i.event_type= event_type " + 
			"where il.is_deleted = false and il.store_id=?1 and il.product_id=?2", nativeQuery = true)
	public List<Map<String, Object>> getHistoryOfProducts(Long storeId, Long productId);

	@Query(value = "select * from product where id = ?1 and is_deleted = false", nativeQuery = true)
	public Product getProductById(Integer productId);

}