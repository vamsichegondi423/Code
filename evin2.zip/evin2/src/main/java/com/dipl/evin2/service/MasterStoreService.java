package com.dipl.evin2.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.model.MasterStoresPayload;
import com.dipl.evin2.repository.MasterStoreRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterStoreService {
	
	@Autowired
	private MasterStoreRepository masterStoreRepository;

	
	public List<Map<String, Object>> findStores(MasterStoresPayload masterStoresPayload) throws Exception {
		List<Map<String, Object>> result = null;
		try {
			if (masterStoresPayload.getStateId() != 0 && masterStoresPayload.getDistrictId() != 0 ) {
				result = masterStoreRepository.findStoreByStateAndDistricAndStoreId(masterStoresPayload.getStateId(),masterStoresPayload.getDistrictId());
				return result;
			}
			if (masterStoresPayload.getStateId() != 0) {
				result = masterStoreRepository.findStoreByStateId(masterStoresPayload.getStateId());
				return result;
			}			

		} catch (Exception e) {
			log.error("Exception occured while fetching master stores by ids: ", e.getCause());
			throw new Exception(" Exception occured while fetching master stores by ids: " + e.getMessage());
		}
		return null;
	}
}
