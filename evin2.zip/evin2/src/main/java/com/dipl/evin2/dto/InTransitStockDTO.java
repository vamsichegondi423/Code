package com.dipl.evin2.dto;

import org.springframework.beans.factory.annotation.Value;

public interface InTransitStockDTO {
	
		@Value(("#{target.booking_id}"))
		Long getBookingId();

		@Value(("#{target.issuing_store_name}"))
		String getIssuingstore();

		@Value(("#{target.ordered_stock}"))
		Long getOrderedStock();

		@Value(("#{target.shipped_stock}"))
		Long getShippedStock();

		@Value(("#{target.yet_to_ship}"))
		Long getYetToShip();
		
		@Value(("#{target.fulfilled_stock}"))
		Long getFulfilledStock();

}
