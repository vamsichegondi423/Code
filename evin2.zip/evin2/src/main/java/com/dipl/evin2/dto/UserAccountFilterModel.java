package com.dipl.evin2.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserAccountFilterModel {
	
	@JsonProperty("pranth_id")
	private Integer pranthId;
	@JsonProperty("user_id")
	private String userId;
	@JsonProperty("f_name")
	private String firstName;
	@JsonProperty("mobile_phone_number")
	private String mobilePhoneNumber;
	@JsonProperty("role")
	private String role;
	@JsonProperty("is_Deleted")
	private Boolean isDeleted;
	@JsonProperty("from_last_login_date")
	private Date fromLastLoginDate;
	@JsonProperty("to_last_login_date")
	private Date toLastLoginDate;
	@JsonProperty("mobile_app_version")
	private String mobileAppVersion;
	@JsonProperty("user_badge")
	private String userBadge;
}

