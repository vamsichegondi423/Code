package com.dipl.evin2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dipl.evin2.entity.TxnCountLog;

@Repository
public interface TxnCountLogRepository extends JpaRepository<TxnCountLog, Long> {

}
