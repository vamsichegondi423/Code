package com.dipl.evin2.dto;

import java.util.List;

import com.dipl.evin2.entity.AssetModelSensorMapping;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssetModelDTO {

	private Boolean modelIsActive;
	private String modelName;
	private Long modelId;
	private String vendorName;
	private String monitoringPoint;
	private Integer assetVendorId;
	private Boolean vendorIsActive;
	private String defaultCensor;
	private Integer assetTypeId;
	private String assetTypeName;
	private Integer monitoringId;
	public List<AssetModelSensorMapping> assetModelSensorMappings;
	
}

