package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


/**
 * The persistent class for the notification_event_details database table.
 * 
 */
@Entity
@Table(name="notification_event_details")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder 
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class NotificationEventDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="booking_badge", columnDefinition = "json")
	@Type(type = "com.dipl.evin2.util.JsonNodeUserType")
	private JsonNode bookingBadge;

	@Column(name="created_by")
	private Long createdBy;

	@Column(name="created_on")
	private Date createdOn;

	@Column(name="time_period")
	private Integer timePeriod;

	@Column(name="post_on_bulletin_board")
	private Boolean postOnBulletinBoard;

	@Column(name="post_on_bulletin_board_badge", columnDefinition = "json")
	@Type(type = "com.dipl.evin2.util.JsonNodeUserType")
	private JsonNode postOnBulletinBoardBadge;

	@Min(value = 1, message = "status_id should not be 0")
	@Column(name="status_id")
	private Integer statusId;
	
	@Column(name="reason_id")
	private Integer reasonId;
	
	@Column(name="product_badge", columnDefinition = "json")
	@Type(type = "com.dipl.evin2.util.JsonNodeUserType")
	private JsonNode productBadge;

	@Column(name="store_badge", columnDefinition = "json")
	@Type(type = "com.dipl.evin2.util.JsonNodeUserType")
	private JsonNode storeBadge;

	@Column(name="updated_by")
	private Long updatedBy;

	@Column(name="updated_on")
	private Date updatedOn;

	@Column(name="whom_to_notify", columnDefinition = "json")
	@Type(type = "com.dipl.evin2.util.JsonNodeUserType")
	private JsonNode whomToNotify;

	@Column(name="notification_event_id")
	private Integer notificationEventId;
	
	@Column(name="pranth_id")
	private Long pranthId;

}