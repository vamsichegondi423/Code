package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.PranthHierarchyRepository;
import com.dipl.evin2.service.AssetDefaultConfigurationService;
import com.dipl.evin2.service.BadgeService;
import com.dipl.evin2.service.ExecutorUtil;
import com.dipl.evin2.service.MasterReasonService;
import com.dipl.evin2.service.MasterStatusService;
import com.dipl.evin2.service.RolePermissionConfigurationService;
import com.dipl.evin2.service.SensorDefaultConfigurationService;
import com.dipl.evin2.service.SystemConfigurationService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@EnableSwagger2
@Slf4j
public class UpdatingUtilityController {

	@Autowired
	private MasterStatusService masterStatusService;

	@Autowired
	private PranthHierarchyRepository pranthHierarchyRepository;

	@Autowired
	private MasterReasonService masterReasonService;

	@Autowired
	private BadgeService badgeService;

	@Autowired
	private RolePermissionConfigurationService permissionConfigurationService;

	@Autowired
	private SystemConfigurationService systemConfigurationService;
	
	@Autowired
	private AssetDefaultConfigurationService assetDefaultConfigurationService;
	
	@Autowired
	private SensorDefaultConfigurationService sensorDefaultConfigurationService;


	@Autowired
	private CacheController cacheController;



	@ApiOperation("Use this api for updating master configuartions to child pranth.")
	@GetMapping(value = "/v1/update-configuration-to-child", produces = "application/json")
	@Transactional(rollbackOn = { Exception.class , CustomException.class })
	public ResponseBean updateParentStatusToChild(@RequestParam(value = "userId") Long userId,@RequestParam(value = "pranthId",required = false) Long pranthId , @RequestParam(value = "mappedPranthId") Long mappedPranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			log.info("Master status updation started");

			masterStatusService.updateParentStatusToChild(pranthId, mappedPranthId, userId);

			log.info("Master status updation completed");

			log.info("Master Reason updation started");

			masterReasonService.updateParentReasonToChild(pranthId, mappedPranthId, userId);

			log.info("Master Reason updation completed");


			log.info("Badges updation started");

			badgeService.updateParentBadgeToChild(pranthId, mappedPranthId, userId);

			log.info("Badges updation completed");



			log.info("System configuration updation started");

			systemConfigurationService.updateParentSystemConfigurationToChild(pranthId, mappedPranthId, userId);

			log.info("System configuration updation completed");


			log.info("Role permission configuration updation started");

			permissionConfigurationService.updateParentRoleToChild(pranthId, mappedPranthId, userId);

			log.info("Role permission configuration updation completed");
			
			log.info("Assest Default configuration updation started");

			assetDefaultConfigurationService.updateParentAssestDefaultConfigToChild(pranthId, mappedPranthId, userId);
			
			log.info("Assest Default configuration updation started");

			log.info("Sensor Default configuration updation started");
			
			sensorDefaultConfigurationService.updateParentSensorDefaultConfigToChild(pranthId, mappedPranthId, userId);
			
			log.info("Sensor Default configuration updation started");

			cacheController.clearCache();

			responseBean.setMessage("Configuration has been updated for child");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occurred");
		}
		return responseBean;
	}


	@ApiOperation("Use this api for updating master configuartions to child pranth.")
	@GetMapping(value = "/v1/update-configuration-to-all-child-pranths", produces = "application/json")
	@Transactional(rollbackOn = { Exception.class , CustomException.class })
	public ResponseBean updateToAllChildPranths(@RequestParam(value = "userId") Long userId,@RequestParam(value = "pranthId",required = true) Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		ExecutorService executor = null;
		try {
			executor = Executors.newFixedThreadPool(20);
			Set<Long> childDomainIds = pranthHierarchyRepository.getChildDomainIds(pranthId);
			List<Callable<String>> callableTasks = new ArrayList<>();
			for (Long childPranth : childDomainIds) {
				Callable<String> callableTask = () -> {
					updateParentStatusToChild(userId,pranthId,childPranth);
					return "pranthId: "+pranthId+", childPranth: "+childPranth;
				};
				callableTasks.add(callableTask);
			}
			List<Future<String>> futures = executor.invokeAll(callableTasks);
			if(futures != null) {
				responseBean.setMessage("Configuration has been updated for child");
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
			}else {
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setMessage("Configuration not updated for child");
			}
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occurred");
		}finally {
			if(executor != null) {
				ExecutorUtil.shutdownAndAwaitTermination(executor);
			}
		}
		return responseBean;
	}




}
