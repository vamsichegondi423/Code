package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.ProductBadge;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.ProductBadgeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductBadgeService {

	@Autowired
	private ProductBadgeRepository productBadgeRepository;

	public ProductBadge getById(Integer id) throws CustomException {
		try {
			Optional<ProductBadge> productBadgeOptional = productBadgeRepository.getById(id);
			if (productBadgeOptional.isPresent()) {
				return productBadgeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public ProductBadge save(ProductBadge productBadge) throws CustomException {
		try {
			if (productBadge.getId() != null && productBadge.getId() > 0) {
				Optional<ProductBadge> existingProductBadgeRecord = productBadgeRepository
						.getById(productBadge.getId());
				if (existingProductBadgeRecord.isPresent()) {
					return productBadgeRepository.save(productBadge);
				}
			} else {
				productBadge = productBadgeRepository.save(productBadge);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return productBadge;
	}

	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<ProductBadge> existingProductBadgeRecord = productBadgeRepository.getById(id);
			if (existingProductBadgeRecord.isPresent()) {
				productBadgeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<ProductBadge> getAll() {
		try {
			return productBadgeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}