package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.dto.AllocatedStockDTO;
import com.dipl.evin2.dto.InTransitStockDTO;
import com.dipl.evin2.entity.Icatalogue;

@Repository
public interface IcatalogueRepository extends JpaRepository<Icatalogue, Long> {

	@Query(value = "select * from icatalogue where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<Icatalogue> getById(Long id);

	@Query(value = "select * from icatalogue where is_deleted = false", nativeQuery = true)
	public List<Icatalogue> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from icatalogue where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Query(value = "SELECT * from icatalogue where  product_id=?1 and store_id=?2 and is_deleted= false limit 1", nativeQuery = true)
	public Icatalogue getDetailsOfIcatalouge(Long productId, Long storeId);

	@Modifying
	@Transactional
	@Query(value = "update icatalogue set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "SELECT * from icatalogue where store_id=?1 and product_id=?2 and is_deleted = false limit 1", nativeQuery = true)
	public Icatalogue getInventoryByStoreIdAndProductId(Long storeId, Long productId);

	@Query(value = "select b.id as booking_id,b.receiving_store_id,s.name as receiving_store_name,coalesce(bi.ordered_stock,0) as ordered_stock, " + 
			" case when ci.cargo_stock<>0 then 0 else coalesce(bi.allocated_stock,0) end as allocated_stock,coalesce(ci.cargo_stock,0) as shipped_stock, " + 
			" coalesce(bi.ordered_stock,0)-coalesce(bi.shipped_stock,0) as yet_to_ship  " + 
			" from bookings b  " + 
			" join booking_items bi on b.id=bi.booking_id and bi.is_deleted = false " + 
			" left join cargo c on b.id=c.booking_id and c.is_deleted=false " + 
			" left join cargo_item ci on c.id=ci.cargo_id and ci.product_id=bi.product_id and ci.is_deleted=false " + 
			" join store s on s.id=b.receiving_store_id and s.is_deleted = false " + 
			" left join icatalogue i on bi.store_id=i.store_id and bi.product_id=i.product_id and i.is_deleted = false " + 
			" where b.is_deleted = false and b.issuing_store_id=?1 and bi.product_id=?2 order by b.id desc", nativeQuery = true)
	public List<AllocatedStockDTO> getAllocatedStockBysidandpid(Long storeId, Long productId);

	@Query(value = "select b.id as booking_id,b.issuing_store_id,s.name as issuing_store_name,coalesce(bi.ordered_stock,0) as ordered_stock, "
			+ "case when ci.fulfilled_stock>0 then 0 else coalesce(ci.cargo_stock,0) end as shipped_stock,  "
			+ "coalesce(ci.fulfilled_stock,0) as fulfilled_stock,  "
			+ "coalesce(bi.ordered_stock,0)-coalesce(ci.cargo_stock,0) as yet_to_ship  " + "from bookings b  "
			+ "join booking_items bi on b.id=bi.booking_id and b.is_deleted=false and bi.is_deleted=false "
			+ "join store s on b.issuing_store_id=s.id and s.is_deleted=false "
			+ "left join cargo c on b.id=c.booking_id and c.is_deleted=false  "
			+ "left join cargo_item ci on c.id=ci.cargo_id and ci.product_id=bi.product_id and ci.is_deleted=false  "
			+ "where  b.receiving_store_id=?1 and bi.product_id=?2 order by b.id desc;", nativeQuery = true)
	public List<InTransitStockDTO> getinTransitStockBysidandpid(Long storeId, Long productId);

	@Query(value = "select * from icatalogue where store_id=?1 and product_id=?2 and id =?3 and is_deleted= false ", nativeQuery = true)
	public Icatalogue getIcatalogueDetailsBySidPidIcatId(Long destStoreId, Integer productId, Long icatId);

	public Icatalogue findByStoreIdAndProductIdAndIsDeletedFalse(Long storeId, Integer productId);

}