package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.Pranth;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.PranthRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PranthService {

	@Autowired
	private PranthRepository pranthRepository;

	@Cacheable(value = "pranth", key = "#id")
	public Pranth getById(Long id) throws CustomException {
		try {
			Optional<Pranth> pranthOptional = pranthRepository.getById(id);
			if (pranthOptional.isPresent()) {
				return pranthOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Cacheable(value = "pranth", key = "#pranthName")
	public Pranth getByPranthName(String pranthName) throws CustomException {
		try {
			Optional<Pranth> pranthOptional = pranthRepository.getByName(pranthName);
			if (pranthOptional.isPresent()) {
				return pranthOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@CacheEvict(value = "pranth", allEntries = true)
	public Pranth save(Pranth pranth) throws CustomException {
		try {
			if (pranth.getId() != null && pranth.getId() > 0) {
				Optional<Pranth> existingPranthRecord = pranthRepository.getById(pranth.getId());
				if (existingPranthRecord.isPresent()) {
					return pranthRepository.save(pranth);
				}
			} else {
				pranth = pranthRepository.save(pranth);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return pranth;
	}

	@CacheEvict(value = "pranth", allEntries = true)
	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<Pranth> existingPranthRecord = pranthRepository.getById(id);
			if (existingPranthRecord.isPresent()) {
				pranthRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Cacheable(value = "pranth")
	public List<Pranth> getAll() throws CustomException {
		List<Pranth> pranths = new ArrayList<Pranth>();
		try {
			pranths = pranthRepository.findAll();;
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return pranths;
	}
}