package com.dipl.evin2.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.domain.Persistable;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(value = "temperature_log_details")
@JsonIgnoreProperties(ignoreUnknown = true)
public class TemperatureLogDetails implements Persistable<String>{

	@Id
	private String id;
	@JsonProperty("vId")
	private String vId;
	@JsonProperty("asm")
	private Integer asm;
	@JsonProperty("dId")
	private String dId;
	@JsonProperty("assetDId")
	private String assetDId;
	@JsonProperty("sId")
	private String sId;
	@JsonProperty("time")
	private Long time;
	@JsonProperty("typ")
	private Integer typ;
	@JsonProperty("tmp")
	private Double tmp;
	@JsonProperty("temperatureLogTime")
	private Date temperatureLogTime;
	private String temperatureLogid;

	private Date updatedOn;
	private Date createdOn;
	private Long updatedBy;
	private Long createdBy;
	@Builder.Default
	private Boolean isDeleted = false;
	
	@Override
	public boolean isNew() {
		return id == null;
	}


}
