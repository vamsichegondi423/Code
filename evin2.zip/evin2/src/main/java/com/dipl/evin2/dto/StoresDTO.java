package com.dipl.evin2.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class StoresDTO {

	private Integer pranthId;
	private Integer storeId;
	private String storeName;
	private Integer rcvngStoreId;
	private String rcvngStoreName;
	private Integer productId;
	private String productName;
	private Double totalStock;
	private String badge;
	private String userId;
	private String location;
}
