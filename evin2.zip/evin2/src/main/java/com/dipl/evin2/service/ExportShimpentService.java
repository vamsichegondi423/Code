package com.dipl.evin2.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.dipl.evin2.controller.CargoController.CargoFilterModel;
import com.dipl.evin2.controller.CargoController.ShipmenByFiltertDTO;
import com.dipl.evin2.controller.CargoController.ShipmentExportModel;
import com.dipl.evin2.model.FileReportResponse;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.JdbcTemplateHelper;
import com.dipl.evin2.util.KafkaProducer;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ExportShimpentService {

	@Autowired
	private SendEmailService sendEmailService;
	@Autowired
	private UploadFileService uploadFileService;
	@Autowired
	private PranthHierarchyService pranthHierarchyService;
	@Autowired
	private JdbcTemplateHelper jdbcTemplateHelper;
	@Autowired
	private KafkaProducer kafkaProducer;
	@Autowired
	@Lazy
	private ExportExcelAsyncService exportExcelAsyncService;

	public ResponseBean getShipmentService(CargoFilterModel shipmentPayload, Long pranthId,
			Long userId, String userName, String email, List<Long> offsetStoreIds) throws IOException {
		ResponseBean responsebean = new ResponseBean();
		try {
			ShipmentExportModel shipmentExportModel = new ShipmentExportModel();
//			this.getShipmentExportData(shipmentPayload, pranthId,
//				 userId, userName, email, offsetStoreIds);
			exportExcelAsyncService.getShipmentExportData(shipmentPayload, pranthId,
					 userId, userName, email, offsetStoreIds);
//			this.setShipmentsExportData(shipmentExportModel, shipmentPayload, pranthId,
//					 userId,  userName, email, offsetStoreIds);
//			kafkaProducer.sendShipmentsExportToProducer(shipmentExportModel);
			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
					+ email
					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
			responsebean.setReturnCode(1);
			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting shipment report : " + e.getStackTrace());
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting shipment report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		return responsebean;
	}
//	void setShipmentsExportData(ShipmentExportModel shipmentExportModel, CargoFilterModel shipmentPayload, Long pranthId,
//			Long userId, String userName, String email, List<Long> offsetStoreIds) {
//		shipmentExportModel.setCargoFilterModel(shipmentPayload);
//		shipmentExportModel.setPranthId(pranthId);
//		shipmentExportModel.setUserId(userId);
//		shipmentExportModel.setUserName(userName);
//		shipmentExportModel.setEmail(email);
//		shipmentExportModel.setOffsetStoreIds(offsetStoreIds);	
//	}
	public void getShipmentExportData(CargoFilterModel shipmentPayload, Long pranthId,
			Long userId, String userName, String email, List<Long> offsetStoreIds) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<ShipmenByFiltertDTO> shipments = null;
		FileOutputStream outputStream = null;
		Workbook workbook = null;
		Sheet sheet = null;
		Object fileData;
		String url = null;
		try {
			StringBuilder builder = new StringBuilder();
			Set<Long> consolidatedDomainIds = pranthHierarchyService
					.getConsolidatedPranthIds(shipmentPayload.getPranthId());
			String queryForConsolidatedDomainIds = pranthHierarchyService.buildQuery(consolidatedDomainIds);
			shipments = getCargoDataByQuery(shipmentPayload, builder, queryForConsolidatedDomainIds, offsetStoreIds);
			//creating workbook
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0, cellIndex3 = 0;
			// Creating row
			Row row = sheet.createRow(0);

			row.createCell(cellIndex++).setCellValue("Title");
			row.createCell(cellIndex++).setCellValue("" + Constants.shipment + "");
			Row row1 = sheet.createRow(1);
			row1.createCell(cellIndex1++).setCellValue("Generated on");
			row1.createCell(cellIndex1++).setCellValue("" + uploadFileService.dateWithHoursMinutes());

			Row row3 = sheet.createRow(3);
			row3.createCell(cellIndex3++).setCellValue("ShipmentId");
			row3.createCell(cellIndex3++).setCellValue("IndentId");
			row3.createCell(cellIndex3++).setCellValue("NoOfShipments");
			row3.createCell(cellIndex3++).setCellValue("ReceivingStoreName");
			row3.createCell(cellIndex3++).setCellValue("ReceivingStoreLocation");
			row3.createCell(cellIndex3++).setCellValue("IssuingStoreName");
			row3.createCell(cellIndex3++).setCellValue("IssuingStoreLocation");
			row3.createCell(cellIndex3++).setCellValue("Status");
			row3.createCell(cellIndex3++).setCellValue("CreatedName");
			row3.createCell(cellIndex3++).setCellValue("CreatedOn");
			row3.createCell(cellIndex3++).setCellValue("Transporter");
			row3.createCell(cellIndex3++).setCellValue("UserName");
			row3.createCell(cellIndex3++).setCellValue("ExpectedDateArrival");

			for (int i = 0; i < shipments.size(); i++) {
				Row dataRow = sheet.createRow(i + 4);
				int rowIndex1 = 0;
				dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getCargoNo() == null ? "" : shipments.get(i).getCargoNo() + "");
				
				dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getBookingId() == null ? "" : shipments.get(i).getBookingId() + "");
				
				dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getNoOfItems() == null ? 0 : shipments.get(i).getNoOfItems());
				
				dataRow.createCell(rowIndex1++).setCellValue(shipments.get(i).getReceivingStoreName() == null ? ""
						: shipments.get(i).getReceivingStoreName() + "");
				
				dataRow.createCell(rowIndex1++)
						.setCellValue(shipments.get(i).getReceivingStoreLocation() == null ? ""
								: shipments.get(i).getReceivingStoreLocation() + "");
				
				dataRow.createCell(rowIndex1++).setCellValue(shipments.get(i).getIssuingStoreName() == null ? ""
						: shipments.get(i).getIssuingStoreName()+ "");
				
				dataRow.createCell(rowIndex1++).setCellValue(shipments.get(i).getIssuingStoreLocation() == null ? ""
						: shipments.get(i).getIssuingStoreLocation() + "");
				
				dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getStatus() == null ? "" : shipments.get(i).getStatus() + "");
				
				dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getCreatedName() == null ? "" : shipments.get(i).getCreatedName() + "");	
				
				Cell cell = dataRow.createCell(rowIndex1++);
				cell.setCellValue(
						shipments.get(i).getCreatedOn() == null ? null : shipments.get(i).getCreatedOn());
				cell.setCellStyle(dateCellStyle);
				
				dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getTransporter() == null ? "" : shipments.get(i).getTransporter() + "");
				
					dataRow.createCell(rowIndex1++).setCellValue(
						shipments.get(i).getUserId() == null ? "" : shipments.get(i).getUserId() + "");
				
			   Cell cell1 = dataRow.createCell(rowIndex1++);
				cell1.setCellValue(
						shipments.get(i).getExpectedDateArrvl() == null ? null : shipments.get(i).getExpectedDateArrvl());
				cell1.setCellStyle(dateCellStyle);

			}

			File tempFile = null;
			tempFile = File.createTempFile("ShipmentReport", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
			workbook.write(outputStream);
			HttpResponse<String> response = uploadFileService.uploadFile(url, userName, tempFile,"Shipment");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			tempFile.delete();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";

			HashMap<String, Object> emailbody = new HashMap<>();
			emailbody = sendEmailService.getShipmentEmail(link, userName, email);

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, email, userName,
					fileDownloadUrl, fileType, fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ email
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting shipment report : " + e.getStackTrace());
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting shipment report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		finally {
			
			outputStream.close();
			workbook.close();
		}
//		return responsebean;
	}
	
	public List<ShipmenByFiltertDTO> getCargoDataByQuery(CargoFilterModel shipmentPayload, StringBuilder builder,
			String queryForConsolidatedDomainIds, List<Long> offsetKioskIds){
		List<ShipmenByFiltertDTO> cargoList = null;

		builder.append(
				"select distinct c.pranth_id,c.id as cargo_id,c.booking_id,c.cargo_no,1 as noOfItems,b.receiving_store_id, rs.name as receiving_store_name,\r\n"
						+ "concat(rs.city,', ',rd.name,', ',rst.name,', ',rc.name) as receiving_store_location,b.issuing_store_id,s.name as issuing_store_name,\r\n"
						+ "concat(s.city,', ',d.name,', ',st.name,', ',ic.name) as issuing_store_location, ms.name as status,b.created_on,concat(u.f_name,' ',u.l_name) as createdName,\r\n"
						+ "u.user_id,b.arrival_date as expectedDateArrvl,ca.carrier_name as transporter,b.source_type from cargo c left join bookings b on b.id=c.booking_id left join store rs on b.receiving_store_id=rs.id\r\n"
						+ "left join master_status ms on ms.id=b.status_id left join master_district rd on rd.id=rs.district_id left join master_state rst on rst.id=rs.state_id\r\n"
						+ "left join master_country rc on rc.id=rs.country_id \r\n"
						+ "left join store s on s.id=b.issuing_store_id left join master_district d on d.id=s.district_id left join master_state st on st.id=s.state_id\r\n"
						+ "left join master_country ic on ic.id=s.country_id left join users u on u.id=b.created_by \r\n"
						+ "left join packages p on p.cargo_id=c.id left join carrier ca on p.carrier_id=ca.id ");
		builder.append(" where c.pranth_id in " + queryForConsolidatedDomainIds + "");
		if (offsetKioskIds != null && !offsetKioskIds.isEmpty()) {
			builder.append(" and (b.receiving_store_id in ( " + StringUtils.join(offsetKioskIds, " ,")
			+ "  ) or b.issuing_store_id in ( " + StringUtils.join(offsetKioskIds, " ,") + "  ))");
		}
		if (shipmentPayload.getReceivingStoreId() != null) {
			builder.append(" and b.receiving_store_id = " + shipmentPayload.getReceivingStoreId() + "");
		}
		if (shipmentPayload.getIssuingStoreId() != null) {
			builder.append(" and b.issuing_store_id = " + shipmentPayload.getIssuingStoreId() + "");
		}
		if (shipmentPayload.getStatus() != null && !shipmentPayload.getStatus().isEmpty()) {
			builder.append(" and ms.name like '%" + shipmentPayload.getStatus() + "%'");
		}
		if (shipmentPayload.getFromDate() != null && shipmentPayload.getToDate() != null) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			builder.append(" and  b.created_on   between '" + simpleDateFormat.format(shipmentPayload.getFromDate())
			+ "' and  '" + simpleDateFormat.format(shipmentPayload.getToDate()) + "'");
		} else {
			if (shipmentPayload.getFromDate() != null) {
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				builder.append(
						" and  b.created_on  >= '" + simpleDateFormat.format(shipmentPayload.getFromDate()) + "'");
			}
			if (shipmentPayload.getToDate() != null) {
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				builder.append(" and  b.created_on  <= '" + simpleDateFormat.format(shipmentPayload.getToDate()) + "'");
			}
		}
		if (shipmentPayload.getTransporter() != null && !shipmentPayload.getTransporter().isEmpty()) {
			builder.append(" and ca.carrier_name  like '%" + shipmentPayload.getTransporter() + "%'");
		}
		if (shipmentPayload.getFromExpectedArrvlDate() != null && shipmentPayload.getToExpectedArrvlDate() != null) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			builder.append(" and b.arrival_date  between '"
					+ simpleDateFormat.format(shipmentPayload.getFromExpectedArrvlDate()) + "' and  '"
					+ simpleDateFormat.format(shipmentPayload.getToExpectedArrvlDate()) + "'");
		} else {
			if (shipmentPayload.getFromExpectedArrvlDate() != null) {
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				builder.append(" and b.arrival_date >= '"
						+ simpleDateFormat.format(shipmentPayload.getFromExpectedArrvlDate()) + "'");
			}
			if (shipmentPayload.getToExpectedArrvlDate() != null) {
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				builder.append(" and b.arrival_date <= '"
						+ simpleDateFormat.format(shipmentPayload.getToExpectedArrvlDate()) + "'");
			}
		}
		builder.append(
				" order by b.created_on desc ");
		cargoList = jdbcTemplateHelper.getResults(builder.toString(), ShipmenByFiltertDTO.class);

		return cargoList;
	}
}