package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import com.dipl.evin2.entity.MasterParentModule;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface MasterParentModuleRepository extends JpaRepository<MasterParentModule, Integer> {

	@Query(value = "select * from master_parent_module where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterParentModule> getById(Integer id);

	@Query(value = "select * from master_parent_module where is_deleted = false", nativeQuery = true)
	public List<MasterParentModule> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from master_parent_module where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);
	
	@Modifying
	@Transactional
	@Query(value = "update master_parent_module set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);
	
}