/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "asset_sensor_configuration")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssetSensorConfiguration extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Long id;
    @Column(name = "asset_id")
    private Long assetId;
    @Column(name = "sensor_id")
    private String sensorId;
    @Column(name = "use_default_configuration")
    private Boolean useDefaultConfiguration;
    @Column(name = "sampling_interval")
    private Integer samplingInterval;
    @Column(name = "push_interval")
    private Integer pushInterval;
    @Column(name = "temperature_push_notification")
    private Boolean temperaturePushNotification;
    @Column(name = "temperature_incursion_excursion_push_notification")
    private Boolean temperatureIncursionExcursionPushNotification;
    @Column(name = "device_alarm_push_notification")
    private Boolean deviceAlarmPushNotification;
    @Column(name = "stats_push_notification")
    private Boolean statsPushNotification;
    @Column(name = "temperature_alarm_push_notifications")
    private Boolean temperatureAlarmPushNotifications;
    @Column(name = "high_alarm_temperature")
    private Double highAlarmTemperature;
    @Column(name = "high_alarm_temperature_duration")
    private Integer highAlarmTemperatureDuration;
    @Column(name = "low_alarm_temperature")
    private Double lowAlarmTemperature;
    @Column(name = "low_alarm_temperature_duration")
    private Integer lowAlarmTemperatureDuration;
    @Column(name = "high_warning_temperature")
    private Double highWarningTemperature;
    @Column(name = "high_warning_temperature_duration")
    private Integer highWarningTemperatureDuration;
    @Column(name = "low_warning_temperature")
    private Double lowWarningTemperature;
    @Column(name = "low_warning_temperature_duration")
    private Integer lowWarningTemperatureDuration;
    @Column(name = "alarm_frequency_notification_duration")
    private Integer alarmFrequencyNotificationDuration;
    @Column(name = "alarm_frequency_notification_number")
    private Integer alarmFrequencyNotificationNumber;
    
    
	public AssetSensorConfiguration(SensorDefaultConfiguration sensorDefaultConfiguration) {
		this.id = sensorDefaultConfiguration.getId();
		this.sensorId = sensorDefaultConfiguration.getSensorId();
		this.useDefaultConfiguration = sensorDefaultConfiguration.getUseDefaultConfiguration();
		this.samplingInterval = sensorDefaultConfiguration.getSamplingInterval();
		this.pushInterval = sensorDefaultConfiguration.getPushInterval();
		this.temperaturePushNotification = sensorDefaultConfiguration.getTemperaturePushNotification();
		this.temperatureIncursionExcursionPushNotification = sensorDefaultConfiguration.getTemperatureIncursionExcursionPushNotification();
		this.deviceAlarmPushNotification = sensorDefaultConfiguration.getDeviceAlarmPushNotification();
		this.statsPushNotification = sensorDefaultConfiguration.getStatsPushNotification();
		this.temperatureAlarmPushNotifications = sensorDefaultConfiguration.getTemperatureAlarmPushNotifications();
		this.highAlarmTemperature = sensorDefaultConfiguration.getHighAlarmTemperature();
		this.highAlarmTemperatureDuration = sensorDefaultConfiguration.getHighAlarmTemperatureDuration();
		this.lowAlarmTemperature = sensorDefaultConfiguration.getLowAlarmTemperature();
		this.lowAlarmTemperatureDuration = sensorDefaultConfiguration.getLowAlarmTemperatureDuration();
		this.highWarningTemperature = sensorDefaultConfiguration.getHighWarningTemperature();
		this.highWarningTemperatureDuration = sensorDefaultConfiguration.getHighAlarmTemperatureDuration();
		this.lowWarningTemperature = sensorDefaultConfiguration.getLowWarningTemperature();
		this.lowWarningTemperatureDuration = sensorDefaultConfiguration.getLowWarningTemperatureDuration();
		this.alarmFrequencyNotificationDuration = sensorDefaultConfiguration.getAlarmFrequencyNotificationDuration();
		this.alarmFrequencyNotificationNumber = sensorDefaultConfiguration.getAlarmFrequencyNotificationNumber();
	}
    
    
    

}
