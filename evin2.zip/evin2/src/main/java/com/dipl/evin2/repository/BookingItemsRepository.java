package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.dto.BookingItemTooltipDTO;
import com.dipl.evin2.entity.BookingItems;

@Repository
public interface BookingItemsRepository extends JpaRepository<BookingItems, Long> {

	@Query(value = "select * from booking_items where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<BookingItems> getById(Long id);

	@Query(value = "select * from booking_items where is_deleted = false", nativeQuery = true)
	public List<BookingItems> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from booking_items where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update booking_items set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from booking_items where is_deleted = false and booking_id = ?1", nativeQuery = true)
	public List<BookingItems> findAllByBookingId(Long bookingId);
	
	@Query(value = "SELECT sum(ordered_stock) from booking_items where booking_id =?1", nativeQuery = true)
	public Long getOrderStockCount(Long bookingId);
	@Query(value = "select * from booking_items where booking_id = ?1 and is_deleted = false", nativeQuery = true)
	public BookingItems getBookingItemDetails(Long bookingId);

	@Query(value = "select * from booking_items where id =?1 and is_deleted = false", nativeQuery = true)
	public BookingItems getBookingItemDetailsForBooking(Long bookingItemId);

	@Query(value = "select count(id) from booking_items where booking_id =?1  and is_deleted = false", nativeQuery = true)
	public Long getByBookingItemsCountByBid(Long bookingId);

	@Query(value = "select recommanded_stock ,orginial_ordered_stock, reason ,ordered_stock as modified_stock,modified_reason from booking_items where id =?1 and is_deleted = false ", nativeQuery = true)
	public List<BookingItemTooltipDTO> getBookingItemTooltipDetails(Long bookingItemId);

	@Query(value = "select * from booking_items where product_id = ?1 and booking_id =?2 and is_deleted = false", nativeQuery = true)
	public BookingItems findBookingItemByProductId(Long productId, Long bookingId);



}