package com.dipl.evin2.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExportStockReportModel {
	
	private Long productId;
	private Long pranthId;
	private Integer abnormalityType;
	private Long duration;
	private Long userId;
	private String userName;
	private String email;
	private List<Integer> includeAllProductBadge;
	private List<Integer> includeStoreBadge;
	private Integer country;
	private Integer state;
	private Integer district;
	private Integer block;
}
