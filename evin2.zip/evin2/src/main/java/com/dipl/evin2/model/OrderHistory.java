package com.dipl.evin2.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Document(collection = "OrderHistory")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderHistory {

	@Id
	private String id;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "IST")
//	@JsonProperty("time")
	private Date time;
	@JsonProperty("order_id")
	private String orderId;
	private String status;
	private String message;
	@JsonProperty("user_id")
	private String userID;
	private String cargoNo;
	@JsonProperty("order_type_id")
	private String orderTypeId;

}
