package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.dto.AbnormalStockDTO;
import com.dipl.evin2.entity.IcatalogueLog;

@Repository
public interface IcatalogueLogRepository extends JpaRepository<IcatalogueLog, Long> {

	@Query(value = "select * from icatalogue_log where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<IcatalogueLog> getById(Long id);

	@Query(value = "select * from icatalogue_log where is_deleted = false", nativeQuery = true)
	public List<IcatalogueLog> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from icatalogue_log where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update icatalogue_log set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);
	@Query(value = "select * from icatalogue_log where icatalogue_id = ?1 and product_id = ?2 and store_id = ?3 and is_deleted = false order by created_on desc limit 1 ", nativeQuery = true)
	public IcatalogueLog getIcatalogueDetails(Long icatalogueId, Integer productId, Long storeId);
	
	@Query(value = "select store_id,product_id,created_on,date_start,date_end,abnormal_type_id from icatalogue_log where abnormal_type_id in(1,200,201,202) and created_on > (SELECT max(created_on) from report_sync_status where name_table='abnormal_stock')", nativeQuery = true)
	public List<AbnormalStockDTO> findAbnormalStocks();

}