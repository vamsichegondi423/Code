package com.dipl.evin2.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.model.MasterStoresPayload;
import com.dipl.evin2.service.MasterStoreService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/master-store")
public class MasterStoreController {
	
	@Autowired
	private MasterStoreService masterStoreService;
	
	@ApiOperation("Use this api for fetching Stores records ")
	@PostMapping(value = "/v1/get-stores", produces = "application/json")
	public ResponseBean getStores(@RequestBody MasterStoresPayload masterStoresPayload ) {
		ResponseBean responseBean = new ResponseBean();
		List<Map<String, Object>> locationList = null;
		try {
			 locationList = masterStoreService.findStores(masterStoresPayload);
			if (locationList != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(locationList);
				log.info(""+locationList.size());
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured while store location details", e.getCause());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Exception occured while master location details" + e.getStackTrace());
		}
		return responseBean;
	}

}
