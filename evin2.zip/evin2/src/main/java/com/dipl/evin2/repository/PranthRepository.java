package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.Pranth;

@Repository
public interface PranthRepository extends JpaRepository<Pranth, Long> {

	@Query(value = "select * from pranth where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<Pranth> getById(Long id);

	@Query(value = "select * from pranth where is_deleted = false", nativeQuery = true)
	public List<Pranth> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from pranth where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update pranth set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from pranth where name = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<Pranth> getByName(String pranthName);

	@Query(value = "select * from pranth where name like ?1 and governor_no = ?2 and is_deleted = false", nativeQuery = true)
	public Optional<Pranth> getByNameAndGovernorNo(String name, String governorNo);

}