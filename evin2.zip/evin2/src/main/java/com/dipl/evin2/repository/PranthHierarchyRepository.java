package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.PranthHierarchy;

@Repository
public interface PranthHierarchyRepository extends JpaRepository<PranthHierarchy, Long> {

	@Query(value = "select * from pranth_hierarchy where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<PranthHierarchy> getById(Long id);

	@Query(value = "select * from pranth_hierarchy where is_deleted = false", nativeQuery = true)
	public List<PranthHierarchy> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from pranth_hierarchy where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update pranth_hierarchy set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from pranth_hierarchy where pranth_id=?1 and is_deleted = false", nativeQuery = true)
	public List<PranthHierarchy> getPranthsByPranthId(Long pranthId);

	@Query(value = "select * from pranth_hierarchy where pranth_id=?1 and mapped_pranth_id = ?2 and mapping_type = ?3 and is_deleted = false", nativeQuery = true)
	public Optional<PranthHierarchy> findByPranthIdMappingTypeAndMappingId(Long pranthId, Long mappedPranthId,
			String mappingType);
	
	@Query(value = "select * from pranth_hierarchy where mapped_pranth_id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<PranthHierarchy> findByMappingId(Long parentPranthId);
	
	@Query(value = "WITH RECURSIVE pranth_heirarchy_recursive AS ( "
			+ " SELECT distinct pranth_id "
			+ " FROM pranth_hierarchy "
			+ " WHERE pranth_id = ?1 "
			+ " UNION ALL "
			+ " SELECT mapped_pranth_id FROM pranth_hierarchy ph, pranth_heirarchy_recursive phr "
			+ " WHERE ph.pranth_id = phr.pranth_id "
			+ ") "
			+ "SELECT * FROM pranth_heirarchy_recursive;", nativeQuery = true)
	public Set<Long> getConsolodatedDomainIds(Long pranthId);
	
	@Query(value = "WITH RECURSIVE pranth_heirarchy_recursive AS (  SELECT distinct pranth_id  FROM pranth_hierarchy  WHERE pranth_id = ?1 UNION ALL "
			+ "SELECT mapped_pranth_id FROM pranth_hierarchy ph, pranth_heirarchy_recursive phr WHERE ph.pranth_id = phr.pranth_id ) "
			+ "SELECT distinct * FROM pranth_heirarchy_recursive where pranth_id != ?1 order by pranth_id ", nativeQuery = true)
	public Set<Long> getChildDomainIds(Long pranthId);



}