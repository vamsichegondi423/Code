package com.dipl.evin2.util;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ReportStockTrend {

	private Long storeId;
	private Long productId;
	private Integer closingCount;
	private String stockTrendDate;
	private Integer stockTrendMonth;
	private Integer stockTrendYear;
	private Boolean isActive;
	
}
