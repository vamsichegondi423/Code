package com.dipl.evin2.dto;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StoresDetailsMapper implements RowMapper<StoresDTO>{

	@Override
	public StoresDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		StoresDTO materialResult = StoresDTO.builder().pranthId(rs.getInt("domain_id")).storeId(rs.getInt("store_id"))
				.storeName(rs.getString("kiosk_name")).productId(rs.getInt("materialid"))
				.productName(rs.getString("material_name")).totalStock(rs.getDouble("total_stock"))
				.badge(rs.getString("tags")).build();
		return materialResult;
	}
}
