package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.BadgePranth;

@Repository
public interface BadgePranthRepository extends JpaRepository<BadgePranth, Integer> {

	@Query(value = "select * from badge_pranth where badge_type_id = ?1 and pranth_id = ?2 and is_active = false", nativeQuery = true)
	public Optional<BadgePranth> getByBadgeTypeId(Integer id, Long pranthId);
	
	@Query(value = "select * from badge_pranth where id = ?1 and is_active = true", nativeQuery = true)
	public Optional<BadgePranth> getById(Integer id);


	@Query(value = "select * from badge_pranth where badge_type_id=?1 and pranth_id = ?2 and is_active = false", nativeQuery = true)
	public List<BadgePranth> getAllBadgesByTypeId(Integer badgeId, Long pranthId);

	@Query(value = "select * from badge_pranth where name like %:name% and badge_type_id=:badgeTypeId and pranth_id = :pranthId and is_active = false", nativeQuery = true)
	public List<BadgePranth> getAllByNameAndBadgeType(@Param("name") String name, @Param("badgeTypeId") Integer badgeTypeId, @Param("pranthId") Long pranthId);


	@Query(value = "select * from badge_pranth where pranth_id = ?1 and is_active = false", nativeQuery = true)
	public List<BadgePranth> findAllByPranth(Long pranthId);
	
	@Modifying
	@Transactional
	@Query(value = "update badge_pranth set is_active = false where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);


	public BadgePranth findByPranthIdAndBadgeIdAndIsActiveTrue(Long pranthId, Integer badgeid);

	public BadgePranth findByBadgeId(Integer id);

	@Query(value = "select * from badge_pranth where pranth_id = ?1 and is_active = true", nativeQuery = true)
	public List<BadgePranth> getByPranthId(Long pranthid);

	public BadgePranth findByPranthIdAndBadgeId(Long pranthId, Integer id);
}