package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.CargoItemBatch;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.CargoItemBatchRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CargoItemBatchService {

	@Autowired
	private CargoItemBatchRepository cargoItemBatchRepository;

	public CargoItemBatch getById(Long id) throws CustomException {
		try {
			Optional<CargoItemBatch> cargoItemBatchOptional = cargoItemBatchRepository.getById(id);
			if (cargoItemBatchOptional.isPresent()) {
				return cargoItemBatchOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public CargoItemBatch save(CargoItemBatch cargoItemBatch) throws CustomException {
		try {
			if (cargoItemBatch.getId() != null && cargoItemBatch.getId() > 0) {
				Optional<CargoItemBatch> existingCargoItemBatchRecord = cargoItemBatchRepository
						.getById(cargoItemBatch.getId());
				if (existingCargoItemBatchRecord.isPresent()) {
					return cargoItemBatchRepository.save(cargoItemBatch);
				}
			} else {
				cargoItemBatch = cargoItemBatchRepository.save(cargoItemBatch);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return cargoItemBatch;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<CargoItemBatch> existingCargoItemBatchRecord = cargoItemBatchRepository.getById(id);
			if (existingCargoItemBatchRecord.isPresent()) {
				cargoItemBatchRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<CargoItemBatch> getAll() {
		try {
			return cargoItemBatchRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}