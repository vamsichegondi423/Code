package com.dipl.evin2.util;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.dipl.evin2.controller.BookingsController.BookingsExportModel;
import com.dipl.evin2.controller.CargoController.ShipmentExportModel;
import com.dipl.evin2.entity.IcatalogueLog;
import com.dipl.evin2.entity.ReportProduct;
import com.dipl.evin2.entity.ReportStore;
import com.dipl.evin2.entity.ReportTxns;
import com.dipl.evin2.model.CargoHistory;
import com.dipl.evin2.model.ExportStockDeviantModel;
import com.dipl.evin2.model.ExportStockReportByOneStoreModel;
import com.dipl.evin2.model.ExportStockReportModel;
import com.dipl.evin2.model.ExportTransactionModel;
import com.dipl.evin2.model.OrderHistory;
import com.dipl.evin2.repository.UsersRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class KafkaProducer {

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
//	@Autowired
//	private KafkaTemplate<String, Object> exportKafkaTemplate;

	@Autowired
	private UsersRepository usersRepository;

	@Autowired
	private ObjectMapper objectMapper;

	public void addOrderTopicToKafkaQueue(String comments, Long userId, Long orderId, String status, Integer orderTypeId)
			throws JsonProcessingException {
		// adding the topic into Kafka queue
		OrderHistory ohh = OrderHistory.builder().orderId(orderId.toString()).message(comments).status(status)
				.userID(usersRepository.findById(userId).get().getUserId()).orderTypeId(orderTypeId.toString()).build();
		kafkaTemplate.send(Status.ORDER_TOPIC.getTopic(), objectMapper.writeValueAsString(ohh));
	}

	public void saveCargoStausToKafka(String comments, Long createdBy, Long bookingId, String cargoNo, String status)
			throws JsonProcessingException {
		OrderHistory ohh1 = OrderHistory.builder().orderId(bookingId.toString()).message(comments).status(status)
				.userID(usersRepository.findById(createdBy).get().getUserId()).cargoNo(cargoNo).build();
		kafkaTemplate.send(Status.ORDER_TOPIC.getTopic(), objectMapper.writeValueAsString(ohh1));
	}

	public void saveBookingStausToKafka(String comments, Long userId, Long bookingId, String cargoNo, String status)
			throws JsonProcessingException {
		OrderHistory ohh1 = OrderHistory.builder().orderId(bookingId.toString()).message(comments).status(status)
				.userID(usersRepository.findById(userId).get().getUserId()).cargoNo(cargoNo).build();
		kafkaTemplate.send(Status.ORDER_TOPIC.getTopic(), objectMapper.writeValueAsString(ohh1));
	}

	public void saveCargoStatusInCargoTopic(String comments, Long createdBy, Long bookingId, String cargoNo,
			Long cargoId, String status) throws JsonProcessingException {
		CargoHistory ohh1 = CargoHistory.builder().orderId(bookingId.toString()).message(comments).status(status)
				.userID(usersRepository.findById(createdBy).get().getUserId()).cargoId(cargoId.toString())
				.cargoNo(cargoNo).build();
		kafkaTemplate.send(Status.CARGO_TOPIC.getTopic(), objectMapper.writeValueAsString(ohh1));

	}

	public void saveTxnToKafka(ReportTxns reportTxns) throws JsonProcessingException {
		kafkaTemplate.send(Status.TXN_TOPIC.getTopic(), objectMapper.writeValueAsString(reportTxns));
	}

	public void saveConsumptionToKafka(ReportConsumption reportConsumption) throws JsonProcessingException {
		kafkaTemplate.send(Status.CONSUMPTION_TOPIC.getTopic(), objectMapper.writeValueAsString(reportConsumption));
	}

	public void saveStockTrendTypeToKafka(ReportStockTrendType stockTrendType) throws JsonProcessingException {
		kafkaTemplate.send(Status.STOCK_TREND_TYPE.getTopic(), objectMapper.writeValueAsString(stockTrendType));
	}

	public void saveAbnormalStockIntoQueue(AbnormalStockModel abnormalStockReport) {
		try {
			kafkaTemplate.send(Status.ABNORMAL_STOCK.getTopic(), objectMapper.writeValueAsString(abnormalStockReport));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

	}

	public void saveClosingStockTrendToKafka(ReportStockTrend stockTrend) throws JsonProcessingException {
		kafkaTemplate.send(Status.STOCKTREND.getTopic(), objectMapper.writeValueAsString(stockTrend));
	}

	public void saveStoreToKafka(String storeName, Long storeId, Boolean isDeleted, String badgeName, int stateId,
			Integer districtId, Integer blockId, String city, Integer badgeId) throws JsonProcessingException {
		ReportStore reportStroe = ReportStore.builder().storeId(storeId).storeName(storeName).isActive(true)
				.storeBadge(badgeName).stateId(stateId).blockId(blockId).city(city).badgeId(badgeId.longValue())
				.build();
		kafkaTemplate.send(Status.STORE_TOPIC.getTopic(), objectMapper.writeValueAsString(reportStroe));
	}

	public void saveProductToKafka(String productName, Integer productId, Boolean isDeleted)
			throws JsonProcessingException {
		ReportProduct reportProduct = ReportProduct.builder().productId(productId).productName(productName)
				.isActive(true).build();
		kafkaTemplate.send(Status.PRODUCT_TOPIC.getTopic(), objectMapper.writeValueAsString(reportProduct));
	}

	public void saveDiscardQuantityToKafka(Long quanty, Long storeId, Integer productId, Boolean isDeleted,
			Integer reasonId) throws JsonProcessingException {
		ReportDiscard reportDiscard = ReportDiscard.builder().storeId(storeId).productId(productId)
				.discardReasonId(reasonId).discardCount(quanty.intValue()).isActive(true).build();
		kafkaTemplate.send(Status.REPORT_DISCARD_TOPIC.getTopic(), objectMapper.writeValueAsString(reportDiscard));
	}

	public void saveIcataLogueLogToKafka(Integer productId, Long storeId, Long pranthId, Integer txnTypeId, Long txnId,
			Long icatId, Long createdBy, Boolean isDeleted, Integer abnormalTypeId) throws JsonProcessingException {
		IcatalogueLog icatalogueLog = IcatalogueLog.builder().storeId(storeId).productId(productId).pranthId(pranthId)
				.txnTypeId(txnTypeId).txnId(txnId).icatalogueId(icatId).abnormalTypeId(abnormalTypeId).build();
		icatalogueLog.setCreatedBy(createdBy);
		icatalogueLog.setIsDeleted(isDeleted);
		kafkaTemplate.send(Status.ICATALOGUE_LOG_TOPIC.getTopic(), objectMapper.writeValueAsString(icatalogueLog));
	}
	
//	public void sendStockWithoutBatchReportToProducer(ExportStockReportModel exportStockReportModel) {
//		try {
//			ObjectMapper obj = new ObjectMapper();
//			String str = obj.writeValueAsString(exportStockReportModel);
//			kafkaTemplate.send(Status.STOCK_EXPORT_WITHOUT_BATCH_TOPIC.getTopic(), str);
//		} catch (Exception e) {
//			log.error("Exception occured in stock without batch export producer", e);
//		}
//	}
	
//	public void sendStockWithBatchReportToProducer(ExportStockReportModel exportStockReportModel) {
//		try {
//			ObjectMapper obj = new ObjectMapper();
//			String str = obj.writeValueAsString(exportStockReportModel);
//			kafkaTemplate.send(Status.STOCK_EXPORT_WITH_BATCH_TOPIC.getTopic(), str);
//		} catch (Exception e) {
//			log.error("Exception occured in stock with batch export producer", e);
//		}
//	}
	
//	public void sendTxnDataWithoutBatchToProducer(ExportTransactionModel exportTransactionModel) {
//		try {
//			ObjectMapper obj = new ObjectMapper();
//			String str = obj.writeValueAsString(exportTransactionModel);
//			kafkaTemplate.send(Status.TXN_EXPORT_WITHOUT_BATCH_TOPIC.getTopic(), str);
//		} catch (Exception e) {
//			log.error("Exception occured in transaction without batch export producer", e);
//		}
//	}
	
//	public void sendTxnDataWithBatchToProducer(ExportTransactionModel exportTransactionModel) {
//		try {
//			ObjectMapper obj = new ObjectMapper();
//			String str = obj.writeValueAsString(exportTransactionModel);
//			kafkaTemplate.send(Status.TXN_EXPORT_WITH_BATCH_TOPIC.getTopic(), str);
//		} catch (Exception e) {
//			log.error("Exception occured in transaction with batch export producer", e);
//		}
//	}
	
//	public void sendStockDeviantExportToProducer(ExportStockDeviantModel exportStockDeviantModel) {
//		try {
//			ObjectMapper obj = new ObjectMapper();
//			String str = obj.writeValueAsString(exportStockDeviantModel);
//			kafkaTemplate.send(Status.STOCK_DEVIANT_EXPORT_TOPIC.getTopic(), str);
//		} catch (Exception e) {
//			log.error("Exception occured in stock deviant export producer", e);
//		}
//	}
	
//	public void sendBookingsExportToProducer(BookingsExportModel bookingsExportModel) {
//		try {
//			ObjectMapper obj = new ObjectMapper();
//			String str = obj.writeValueAsString(bookingsExportModel);
//			kafkaTemplate.send(Status.BOOKINGS_EXPORT_TOPIC.getTopic(), str);
//		} catch (Exception e) {
//			log.error("Exception occured in bookings export producer", e);
//		}
//	}
	
//	public void sendShipmentsExportToProducer(ShipmentExportModel shipmentExportModel) {
//		try {
//			ObjectMapper obj = new ObjectMapper();
//			String str = obj.writeValueAsString(shipmentExportModel);
//			kafkaTemplate.send(Status.SHIPMENTS_EXPORT_TOPIC.getTopic(), str);
//		} catch (Exception e) {
//			log.error("Exception occured in shipments export producer", e);
//		}
//	}
	
//	public void sendStockReportByStoreWithBatchExportToProducer(ExportStockReportByOneStoreModel exportStockReportByOneStoreModel) {
//		try {
//			ObjectMapper obj = new ObjectMapper();
//			String str = obj.writeValueAsString(exportStockReportByOneStoreModel);
//			kafkaTemplate.send(Status.STOCK_REPORT_BY_STORE_WITH_BATCH_EXPORT_TOPIC.getTopic(), str);
//		} catch (Exception e) {
//			log.error("Exception occured in shipments export producer", e);
//		}
//	}
	
//	public void sendStockReportByStoreWithoutBatchExportToProducer(ExportStockReportByOneStoreModel exportStockReportByOneStoreModel) {
//		try {
//			ObjectMapper obj = new ObjectMapper();
//			String str = obj.writeValueAsString(exportStockReportByOneStoreModel);
//			kafkaTemplate.send(Status.STOCK_REPORT_BY_STORE_WITHOUT_BATCH_EXPORT_TOPIC.getTopic(), str);
//		} catch (Exception e) {
//			log.error("Exception occured in shipments export producer", e);
//		}
//	}
	

	/*
	 * topic creation
	 */
	@Bean
	public NewTopic createEmailTopic() {
		return new NewTopic(Status.ORDER_TOPIC.getTopic(), 10, (short) 1);
	}

	@Bean
	public NewTopic createCargoTopic() {
		return new NewTopic(Status.CARGO_TOPIC.getTopic(), 10, (short) 1);
	}

	@Bean
	public NewTopic createTxnTopic() {
		return new NewTopic(Status.TXN_TOPIC.getTopic(), 10, (short) 1);
	}

	@Bean
	public NewTopic createStoreTopic() {
		return new NewTopic(Status.STORE_TOPIC.getTopic(), 10, (short) 1);
	}

	@Bean
	public NewTopic createProductTopic() {
		return new NewTopic(Status.PRODUCT_TOPIC.getTopic(), 10, (short) 1);
	}

	@Bean
	public NewTopic createReportDiscardTopic() {
		return new NewTopic(Status.REPORT_DISCARD_TOPIC.getTopic(), 10, (short) 1);
	}

	@Bean
	public NewTopic createIcatalogueLogTopic() {
		return new NewTopic(Status.ICATALOGUE_LOG_TOPIC.getTopic(), 10, (short) 1);
	}
	
//	@Bean
//	public NewTopic createStockExportWithoutBatchTopic() {
//		return new NewTopic(Status.STOCK_EXPORT_WITHOUT_BATCH_TOPIC.getTopic(), 10, (short) 1);
//	}
//	
//	@Bean
//	public NewTopic createStockExportWithBatchTopic() {
//		return new NewTopic(Status.STOCK_EXPORT_WITH_BATCH_TOPIC.getTopic(), 10, (short) 1);
//	}
//	
//	@Bean
//	public NewTopic createTransactionExportWithoutBatchTopic() {
//		return new NewTopic(Status.TXN_EXPORT_WITHOUT_BATCH_TOPIC.getTopic(), 10, (short) 1);
//	}
//	
//	@Bean
//	public NewTopic createTransactionExportWithBatchTopic() {
//		return new NewTopic(Status.TXN_EXPORT_WITH_BATCH_TOPIC.getTopic(), 10, (short) 1);
//	}
//	
//	@Bean
//	public NewTopic createStockDeviantExportTopic() {
//		return new NewTopic(Status.STOCK_DEVIANT_EXPORT_TOPIC.getTopic(), 10, (short) 1);
//	}
//	
//	@Bean
//	public NewTopic createBookingsExportTopic() {
//		return new NewTopic(Status.BOOKINGS_EXPORT_TOPIC.getTopic(), 10, (short) 1);
//	}
//	
//	@Bean
//	public NewTopic createShipmentsExportTopic() {
//		return new NewTopic(Status.SHIPMENTS_EXPORT_TOPIC.getTopic(), 10, (short) 1);
//	}
//  
//	@Bean
//	public NewTopic createStockReportByStoreWithBatchExportTopic() {
//		return new NewTopic(Status.STOCK_REPORT_BY_STORE_WITH_BATCH_EXPORT_TOPIC.getTopic(), 10, (short) 1);
//	}
//	
//	@Bean
//	public NewTopic createStockReportByStoreWithoutBatchExportTopic() {
//		return new NewTopic(Status.STOCK_REPORT_BY_STORE_WITHOUT_BATCH_EXPORT_TOPIC.getTopic(), 10, (short) 1);
//	}
}
