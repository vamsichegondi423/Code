package com.dipl.evin2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterPermission;
import com.dipl.evin2.repository.MasterPermissionRepository;

@Service
public class MasterPermissionService {

	@Autowired
	private MasterPermissionRepository masterPermissionRepository;

	@Cacheable(value = "master-permission", key = "#id")
	public MasterPermission getById(Integer id) {
		Optional<MasterPermission> masterPermissionOptional = masterPermissionRepository.getById(id);
		if (masterPermissionOptional.isPresent()) {
			return masterPermissionOptional.get();
		} else {
			return null;
		}
	}

	@CachePut(value = "master-permission", key = "#masterPermission.id")
	public MasterPermission save(MasterPermission masterPermission) {
		if (masterPermission.getId() != null && masterPermission.getId() > 0) {
			Optional<MasterPermission> existingMasterPermissionRecord = masterPermissionRepository
					.getById(masterPermission.getId());
			if (existingMasterPermissionRecord.isPresent()) {
				return masterPermissionRepository.save(masterPermission);
			}
		} else {
			masterPermission = masterPermissionRepository.save(masterPermission);
		}
		return masterPermission;
	}

	@CacheEvict(value = "master-permission", allEntries = true)
	public Integer deleteById(Integer id) {
		Optional<MasterPermission> existingMasterPermissionRecord = masterPermissionRepository.getById(id);
		if (existingMasterPermissionRecord.isPresent()) {
			masterPermissionRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	@Cacheable(value = "master-permission")
	public List<MasterPermission> getAll() {
		return masterPermissionRepository.findAll();
	}

	public List<MasterPermission> saveAll(List<MasterPermission> monitoringPointSensors) {
		return masterPermissionRepository.saveAll(monitoringPointSensors);
	}

}