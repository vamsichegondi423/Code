package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.StoreUsers;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.StoreUsersRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StoreUsersService {

	@Autowired
	private StoreUsersRepository storeUsersRepository;

	public StoreUsers getById(Long id) throws CustomException {
		try {
			Optional<StoreUsers> storeUsersOptional = storeUsersRepository.getById(id);
			if (storeUsersOptional.isPresent()) {
				return storeUsersOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public StoreUsers save(StoreUsers storeUsers) throws CustomException {
		try {
			if (storeUsers.getId() != null && storeUsers.getId() > 0) {
				Optional<StoreUsers> existingStoreUsersRecord = storeUsersRepository.getById(storeUsers.getId());
				if (existingStoreUsersRecord.isPresent()) {
					return storeUsersRepository.save(storeUsers);
				}
			} else {
				storeUsers = storeUsersRepository.save(storeUsers);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return storeUsers;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<StoreUsers> existingStoreUsersRecord = storeUsersRepository.getById(id);
			if (existingStoreUsersRecord.isPresent()) {
				storeUsersRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<StoreUsers> getAll() {
		try {
			return storeUsersRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public List<StoreUsers> getByUserId(Long userId) {
		return storeUsersRepository.getByUserId(userId);
	}
}