package com.dipl.evin2.util;

public class Constants {

	private Constants() {

	}
	
	public static final String MAX_STOCK_COLOR = "#C2E4F3";
	public static final String MAX_STOCK_BORDER_COLOR = "#C2E4F3";
	public static final String MAX_STOCK_BACKGROUND_COLOR = "#C2E4F3";
	public static final String MIN_STOCK_COLOR = "#ead03e";
	public static final String MIN_STOCK_BORDER_COLOR = "#ead03e";
	public static final String MIN_STOCK_BACKGROUND_COLOR = "#ead03e";
	public static final String STOCK_OUT_COLOR = "#e44949";
	public static final String STOCK_OUT_BORDER_COLOR = "#e44949";
	public static final String STOCK_OUT_BACKGROUND_COLOR = "#e44949";

	public static final String CHART_NORMAL_STOCK_BACKGROUND_COLOR = "#1aaf5d";
	public static final String CHART_ZERO_STOCK_BACKGROUND_COLOR = "#d9534f";
	public static final String CHART_MIN_STOCK_BACKGROUND_COLOR = "#fad42e";
	public static final String CHART_MAX_STOCK_BACKGROUND_COLOR = "#00c0ef";

	public static final String DATE_FORMATE = "yyyy-MMM-dd";
	
	
	public static Integer ASSET_OWNER_USER_ROLE = 4;
	
	public static Integer ASSET_MAINTAINER_USER_ROLE = 5;
	
	public static Integer ASSET_TYPE_WALK_IN_COOLER = 4;	
	public static Integer ASSET_TYPE_WALK_IN_FREEZER = 5;
	public static Integer ASSET_TYPE_RADIANT_WARMER = 6;	
	public static Integer ASSET_TYPE_TEMPERATURE_LOGGER = 1;
	public static Integer ASSET_TYPE_DEEP_FREEZER = 3;
	public static Integer ASSET_TYPE_ILR = 5;
	
	
	public static final Integer PRODUCT_BADGE_TYPE = 1;
	public static final Integer STORE_BADGE_TYPE = 2;
	public static final Integer USER_BADGE_TYPE = 3;
	public static final Integer ORDER_BADGE_TYPE = 4;
	public static final Integer MANUFACTURER_BADGE_TYPE = 5;
	public static final Integer ROUTE_BADGE_TYPE = 6;
	
	public static final Integer TAGS_CONFIG_TYPE_ID = 7;
	
	public static final Integer OPERATOR_ROLE = 1;
	public static final Integer MANAGER_ROLE = 2;
	public static final Integer ADMINISTRATOR_ROLE = 3;
	public static final Integer OWNER_ROLE = 4;
	
    public static final String booking = "Booking Reports";	
	
	public static final String shipment = "Shipment Reports";
	
	public static final String stock_deviannt = "Stock Deviant Reports";
	
	public static final String transaction = "Transaction Reports";	
	
	public static final String stock_report = "Stock Reports";	
	
	public static final String stock_report_by_store = "Stock Reports By Store";	
	
}
