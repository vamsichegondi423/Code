package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.dipl.evin2.dto.BatchDetailsDTO;
import com.dipl.evin2.entity.IcatalogueBatch;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.IcatalogueBatchRepository;
import com.dipl.evin2.util.JdbcTemplateHelper;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class IcatalogueBatchService {

	@Autowired
	private IcatalogueBatchRepository icatalogueBatchRepository;

	@Autowired
	private JdbcTemplateHelper jdbcTemplateHelper;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public IcatalogueBatch getById(Long id) throws CustomException {
		try {
			Optional<IcatalogueBatch> icatalogueBatchOptional = icatalogueBatchRepository.getById(id);
			if (icatalogueBatchOptional.isPresent()) {
				return icatalogueBatchOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public IcatalogueBatch save(IcatalogueBatch icatalogueBatch) throws CustomException {
		try {
			if (icatalogueBatch.getId() != null && icatalogueBatch.getId() > 0) {
				Optional<IcatalogueBatch> existingIcatalogueBatchRecord = icatalogueBatchRepository
						.getById(icatalogueBatch.getId());
				if (existingIcatalogueBatchRecord.isPresent()) {
					return icatalogueBatchRepository.save(icatalogueBatch);
				}
			} else {
				icatalogueBatch = icatalogueBatchRepository.save(icatalogueBatch);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return icatalogueBatch;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<IcatalogueBatch> existingIcatalogueBatchRecord = icatalogueBatchRepository.getById(id);
			if (existingIcatalogueBatchRecord.isPresent()) {
				icatalogueBatchRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<IcatalogueBatch> getAll() {
		try {
			return icatalogueBatchRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public ResponseBean getBatchData(String batchNo, Integer producerId, Long productId) throws Exception {
		List<BatchDetailsDTO> batchDetailsDTOs = new ArrayList<BatchDetailsDTO>();
		String query = "select p.id as productId,p.name as productName ,icb.batch_no as batchNo ,icb.expiry_date as expiryDate ,pr.id as producerId,pr.name as producerName,icb.manufactured_date as manufacturedDate "
				+ " from icatalogue_batch icb "
				+ " join icatalogue ic on ic.id = icb.icatalogue_id and ic.is_deleted=false "
				+ " join product p on  p.id = ic.product_id and p.is_deleted = false "
				+ " join producer pr on pr.id = icb.producer_id where icb.batch_no ='" + batchNo
				+ "' and icb.producer_id =" + producerId + "" + " and ic.product_id =" + productId
				+ "  and icb.is_deleted = false order by icb.created_on desc limit 1";
		try {
			batchDetailsDTOs = jdbcTemplateHelper.getResults(query, BatchDetailsDTO.class);
			if (batchDetailsDTOs.isEmpty()) {
				BatchDetailsDTO batchDetailsDTO = BatchDetailsDTO.builder().batchNo(null).expiryDate(null)
						.manufacturedDate(null).producerId(null).producerName(null).productId(null).productName(null)
						.build();
				return ResponseBean.builder().data(batchDetailsDTO).message("no data found").returnCode(1)
						.status(HttpStatus.OK).build();
			}
		} catch (Exception e) {
			log.info("Exception occured while fetching batch details", e);
			return ResponseBean.builder().data(null).message("something went wrong").returnCode(0)
					.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
		return ResponseBean.builder().data(batchDetailsDTOs.iterator().next()).message("Data fetched successfully")
				.returnCode(1).status(HttpStatus.OK).build();
	}

	public ResponseBean getBatchDataByProductIds(Long StoreId, Long pranthId, List<Long> productIds) throws Exception {
		StringBuilder builder = new StringBuilder();
		builder.append(
				"select icb.product_id as productId,p.name as productName,icb.batch_no as batchNo, icb.expiry_date as expiryDate,  icb.producer_id as producerId, icb.manufactured_date from icatalogue_batch icb"
						+ " join icatalogue ic on ic.id=icb.icatalogue_id\n"
						+ "join  product p on icb.product_id=p.id \n"
						+ " join  producer pr on pr.id = icb.producer_id \n"
						+ " where p.is_deleted=false and pr.is_deleted=false and icb.is_deleted=false and  ic.is_deleted=false  and  icb.product_id in("
						+ StringUtils.join(productIds, ",") + ") and ic.store_id in (" + StoreId + ")");
		try {
			List<BatchDetailsDTO> batchDetailsDTOs = jdbcTemplateHelper.getResults(builder.toString(),
					BatchDetailsDTO.class);
			if (!batchDetailsDTOs.isEmpty()) {
				return ResponseBean.builder().data(batchDetailsDTOs).message("Data fetched successfully").returnCode(1)
						.status(HttpStatus.OK).build();
			}
		} catch (Exception e) {
			log.info("Exception occured while fetching batch details", e);
			return ResponseBean.builder().data(null).message("something went wrong").returnCode(0)
					.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
		return ResponseBean.builder().data(null).message("data not found").returnCode(1).status(HttpStatus.OK).build();

	}

}