package com.dipl.evin2.mongo.services;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.ReportEmailLogs;
import com.dipl.evin2.mongo.repository.ReportsEmailLogsRepository;
import com.dipl.evin2.util.ResponseBean;

@Service
public class ReportEmailLogsService {

	@Autowired
	private ReportsEmailLogsRepository reportsEmailLogsRepository;

	private static final Logger LOGGER = LoggerFactory.getLogger(ReportEmailLogsService.class);

	public ResponseBean getReportLogs(String url, String email, String userid, String fileType, String fileName,
			String fileSystemPath) {

		ResponseBean responseBean = new ResponseBean();

		try {
			ReportEmailLogs reportEmailLog = new ReportEmailLogs();
			reportEmailLog.setUserId(userid);
			reportEmailLog.setEmail(email);
			reportEmailLog.setUrl(url);
			reportEmailLog.setCreatedOn(new Date());
			reportEmailLog.setUpdateddOn(new Date());
			reportEmailLog.setFileType(fileType);
			reportEmailLog.setFileName(fileName);
			reportEmailLog.setFileSystemPath(fileSystemPath);

			ReportEmailLogs logs = reportsEmailLogsRepository.save(reportEmailLog);

			responseBean.setData(logs);

			responseBean.setMessage("Success");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			LOGGER.error("error while saving report email logs" + e.getCause());
			// TODO Auto-generated catch block
			e.printStackTrace();
			responseBean.setMessage("failed");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.FORBIDDEN);
		}

		return responseBean;

	}
}