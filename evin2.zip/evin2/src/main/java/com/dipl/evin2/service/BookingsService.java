package com.dipl.evin2.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dipl.evin2.controller.BookingsController.BookingByFilterDetails;
import com.dipl.evin2.controller.BookingsController.BookingsByFilterPayload;
import com.dipl.evin2.controller.BookingsController.BookingsFilterDTO;
import com.dipl.evin2.controller.BookingsController.RecmndQtyDTO;
import com.dipl.evin2.controller.BookingsController.UpdateBookingModel;
import com.dipl.evin2.controller.BookingsController.UpdateOrderProductModel;
import com.dipl.evin2.dto.BatchProductDTO;
import com.dipl.evin2.dto.BookingDetailDTO;
import com.dipl.evin2.dto.BookingItemTooltipDTO;
import com.dipl.evin2.dto.RcmndQutyDTO;
import com.dipl.evin2.dto.StockDetailsDTO;
import com.dipl.evin2.dto.UserCommentsDTO;
import com.dipl.evin2.entity.BookingBadge;
import com.dipl.evin2.entity.BookingItemBatch;
import com.dipl.evin2.entity.BookingItemPranth;
import com.dipl.evin2.entity.BookingItemProductBadge;
import com.dipl.evin2.entity.BookingItems;
import com.dipl.evin2.entity.BookingStoreBadge;
import com.dipl.evin2.entity.BookingTracking;
import com.dipl.evin2.entity.Bookings;
import com.dipl.evin2.entity.Bookings.BookingProducts;
import com.dipl.evin2.entity.Bookings.ProductBooking;
import com.dipl.evin2.entity.Cargo;
import com.dipl.evin2.entity.CargoItem;
import com.dipl.evin2.entity.CargoItemBatch;
import com.dipl.evin2.entity.Icatalogue;
import com.dipl.evin2.entity.IcatalogueBatch;
import com.dipl.evin2.entity.Product;
import com.dipl.evin2.entity.ProductBadge;
import com.dipl.evin2.entity.StoreBadge;
import com.dipl.evin2.entity.SystemConfiguration;
import com.dipl.evin2.entity.UserComments;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.jackson.DispatchOrderModel;
import com.dipl.evin2.jackson.DispatchOrderModel.ProductBatch;
import com.dipl.evin2.jackson.DispatchOrderModel.Products;
import com.dipl.evin2.model.BookingInvoiceModel;
import com.dipl.evin2.model.BookingInvoiceModel.BookingInvoiceItemBatches;
import com.dipl.evin2.model.BookingInvoiceModel.BookingInvoiceItems;
import com.dipl.evin2.model.BookingInvoiceModel.Parameters;
import com.dipl.evin2.model.UpdateOrderModel;
import com.dipl.evin2.repository.BookingBadgeRepository;
import com.dipl.evin2.repository.BookingItemBatchRepository;
import com.dipl.evin2.repository.BookingItemPranthRepository;
import com.dipl.evin2.repository.BookingItemProductBadgeRepository;
import com.dipl.evin2.repository.BookingItemsRepository;
import com.dipl.evin2.repository.BookingStoreBadgeRepository;
import com.dipl.evin2.repository.BookingTrackingRepository;
import com.dipl.evin2.repository.BookingsRepository;
import com.dipl.evin2.repository.CargoItemBatchRepository;
import com.dipl.evin2.repository.CargoItemRepository;
import com.dipl.evin2.repository.CargoRepository;
import com.dipl.evin2.repository.IcatalogueBatchRepository;
import com.dipl.evin2.repository.IcatalogueRepository;
import com.dipl.evin2.repository.ProductBadgeRepository;
import com.dipl.evin2.repository.ProductRepository;
import com.dipl.evin2.repository.StoreBadgeRepository;
import com.dipl.evin2.repository.SystemConfigurationRepository;
import com.dipl.evin2.repository.UserCommentsRepository;
import com.dipl.evin2.service.RolePermissionConfigurationService.RolePermissionConfigurationModel;
import com.dipl.evin2.util.KafkaProducer;
import com.dipl.evin2.util.ResponseBean;
import com.dipl.evin2.util.Status;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BookingsService {

	@Autowired
	private BookingsRepository bookingsRepository;

	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@Autowired
	private UsersService usersService;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private BookingItemsRepository bookingItemsRepository;

	@Autowired
	private BookingItemPranthRepository bookingItemPranthRepository;

	@Autowired
	private BookingItemProductBadgeRepository bookingItemProductBadgeRepository;

	@Autowired
	private ProductBadgeRepository productBadgeRepository;

	@Autowired
	private StoreBadgeRepository storeBadgeRepository;

	@Autowired
	private BookingBadgeRepository bookingBadgeRepository;

	@Autowired
	private BookingStoreBadgeRepository bookingStoreBadgeRepository;

	@Autowired
	private BookingItemBatchRepository bookingItemBatchRepository;

	@Autowired
	private BookingTrackingRepository bookingTrackingRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private IcatalogueBatchRepository icatalogueBatchRepository;
	@Autowired
	private CargoRepository cargoRepository;
	@Autowired
	private CargoItemRepository cargoItemRepository;
	@Autowired
	private IcatalogueRepository icatalogueRepository;
	@Autowired
	private CargoItemBatchRepository cargoItemBatchRepository;
	@Autowired
	private UserCommentsRepository userCommentsRepository;

	@Autowired
	private KafkaProducer kafkaProducer;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private BadgeService badgeService;

	@Autowired
	private SystemConfigurationRepository systemConfigurationRepository;

	@Value("${BASE_URL}")
	private String baseUrl;

	@Autowired
	private RolePermissionConfigurationService rolePermissionConfigurationService;

	public Bookings getById(Long id) throws CustomException {
		try {
			Optional<Bookings> bookingsOptional = bookingsRepository.getById(id);
			if (bookingsOptional.isPresent()) {
				return bookingsOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}
	
/*	public Bookings getBystatusId(int status_id) throws CustomException {
		try {
			Optional<Bookings> bookingsOptional = bookingsRepository.getBystatusId(status_id);
			if (bookingsOptional.isPresent()) {
				return bookingsOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}*/
	
	public List<Map<String,Object>> getBystatusId(int status_id,Pageable pageable) throws CustomException {
		try {
		
			List<Map<String, Object>> bookingsList = null;

			StringBuilder builder = new StringBuilder();
			
			builder.append("select * from bookings where status_id = "+status_id+" and is_deleted = false");
			
			builder.append("  LIMIT " + pageable.getPageSize() + " OFFSET "
					+ pageable.getOffset());
			
			
				bookingsList  =  jdbcTemplate.queryForList(builder.toString());
				return bookingsList;
			
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}
	
	

	public Bookings save(Bookings bookings) throws CustomException {
		try {
			if (bookings.getId() != null && bookings.getId() > 0) {
				Optional<Bookings> existingBookingsRecord = bookingsRepository.getById(bookings.getId());
				if (existingBookingsRecord.isPresent()) {
					return bookingsRepository.save(bookings);
				}
			} else {
				bookings = bookingsRepository.save(bookings);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return bookings;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<Bookings> existingBookingsRecord = bookingsRepository.getById(id);
			if (existingBookingsRecord.isPresent()) {
				bookingsRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<Bookings> getAll() {
		try {
			return bookingsRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public BookingByFilterDetails getBookingsByFilter(BookingsByFilterPayload bookingsByFilterPayload,
			Pageable pageable, Long userId, List<Long> offsetKioskIds, Long pranthId) {
		BookingByFilterDetails bookingFilterDetails = null;
		try {
			Set<Long> consolidatedDomainIds = pranthHierarchyService
					.getConsolidatedPranthIds(bookingsByFilterPayload.getPranthId());
			String queryForConsolidatedDomainIds = pranthHierarchyService.buildQuery(consolidatedDomainIds);
			StringBuilder builder = new StringBuilder();
			Long count = buildQueryForFilterParams(bookingsByFilterPayload, builder, queryForConsolidatedDomainIds,
					pageable, userId, offsetKioskIds, pranthId);
			if (count > 0) {
				String query = builder.toString();
				log.info(query);
				List<BookingsFilterDTO> bookingFilterDTOs = jdbcTemplate.query(query,
						new RowMapper<BookingsFilterDTO>() {

							@Override
							public BookingsFilterDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
								return BookingsFilterDTO.builder().createdOn(rs.getTimestamp("created_on"))
										.pranthId(rs.getLong("pranth_id"))
										.issuingStoreId(rs.getLong("issuing_store_id"))
										.issuingStoreLocation(rs.getString("issuing_store_location"))
										.issuingStoreName(rs.getString("issuing_store_name"))
										.bookingItemsCount(rs.getLong("items_count"))
										.bookingId(rs.getLong("booking_id")).bookingBadge(rs.getString("booking_badge"))
										.bookingBadgeId(rs.getInt("booking_badge_id")).status(rs.getString("status"))
										.statusId(rs.getLong("status_id"))
										.recevingStoreId(rs.getLong("receiving_store_id"))
										.recevingStoreLocation(rs.getString("receiving_store_location"))
										.recevingStoreName(rs.getString("receiving_store_name"))
										.createdBy(rs.getString("created_by")).sourceType(rs.getInt("source_type"))
										.indentTypeId(rs.getInt("indent_type_id")).build();
							}
						});
				return BookingByFilterDetails.builder().bookingFilterDTOs(bookingFilterDTOs).totalRecordsCount(count)
						.build();
			} else {
				return bookingFilterDetails;
			}
		} catch (Exception e) {
			log.error("Exception occured while performing the indent fetching..", e.getCause());
			e.printStackTrace();
		}
		return bookingFilterDetails;
	}

	public List<Map<String, Object>> getBookingsDataByQuery(BookingsByFilterPayload bookingsByFilterPayload,
			StringBuilder builder, String queryForConsolidatedDomainIds, Pageable pageable, Long userId,
			List<Long> offsetKioskIds, Long pranthId) throws JsonMappingException, JsonProcessingException {

		List<Map<String, Object>> bookingsList = null;

		Users users = usersService.getById(userId);
		RolePermissionConfigurationModel configurationModel = rolePermissionConfigurationService
				.getPermissionCodeValue("mnstomtbhfov30", users.getRoleId(), bookingsByFilterPayload.getPranthId());

		builder.append(
				"select b.pranth_id,b.id as booking_id,b.items_count,ms.id as status_id,ms.name as status,b.receiving_store_id,b.order_type_id as indent_type_id,rs.name as receiving_store_name, "
						+ "concat(rs.city,', ',rd.name,', ',rst.name,', ',rc.name) as receiving_store_location,u.user_id as created_by,b.created_on,b.issuing_store_id, "
						+ "s.name as issuing_store_name,concat(s.city,', ',id.name,', ',ist.name,', ',ic.name) as issuing_store_location,string_agg(bd.name,',') as booking_badge,bb.badge_id as booking_badge_id ,b.source_type  "
						+ " from bookings b " + "inner join booking_items bi on bi.booking_id = b.id "
						+ "left join master_status ms on b.status_id=ms.id "
						+ "left join store rs on b.receiving_store_id=rs.id "
						+ "left join master_district rd on rs.district_id=rd.id "
						+ "left join master_state rst on rs.state_id=rst.id "
						+ "left join master_country rc on rc.id=rs.country_id "
						+ "left join users u on b.created_by=u.id " + "left join store s on b.issuing_store_id=s.id "
						+ "left join master_district id on s.district_id=id.id "
						+ "left join master_state ist on s.state_id=ist.id "
						+ "left join master_country ic on ic.id=s.country_id "
						+ "left join booking_badge bb on b.id=bb.booking_id "
						+ "left join badge bd on bb.badge_id=bd.id ");
		if (bookingsByFilterPayload.getStoreId() != null) {
			StoreBadge storeBadge = storeBadgeRepository.getStoreBadgeDetails(bookingsByFilterPayload.getStoreId());
			if (storeBadge.getBadgeId().equals(57) && bookingsByFilterPayload.getIndentTypeId().equals(3)) {
				builder.append(" where s.id = " + bookingsByFilterPayload.getStoreId() + " ");
				builder.append(" and b.order_type_id = " + bookingsByFilterPayload.getIndentTypeId() + " ");
			} else if (bookingsByFilterPayload.getIndentTypeId().equals(3)) {
				builder.append(" where rs.id = " + bookingsByFilterPayload.getStoreId() + " ");
				builder.append(" and b.order_type_id = " + bookingsByFilterPayload.getIndentTypeId() + " ");
			} else {
				if (bookingsByFilterPayload.getIndentTypeId().equals(1)) {
					builder.append(" where s.id = " + bookingsByFilterPayload.getStoreId() + " ");
				} else if (bookingsByFilterPayload.getIndentTypeId().equals(2)) {
					builder.append(" where rs.id = " + bookingsByFilterPayload.getStoreId() + " ");
				}
			}
		} else if (bookingsByFilterPayload.getStoreId() == null) {
			builder.append(" where b.pranth_id in " + queryForConsolidatedDomainIds);
			builder.append(" and b.order_type_id = " + bookingsByFilterPayload.getIndentTypeId() + " ");
		}
		if (offsetKioskIds != null && !offsetKioskIds.isEmpty()) {
			builder.append(" and (s.id in ( " + StringUtils.join(offsetKioskIds, " ,") + "  ) or rs.id in ( "
					+ StringUtils.join(offsetKioskIds, " ,") + "  ))");
		}
		if (bookingsByFilterPayload.getStatus() != null && !bookingsByFilterPayload.getStatus().isEmpty()) {
			builder.append(" and ms.name = '" + bookingsByFilterPayload.getStatus() + "'");
		}
		if (bookingsByFilterPayload.getFromDate() != null && bookingsByFilterPayload.getToDate() != null) {
			SimpleDateFormat formate = new SimpleDateFormat("yyyy-MM-dd");
			builder.append(
					"and cast(b.created_on as date) between '" + formate.format(bookingsByFilterPayload.getFromDate())
							+ "'  and '" + formate.format(bookingsByFilterPayload.getToDate()) + "'");
		} else {
			if (bookingsByFilterPayload.getFromDate() != null) {
				SimpleDateFormat formate = new SimpleDateFormat("yyyy-MM-dd");
				builder.append(" and cast(b.created_on as date) >= '"
						+ formate.format(bookingsByFilterPayload.getFromDate()) + "'");
			}
			if (bookingsByFilterPayload.getToDate() != null) {
				SimpleDateFormat formate = new SimpleDateFormat("yyyy-MM-dd");
				builder.append(" and cast(b.created_on as date) <= '"
						+ formate.format(bookingsByFilterPayload.getToDate()) + "'");
			}
		}
		if (bookingsByFilterPayload.getIssueReferenceId() != null
				&& !bookingsByFilterPayload.getIssueReferenceId().isEmpty()) {
			builder.append(" and b.order_reference_no = " + bookingsByFilterPayload.getIssueReferenceId() + "");
		}
		if (bookingsByFilterPayload.getReceiptReferenceId() != null
				&& !bookingsByFilterPayload.getReceiptReferenceId().isEmpty()) {
			builder.append(" and b.transfer_reference_no = " + bookingsByFilterPayload.getReceiptReferenceId() + "");
		}
		if (bookingsByFilterPayload.getBookingId() != null) {
			builder.append(" and b.id = " + bookingsByFilterPayload.getBookingId() + " ");
		}
		if (bookingsByFilterPayload.getBookingBadgeId() != null) {
			builder.append(" and bd.id = " + bookingsByFilterPayload.getBookingBadgeId() + " ");
		}

		List<Integer> materialTagsToHide = getMaterialTagsToHide(configurationModel, pranthId);
		if (materialTagsToHide != null && !materialTagsToHide.isEmpty()) {
			builder.append(
					"  and ( bi.product_id not in (select p.id from product p left join product_badge pb on pb.product_id = p.id left join badge bad on bad.id = pb.badge_id"
							+ " where  bad.name in ( " + StringUtils.join(materialTagsToHide, ",") + ")");
		}
		builder.append(
				"group by b.pranth_id,b.id,b.items_count,ms.id,ms.name,b.receiving_store_id,rs.city,rs.name,bb.badge_id,b.source_type,rd.name,rst.name,rc.name,u.user_id,b.issuing_store_id,s.name,s.city,id.name,ist.name,ic.name order by b.created_on DESC ");
		bookingsList = jdbcTemplate.queryForList(builder.toString());
		return bookingsList;
	}

	private Long buildQueryForFilterParams(BookingsByFilterPayload bookingsByFilterPayload, StringBuilder builder,
			String queryForConsolidatedDomainIds, Pageable pageable, Long userId, List<Long> offsetKioskIds,
			Long pranthId) throws Exception {

		getBookingsDataByQuery(bookingsByFilterPayload, builder, queryForConsolidatedDomainIds, pageable, userId,
				offsetKioskIds, pranthId);
		String query = builder.toString();
		String mainQuery = "SELECT COUNT(*) FROM (" + query + " ) as cnt";

		Long count = jdbcTemplate.queryForObject(mainQuery, Long.class);
		if (count > 0) {
			builder.append(" LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset());
		} else {
			count = 0l;
		}
		return count;
	}

	public List<Integer> getMaterialTagsToHide(RolePermissionConfigurationModel permissionConfigurationModel,
			Long pranthId) throws JsonMappingException, JsonProcessingException {
		List<Integer> materialTagIdsToHide = new ArrayList<Integer>();
		List<Integer> materialTagsToHide = new ArrayList<Integer>();
		if (permissionConfigurationModel != null) {
			JsonElement jsonObject = JsonParser
					.parseString(permissionConfigurationModel.getConfiguredValue().toString());
			JsonObject object = jsonObject.getAsJsonObject();
			if (object != null && !object.get("value").isJsonNull()) {
				JsonArray integers = object.get("value").getAsJsonArray();
				integers.forEach(m -> materialTagIdsToHide.add(m.getAsInt()));
			}
			if (materialTagIdsToHide != null && !materialTagIdsToHide.isEmpty()) {
				materialTagsToHide = badgeService.getAllByIds(materialTagIdsToHide, pranthId);
			}
		}
		return materialTagsToHide;
	}

	public List<Map<String, Object>> getProductsByBookingId(Long bookingId) throws Exception {
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
		try {
			result = bookingsRepository.getProductsByBookingId(bookingId);
			if (result != null) {
				return result;
			}
		} catch (Exception e) {
			log.error("Exception occured in while getting products based on booking id", e.getCause());
			throw new Exception("Exception occured in while getting products based on booking id", e.getCause());
		}
		return null;
	}

	@Builder
	@Data
	public static class BookingProductsDTO {
		private Long orderId;
		private Long materialId;
		private String materialName;
		private Integer ordered;
		private Integer shippedQuantity;
		private Integer fulfilledQuantity;
		private Boolean be;
	}

	public List<BookingDetailDTO> getBookingsByBookingId(Long bookingId) throws Exception {
		List<BookingDetailDTO> bookingDetailDTOs = null;
		try {
			bookingDetailDTOs = bookingsRepository.getBookingsByBookingId(bookingId);
			if (bookingDetailDTOs != null) {
				return bookingDetailDTOs;
			}
		} catch (Exception e) {
			log.error("Exception occured ", e.getCause());
			throw new Exception("Exception occured ", e.getCause());
		}
		return null;
	}

	@Transactional(rollbackOn = Exception.class)
	public ResponseBean createBooking(Bookings bookingsPayload, Long userId, Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer orderType = bookingsPayload.getOrderTypeId();
			Integer statusId = null;
			int configutationTypeId = 4;
			Bookings bookingData = new Bookings();
			Optional<SystemConfiguration> systemConfigurationOptional = systemConfigurationRepository
					.getByConfigutationType(configutationTypeId, pranthId);
			if (orderType.equals(1) && systemConfigurationOptional.isPresent()) {
				if (systemConfigurationOptional.get().getConfigJson().get("general") != null
						&& systemConfigurationOptional.get().getConfigJson().get("general")
								.get("mark_indent_as_confirmed") != null
						&& systemConfigurationOptional.get().getConfigJson().get("general")
								.get("mark_indent_as_confirmed")
								.get("allow_marking_indent_as_confirmed_during_order_creation").booleanValue()) {
					statusId = Status.CONFIRMED.getValue();
					bookingData.setConfirmStartDate(new Date());
					bookingData.setConfirmEndDate(new Date());
					bookingData.setArrivalDate(
							(bookingsPayload.getArrivalDate()) == null ? null : bookingsPayload.getArrivalDate());
				} else {
					statusId = Status.PENDING.getValue();
					bookingData.setReceiptDate(
							bookingsPayload.getReceiptDate() == null ? null : bookingsPayload.getReceiptDate());
				}
				bookingData.setOrderReferenceNo(
						bookingsPayload.getOrderReferenceNo() == null ? null : bookingsPayload.getOrderReferenceNo());
			} else if (orderType.equals(2)) {
				statusId = Status.PENDING.getValue();
				bookingData.setReceiptDate(
						bookingsPayload.getReceiptDate() == null ? null : bookingsPayload.getReceiptDate());
				bookingData.setOrderReferenceNo(
						bookingsPayload.getOrderReferenceNo() == null ? null : bookingsPayload.getOrderReferenceNo());
			}
			bookingData.setIssuingStoreId(bookingsPayload.getIssuingStoreId());
			bookingData.setReceivingStoreId(bookingsPayload.getReceivingStoreId());
			bookingData.setPranthId(bookingsPayload.getPranthId());
			bookingData.setStatusId(statusId);
			bookingData.setOrderTypeId(orderType);
			bookingData.setBadgeId(bookingsPayload.getBadgeId() == null ? null : bookingsPayload.getBadgeId());
			bookingData.setTransferReferenceNo(bookingsPayload.getTransferReferenceNo());
			bookingData.setComments(bookingsPayload.getComments() == null ? null : bookingsPayload.getComments());
			bookingData.setCreatedBy(bookingsPayload.getCreatedBy());
			bookingData.setUpdatedBy(bookingsPayload.getCreatedBy());
			bookingData.setSrcType(bookingsPayload.getSrcType());
			Integer noi = bookingsPayload.getProductBookings().size();
			bookingData.setItemsCount(noi);
			Bookings bookingDta = bookingsRepository.save(bookingData);
			insertDataIntoBookingsTables(bookingsPayload, statusId, bookingDta);
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setData("Order Created Successfully with order ID " + bookingData.getId());
			responseBean.setMessage("Order Created Successfully");

			kafkaProducer.addOrderTopicToKafkaQueue(
					bookingsPayload.getComments() == null ? null : bookingsPayload.getComments(),
					bookingsPayload.getCreatedBy(), bookingDta.getId(), "OPENED CONFIRMED",
					bookingDta.getOrderTypeId());
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		return responseBean;
	}

	@Transactional(rollbackOn = Exception.class)
	public ResponseBean createReleaseBooking(Bookings bookingsPayload) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer orderTypeId = bookingsPayload.getOrderTypeId();
			Integer statusId = null;
			Integer noi = bookingsPayload.getProductBookings().size();
			Bookings bookingData = new Bookings();
			if (orderTypeId.equals(3)) {
				Long storeId = bookingsPayload.getIssuingStoreId();
				StoreBadge issueingStoreBadge = storeBadgeRepository.getStoreBadgeDetails(storeId);
				StoreBadge recvingStoreBadge = storeBadgeRepository
						.getStoreBadgeDetails(bookingsPayload.getReceivingStoreId());

				if ((issueingStoreBadge != null && recvingStoreBadge != null)
						&& (issueingStoreBadge.getBadgeId().equals(57) && recvingStoreBadge.getBadgeId().equals(52))) {
					statusId = Status.PENDING.getValue();
					bookingData.setOrderReferenceNo(bookingsPayload.getOrderReferenceNo() == null ? null
							: bookingsPayload.getOrderReferenceNo());
					bookingData.setReceiptDate(
							bookingsPayload.getReceiptDate() == null ? null : bookingsPayload.getReceiptDate());
					bookingData.setIssuingStoreId(
							bookingsPayload.getIssuingStoreId() == null ? null : bookingsPayload.getIssuingStoreId());
					bookingData.setReceivingStoreId(bookingsPayload.getReceivingStoreId());
					bookingData.setPranthId(bookingsPayload.getPranthId());
					bookingData.setStatusId(statusId);
					bookingData.setOrderTypeId(orderTypeId);
					bookingData.setBadgeId(bookingsPayload.getBadgeId() == null ? null : bookingsPayload.getBadgeId());
					bookingData.setTransferReferenceNo(bookingsPayload.getTransferReferenceNo());
					bookingData
							.setComments(bookingsPayload.getComments() == null ? null : bookingsPayload.getComments());
					bookingData.setCreatedBy(bookingsPayload.getCreatedBy());
					bookingData.setUpdatedBy(bookingsPayload.getCreatedBy());
					bookingData.setSrcType(bookingsPayload.getSrcType());
					bookingData.setItemsCount(noi);
					Bookings bookings = bookingsRepository.save(bookingData);
					insertDataIntoBookingsTables(bookingsPayload, statusId, bookings);
					responseBean.setReturnCode(1);
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setData("Release Indent Created Successfully with Indent ID " + bookingData.getId());
					responseBean.setMessage("Indent Created Successfully ");
					kafkaProducer.addOrderTopicToKafkaQueue(
							bookingsPayload.getComments() == null ? null : bookingsPayload.getComments(),
							bookingsPayload.getCreatedBy(), bookingData.getId(), "OPENED PENDING",
							bookingsPayload.getOrderTypeId());
				} else {
					responseBean.setData(null);
					responseBean.setMessage(
							"We can't create release Indent for this store as this store is NOT belogs to GMSD ");
					responseBean.setReturnCode(1);
					responseBean.setStatus(HttpStatus.OK);
				}
			} else {
				responseBean.setData(null);
				responseBean.setMessage("We cannot create release Indent for this Indent Type ... ");
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Exception occured while performing the GMSD release order.. " + e.getMessage());
			return ResponseBean.builder().data(null)
					.message("Exception occured while performing the GMSD release order.." + e.getMessage())
					.status(HttpStatus.INTERNAL_SERVER_ERROR).returnCode(0).build();
		}
		return responseBean;
	}

	@Transactional(rollbackOn = Exception.class)
	public ResponseBean createTransferBooking(Bookings bookingsPayload) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer orderTypeId = bookingsPayload.getOrderTypeId();
			Integer statusId = null;
			Integer noi = bookingsPayload.getProductBookings().size();
			Bookings bookingData = new Bookings();
			if (orderTypeId.equals(4)) {
				statusId = Status.PENDING.getValue();
				bookingData.setOrderReferenceNo(
						bookingsPayload.getOrderReferenceNo() == null ? null : bookingsPayload.getOrderReferenceNo());
				bookingData.setReceiptDate(
						bookingsPayload.getReceiptDate() == null ? null : bookingsPayload.getReceiptDate());
				bookingData.setIssuingStoreId(
						bookingsPayload.getIssuingStoreId() == null ? null : bookingsPayload.getIssuingStoreId());
				bookingData.setReceivingStoreId(bookingsPayload.getReceivingStoreId());
				bookingData.setPranthId(bookingsPayload.getPranthId());
				bookingData.setStatusId(statusId);
				bookingData.setOrderTypeId(orderTypeId);
				bookingData.setBadgeId(bookingsPayload.getBadgeId() == null ? null : bookingsPayload.getBadgeId());
				bookingData.setTransferReferenceNo(bookingsPayload.getTransferReferenceNo());
				bookingData.setComments(bookingsPayload.getComments() == null ? null : bookingsPayload.getComments());
				bookingData.setCreatedBy(bookingsPayload.getCreatedBy());
				bookingData.setUpdatedBy(bookingsPayload.getCreatedBy());
				bookingData.setSrcType(bookingsPayload.getSrcType());
				bookingData.setItemsCount(noi);
				Bookings bookings = bookingsRepository.save(bookingData);
				insertDataIntoBookingsTables(bookingsPayload, statusId, bookings);
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setData("Transfer Indent Created Successfully with Indent ID " + bookingData.getId());
				responseBean.setMessage("Indent Created Successfully ");
				kafkaProducer.addOrderTopicToKafkaQueue(
						bookingsPayload.getComments() == null ? null : bookingsPayload.getComments(),
						bookingsPayload.getCreatedBy(), bookingData.getId(), "OPENED PENDING",
						bookingsPayload.getOrderTypeId());

			}
		} catch (Exception e) {
			log.error("Exception occured while performing the  transfer order.. " + e.getMessage());
			return ResponseBean.builder().data(null)
					.message("Exception occured while performing the  transfer order.." + e.getMessage())
					.status(HttpStatus.INTERNAL_SERVER_ERROR).returnCode(0).build();
		}
		return responseBean;
	}

	private void insertDataIntoBookingsTables(Bookings bookingsPayload, Integer statusId, Bookings bookingData) {
		if (bookingsPayload.getComments() != null && !bookingsPayload.getComments().isEmpty()) {
			UserComments bookingComments = UserComments.builder().bookingId(bookingData.getId()).cargoId(null)
					.comments(bookingsPayload.getComments()).createdBy(bookingData.getCreatedBy()).createdOn(new Date())
					.entryFrom("Booking").build();
			userCommentsRepository.save(bookingComments);
		}
		if (bookingData != null && bookingsPayload.getBadgeId() != null) {
			BookingBadge bookingBadge = BookingBadge.builder().badgeId(bookingData.getBadgeId())
					.bookingId(bookingData.getId()).build();
			bookingBadge.setCreatedBy(bookingsPayload.getCreatedBy());
			bookingBadge.setUpdatedBy(bookingsPayload.getUpdatedBy());
			bookingBadge = bookingBadgeRepository.save(bookingBadge);
		}
		List<StoreBadge> storeBadge = storeBadgeRepository.findStoreBadgeDetails(bookingData.getReceivingStoreId());
		if (!storeBadge.isEmpty()) {
			storeBadge.forEach(sb -> {
				BookingStoreBadge bookingStoreBadge = null;
				bookingStoreBadge = BookingStoreBadge.builder().storeBadgeId(sb.getId()).bookingId(bookingData.getId())
						.build();
				bookingStoreBadge.setCreatedBy(bookingsPayload.getCreatedBy());
				bookingStoreBadge.setUpdatedBy(bookingsPayload.getUpdatedBy());
				bookingStoreBadge = bookingStoreBadgeRepository.save(bookingStoreBadge);
			});
		}
		BookingTracking bookingTracking = BookingTracking.builder().bookingId(bookingData.getId())
				.pranthId(bookingData.getPranthId()).storeId(bookingData.getIssuingStoreId())
				.statusId(bookingData.getStatusId()).build();
		bookingTracking.setCreatedBy(bookingsPayload.getCreatedBy());
		bookingTracking.setUpdatedBy(bookingsPayload.getUpdatedBy());
		bookingTracking = bookingTrackingRepository.save(bookingTracking);

		for (ProductBooking bookingProduct : bookingsPayload.getProductBookings()) {
			insertRecordIntoBookingItem(bookingData, bookingProduct, statusId);
		}
	}

	private void insertRecordIntoBookingItem(Bookings bookingData, ProductBooking bookingProduct, Integer statusId) {
		BookingItems bookingItems = BookingItems.builder().bookingId(bookingData.getId())
				.originalOrderStock(bookingProduct.getQuantity()).orderedStock(bookingProduct.getQuantity())
				.pranthId(bookingData.getPranthId()).recommendedStock(bookingProduct.getRecommendedQuantity())
				.productId(bookingProduct.getProductId()).statusId(statusId).reason(bookingProduct.getReason())
				.storeId(bookingData.getIssuingStoreId()).quantity(bookingProduct.getQuantity()).allocatedStock(0l)
				.shippedStock(0l).fulfilledStock(0l).build();
		bookingItems.setCreatedBy(bookingData.getCreatedBy());
		bookingItems = bookingItemsRepository.save(bookingItems);
		BookingItemPranth bookingItemPranth = BookingItemPranth.builder().bookingItemId(bookingItems.getId())
				.pranthId(bookingItems.getPranthId()).build();
		bookingItemPranth.setCreatedBy(bookingData.getCreatedBy());
		bookingItemPranthRepository.save(bookingItemPranth);
		ProductBadge productBadge = productBadgeRepository.getProductDetails(bookingItems.getProductId());
		if (productBadge != null) {
			BookingItemProductBadge bookingItemProductBadge = BookingItemProductBadge.builder()
					.bookingItemId(bookingItems.getId()).productBadgeId(productBadge.getId()).build();
			bookingItemProductBadge.setCreatedBy(bookingData.getCreatedBy());
			bookingItemProductBadgeRepository.save(bookingItemProductBadge);
		}
	}

	@Transactional(rollbackOn = Exception.class)
	public ResponseBean updateBookingStatus(UpdateOrderModel updateOrderModel, Long orderId, Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		Boolean flag1 = false;
		Boolean flag2 = true;
		Boolean flag3 = false;
		Boolean flag6 = false;
		Boolean flag7 = true;
		Boolean flag4 = true;
		Boolean flag5 = true;
		try {
			Optional<Bookings> bookingsOptional = bookingsRepository.findById(orderId);
			Bookings order = null;
			if (bookingsOptional.isPresent()) {
				order = bookingsOptional.get();
			}
			if(order != null && order.getStatusId().equals(6)) {
				List<BookingItems> bookingItemsList = bookingItemsRepository.findAllByBookingId(orderId);
				for (BookingItems bookingItem : bookingItemsList) {
					Product optional = productRepository.getProductById(bookingItem.getProductId());
					if (optional.getIsBatchEnabled().equals(false)) {
						BookingItems bitem = bookingItemsRepository.getBookingItemDetailsForBooking(bookingItem.getId());
						if (bitem == null) {
							flag4 = false;
						} else if (bitem != null && bitem.getAllocatedStock() != null && bitem.getAllocatedStock() > 0) {
							flag3 = true;

						} else if (bitem != null && (bitem.getAllocatedStock() == null || bitem.getAllocatedStock() == 0)) {
							flag5 = false;
						}
					} else {
						List<BookingItemBatch> bitemBatch = bookingItemBatchRepository
								.findBookingItemBatchByBkId(bookingItem.getId());
						if (bitemBatch != null && !bitemBatch.isEmpty()) {
							flag1 = true;
						} else {
							flag2 = false;

						}
					}
				}
				for (BookingItems bkitem : bookingItemsList) {
					if (bkitem.getOrderedStock().equals(bkitem.getAllocatedStock())) {
						flag6 = true;
					} else {
						flag7 = false;
					}
				}
				if ((flag6.equals(true) && flag7.equals(true)) || (flag1.equals(false) && flag2.equals(true))
						|| (flag3.equals(false) && flag4.equals(false)) || (flag2.equals(false) && flag5.equals(false))) {
					if ((flag1.equals(true) && flag2.equals(true)) || (flag3.equals(true) && flag4.equals(true))) {
						order.setStatusId(Status.READY_FOR_DISPATCH.getValue());
						order.setComments(updateOrderModel.getComments());
						order.setUpdatedBy(updateOrderModel.getUserId());
						bookingsRepository.save(order);
						if (updateOrderModel.getComments() != null) {
							UserComments bookingComments = UserComments.builder().bookingId(orderId).cargoId(null)
									.comments(updateOrderModel.getComments()).createdBy(order.getCreatedBy())
									.createdOn(new Date()).entryFrom("Booking").build();
							userCommentsRepository.save(bookingComments);
						}
						BookingTracking bookingTracking = BookingTracking.builder().bookingId(order.getId())
								.pranthId(order.getPranthId()).storeId(order.getIssuingStoreId())
								.statusId(order.getStatusId()).build();
						bookingTracking.setCreatedBy(updateOrderModel.getUserId());
						bookingTracking.setUpdatedBy(updateOrderModel.getUserId());
						bookingTracking = bookingTrackingRepository.save(bookingTracking);
						responseBean.setReturnCode(1);
						responseBean.setStatus(HttpStatus.OK);
						responseBean.setData("Materials updated successfully for the Order ID " + orderId);
						responseBean.setMessage("Materials updated successfully..");

						kafkaProducer.addOrderTopicToKafkaQueue(
								updateOrderModel.getComments() == null ? null : updateOrderModel.getComments(),
								updateOrderModel.getUserId(), orderId, "READY FOR DISPATCH", order.getOrderTypeId());

					} else if ((flag1.equals(false) && flag2.equals(false)) || (flag3.equals(false) && flag4.equals(false))
							|| (flag2.equals(false) && flag5.equals(false))
							|| (flag5.equals(false) && flag7.equals(false))) {
						// performing the auto allocation if the user has not done the manual allocation
						int configutationTypeId = 4;
						Optional<SystemConfiguration> systemConfigurationOptional = systemConfigurationRepository
								.getByConfigutationType(configutationTypeId, pranthId);
						if (systemConfigurationOptional.isPresent()) {
							if (systemConfigurationOptional.get().getConfigJson().get("general") != null
									&& systemConfigurationOptional.get().getConfigJson().get("general")
											.get("disable_auto_allocation") != null
									&& !systemConfigurationOptional.get().getConfigJson().get("general")
											.get("disable_auto_allocation").get("make_auto_allocation_disable_on_marking")
											.booleanValue()) {
								Long withOutBatchEnabledStockCount = bookingsRepository
										.getStockCountForwithOutBatchEnabled(orderId);
								withOutBatchEnabledStockCount = withOutBatchEnabledStockCount != null
										? withOutBatchEnabledStockCount
										: 0;
								Long withBatchStockCount = bookingsRepository.getStockCountForwithBatchEnabled(orderId);
								withBatchStockCount = withBatchStockCount != null ? withBatchStockCount : 0;
								Long bookingStockCount = bookingItemsRepository.getOrderStockCount(orderId);
								bookingStockCount = bookingStockCount != null ? bookingStockCount : 0;
								Long totalStockCount = withOutBatchEnabledStockCount + withBatchStockCount;

								if (bookingStockCount <= totalStockCount) {
									if (bookingItemsList != null) {
										for (BookingItems bookingItems : bookingItemsList) {
											Optional<Product> optional = productRepository
													.findById(bookingItems.getProductId());
											Product product = null;
											if (optional.isPresent()) {
												product = optional.get();
											}
											Long quantity = bookingItems.getQuantity();
											if (product.getIsBatchEnabled()) {
												List<IcatalogueBatch> icatalogueBatchList = icatalogueBatchRepository
														.getBatchesByMID(product.getId(), order.getIssuingStoreId());

												for (IcatalogueBatch icatalogueBatch : icatalogueBatchList) {
													Long remainingQuantity = 0L;
													Long batchQuantity = icatalogueBatch.getAvailableStock();

													Long alcStk = icatalogueBatch.getAllocatedStk();
													if (quantity >= batchQuantity) {
														updateBookigItemBatch(bookingItems, icatalogueBatch, batchQuantity);
														quantity = quantity - batchQuantity;
														icatalogueBatch.setQuantity(batchQuantity);
														icatalogueBatch.setAllocatedStk(alcStk + batchQuantity);
														icatalogueBatch.setAvailableStock(0l);
														icatalogueBatch.setTotalStock(alcStk + batchQuantity);
														icatalogueBatch.setInTransitStock(
																icatalogueBatch.getInTransitStock() == null ? 0l
																		: icatalogueBatch.getInTransitStock());
														icatalogueBatch.setUpdatedBy(updateOrderModel.getUserId());
														icatalogueBatchRepository.save(icatalogueBatch);
													} else if (quantity < batchQuantity) {
														updateBookigItemBatch(bookingItems, icatalogueBatch, quantity);
														remainingQuantity = batchQuantity - quantity;
														Long totBatchAlocated = alcStk + quantity;
														icatalogueBatch.setQuantity(quantity);
														icatalogueBatch.setAllocatedStk(alcStk + quantity);
														icatalogueBatch.setAvailableStock(remainingQuantity);
														icatalogueBatch.setTotalStock(remainingQuantity + totBatchAlocated);
														icatalogueBatch.setInTransitStock(
																icatalogueBatch.getInTransitStock() == null ? 0l
																		: icatalogueBatch.getInTransitStock());
														icatalogueBatchRepository.save(icatalogueBatch);
														quantity = 0L;
													}
													if (quantity.equals(0L)) {
														break;
													} else {
														continue;
													}

												}
												updateICatalogueWithStock(updateOrderModel.getUserId(),
														order.getIssuingStoreId(), product.getId());
											} else {
												Icatalogue intr = icatalogueRepository.getInventoryByStoreIdAndProductId(
														order.getIssuingStoreId(), product.getId().longValue());
												Long allocatedStock = 0l;
												Long totalStock = 0l;
												Long currentStock = 0l;
												if (quantity > intr.getCurrentStock()) {
													break;
												} else {
													allocatedStock = intr.getAllocatedStock() + quantity;
													currentStock = intr.getCurrentStock() - quantity;
													totalStock = currentStock + allocatedStock;
												}
												intr.setAllocatedStock(allocatedStock);
												intr.setCurrentStock(currentStock);
												intr.setTotalStock(totalStock);
												intr.setInTransitStock(
														intr.getInTransitStock() == null ? 0 : intr.getInTransitStock());
												intr.setUpdatedBy(updateOrderModel.getUserId());
												intr.setUpdatedOn(new Date());
												icatalogueRepository.save(intr);
											}
											bookingItems.setAllocatedStock(bookingItems.getQuantity());
											bookingItems.setUpdatedOn(new Date());
											bookingItems.setUpdatedBy(updateOrderModel.getUserId());
											bookingItemsRepository.save(bookingItems);
										}
										order.setStatusId(Status.READY_FOR_DISPATCH.getValue());
										order.setComments(updateOrderModel.getComments());
										order.setUpdatedBy(updateOrderModel.getUserId());
										bookingsRepository.save(order);
										if (updateOrderModel.getComments() != null) {
											UserComments bookingComments = UserComments.builder().bookingId(orderId)
													.cargoId(null).comments(updateOrderModel.getComments())
													.createdBy(order.getCreatedBy()).createdOn(new Date())
													.entryFrom("Booking").build();
											userCommentsRepository.save(bookingComments);
										}
										BookingTracking bookingTracking = BookingTracking.builder().bookingId(order.getId())
												.pranthId(order.getPranthId()).storeId(order.getIssuingStoreId())
												.statusId(order.getStatusId()).build();
										bookingTracking.setCreatedBy(updateOrderModel.getUserId());
										bookingTracking.setUpdatedBy(updateOrderModel.getUserId());
										bookingTracking = bookingTrackingRepository.save(bookingTracking);
										responseBean.setReturnCode(1);
										responseBean.setStatus(HttpStatus.OK);
										responseBean.setData("Materials updated successfully for the Order ID " + orderId);
										responseBean.setMessage("Materials updated successfully..");

										kafkaProducer.addOrderTopicToKafkaQueue(
												updateOrderModel.getComments() == null ? null
														: updateOrderModel.getComments(),
												updateOrderModel.getUserId(), orderId, "READY FOR DISPATCH",
												order.getOrderTypeId());

									} else {
										responseBean.setReturnCode(0);
										responseBean.setStatus(HttpStatus.BAD_GATEWAY);
										responseBean.setData("No Order has found for this Order ID" + orderId);
										responseBean.setMessage("No items found for the Order ID");
									}
								} else {
									responseBean.setReturnCode(0);
									responseBean.setStatus(HttpStatus.OK);
									responseBean.setData("Please allocate fully... for the order ID " + orderId);
									responseBean.setMessage("Please allocate Fully");
								}

							} else {
								responseBean.setReturnCode(0);
								responseBean.setStatus(HttpStatus.OK);
								responseBean.setData("Please do manual allocation ..." + orderId);
								responseBean.setMessage("Please do manual allocation");
							}
						}
					} else {
						responseBean.setReturnCode(0);
						responseBean.setStatus(HttpStatus.OK);
						responseBean.setData("Please allocate fully... for the order ID " + orderId);
						responseBean.setMessage("Please allocate Fully");
					}
				} else {
					responseBean.setReturnCode(0);
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setData("Please allocate fully... for the order ID " + orderId);
					responseBean.setMessage("Please allocate Fully");
				}

			} else {
				responseBean.setMessage("Allocation cannot be done for this indent ..");
				responseBean.setData(null);
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setReturnCode(0);
			}
		} catch (Exception e) {
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.BAD_GATEWAY);
			responseBean.setData(null);
			responseBean.setMessage("something went wrong ");
			return responseBean;
		}

		return responseBean;
	}

	private void updateICatalogueWithStock(Long userId, Long IssuingStoreId, Integer productId) {
		Icatalogue intr = icatalogueRepository.getInventoryByStoreIdAndProductId(IssuingStoreId, productId.longValue());
		Long totalStock = intr.getTotalStock();
		Long allocatedStock = icatalogueBatchRepository.getTotalAllocatedStockQuantity(intr.getId(), productId);
		Long diffCurrCount = totalStock - allocatedStock;
		intr.setCurrentStock(diffCurrCount);
		intr.setAllocatedStock(allocatedStock);
		intr.setTotalStock(diffCurrCount + allocatedStock);
		intr.setUpdatedBy(userId);
		intr.setUpdatedOn(new Date());
		icatalogueRepository.save(intr);

	}

	private void updateBookigItemBatch(BookingItems bookingItems, IcatalogueBatch icatalogueBatch, Long batchQuantity) {
		BookingItemBatch bookingItemBatch = BookingItemBatch.builder().batchExpiryDate(icatalogueBatch.getExpiryDate())
				.batchMfDate(icatalogueBatch.getManufacturedDate()).batchNo(icatalogueBatch.getBatchNo()).producerId(icatalogueBatch.getProducerId())
				.bookingItemId(bookingItems.getId()).quantity(batchQuantity).build();
		bookingItemBatch.setCreatedBy(bookingItems.getCreatedBy());
		bookingItemBatchRepository.save(bookingItemBatch);

	}

	@Transactional(rollbackOn = Exception.class)
	public ResponseBean ManualBookingDispatch(DispatchOrderModel dispatchOrderModel, Long orderId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Boolean flag = true;
			Optional<Bookings> bookings = bookingsRepository.findById(orderId);
			if (bookings.get() != null && bookings.get().getStatusId().equals(6)) {
				List<Products> products = dispatchOrderModel.getProducts();
				if (!products.isEmpty()) {
					for (Products product : products) {
						Optional<Product> prd = productRepository.findById(product.getProductId());
						List<ProductBatch> prodBatches = product.getProductBatches();
						if (prd.get().getIsBatchEnabled()) {
							if (!prodBatches.isEmpty()) {
								// Long allocatedCount = 0L;
								IcatalogueBatch icatBatchData;
								Icatalogue catalogue = icatalogueRepository.getDetailsOfIcatalouge(
										product.getProductId().longValue(), bookings.get().getIssuingStoreId());
								List<BookingItemBatch> bookingItemBatches = bookingItemBatchRepository
										.findBookingItemBatchByBkId(product.getBookingItemId());
								if (!bookingItemBatches.isEmpty()) {
									deleteExistingBookingItemBatches(dispatchOrderModel, product, catalogue,
											bookingItemBatches);
								}
								for (ProductBatch pb : prodBatches) {
									// allocatedCount = allocatedCount + pb.getQuantity();
									BookingItemBatch bib = bookingItemBatchRepository
											.findBookingItemBatchByBkIdAndBatchNo(product.getBookingItemId(),
													pb.getBatchId(),pb.getProducerId());
									if (bib != null) {
										Long updatedQuantity = 0l;
										Long increasedQty = 0l;
										Long reducedQty = 0l;
										Long availableStock = 0l;
										Long allocatedStock = 0l;
										if (bib.getQuantity() < pb.getQuantity()) {
											increasedQty = pb.getQuantity() - bib.getQuantity();
											updatedQuantity = bib.getQuantity() + increasedQty;
										} else {
											reducedQty = bib.getQuantity();
											updatedQuantity = pb.getQuantity();
										}
										bib.setQuantity(updatedQuantity);
										bib.setCreatedBy(dispatchOrderModel.getUserId());
										bib.setUpdatedBy(dispatchOrderModel.getUserId());
										bookingItemBatchRepository.save(bib);
										icatBatchData = icatalogueBatchRepository.getDetailsOfIcatalougeBatch(
												catalogue.getId(), pb.getBatchId(), product.getProductId(),pb.getProducerId());
										if (increasedQty > 0) {
											availableStock = icatBatchData.getAvailableStock() - increasedQty;
											icatBatchData.setAvailableStock(availableStock);
											allocatedStock = icatBatchData.getAllocatedStk() + increasedQty;
											icatBatchData.setAllocatedStk(allocatedStock);
										} else if (reducedQty > 0) {
											Long decreasedValue = 0l;
											decreasedValue = reducedQty - updatedQuantity;
											availableStock = icatBatchData.getAvailableStock() + decreasedValue;
											icatBatchData.setAvailableStock(availableStock);
											allocatedStock = icatBatchData.getAllocatedStk() - decreasedValue;
											icatBatchData.setAllocatedStk(allocatedStock);
										}
										icatBatchData.setTotalStock(availableStock + allocatedStock);
										icatalogueBatchRepository.save(icatBatchData);

									} else {
										BookingItemBatch	bibatch = BookingItemBatch.builder().batchExpiryDate(pb.getExpiryDate())
												.batchNo(pb.getBatchId()).bookingItemId(product.getBookingItemId())
												.quantity(pb.getQuantity()).batchMfDate(pb.getManufacturedDate()).producerId(pb.getProducerId())
												.build();
										bibatch.setCreatedBy(dispatchOrderModel.getUserId());
										bibatch.setUpdatedBy(dispatchOrderModel.getUserId());
										bookingItemBatchRepository.save(bibatch);
										icatBatchData = icatalogueBatchRepository.getDetailsOfIcatalougeBatch(
												catalogue.getId(), pb.getBatchId(), product.getProductId(),pb.getProducerId());
										if (icatBatchData != null) {
											icatBatchData.setAllocatedStk(
													icatBatchData.getAllocatedStk() + pb.getQuantity());
											icatBatchData.setAvailableStock(
													icatBatchData.getAvailableStock() - pb.getQuantity());
											icatalogueBatchRepository.save(icatBatchData);
										}
									}
								}

								Optional<BookingItems> bi = bookingItemsRepository.findById(product.getBookingItemId());
								Long alkStock = bookingItemBatchRepository.sumOffulfilQuantity(bi.get().getId());
								bi.get().setAllocatedStock(alkStock);
								updateBookingItemWithAlcStk(dispatchOrderModel.getUserId(),
										dispatchOrderModel.getPranthId(), product, bi);
								updateICatalogueWithStock(dispatchOrderModel.getUserId(),
										bookings.get().getIssuingStoreId(), product.getProductId());
							} else {
								continue;
							}
						} else if (product.getAllocatedQuantity() != null
								&& !product.getAllocatedQuantity().equals(0L)) {
							Optional<BookingItems> bi = bookingItemsRepository.findById(product.getBookingItemId());
							if (bi.isPresent()) {

								updateBookingItemsIcatalogueForWithOutBatchMaterials(dispatchOrderModel, bookings,
										product, bi);
							} else {
								log.error("Not found any Indent items with this Indent ..");
								responseBean.setMessage("Not found any booking items with this Indent "
										+ bookings.get().getId() + " .");
								responseBean.setData(null);
								responseBean.setStatus(HttpStatus.BAD_REQUEST);
								responseBean.setReturnCode(0);
								flag = false;
								break;
							}
						} else {
							responseBean.setMessage("Quantity should be more than 0 and field cannot be blank");
							responseBean.setData(null);
							responseBean.setStatus(HttpStatus.BAD_REQUEST);
							responseBean.setReturnCode(0);
							flag = false;
							break;
						}
					}
					if (flag) {
						bookings.get().setStatusId(Status.CONFIRMED.getValue());
						bookingsRepository.save(bookings.get());
						responseBean.setMessage("Order has been updated successfully..");
						responseBean.setData(null);
						responseBean.setStatus(HttpStatus.OK);
						responseBean.setReturnCode(1);

					}
				}
			}else {
				if(bookings.get().getStatusId().equals(1)) {
					responseBean.setMessage("Allocation cannot be done as indent is in cancelled state..");
				}else {
					responseBean.setMessage("please check indent status ..");
				}
				responseBean.setData(null);
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setReturnCode(0);
			}
		} catch (Exception e) {
			log.error("Exceptio occured in the Booking batch item saving " + e.getCause());
			responseBean.setMessage("something went worng ");
			responseBean.setData(null);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setReturnCode(0);
		}
		return responseBean;
	}

	private void deleteExistingBookingItemBatches(DispatchOrderModel dispatchOrderModel, Products product,
			Icatalogue catalogue, List<BookingItemBatch> bookingItemBatches) {
		bookingItemBatches.forEach(bib -> {
			IcatalogueBatch icb = icatalogueBatchRepository.findIcatalogueBatchByBId(
					bookingItemsRepository.findById(product.getBookingItemId()).get().getProductId(), bib.getBatchNo(),
					catalogue.getId());

			icb.setAvailableStock(icb.getAvailableStock() + bib.getQuantity());
			icb.setAllocatedStk(
					icb.getAllocatedStk().equals(0l) ? bib.getQuantity() : icb.getAllocatedStk() - bib.getQuantity());
			bib.setIsDeleted(true);
			bib.setUpdatedBy(dispatchOrderModel.getUserId());
			bookingItemBatchRepository.save(bib);
		});

		StockDetailsDTO stockDto = icatalogueBatchRepository.getTotalAlc_Cur_Total_StockQuantity(catalogue.getId(),
				bookingItemsRepository.findById(product.getBookingItemId()).get().getProductId());

		catalogue.setAllocatedStock(stockDto.getAllocatedStock());
		catalogue.setCurrentStock(stockDto.getAvailableStock());
		catalogue.setTotalStock(stockDto.getTotalStock());
		icatalogueRepository.save(catalogue);
	}

	private void updateBookingItemsIcatalogueForWithOutBatchMaterials(DispatchOrderModel dispatchOrderModel,
			Optional<Bookings> bookings, Products product, Optional<BookingItems> bi) {
		Long increasedQty = 0l;
		Long reducedQty = 0l;
		Long availableStock = 0l;
		Long allocatedStock = 0l;
		Long updatedQuantity = 0l;
		BookingItems bookingItem = bi.get();
		Long firstTimeAllocation = bookingItem.getAllocatedStock() == null ? 0 : bookingItem.getAllocatedStock();
		Long temp = 0l;
		if (firstTimeAllocation.equals(temp)) {
			updatedQuantity = product.getAllocatedQuantity();
		} else if (bookingItem.getAllocatedStock() < product.getAllocatedQuantity()) {
			increasedQty = product.getAllocatedQuantity() - bookingItem.getAllocatedStock();
			updatedQuantity = bookingItem.getAllocatedStock() + increasedQty;
		} else {
			reducedQty = bookingItem.getAllocatedStock() - product.getAllocatedQuantity();
			updatedQuantity = product.getAllocatedQuantity();
		}
		// bookingItem.setQuantity(updatedQuantity);
		bookingItem.setOrderedStock(product.getOrderedQuantity());
		bookingItem.setAllocatedStock(updatedQuantity);
		bookingItem.setCreatedBy(dispatchOrderModel.getUserId());
		bookingItem.setUpdatedBy(dispatchOrderModel.getUserId());
		bookingItem.setPranthId(dispatchOrderModel.getPranthId());
		bookingItemsRepository.save(bookingItem);
		Icatalogue issuingStoreInvntry = icatalogueRepository.getInventoryByStoreIdAndProductId(
				bookings.get().getIssuingStoreId(), product.getProductId().longValue());
		if (firstTimeAllocation.equals(temp)) {
			availableStock = issuingStoreInvntry.getCurrentStock() - updatedQuantity;
			issuingStoreInvntry.setCurrentStock(availableStock);
			allocatedStock = issuingStoreInvntry.getAllocatedStock() + updatedQuantity;
			issuingStoreInvntry.setAllocatedStock(allocatedStock);
		} else if (increasedQty > 0) {
			availableStock = issuingStoreInvntry.getCurrentStock() - increasedQty;
			issuingStoreInvntry.setCurrentStock(availableStock);
			allocatedStock = issuingStoreInvntry.getAllocatedStock() + increasedQty;
			issuingStoreInvntry.setAllocatedStock(allocatedStock);
		} else {
			availableStock = issuingStoreInvntry.getCurrentStock() + reducedQty;
			issuingStoreInvntry.setCurrentStock(availableStock);
			allocatedStock = issuingStoreInvntry.getAllocatedStock() - reducedQty;
			issuingStoreInvntry.setAllocatedStock(allocatedStock);
		}
		issuingStoreInvntry.setTotalStock(availableStock + allocatedStock);
		issuingStoreInvntry.setUpdatedBy(dispatchOrderModel.getUserId());
		icatalogueRepository.save(issuingStoreInvntry);
	}

	private void updateBookingItemWithAlcStk(Long userId, Long pranthId, Products product, Optional<BookingItems> bi) {
		BookingItems bookingItem = bi.get();
		if (bookingItem != null) {
			bookingItem.setOrderedStock(product.getOrderedQuantity());
			bookingItem.setAllocatedStock(bookingItem.getAllocatedStock());
			bookingItem.setUpdatedBy(userId);
			bookingItem.setUpdatedOn(new Date());
			bookingItem.setPranthId(pranthId);
			bookingItemsRepository.save(bookingItem);
		}
	}

	public Long getRcmndQutyByProductId(Long storeId, Long productId) {
		Long rcmndQuty = null;
		try {
			RcmndQutyDTO rcmndQutyDTO = bookingsRepository.getRcmndQutyByPid(storeId, productId);
			Long rcmndQtyAvilableStk = rcmndQutyDTO.getAvailableStk() - rcmndQutyDTO.getExpiredStk();
			Long rcmndQtyIntransitStk = rcmndQtyAvilableStk + rcmndQutyDTO.getInTransitStk();
			rcmndQuty = rcmndQutyDTO.getMaxStock() - rcmndQtyIntransitStk;
			if (rcmndQuty < 0) {
				return rcmndQuty = 0L;
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching recommended Quantity ");
			e.printStackTrace();
		}
		return rcmndQuty;
	}

	public ResponseBean getBatchProductsByBooking(Long bookingId, List<Long> bookingItemIds) {
		return batchMaterial(bookingId, bookingItemIds);
	}

	private ResponseBean batchMaterial(Long bookingId, List<Long> bookingItemIds) {
		ResponseBean responseBean = new ResponseBean();
		Integer status = (Integer) bookingsRepository.getStatusByOrderId(bookingId);
		if (status != null) {
			List<Map<String, Object>> demanditembatches = bookingItemBatchRepository.getBatchMaterial(bookingId,
					bookingItemIds);
			if (demanditembatches != null && !demanditembatches.isEmpty()) {
				responseBean.setData(demanditembatches);
				responseBean.setMessage("products batch fetched successfully");
				responseBean.setStatus(HttpStatus.OK);
			} else {
				responseBean.setMessage("products batch not found");
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setData(null);
			}
		}
		responseBean.setReturnCode(1);
		return responseBean;
	}

	public ResponseBean getBatchProductsByBookingItemId(Long bookingItemId) {
		ResponseBean responseBean = new ResponseBean();
		List<Map<String, Object>> demanditembatches = bookingItemBatchRepository
				.getBatchMaterialByBookingItemId(bookingItemId);
		if (demanditembatches != null && !demanditembatches.isEmpty()) {
			responseBean.setData(demanditembatches);
			responseBean.setMessage("products batch fetched successfully");
			responseBean.setStatus(HttpStatus.OK);
		} else {
			responseBean.setMessage("products batch not found");
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setData(null);
		}
		responseBean.setReturnCode(1);
		return responseBean;
	}

	public ResponseBean updateOrderdQuantity(UpdateOrderProductModel updateOrderProductModel) {
		ResponseBean responseBean = new ResponseBean();
		Boolean flag = false;
		Long bookingId = updateOrderProductModel.getBookingId();
		List<BookingProducts> pblist = updateOrderProductModel.getBookingItems();
		Long allocatedStk = 0L;
		for (BookingProducts pb : pblist) {
			Long quantity = pb.getQuantity();
			BookingItems bkItems = null;
			if (pb.getBookingItemId() > 0) {
				bkItems = bookingItemsRepository.getBookingItemDetailsForBooking(pb.getBookingItemId());
				if (bkItems.getAllocatedStock() == null) {
					allocatedStk = 0L;
				} else {
					allocatedStk = bkItems.getAllocatedStock();
				}
				if (bkItems != null && quantity >= allocatedStk) {
					flag = true;
				} else {
					flag = false;
					break;
				}
			} else {
				flag = true;
			}
		}
		if (flag == true) {
			for (BookingProducts pb : pblist) {
				updateOrInsertBookingItem(updateOrderProductModel, bookingId, pb);
				Long bitemsCount = bookingItemsRepository.getByBookingItemsCountByBid(bookingId);
				Bookings bookings = bookingsRepository.getByBookingId(bookingId);
				bookings.setItemsCount(bitemsCount.intValue());
				bookingsRepository.save(bookings);
			}
			responseBean.setData(null);
			responseBean.setMessage("Ordered Quantity updated successfully");
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);

		} else {
			responseBean.setData(updateOrderProductModel);
			responseBean.setMessage("Ordered quantity cannot be less than or equal to  allocated quantity.");
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		}

		return responseBean;

	}

	private void updateOrInsertBookingItem(UpdateOrderProductModel updateOrderProductModel, Long bookingId,
			BookingProducts pb) {
		if (pb.getBookingItemId() > 0) {
			BookingItems bkItems = bookingItemsRepository.getBookingItemDetailsForBooking(pb.getBookingItemId());
			Long quantity = pb.getQuantity();
			bkItems.setOrderedStock(quantity);
			bkItems.setQuantity(quantity);
			bkItems.setModifiedReason(pb.getModifiedReason());
			bkItems.setIsModified(true);
			bkItems.setUpdatedBy(updateOrderProductModel.getUserId());
			bkItems.setUpdatedOn(updateOrderProductModel.getUpdatedDate());
			bookingItemsRepository.save(bkItems);
		} else {
			BookingItems bkItems1 = BookingItems.builder().orderedStock(pb.getQuantity()).quantity(pb.getQuantity())
					.reason(pb.getReason()).bookingId(updateOrderProductModel.getBookingId())
					.originalOrderStock(pb.getQuantity()).pranthId(updateOrderProductModel.getPranthId())
					.recommendedStock(pb.getRecommendedQuantity()).productId(pb.getProductId()).shippedStock(0l)
					.allocatedStock(0l).fulfilledStock(0l).storeId(updateOrderProductModel.getIssuingStoreId())
					.statusId(6).build();
			bkItems1.setCreatedBy(updateOrderProductModel.getUserId());
			bkItems1.setUpdatedBy(updateOrderProductModel.getUserId());
			bookingItemsRepository.save(bkItems1);
		}

	}

	public ResponseBean updateBookingDetails(UpdateBookingModel updateBookingPayload) {
		ResponseBean responseBean = new ResponseBean();
		Long bookingId = updateBookingPayload.getBookingId();
		Bookings bookings = bookingsRepository.getByBookingId(bookingId);
		if (bookings != null) {
			if (updateBookingPayload.getEstimatedDateOfArvl() != null) {
				bookings.setArrivalDate(updateBookingPayload.getEstimatedDateOfArvl());
			}
			if (updateBookingPayload.getIssuseRefNo() != null) {
				bookings.setOrderReferenceNo(updateBookingPayload.getIssuseRefNo());
			}
			if (updateBookingPayload.getRequiredByDate() != null) {
				bookings.setReceiptDate(updateBookingPayload.getRequiredByDate());
			}
			if (updateBookingPayload.getBookingBadge() != null) {
				bookings.setBadgeId(updateBookingPayload.getBookingBadge());
			}
			bookings.setUpdatedBy(updateBookingPayload.getUserId());
			bookingsRepository.save(bookings);
			if (updateBookingPayload.getComments() != null) {
				UserComments bookingComments = UserComments.builder().bookingId(updateBookingPayload.getBookingId())
						.cargoId(null).comments(updateBookingPayload.getComments())
						.createdBy(updateBookingPayload.getUserId()).createdOn(new Date()).entryFrom("Booking").build();
				userCommentsRepository.save(bookingComments);
			}
			if (updateBookingPayload.getBookingBadge() != null) {
				BookingBadge bookingBadge = bookingBadgeRepository.findBadgeDetailsByBid(bookingId);
				if (bookingBadge != null) {
					bookingBadge.setBadgeId(updateBookingPayload.getBookingBadge());
					bookingBadge.setUpdatedBy(updateBookingPayload.getUserId());
					bookingBadgeRepository.save(bookingBadge);
				} else {
					BookingBadge bkBadge = BookingBadge.builder().badgeId(updateBookingPayload.getBookingBadge())
							.bookingId(updateBookingPayload.getBookingId()).build();
					bkBadge.setCreatedBy(updateBookingPayload.getUserId());
					bkBadge.setUpdatedBy(updateBookingPayload.getUserId());
					bookingBadgeRepository.save(bkBadge);

				}
			}
			responseBean.setData(updateBookingPayload);
			responseBean.setMessage("Order record updated successfully");
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} else {
			responseBean.setData(null);
			responseBean.setMessage("No record found with this booking " + bookingId);
			responseBean.setStatus(HttpStatus.OK);
		}
		return responseBean;
	}

	public List<BatchProductDTO> getAllocateBatchDetailsByBId(Long IssuingStoreId, Long productId) throws Exception {
		List<BatchProductDTO> result = null;
		try {
			Long icatId = bookingsRepository.findAllocateBatchDetailsByBId(IssuingStoreId, productId);
			if (icatId != null) {
				result = icatalogueBatchRepository.findByIcatalougeId(icatId);
				return result;
			}
		} catch (Exception e) {
			log.error("Exception Occured at allocate Batch Details " + e.getMessage());
			throw new Exception("Exception Occured at allocate Batch Details " + e.getMessage());
		}

		return null;
	}

	public List<BookingItemTooltipDTO> getBookingItemTooltip(Long bookingItemId) throws Exception {
		List<BookingItemTooltipDTO> result = null;
		try {
			result = bookingItemsRepository.getBookingItemTooltipDetails(bookingItemId);
			if (result != null) {
				return result;
			}
		} catch (Exception e) {
			log.error("Exception Occured at Booking Item Tooltip Details " + e.getMessage());
			throw new Exception("Exception Occured at Booking Item Tooltip Details " + e.getMessage());
		}
		return null;
	}

	public List<Map<String, Object>> getFulfilledOrderBatchesDetails(Long cargoItemId) throws Exception {
		List<Map<String, Object>> result = null;
		try {
			result = cargoItemBatchRepository.findFulfilledOrderBatchesDetails(cargoItemId);
			if (result != null) {
				return result;
			}
		} catch (Exception e) {
			log.error("Exception Occured at Fulfilled Order Batches Details " + e.getMessage());
			throw new Exception("Exception Occured at Fulfilled Order Batches Details " + e.getMessage());
		}
		return null;
	}

	public UserComments saveUserComments(UserComments userCommentsPayload) throws Exception {
		try {
			UserComments userComments = userCommentsRepository.save(userCommentsPayload);
			if (userComments != null) {
				return userComments;
			}
		} catch (Exception e) {
			log.error("Exception Occured while saving Comments " + e.getMessage());
			throw new Exception("Exception Occured while saving Comments " + e.getMessage());
		}

		return null;
	}

	public List<UserCommentsDTO> getUserComments(String objType, Long objId, Pageable pageable)
			throws RuntimeException {
		List<UserCommentsDTO> userCommentsList = null;
		try {
			if (objType.equals("Booking")) {
				userCommentsList = userCommentsRepository.findUserBookingComments(objId, pageable);
			} else if (objType.equals("Cargo")) {
				userCommentsList = userCommentsRepository.findUserCargoComments(objId, pageable);
			}

		} catch (Exception e) {
			log.error("Exception Occured while saving Comments " + e.getMessage());
			throw new RuntimeException("Exception Occured while saving Comments " + e.getMessage());
		}
		return userCommentsList;
	}

	public ResponseBean generateBookingInvoice(Long bookingId) {
		ResponseBean responseBean = new ResponseBean();

		BookingInvoiceModel bookingInvoiceModel = new BookingInvoiceModel();

		List<Map<String, Object>> invoiceData = bookingsRepository.getInvoiceData(bookingId);
		Bookings bookingStatus =  bookingsRepository.getStatusByBookingId(bookingId);


		if (!invoiceData.isEmpty()) {

			Set<BookingInvoiceItems> invoiceItems = new HashSet<>();

			for (Map<String, Object> invcdata : invoiceData) {
				BookingInvoiceItems bookingInvoiceItem = new BookingInvoiceItems();
				bookingInvoiceModel.setIssuingStoreName(invcdata.get("issuing_store_name") == null ? ""
						: invcdata.get("issuing_store_name").toString());
				bookingInvoiceModel.setIssuingStoreState(invcdata.get("issuing_state_name") == null ? ""
						: invcdata.get("issuing_state_name").toString());
				bookingInvoiceModel.setIssuingStoreDistrict(invcdata.get("issing_store_district") == null ? ""
						: invcdata.get("issing_store_district").toString());
				bookingInvoiceModel.setReceievingStoreName(invcdata.get("receiving_store_name") == null ? ""
						: invcdata.get("receiving_store_name").toString());
				bookingInvoiceModel.setReceievingStoreState(invcdata.get("receiving_state_name") == null ? ""
						: invcdata.get("receiving_state_name").toString());
				bookingInvoiceModel.setReceievingStoreDistrict(invcdata.get("receiving_district_name") == null ? ""
						: invcdata.get("receiving_district_name").toString());
				bookingInvoiceModel.setIssueReference(invcdata.get("order_reference_no") == null ? ""
						: invcdata.get("order_reference_no").toString());
				bookingInvoiceModel.setReceiptReference(invcdata.get("issue_reference_no") == null ? ""
						: invcdata.get("issue_reference_no").toString());
				bookingInvoiceModel.setInvoiceDate(
						invcdata.get("invoice_date") == null ? "" : invcdata.get("invoice_date").toString());
				bookingInvoiceModel.setDateOfSupply(
						invcdata.get("date_of_supply") == null ? null : invcdata.get("date_of_supply").toString());
				if(bookingStatus.getStatusId() != null && bookingStatus.getStatusId() == 2) {
				bookingInvoiceModel.setDateOfReceipt(
						invcdata.get("date_of_receipt") == null ? null : invcdata.get("date_of_receipt").toString());
				}
				bookingInvoiceModel
						.setOrderNo(invcdata.get("booking_id") == null ? "" : invcdata.get("booking_id").toString());

				bookingInvoiceItem
						.setName(invcdata.get("product_name") == null ? "" : invcdata.get("product_name").toString());

				bookingInvoiceItem
						.setQuantity(invcdata.get("quantity") == null ? "" : invcdata.get("quantity").toString());
				bookingInvoiceItem.setRecommended(
						invcdata.get("recommanded_stock") == null ? "" : invcdata.get("recommanded_stock").toString());
				/*
				 * String name = invcdata.get("reason").toString(); Optional<MasterReason> mr =
				 * masterReasonRepository.findById(Integer.parseInt(name)); String reason =
				 * null; if (mr.get() != null) { reason = mr.get().getName(); } else { reason =
				 * name; } bookingInvoiceItem.setRemarks(reason);
				 */
				bookingInvoiceItem
						.setRemarks(invcdata.get("reason") == null ? null : invcdata.get("reason").toString());
				List<BookingInvoiceItemBatches> bookingItemBatches = new ArrayList<BookingInvoiceItemBatches>();
				if (invcdata.get("is_batch_enabled").toString() == "true") {
					Long bookingItemId = Long.parseLong(invcdata.get("booking_item_id").toString());
					List<Map<String, Object>> batchDetails = bookingItemBatchRepository
							.getBatchMaterialByBookingItemId(bookingItemId);
					for (Map<String, Object> details : batchDetails) {
						BookingInvoiceItemBatches biib = new BookingInvoiceItemBatches();
						biib.setBatchId(details.get("batch_no") == null ? "" : details.get("batch_no").toString());
						biib.setExpiryDate(details.get("batch_expiry_date") == null ? ""
								: details.get("batch_expiry_date").toString());
						biib.setQuantity(details.get("quantity") == null ? "" : details.get("quantity").toString());
						biib.setManufacturer(
								details.get("manufacturer") != null ? details.get("manufacturer").toString() : "");
						// add batches into BookingItems
						bookingItemBatches.add(biib);
					}
				}
				// set booking iTEM BATCHES INTO BookingItemModl
				bookingInvoiceItem.setBookingItemBatches(bookingItemBatches);
				// add BookingItems into BookingModel
				invoiceItems.add(bookingInvoiceItem);
			}
			bookingInvoiceModel.setBookingItems(new ArrayList<>(invoiceItems));

		}
		// set Booking Items data into Booking Model
		// return bookingInvoiceModel;

		// booking invoice pdf generate code
		try {
			ObjectMapper mapper = new ObjectMapper();
			ResponseBean response = new ResponseBean();
			Object data;

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			Parameters parameters = new Parameters();
			parameters.setId(1);
			parameters.setFileType("pdf");
			bookingInvoiceModel.setParameters(parameters);
			response.setData(bookingInvoiceModel);
			String json = new Gson().toJson(response);
			log.info("json :" + json);
			HttpEntity<String> requestEntity = new HttpEntity<>(json, headers);
			String bookingInvoiceResponse = restTemplate.postForObject(baseUrl + "jasper/nojwt/generate", requestEntity,
					String.class);
			HashMap<String, Object> responseObj = mapper.readValue(bookingInvoiceResponse, HashMap.class);
			data = responseObj.get("data");
			String invoiceJson = new Gson().toJson(data);
			log.info("invoiceJson:" + invoiceJson);
			HashMap<String, Object> reportResponse = mapper.readValue(invoiceJson, HashMap.class);
			String bookingInvoicePdfGenerationUrl = reportResponse.get("viewPath").toString();
			Map<String, Object> bookinginvoicemap = new HashMap<>();
			bookinginvoicemap.put("downloadurlpath", bookingInvoicePdfGenerationUrl);
			responseBean.setData(bookinginvoicemap);
			responseBean.setMessage("Booking Invoice Generated Successfully");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
			responseBean.setMessage("Booking Invoice Generation failed");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.BAD_REQUEST);
		}
		return responseBean;

	}

	@SuppressWarnings("unused")
	public List<RecmndQtyDTO> getRcmndQutyByStoreId(Long storeId, Long productId) {
		List<RecmndQtyDTO> recmndQtyDTOs = new ArrayList<RecmndQtyDTO>();
		RecmndQtyDTO recmndQtyDTO = null;
		if (storeId != null && productId == null) {
			List<RcmndQutyDTO> rs = bookingsRepository.getRcmndQutyByStoreId(storeId);
			for (RcmndQutyDTO rcmndQutyDTO : rs) {
				recmndQtyDTO = new RecmndQtyDTO();
				Long rs1 = rcmndQutyDTO.getAvailableStk() - rcmndQutyDTO.getExpiredStk();
				Long rs2 = rs1 + rcmndQutyDTO.getInTransitStk();
				Long rs3 = rcmndQutyDTO.getMaxStock() - rs2;
				Long pid = rcmndQutyDTO.getProductId();
				recmndQtyDTO.setProductId(pid);
				if (rs3 < 0) {
					recmndQtyDTO.setRecmndQty(0L);
				} else {
					recmndQtyDTO.setRecmndQty(rs3);
				}
				recmndQtyDTO.setStroreId(rcmndQutyDTO.getStroeId());
				recmndQtyDTOs.add(recmndQtyDTO);
			}
		} else if (storeId != null && productId != null) {
			List<RcmndQutyDTO> rs = bookingsRepository.getRcmndQutyByStoreIdPid(storeId, productId);
			for (RcmndQutyDTO rcmndQutyDTO : rs) {
				recmndQtyDTO = new RecmndQtyDTO();
				Long rs1 = rcmndQutyDTO.getAvailableStk() - rcmndQutyDTO.getExpiredStk();
				Long rs2 = rs1 + rcmndQutyDTO.getInTransitStk();
				Long rs3 = rcmndQutyDTO.getMaxStock() - rs2;
				Long pid = rcmndQutyDTO.getProductId();
				recmndQtyDTO.setProductId(pid);
				if (rs3 < 0) {
					recmndQtyDTO.setRecmndQty(0L);
				} else {
					recmndQtyDTO.setRecmndQty(rs3);
				}
				recmndQtyDTO.setStroreId(rcmndQutyDTO.getStroeId());
				recmndQtyDTOs.add(recmndQtyDTO);
			}
		}
		return recmndQtyDTOs;
	}

	public List<RecmndQtyDTO> getRcmndQutyByStores(List<Long> storeIds) {
		List<RecmndQtyDTO> recmndQtyDTOs = new ArrayList<>();
		RecmndQtyDTO recmndQtyDTO = null;
		if (storeIds != null && !storeIds.isEmpty()) {
			List<RcmndQutyDTO> rs = bookingsRepository.getRcmndQutyByStores(storeIds);
			for (RcmndQutyDTO rcmndQutyDTO : rs) {
				recmndQtyDTO = new RecmndQtyDTO();
				Long rs1 = rcmndQutyDTO.getAvailableStk() - rcmndQutyDTO.getExpiredStk();
				Long rs2 = rs1 + rcmndQutyDTO.getInTransitStk();
				Long rs3 = rcmndQutyDTO.getMaxStock() - rs2;
				Long pid = rcmndQutyDTO.getProductId();
				recmndQtyDTO.setProductId(pid);
				if (rs3 < 0) {
					recmndQtyDTO.setRecmndQty(0L);
				} else {
					recmndQtyDTO.setRecmndQty(rs3);
				}
				recmndQtyDTO.setStroreId(rcmndQutyDTO.getStroeId());
				recmndQtyDTOs.add(recmndQtyDTO);
			}
		}
		return recmndQtyDTOs;
	}

	@Transactional(rollbackOn = Exception.class)
	public ResponseBean cancelOrderService(CancelOrderModel cancelOrderModel) {
		ResponseBean responseBean = new ResponseBean();
		Long bookingId = cancelOrderModel.getBookingId();
		try {
			Optional<Bookings> bookings = bookingsRepository.findById(bookingId);
			Boolean flag = false;
			if (bookings.get() != null) {
				Integer status = bookings.get().getStatusId();

				if (status.equals(4)) {
					String message = makeRecordsAsSoftDeleteByBookingid(bookingId, bookings, true,
							cancelOrderModel.getUserId());
					if (message.equalsIgnoreCase("success")) {
						flag = true;
						responseBean.setStatus(HttpStatus.OK);
						responseBean.setData("Order has been cancelled successfully..");
						responseBean.setMessage("Orde has been cancelled successfully");
						responseBean.setReturnCode(1);
					}
				} else if (status.equals(7)) {
					String biMessage = makeRecordsAsSoftDeleteByBookingid(bookingId, bookings, true,
							cancelOrderModel.getUserId());
					String ciMessage = deleteRecordsInCargobyBookingId(bookingId, bookings,
							cancelOrderModel.getUserId());

					if (biMessage.equalsIgnoreCase("success") && ciMessage.equalsIgnoreCase("success")) {
						flag = true;
						responseBean.setStatus(HttpStatus.OK);
						responseBean.setData("Order has been cancelled successfully..");
						responseBean.setMessage("Orde has been cancelled successfully");
						responseBean.setReturnCode(1);

					}
				} else if (status.equals(1)) {
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setData("Order has already been cancelled." + bookingId);
					responseBean.setMessage("Order has ben cancelled please check the status..");
					responseBean.setReturnCode(1);
					return responseBean;
				} else if (status.equals(6) || status.equals(5) ) {
					List<BookingItems> bookingItemsList = bookingItemsRepository.findAllByBookingId(bookingId);
					if (!bookingItemsList.isEmpty()) {
						Boolean check = false;
						for (BookingItems bi : bookingItemsList) {
							if (bi.getAllocatedStock() != null && bi.getAllocatedStock() >= 0) {
								check = true;
								break;
							}
						}
						if (check) {
							makeRecordsAsSoftDeleteByBookingid(bookingId, bookings, check,
									cancelOrderModel.getUserId());
							flag = true;
						} else {
							makeRecordsAsSoftDeleteByBookingid(bookingId, bookings, false,
									cancelOrderModel.getUserId());
							flag = true;
						}
					} else {
						responseBean.setStatus(HttpStatus.OK);
						responseBean.setData("No Booking Items found for the Booking ID " + bookingId);
						responseBean.setMessage("No Bookings were found.");
						responseBean.setReturnCode(1);
					}

				} else {

					responseBean.setStatus(HttpStatus.OK);
					responseBean.setData("No Booking found for the Booking ID " + bookingId);
					responseBean.setMessage("No Bookings were found.");
					responseBean.setReturnCode(1);

				}
				if (flag) {
					bookings.get().setStatusId(1);
					bookings.get().setUpdatedBy(cancelOrderModel.getUserId());
					bookings.get().setReason(cancelOrderModel.getReason());
					bookingsRepository.save(bookings.get());
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setData("Order has been cancelled successfully..");
					responseBean.setMessage("Orde has been cancelled successfully");
					responseBean.setReturnCode(1);
					// saving booking tracking in the booking tracking table for the updates done on
					// bookings table
					BookingTracking bookingTracking = BookingTracking.builder().bookingId(bookingId)
							.pranthId(bookings.get().getPranthId()).storeId(bookings.get().getIssuingStoreId())
							.statusId(1).build();
					bookingTracking.setCreatedBy(cancelOrderModel.getUserId());
					bookingTracking.setUpdatedBy(cancelOrderModel.getUserId());
					bookingTracking = bookingTrackingRepository.save(bookingTracking);
					if (cancelOrderModel.getComments() != null) {
						UserComments bookingComments = UserComments.builder().bookingId(bookingId).cargoId(null)
								.comments(cancelOrderModel.getComments()).createdBy(cancelOrderModel.getUserId())
								.createdOn(new Date()).entryFrom(cancelOrderModel.getSourcePage()).build();
						userCommentsRepository.save(bookingComments);
					}

					try {
						kafkaProducer.addOrderTopicToKafkaQueue(
								cancelOrderModel.getComments() == null ? null : cancelOrderModel.getComments(),
								cancelOrderModel.getUserId(), bookingId, "CANCELLED", bookings.get().getOrderTypeId());
					} catch (JsonProcessingException e) {
						log.error("EXception occured while performing adding topic in cancel order " + e.getMessage());
						e.printStackTrace();
					}
				} else {
					responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
					responseBean.setData("Order not cancelled");
					responseBean.setMessage("Order not cancelled");
					responseBean.setReturnCode(0);
				}
			}
		} catch (Exception e) {
			log.error("Exception occured while performing in cancel order " + e.getMessage());
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData("Order not cancelled");
			responseBean.setMessage("Order not cancelled");
			responseBean.setReturnCode(0);
			return responseBean;
		}
		return responseBean;
	}

	public ResponseBean reOpenOrder(GenericBookingModel reOpenModel) {
		ResponseBean responseBean = new ResponseBean();
		Long bookingId = reOpenModel.getBookingId();
		try {
			Optional<Bookings> bookings = bookingsRepository.findById(bookingId);
			Boolean flag = true;
			if (bookings.get() != null) {
				if (bookings.get().getStatusId().equals(6)) {
					List<BookingItems> bookingItemsList = bookingItemsRepository.findAllByBookingId(bookingId);
					if (!bookingItemsList.isEmpty()) {
						for (BookingItems bi : bookingItemsList) {
							if (bi.getAllocatedStock() > 0) {
								flag = false;
								break;
							}
						}
					}
				} else if (bookings.get().getStatusId().equals(4) || bookings.get().getStatusId().equals(7)
						|| bookings.get().getStatusId().equals(2) || bookings.get().getStatusId().equals(5)) {
					flag = false;
				}
			}
			if (flag) {
				bookings.get().setStatusId(5);
				bookings.get().setUpdatedBy(reOpenModel.getUserId());
				bookingsRepository.save(bookings.get());
				// saving user comments if comments are not null bcz comments are optional
				if (reOpenModel.getComments() != null) {
					UserComments bookingComments = UserComments.builder().bookingId(bookingId).cargoId(null)
							.comments(reOpenModel.getComments()).createdBy(reOpenModel.getUserId())
							.createdOn(new Date()).build();
					userCommentsRepository.save(bookingComments);
				}
				List<BookingTracking> trackings = bookingTrackingRepository.getStatusByBooking(bookingId);
				trackings.forEach(tracking -> {
					tracking.setIsDeleted(true);
					bookingTrackingRepository.save(tracking);

				});
				// saving logs in booking tracking..
				BookingTracking bookingTracking = BookingTracking.builder().bookingId(bookingId)
						.pranthId(bookings.get().getPranthId()).storeId(bookings.get().getIssuingStoreId()).statusId(5)
						.build();
				bookingTracking.setCreatedBy(reOpenModel.getUserId());
				bookingTracking.setUpdatedBy(reOpenModel.getUserId());
				bookingTracking = bookingTrackingRepository.save(bookingTracking);
				// saving the history information in MogoDB using Kafka Queue
				try {
					kafkaProducer.addOrderTopicToKafkaQueue(
							reOpenModel.getComments() == null ? null : reOpenModel.getComments(),
							reOpenModel.getUserId(), bookingId, "RE-OPENED", bookings.get().getOrderTypeId());
				} catch (JsonProcessingException e) {
					log.error("EXception occured while performing adding topic in cancel order " + e.getMessage());
					e.printStackTrace();
				}
				responseBean.setData("Order Re-opened successfully..");
				responseBean.setReturnCode(1);
				responseBean.setMessage("Order Re-Opened Suceddfully..");
				responseBean.setStatus(HttpStatus.OK);
			} else {
				responseBean.setData("Order can not be Re-opened please check the status..");
				responseBean.setReturnCode(1);
				responseBean.setMessage("Please check the Order Status..");
				responseBean.setStatus(HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("EXception occured while performing adding topic in re- order " + e.getMessage());
			responseBean.setData("Did not perform Re-Open on Order");
			responseBean.setReturnCode(0);
			responseBean.setMessage("Did not perform Re-Open on Order");
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			return responseBean;
		}
		return responseBean;
	}

	private String deleteRecordsInCargobyBookingId(Long bookingId, Optional<Bookings> bookings, Long userId) {
		String message = "";
		try {
			Cargo cargo = cargoRepository.getStatusByCargoId(bookingId);
			List<CargoItem> cargoItemList = cargoItemRepository.findCargoItemsByCargoId(cargo.getId());
			cargoItemList.forEach(ci -> {
				Icatalogue rsIcat = null;
				List<CargoItemBatch> cargoItembatchList = cargoItemBatchRepository
						.findCargoItemBatchDetails(ci.getId());
				if (!cargoItembatchList.isEmpty()) {
					cargoItembatchList.forEach(cib -> {
						cib.setIsDeleted(true);
						cargoItemBatchRepository.save(cib);
					});
				}
				rsIcat = icatalogueRepository.getDetailsOfIcatalouge(Long.valueOf(ci.getProductId()),
						bookings.get().getReceivingStoreId());
				Long stock = ci.getOrderedStock();
				rsIcat.setInTransitStock(rsIcat.getInTransitStock() - stock);
				icatalogueRepository.save(rsIcat);
				ci.setIsDeleted(true);
				ci.setUpdatedBy(userId);
				cargoItemRepository.save(ci);
			});
			cargo.setUpdatedBy(userId);
			cargoRepository.save(cargo);
		} catch (Exception e) {
			log.error("Exception occured while performing the deletion in cargo,CargoItem nd CargoItemBatch..");
			message = "failure";
			e.printStackTrace();
			return message;
		}
		message = "success";
		return message;
	}

	@Transactional(rollbackOn = Exception.class)
	private String makeRecordsAsSoftDeleteByBookingid(Long bookingId, Optional<Bookings> bookings, Boolean status,
			Long userId) {
		String message = "";
		try {
			BookingBadge bookingBadge = bookingBadgeRepository.findBadgeDetailsByBid(bookingId);
			if (bookingBadge != null) {
				bookingBadge.setIsDeleted(true);
				bookingBadgeRepository.save(bookingBadge);
			}
			BookingStoreBadge bookingStoreBadge = bookingStoreBadgeRepository.findByBookingId(bookingId);
			if (bookingStoreBadge != null) {
				bookingStoreBadge.setIsDeleted(true);
				bookingStoreBadgeRepository.save(bookingStoreBadge);
			}
			if (status) {
				deleteBookingItemRecordsByBookingId(bookingId, bookings);
			} else {
				List<BookingItems> bookingItemsList = bookingItemsRepository.findAllByBookingId(bookingId);
				bookingItemsList.forEach(bi -> {
					bi.setIsDeleted(true);
					bi.setUpdatedBy(userId);
					bookingItemsRepository.save(bi);
				});
			}
		} catch (Exception e) {
			log.error("Error while performing the cancel order items " + e.getCause());
			e.printStackTrace();
			message = "failure";

		}
		message = "success";
		return message;
	}

	@Transactional(rollbackOn = Exception.class)
	public ResponseBean confirmBooking(GenericBookingModel confirmBookingModel) {
		ResponseBean responseBean = new ResponseBean();

		try {
			Optional<Bookings> bookings = bookingsRepository.findById(confirmBookingModel.getBookingId());
			Bookings bkng = bookings.get();
			if (bkng != null) {
				if(!bkng.getStatusId().equals(1)) {
					Integer statusId = Status.CONFIRMED.getValue();
					bkng.setStatusId(statusId);
					bkng.setUpdatedBy(confirmBookingModel.getUserId());
					Bookings bs = bookingsRepository.save(bkng);
					kafkaProducer.addOrderTopicToKafkaQueue(
							confirmBookingModel.getComments() == null ? null : confirmBookingModel.getComments(),
									confirmBookingModel.getUserId(), bs.getId(), "CONFIRMED",
									bs.getOrderTypeId());
					BookingTracking bookingTracking = BookingTracking.builder().bookingId(bs.getId())
							.pranthId(bs.getPranthId()).storeId(bs.getIssuingStoreId()).statusId(bs.getStatusId()).build();
					bookingTracking.setCreatedBy(confirmBookingModel.getUserId());
					bookingTracking.setUpdatedBy(confirmBookingModel.getUserId());
					bookingTrackingRepository.save(bookingTracking);
					responseBean.setData("Record updated successfully..");
					responseBean.setMessage("Order has been updated from Pending to Confirmed.");
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setReturnCode(1);
				} else {
					responseBean.setData(null);
					responseBean.setMessage("Order was  cancelled state ..");
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setReturnCode(0);
				}
			} else {
				responseBean.setData("Record Not updated successfully..");
				responseBean.setMessage("Order has not updated from Pending to Confirmed. please try again");
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setReturnCode(1);
			}
		} catch (Exception e) {
			log.error("Exception occured while performing the Indent confirmation..");
			e.printStackTrace();
			responseBean.setData("Record Not updated successfully..");
			responseBean.setMessage("Order has not updated from Pending to Confirmed. please try again");
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setReturnCode(0);
			return responseBean;
		}

		return responseBean;
	}

	private void deleteBookingItemRecordsByBookingId(Long bookingId, Optional<Bookings> bookings) {
		Integer statusId = bookings.get().getStatusId();
		List<BookingItems> bookingItemsList = bookingItemsRepository.findAllByBookingId(bookingId);
		if (!bookingItemsList.isEmpty()) {
			bookingItemsList.forEach(bi -> {
				Icatalogue icatalogue = icatalogueRepository.getDetailsOfIcatalouge(Long.valueOf(bi.getProductId()),
						bookings.get().getIssuingStoreId());
				List<BookingItemBatch> bookingItemBatches = bookingItemBatchRepository
						.findBookingItemBatchByBkId(bi.getId());
				if (!bookingItemBatches.isEmpty()) {
					bookingItemBatches.forEach(bib -> {
						Long batchWiseQuantity = 0L;
						batchWiseQuantity = bib.getQuantity();
						IcatalogueBatch ib = icatalogueBatchRepository.getDetailsOfIcatalougeBatch(icatalogue.getId(),
								bib.getBatchNo(), bi.getProductId(),bib.getProducerId());
						Long ibAllocated = 0L;
						// need to put and operator also why beacause some products don't have allocated
						// stock
						if ((statusId.equals(6) || statusId.equals(4)) && ib.getAllocatedStk() >= batchWiseQuantity) {
							ibAllocated = ib.getAllocatedStk() - batchWiseQuantity;
						} else {
							ibAllocated = ib.getAllocatedStk();
						}
						ib.setAllocatedStk(ibAllocated);
						Long availbleStock = ib.getAvailableStock() + batchWiseQuantity;
						ib.setAvailableStock(availbleStock);
						Long totalStk = ibAllocated + availbleStock;
						ib.setTotalStock(totalStk);
						icatalogueBatchRepository.save(ib);
						bib.setIsDeleted(true);
						bookingItemBatchRepository.save(bib);
					});
					StockDetailsDTO dto = icatalogueBatchRepository
							.getTotalAlc_Cur_Total_StockQuantity(icatalogue.getId(), bi.getProductId());
					icatalogue.setAllocatedStock(dto.getAllocatedStock());
					icatalogue.setCurrentStock(dto.getAvailableStock());
					icatalogue.setTotalStock(dto.getTotalStock());
					icatalogueRepository.save(icatalogue);
				} else if (bi != null && bookingItemBatches.isEmpty()) {
					Long quanty = bi.getAllocatedStock();
					Long icatAllocatedStk = 0L;
					// need to put and operator also why beacause some products don't have allocated
					// stock
					if ((statusId.equals(6) || statusId.equals(4)) && icatalogue.getAllocatedStock() >= quanty) {
						icatAllocatedStk = icatalogue.getAllocatedStock() - quanty;
					} else {
						icatAllocatedStk = icatalogue.getAllocatedStock();
					}
					Long icatCurrentStk = icatalogue.getCurrentStock() + quanty;
					icatalogue.setCurrentStock(icatCurrentStk);
					icatalogue.setAllocatedStock(icatAllocatedStk);
					icatalogue.setTotalStock(icatCurrentStk + icatAllocatedStk);
					icatalogueRepository.save(icatalogue);
				}
				bi.setIsDeleted(true);
				bookingItemsRepository.save(bi);
			});
		}
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class CancelOrderModel extends GenericBookingModel {
		private String reason;
		private String sourcePage;

	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	@JsonIgnoreProperties(ignoreUnknown = false)
	public static class GenericBookingModel {
		private Long bookingId;
		private Long userId;
		private String comments;
	}

}