package com.dipl.evin2.dto;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

public interface BatchProductDTO {
	@Value(("#{target.batch_no}"))
	String getBatchNo();
	@Value(("#{target.manufactured_date}"))
	Date getManufacturedDate();
	@Value(("#{target.expiry_date}"))
	Date getExpiryDate();
	@Value(("#{target.manufacture_name}"))
	String getManufactureName();
	@Value(("#{target.manufacture_id}"))
	Integer getManufactureId();
	@Value(("#{target.total_stock}"))
	Long getTotalStock();
	@Value(("#{target.allocated_stock}"))
	Long getAllocatedStock();
	@Value(("#{target.available_stock}"))
	Long getAvailableStock();
	@Value(("#{target.quantity}"))
	Long getQuantity();
}
