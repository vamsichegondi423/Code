package com.dipl.evin2.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.model.FileReportResponse;
import com.dipl.evin2.service.IcatalogueService.ExcelResponse;
import com.dipl.evin2.service.UploadFileService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Nikhil
 *
 */
@Service
@Slf4j
public class ImportFileData {

	@Autowired
	private UploadFileService uploadFileService;

	/**
	 * 
	 * @param inputStream
	 * @return
	 * @throws CustomException
	 */
	public List<IcatalogueModel> csvToIcatalogueModel(InputStream inputStream) throws CustomException {
		try {
			BufferedReader fileReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
			CSVParser csvParser = new CSVParser(fileReader, CSVFormat.DEFAULT);
			List<IcatalogueModel> assetModelList = new ArrayList<>();
			Iterable<CSVRecord> csvRecords = csvParser.getRecords();
			Iterator<CSVRecord> iterator = csvRecords.iterator();
			while (iterator.hasNext()) {
				CSVRecord next = iterator.next();
				IcatalogueModel icatalogueModel = new IcatalogueModel();
				icatalogueModel.setStoreId((next.get(0) == null || next.get(0).equalsIgnoreCase("")) ? null : next.get(0).trim());
				icatalogueModel.setStoreName((next.get(1) == null || next.get(1).equalsIgnoreCase("")) ? null : next.get(1).trim());
				icatalogueModel.setStateName((next.get(2) == null || next.get(2).equalsIgnoreCase("")) ? null : next.get(2).trim());
				icatalogueModel.setDistrictName((next.get(3) == null || next.get(3).equalsIgnoreCase("")) ? null : next.get(3).trim());
				icatalogueModel.setBlockName((next.get(4) == null || next.get(4).equalsIgnoreCase("")) ? null : next.get(4).trim());
				icatalogueModel.setPranthId((next.get(5) == null || next.get(5).equalsIgnoreCase("")) ? null : next.get(5).trim());
				icatalogueModel.setMaterialName((next.get(6) == null || next.get(6).equalsIgnoreCase("")) ? null : next.get(6).trim());
				icatalogueModel.setMinStock((next.get(7) == null || next.get(7).equalsIgnoreCase("")) ? "0" : next.get(7).trim());
				icatalogueModel.setMaxStock((next.get(8) == null || next.get(8).equalsIgnoreCase("")) ? "0" : next.get(8).trim());
				if(next.getRecordNumber() == 1 ) {
					icatalogueModel.setRemarks("Remarks(This filed should be entered by system)");
				}
				assetModelList.add(icatalogueModel);
			}
			return assetModelList;
		} catch (IOException e) {
			log.error("Excepton occured while reading the excel data from CSV ImportFileData... " + e.getMessage());
			throw new CustomException("fail to parse CSV file: ", HttpStatus.FORBIDDEN);

		}
	}

	/**
	 * 
	 * @param icatalogueModels
	 * @param model
	 * @param excelResponse
	 * @param userName
	 * @return
	 * @throws IOException
	 */

	public ExcelResponse exportErrorFile(List<IcatalogueModel> icatalogueModels, IcatalogueModel model,
			ExcelResponse excelResponse, String userName) throws IOException {
		Long successCount = 0L;
		Object fileData;
		String url = null;
		Long errorCount = 0L;
		CSVPrinter csvPrinter = null;
		try {
			// creating workbook
			File file = File.createTempFile("StockBulkUpdate", ".csv");
			csvPrinter = new CSVPrinter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8")),
					CSVFormat.DEFAULT.withHeader(model.getStoreId(), model.getStoreName(), model.getStateName(),
							model.getDistrictName(),model.getBlockName(),model.getPranthId(), model.getMaterialName(), model.getMinStock(), model.getMaxStock(),
							model.getRemarks()));

			// fetching data under headers
			for (int i = 0; i < icatalogueModels.size(); i++) {
				String remarks = icatalogueModels.get(i).getRemarks();
				csvPrinter.printRecord(icatalogueModels.get(i).getStoreId(), icatalogueModels.get(i).getStoreName(),
						icatalogueModels.get(i).getStateName(), icatalogueModels.get(i).getDistrictName(),icatalogueModels.get(i).getBlockName(),
						icatalogueModels.get(i).getPranthId(),
						icatalogueModels.get(i).getMaterialName(), icatalogueModels.get(i).getMinStock(),
						icatalogueModels.get(i).getMaxStock(), remarks);
				if (remarks.equalsIgnoreCase("Record updated successfully")) {
					successCount++;
				} else {
					errorCount++;
				}
			}
			// this method is used to write the data into file
			csvPrinter.flush();
			// this method is used to close the csv printer
			csvPrinter.close();

			// uploading excel file
			HttpResponse<String> response = uploadFileService.uploadFile(url, userName, file, "StockBulkUpdate");
			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();
			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			excelResponse.setDownloadUrl(fileDownloadUrl);
			excelResponse.setSuccessCount(successCount);
			excelResponse.setErrorCount(errorCount);
			excelResponse.setMessage("Success");
			file.delete();
		} catch (Exception e) {
			log.error("Exception occured while exporting stock report by store : " + e.getMessage());
			excelResponse.setMessage("Error wile returning data");
		} finally {
			csvPrinter.close();
		}
		return excelResponse;

	}
}
