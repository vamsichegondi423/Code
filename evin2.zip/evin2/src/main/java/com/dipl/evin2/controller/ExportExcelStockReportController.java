package com.dipl.evin2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.model.ExportStockReportModel;
import com.dipl.evin2.service.ExportStockReportService;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/icatalogue")
public class ExportExcelStockReportController {

	@Autowired
	private ExportStockReportService exportStockReportService;

	@PostMapping(value = "/v1/export-stock-report" ,consumes = "application/json",produces = "application/json" )
	public ResponseBean getStockReport(@RequestBody ExportStockReportModel exportStockReportModel) {

		   ResponseBean responseBean = new ResponseBean();

		try {
			return exportStockReportService.getStockService(exportStockReportModel);
		} catch (Exception e) {
			log.error("Exception occured while getting stock report", e.getCause());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured while exporting stockreport " + e.getMessage());
			e.printStackTrace();

		}
		return responseBean;
	}
	@PostMapping(value = "/v1/export-stock-report-with-batch",consumes = "application/json",produces = "application/json" )
	public ResponseBean getStockReportWithBatch(@RequestBody ExportStockReportModel exportStockReportModel) {

		   ResponseBean responseBean = new ResponseBean();

		try {
			return exportStockReportService.getStockServiceWithBatch(exportStockReportModel);
		} catch (Exception e) {
			log.error("Exception occured while getting stock report", e.getCause());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured while exporting stockreport " + e.getMessage());
			e.printStackTrace();
		}
		return responseBean;
	}
}
