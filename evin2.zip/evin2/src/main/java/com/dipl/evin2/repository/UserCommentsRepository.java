package com.dipl.evin2.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dipl.evin2.dto.UserCommentsDTO;
import com.dipl.evin2.entity.UserComments;

@Repository
public interface UserCommentsRepository  extends JpaRepository<UserComments, Long >{

	@Query(value="select uc.created_on ,uc.comments,u.user_id from user_comments uc " + 
			"	left join users u on u.id = uc.created_by " + 
			"	where entry_from ='Booking' and booking_id =?1",nativeQuery = true)
	public List<UserCommentsDTO> findUserBookingComments(Long objId,Pageable pageable);

	@Query(value="select uc.created_on ,uc.comments,u.user_id from user_comments uc " + 
			"	left join users u on u.id = uc.created_by " + 
			"	where entry_from ='Cargo' and cargo_id =?1",nativeQuery = true)
	public List<UserCommentsDTO> findUserCargoComments(Long objId,Pageable pageable);

}
