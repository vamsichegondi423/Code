package com.dipl.evin2.model;

import java.util.List;

import lombok.Builder;
import lombok.Data;

public class GenericDTO {
	
	@Data
	@Builder
	public static class TxnLogsCountDTO{
		private Long stateId;
		private Integer count;
	}

}
