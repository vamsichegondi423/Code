package com.dipl.evin2.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.dipl.evin2.controller.AssetController.AssetModelDetailsDTO;
import com.dipl.evin2.controller.AssetController.GraphDTO;
import com.dipl.evin2.dto.AssetDTO;
import com.dipl.evin2.dto.AssetDetailsDTO;
import com.dipl.evin2.dto.AssetDetailsDTO.SensorMonitoringPoint;
import com.dipl.evin2.dto.AssetFilterMapper;
import com.dipl.evin2.entity.Asset;
import com.dipl.evin2.entity.AssetConfiguration;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.model.TemperatureLog;
import com.dipl.evin2.model.TemperatureLogDetails;
import com.dipl.evin2.mongo.repository.TemperatureLogDetailsRepository;
import com.dipl.evin2.mongo.repository.TemperatureLogRepository;
import com.dipl.evin2.repository.AssetRepository;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.PowerAvailabilityGraphResponse;
import com.dipl.evin2.util.PowerAvailabilityGraphResponse.PowerChartConfig;
import com.dipl.evin2.util.PowerAvailabilityGraphResponse.PowerData;
import com.dipl.evin2.util.TempatureGraphResponse;
import com.dipl.evin2.util.TempatureGraphResponse.ChartConfig;
import com.dipl.evin2.util.TempatureGraphResponse.RecentActivity;
import com.dipl.evin2.util.TempatureGraphResponse.TempatureData;
import com.dipl.evin2.util.TempatureGraphResponse.TrendLine;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AssetService {

	@Autowired
	private AssetRepository assetRepository;

	@Autowired
	AssetConfigurationService assetConfigurationService;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private TemperatureLogDetailsRepository temperatureLogDetailsRepository;

	@Autowired
	private TemperatureLogRepository temperatureLogRepository;

	public Asset getById(Long id) throws CustomException {
		Optional<Asset> assetOptional = assetRepository.getById(id);
		if (assetOptional.isPresent()) {
			return assetOptional.get();
		} else {
			return null;
		}
	}

	public Asset getBySerialNumber(String serialNumber) {
		Optional<Asset> assetOptional = assetRepository.getBySerialNumber(serialNumber);
		if (assetOptional.isPresent()) {
			return assetOptional.get();
		} else {
			return null;
		}
	}

	public Asset save(Asset asset) throws CustomException {
		if (asset.getId() != null && asset.getId() > 0) {
			Optional<Asset> existingAssetRecord = assetRepository.getById(asset.getId());
			if (existingAssetRecord.isPresent()) {
				return assetRepository.save(asset);
			}
		} else {
			asset = assetRepository.save(asset);
		}
		return asset;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<Asset> existingAssetRecord = assetRepository.getById(id);
			if (existingAssetRecord.isPresent()) {
				assetRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<Asset> getAll() {
		try {
			return assetRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public Asset getBySerialNumberAndAssetModel(String serialNumber, Long assetModelId) {
		Optional<Asset> assetOptional = assetRepository.getBySerialNumberAndAssetModel(serialNumber, assetModelId);
		if (assetOptional.isPresent()) {
			return assetOptional.get();
		} else {
			return null;
		}
	}

	public List<AssetDTO> fetchAssetsBySerialNoAndType(String serialNumber,List<Integer> typeIds, Pageable pageable) {
		List<AssetDTO> listOfAssets = new ArrayList<>();
		StringBuilder builder = new StringBuilder();
		try {
			builder.append("select a.id as asset_id,a.serial_number,a.asset_model_id,mam.model_name,mam.asset_vendor_id,mav.name as asset_vendor_name,\n" + 
					"mam.asset_type_id,mat.name as asset_type_name,a.store_id,s.name as store_name,\n" + 
					"s.address, s.city, b.name as block_name, d.name as district_name, st.name as state_name, c.name as country,\n" + 
					"a.updated_by as last_updated_by_id,concat(u.f_name,' ',u.l_name) as last_updated_by_name,a.updated_on as last_updated_on\n" + 
					"from asset a join master_asset_model mam on a.asset_model_id=mam.id\n" + 
					"join master_asset_vendor mav on mam.asset_vendor_id=mav.id\n" + 
					"join master_asset_type mat on mam.asset_type_id=mat.id\n" + 
					"left join store s on a.store_id=s.id left join master_block b on s.block_id=b.id\n" + 
					"left join master_district d on s.district_id=d.id left join master_state st on s.state_id=st.id\n" + 
					"left join master_country c on s.country_id=c.id left join users u on a.updated_by=u.id"); 

			builder.append(" where ");
			StringBuilder params = new StringBuilder();
			params.append(" a.is_deleted = false ");

			if (serialNumber != null && !serialNumber.isEmpty()) {
				params = params.length() > 0 ? params.append(" and ") : params.append("");
				params.append(" a.serial_number like '%" + serialNumber + "%'");
			}
			if (typeIds != null && !typeIds.isEmpty()) {
				params = params.length() > 0 ? params.append(" and ") : params.append("");
				params.append(" mam.asset_type_id  in ("+StringUtils.collectionToCommaDelimitedString(typeIds)+")");
			}
			params.append(" order by a.updated_on desc ") ;
			params.append(" LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset()) ;
			String sqlQuery = builder.append(params).toString();
			System.out.println(sqlQuery);
			listOfAssets = jdbcTemplate.query(sqlQuery, new AssetFilterMapper());
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return listOfAssets;
	}

	public List<AssetDetailsDTO> getAssetsDetails(Long assetId, Long storeId, Pageable pageable) {
		List<AssetDetailsDTO> assetsList = new ArrayList<>();
		StringBuilder builder = new StringBuilder();
		try {
			builder.append("select a.id as assetId,a.serial_number as serialNumber,a.asset_model_id as assetModelId,mam.model_name as modelName,\n"
					+ "am.mapped_asset_id as mappedAssetId, ma.serial_number as mappedAssetSerialNumber,\n"
					+ "mam.asset_vendor_id as assetVendorId, mav.name as assetVendorName,a.store_id as storeId, s.name as storeName,s.city,\n"
					+ "d.name as districtName, st.name as stateName, c.name as country,amps.sensor_monitoring_point as sensorMonitoringPoint,\n"
					+ "mam.asset_type_id as assetTypeId,mat.name as assetTypeName, a.status_id as statusId,ms.name as assetStatus,\n"
					+ "ut.user_detail as userDetail,a.created_on as createdOn,a.created_by as createdBy, concat(cu.f_name,' ',cu.l_name)\n"
					+ "as createdByUser, a.updated_on as updatedOn, a.updated_by as updatedBy, concat(uu.f_name,' ',uu.l_name) as updatedByUser\n"
					+ ", s.pranth_id as pranthId,p.name as pranthName,s.latitude,s.longitude,a.year_of_manufacture as yearOfManufacture,\n"
					+ "mam.capacity from asset a join master_asset_model mam on a.asset_model_id=mam.id join master_asset_vendor mav on\n"
					+ "mam.asset_vendor_id=mav.id join master_asset_type mat on mam.asset_type_id=mat.id\n"
					+ "left join asset_mapping am on a.id = am.asset_id left join asset ma on ma.id=am.mapped_asset_id\n"
					+ "left join store s on a.store_id=s.id left join (select asset_id,json_agg(json_build_object('user_role',user_role,'user_list',user_list))::text\n"
					+ "as user_detail from(select asset_id,r.name as user_role, json_agg(json_build_object('name',u.f_name||' '||u.l_name,'mobile',u.mobile, 'userId', u.id)) as user_list\n"
					+ "from asset_users au join master_role r on r.id=au.role_id join users u on au.user_id=u.id group by 1,2)t group by 1)ut on ut.asset_id=a.id left \n"
					+ "join master_district d on s.district_id=d.id left join master_state st on s.state_id=st.id left join master_country c on s.country_id=c.id\n"
					+ "left join (select asset_id, json_agg(json_build_object('sensor',sensor,'monitoring_point',monitoring_point))::text as sensor_monitoring_point from\n"
					+ "asset_monitoring_point_sensor group by 1) amps on a.id=amps.asset_id left join master_status ms on ms.id=a.status_id left join pranth p on p.id=s.pranth_id\n"
					+ "join users cu on a.created_by=cu.id left join users uu on uu.id=a.updated_by");

			builder.append(" where ");
			StringBuilder params = new StringBuilder();
			params.append(" (a.is_deleted = false or a.is_deleted is null)");
			if (assetId != null && assetId > 0) {
				params = params.length() > 0 ? params.append(" and ") : params.append("");
				params.append(" a.id = "+assetId);
			}

			if(storeId != null && storeId > 0) {
				params = params.length() > 0 ? params.append(" and ") : params.append("");
				params.append(" s.id = "+storeId);
			}

			params.append(" order by a.updated_on desc ") ;

			params.append(" LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset()) ;
			String sqlQuery = builder.append(params).toString();
			assetsList = jdbcTemplate.query(sqlQuery, new BeanPropertyRowMapper<AssetDetailsDTO>(AssetDetailsDTO.class));
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return assetsList;
	}

	public List<Asset> getAvailableTemperatureLoggers(Integer assetType, String serialNumber) {
		if(serialNumber != null && !serialNumber.isEmpty()) {
			return assetRepository.getAvailableTemperatureLoggers(assetType, serialNumber);
		}
		else {
			return assetRepository.getAvailableTemperatureLoggers(assetType);
		}
	}

	public List<Asset> getAllBySerialNumber(List<Long> values) {
		return assetRepository.getAllBySerialNumber(values);
	}

	public List<AssetDetailsDTO> getAssetsDetails(Long storeId, Long assetId, List<Integer> assetTypes,
			String relationships, Integer statusId, String alarms, Pageable pageable, Set<Long> storeIds, String serialNumber) {
		List<AssetDetailsDTO> assetsList = new ArrayList<>();
		StringBuilder builder = new StringBuilder();
		try {
			builder.append("select a.id as assetId,a.serial_number as serialNumber,a.asset_model_id as assetModelId,mam.model_name as modelName,\n"
					+ "am.mapped_asset_id as mappedAssetId, ma.serial_number as mappedAssetSerialNumber,\n"
					+ "mam.asset_vendor_id as assetVendorId, mav.name as assetVendorName,a.store_id as storeId, s.name as storeName,s.city,\n"
					+ "d.name as districtName, st.name as stateName, c.name as country,amps.sensor_monitoring_point as sensorMonitoringPoint,\n"
					+ "mam.asset_type_id as assetTypeId,mat.name as assetTypeName, a.status_id as statusId,ms.name as assetStatus,\n"
					+ "ut.user_detail as userDetail,a.created_on as createdOn,a.created_by as createdBy, concat(cu.f_name,' ',cu.l_name)\n"
					+ "as createdByUser, a.updated_on as updatedOn, a.updated_by as updatedBy, concat(uu.f_name,' ',uu.l_name) as updatedByUser\n"
					+ ", s.pranth_id as pranthId,p.name as pranthName,s.latitude,s.longitude,a.year_of_manufacture as yearOfManufacture,\n"
					+ "mam.capacity from asset a join master_asset_model mam on a.asset_model_id=mam.id join master_asset_vendor mav on\n"
					+ "mam.asset_vendor_id=mav.id join master_asset_type mat on mam.asset_type_id=mat.id\n"
					+ "left join asset_mapping am on a.id = am.asset_id left join asset ma on ma.id=am.mapped_asset_id\n"
					+ "left join store s on a.store_id=s.id left join (select asset_id,json_agg(json_build_object('user_role',user_role,'user_list',user_list))::text\n"
					+ "as user_detail from(select asset_id,r.name as user_role, json_agg(json_build_object('name',u.f_name||' '||u.l_name,'mobile',u.mobile, 'userId', u.id)) as user_list \n"
					+ "from asset_users au join master_role r on r.id=au.role_id join users u on au.user_id=u.id group by 1,2)t group by 1)ut on ut.asset_id=a.id left \n"
					+ "join master_district d on s.district_id=d.id left join master_state st on s.state_id=st.id left join master_country c on s.country_id=c.id\n"
					+ "left join (select asset_id, json_agg(json_build_object('sensor',sensor,'monitoring_point',monitoring_point))::text as sensor_monitoring_point from\n"
					+ "asset_monitoring_point_sensor group by 1) amps on a.id=amps.asset_id left join master_status ms on ms.id=a.status_id left join pranth p on p.id=s.pranth_id\n"
					+ "join users cu on a.created_by=cu.id left join users uu on uu.id=a.updated_by");

			builder.append(" where ");
			StringBuilder params = new StringBuilder();
			params.append(" a.is_deleted = false ");

			if (assetId != null && assetId > 0) {
				params = params.length() > 0 ? params.append(" and ") : params.append("");
				params.append(" a.id = "+assetId);
			}

			if(storeId != null && storeId > 0) {
				params = params.length() > 0 ? params.append(" and ") : params.append("");
				params.append(" s.id = "+storeId);
			}

			if(assetTypes != null && !assetTypes.isEmpty()) {
				params = params.length() > 0 ? params.append(" and ") : params.append("");
				params.append(" mam.asset_type_id in ("+StringUtils.collectionToCommaDelimitedString(assetTypes)+")");
			}
			
			if(serialNumber != null && !serialNumber.isEmpty()) {
				params = params.length() > 0 ? params.append(" and ") : params.append("");
				params.append(" a.serial_number like '%"+serialNumber+"%'");
			}

			if(relationships != null && !relationships.isEmpty()) {
				params = params.length() > 0 ? params.append(" and ") : params.append("");
				if(relationships.equalsIgnoreCase("Assets with relationships")) {
					params.append(" a.id in (SELECT asset_id AS name FROM asset_mapping UNION SELECT mapped_asset_Id AS name FROM asset_mapping)");
				}else {
					params.append(" a.id not in (SELECT asset_id AS name FROM asset_mapping UNION SELECT mapped_asset_Id AS name FROM asset_mapping)");
				}

			}

			if(statusId != null && statusId > 0) {
				params = params.length() > 0 ? params.append(" and ") : params.append("");
				params.append(" a.status_id = "+statusId);
			}

			if(alarms != null && !alarms.isEmpty()) {

			}

			if(!storeIds.isEmpty()) {
				String storeIdsString = "("+StringUtils.collectionToCommaDelimitedString(storeIds.stream().map(s -> s+"").collect(Collectors.toSet()))+")";
				params = params.length() > 0 ? params.append(" and ") : params.append("");
				params.append(" s.id in "+storeIdsString);
			}

			params.append(" order by a.updated_on desc ") ;

			params.append(" LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset()) ;
			String sqlQuery = builder.append(params).toString();
			System.out.println(sqlQuery);
			assetsList = jdbcTemplate.query(sqlQuery, new BeanPropertyRowMapper<AssetDetailsDTO>(AssetDetailsDTO.class));
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return assetsList;
	}

	public List<Map<String, Object>> findAssetBySerialNumber(String assestSerialNum) {
		List<Map<String, Object>> assestSerialNUmber = null;
		if(assestSerialNum != null && !assestSerialNum.isEmpty()) {
			assestSerialNUmber = assetRepository.findAssestSerialNumber(assestSerialNum);
			return assestSerialNUmber;
		}
		return null;
	}

	public List<AssetSensorMonitoringPointDTO> getSensorMonitoringPoints(Set<Long> assetIds){
		if(assetIds != null && !assetIds.isEmpty()) {
			String assetIdsString  = StringUtils.collectionToCommaDelimitedString(assetIds);
			String q = "select amps.asset_id as assetId, json_agg(json_build_object('sensor',amps.sensor,'monitoring_point',amps.monitoring_point))::text as sensorMonitoringPoint from \r\n"
					+ "asset_monitoring_point_sensor amps join asset_mapping am on amps.asset_id = am.mapped_asset_id where \r\n"
					+ " am.asset_id in ("+assetIdsString+") group by amps.asset_id";
			return jdbcTemplate.query(q, new BeanPropertyRowMapper<AssetSensorMonitoringPointDTO>(AssetSensorMonitoringPointDTO.class));
		}else {
			return new ArrayList<>();
		}
	}

	@Builder
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class AssetSensorMonitoringPointDTO{
		private Long assetId;
		private String sensorMonitoringPoint;
		private List<SensorMonitoringPoint> sensorMonitoringPoints;

	}

	public AssetModelDetailsDTO getAssetModelDetails(Long assetId){
		List<AssetModelDetailsDTO> assetModelDetailsDTOs = jdbcTemplate.query("select a.id as assetId, mat.id as assetTypeId, mat.name as assetType, "
				+ "mam.id as modelId, mam.model_name as"
				+ " modelName, mav.id as vendorId, mav.name as vendorName from asset a left join master_asset_model mam on mam.id"
				+ " = a.asset_model_id left join master_asset_vendor mav on mam.asset_vendor_id = mav.id left join master_asset_type"
				+ " mat on mat.id = mam.asset_type_id where a.id = "+assetId, new BeanPropertyRowMapper<AssetModelDetailsDTO>(AssetModelDetailsDTO.class));
		return assetModelDetailsDTOs.iterator().next();
	}

	public TempatureGraphResponse findTempatureGraphDetails(GraphDTO graphDTO) throws CustomException {
		Long assetId = null;
		TempatureGraphResponse graphResponse = new TempatureGraphResponse();
		List<TemperatureLogDetails> temperatureLogDetailsList = new ArrayList<>();
		List<TempatureData> tempatureDatas = new ArrayList<>();
		List<TrendLine> trendLines = new ArrayList<>();
		List<RecentActivity> recentActivitiyList = new ArrayList<>();
		List<ChartConfig> chartConfigs = new ArrayList<>();
		AssetModelDetailsDTO modelDetailsDTO = getAssetModelDetails(graphDTO.getAssetId());
		Date fromDate = null;
		Date toDate = null;
		try {
			if(graphDTO.getFromDate() != null) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate localDate = LocalDate.parse(graphDTO.getFromDate(), formatter);
				fromDate = new SimpleDateFormat("yyyy-MM-dd").parse(localDate.toString());
				toDate = new SimpleDateFormat("yyyy-MM-dd").parse(localDate.plusDays(1).toString());
			}
			if(modelDetailsDTO.getAssetTypeId().equals(Constants.ASSET_TYPE_TEMPERATURE_LOGGER)) {
				assetId =  graphDTO.getAssetId();
				if(graphDTO.getFromDate() != null) {
					temperatureLogDetailsList = temperatureLogDetailsRepository.findByDIdAndTemperatureLogTimeAndSId(graphDTO.getAssetSerialNumber(), graphDTO.getSensorName(),
							fromDate, toDate);
				}else {
					temperatureLogDetailsList = temperatureLogDetailsRepository.findByDIdAndSIdAndIsDeletedFalse(graphDTO.getAssetSerialNumber(), graphDTO.getSensorName());
				}
			} else {
				AssetMappingDTO mappedMonitoredAssetBySerialNo = getMappedMonitoredAssetBySerialNo(graphDTO.getAssetSerialNumber());
				if(mappedMonitoredAssetBySerialNo != null) {
					assetId = mappedMonitoredAssetBySerialNo.getMappedAssetId();
					if(graphDTO.getFromDate() != null) {
						temperatureLogDetailsList = temperatureLogDetailsRepository.findByDIdAndAssetDIdAndTemperatureLogTimeAndSId(mappedMonitoredAssetBySerialNo.getMappedSerialNumber(),
								mappedMonitoredAssetBySerialNo.getSerialNumber(), fromDate, toDate, graphDTO.getSensorName());
					} else {
						temperatureLogDetailsList = temperatureLogDetailsRepository.findByDIdAndAssetDIdAndSIdAndIsDeletedFalse(mappedMonitoredAssetBySerialNo.getMappedSerialNumber(),
								mappedMonitoredAssetBySerialNo.getSerialNumber(),graphDTO.getSensorName());
					}
				}
			}
			ChartConfig chartConfig = ChartConfig.builder().caption("").subCaption("").
					xAxisname("Temperature").yAxisName("Time").numberSuffix("°C").snumbersuffix("°C").build();
			chartConfigs.add(chartConfig);
			graphResponse.setChartConfig(chartConfigs);
			for(TemperatureLogDetails tm :temperatureLogDetailsList){
				LocalDateTime logDate = null;
				LocalDateTime  presentDate = LocalDateTime.now();
				TempatureData td = TempatureData.builder().label(tm.getTemperatureLogTime()).value(tm.getTmp()).build();
				tempatureDatas.add(td);
				logDate = LocalDateTime.ofInstant(tm.getTemperatureLogTime().toInstant(),
						ZoneId.systemDefault());
				Duration duration = Duration.between(logDate, presentDate);
				if(tm.getTyp() == 1) {
					RecentActivity recentActivity = RecentActivity.builder().sensorName("Main").monitoringPoint("Main").alarmMessage("Temperature incursion of "+tm.getTmp()+"°C").time(duration.toDays() +""+" day ago").build();
					recentActivitiyList.add(recentActivity);
				}
				if(tm.getTyp() == 2) {
					RecentActivity recentActivity = RecentActivity.builder().sensorName("Main").monitoringPoint("Main").alarmMessage("High Temperature excursion of "+tm.getTmp()+"°C").time(duration.toDays()+""+" day ago").build();
					recentActivitiyList.add(recentActivity);
				}
			}
			graphResponse.setData(tempatureDatas);
			AssetConfiguration assetConfig = assetConfigurationService.getByAssetId(assetId);
			if(assetConfig.getHighAlarmTemperature() != null) {
				TrendLine highTrendLine = TrendLine.builder().displayName("High Alarm Temperature").displayValue(assetConfig.getHighAlarmTemperature()).startValue(assetConfig.getHighAlarmTemperature()).build();
				TrendLine lowTrendLine = TrendLine.builder().displayName("Low Alarm Temperature").displayValue(assetConfig.getLowAlarmTemperature()).startValue(assetConfig.getLowAlarmTemperature()).build();
				trendLines.add(highTrendLine);
				trendLines.add(lowTrendLine);
				graphResponse.setTrendLine(trendLines);
			}
			graphResponse.setRecentActivity(recentActivitiyList);
			return graphResponse;
		} catch (ParseException e) {
			e.printStackTrace();
			log.info("Error while fetching data",e);
			throw new CustomException("Exception while fecthing data", HttpStatus.OK);
		}
	}

	public AssetMappingDTO getMappedMonitoredAssetBySerialNo(String tempLogSerialNo){
		String q = "select a.asset_id as assetId, b.serial_number as serialNumber, a.mapped_asset_id as mappedAssetId,"
				+ " c.serial_number as mappedSerialNumber from asset_mapping a left join asset b on b.id = a.asset_id"
				+ " left join asset c on c.id = a.mapped_asset_id where b.serial_number = '"+tempLogSerialNo+"'";
		log.info(q);
		List<AssetMappingDTO> assetMappingDTOs = jdbcTemplate.query(q, new BeanPropertyRowMapper<AssetMappingDTO>(AssetMappingDTO.class));
		return !assetMappingDTOs.isEmpty() ? assetMappingDTOs.iterator().next() : null;
	}


	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class AssetMappingDTO{
		private Long assetId;
		private Long mappedAssetId;
		private String serialNumber;
		private String mappedSerialNumber;
	}

	public  PowerAvailabilityGraphResponse findPowerAvailabilityGraphDetails(GraphDTO graphDTO) throws CustomException {
		Long assetId = null;
		PowerAvailabilityGraphResponse graphResponse = new PowerAvailabilityGraphResponse();
		List<TemperatureLog> temperatureLogList = new ArrayList<>();
		List<PowerData> powerDatas = new ArrayList<>();
		List<PowerChartConfig> powerChartConfig = new ArrayList<>();
		AssetModelDetailsDTO modelDetailsDTO = getAssetModelDetails(graphDTO.getAssetId());
		Date fromDate = null;
		Date toDate = null;
		try {
			if(graphDTO.getFromDate() != null) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate localDate = LocalDate.parse(graphDTO.getFromDate(), formatter);
				fromDate = new SimpleDateFormat("yyyy-MM-dd").parse(localDate.toString());
				toDate = new SimpleDateFormat("yyyy-MM-dd").parse(localDate.plusDays(1).toString());
			}
			if(modelDetailsDTO.getAssetTypeId().equals(Constants.ASSET_TYPE_TEMPERATURE_LOGGER)) {
				assetId =  graphDTO.getAssetId();
				if(graphDTO.getFromDate() != null) {
					temperatureLogList = temperatureLogRepository.findByDIdAndCreatedOnAndIsDeletedFalse(graphDTO.getAssetSerialNumber(),fromDate, toDate);
				}else {
					temperatureLogList = temperatureLogRepository.findByDIdAndIsDeletedFalse(graphDTO.getAssetSerialNumber());
				}
			} else {
				AssetMappingDTO mappedMonitoredAssetBySerialNo = getMappedMonitoredAssetBySerialNo(graphDTO.getAssetSerialNumber());
				if(mappedMonitoredAssetBySerialNo != null) {
					assetId = mappedMonitoredAssetBySerialNo.getMappedAssetId();
					if(graphDTO.getFromDate() != null) {
						temperatureLogList = temperatureLogRepository.findByDIdAndAssetDIdAndCreatedOnAndIsDeletedFalse(mappedMonitoredAssetBySerialNo.getMappedSerialNumber(),
								mappedMonitoredAssetBySerialNo.getSerialNumber(), fromDate, toDate);
					} else {
						temperatureLogList = temperatureLogRepository.findByDIdAndAssetDIdAndCreatedOn(mappedMonitoredAssetBySerialNo.getMappedSerialNumber(),
								mappedMonitoredAssetBySerialNo.getSerialNumber());
					}
				}
			}
			PowerChartConfig chartConfig = PowerChartConfig.builder().caption("").subCaption("").
					xAxisname("Time").yAxisName("Status").numberSuffix("").snumbersuffix("").build();
			powerChartConfig.add(chartConfig);
			graphResponse.setPowerChartConfig(powerChartConfig);
			for(TemperatureLog tm :temperatureLogList){
				if(!tm.getData().isEmpty()) {
					tm.getData().forEach(data -> {
						if(data.getPwa() != null) {
								PowerData td = PowerData.builder().powerAvailabilityTime(getDate(data.getPwa().getTime().longValue())).stat(data.getPwa().getStat())
										.time(data.getPwa().getTime()).build();
								powerDatas.add(td);
						}
					});
				}
			}
			graphResponse.setPowerData(powerDatas);
			return graphResponse;
		} catch (ParseException e) {
			e.printStackTrace();
			log.info("Error while fetching data",e);
			throw new CustomException("Exception while fecthing data", HttpStatus.OK);
		}
	}
	public static Date getDate(Long timeInSeconds) {
		return new Date(timeInSeconds*1000L);
	}

}