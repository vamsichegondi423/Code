package com.dipl.evin2.controller;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.controller.IcatalogueController.StockIndicator;
import com.dipl.evin2.controller.StoreController.StoresTransactionDetails;
import com.dipl.evin2.dto.StoreFilterDTO;
import com.dipl.evin2.dto.StoreFiltersDTO;
import com.dipl.evin2.dto.StoresTransactionDTO;
import com.dipl.evin2.entity.Badge;
import com.dipl.evin2.entity.Store;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.jackson.StoreModel;
import com.dipl.evin2.repository.BadgeRepository;
import com.dipl.evin2.service.BookingsService;
import com.dipl.evin2.service.StoreService;
import com.dipl.evin2.service.StoreService.StoreDetailsDTO;
import com.dipl.evin2.service.StoreService.UserDetailsDTO;
import com.dipl.evin2.util.EvinUtility;
import com.dipl.evin2.util.KafkaProducer;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/store")
public class StoreController {

	@Autowired
	private StoreService storeService;
	@Autowired
	private KafkaProducer kafkaProducer;
	@Autowired
	private BadgeRepository badgeRepository;
	
	@ApiOperation("Use this api for saving or updating Store. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/create-store")
	public ResponseBean createStore(@RequestBody StoreModel storePayload, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured while creating Store", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (storePayload.getId() != null && storePayload.getId() > 0) {
				Store existingStore = storeService.getById(storePayload.getId());
				if (existingStore != null) {
					Store store = storeService.createStore(storePayload);
					log.info("Store updated successfully");
					responseBean.setMessage("Store updated successfully");
					responseBean.setData(store);
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setReturnCode(1);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setReturnCode(1);
				}
			} else {
				if (storePayload.getName() != null) {
					Store existingStore = storeService.getStoreByName(storePayload.getName());
					if (existingStore != null) {
						responseBean.setMessage("Store is allready exists with this name " + existingStore.getName());
						responseBean.setData(existingStore);
						responseBean.setStatus(HttpStatus.OK);
						responseBean.setReturnCode(1);
					} else {
						Store store = storeService.createStore(storePayload);
						Integer badgeId = storePayload.getStoreBadgeModel().get(0).getBadgeId();
						try {

							Optional<Badge> badgeDetails = badgeRepository.findById(badgeId);
							String storeBadge = null;
							if (!badgeDetails.isEmpty()) {
								storeBadge = badgeDetails.get().getName();
							}
							kafkaProducer.saveStoreToKafka(store.getName(), store.getId(), store.getIsDeleted(),
									storeBadge, store.getStateId(), store.getDistrictId(), store.getBlockId(),
									store.getCity(), badgeId);
						} catch (JsonProcessingException e) {
							e.printStackTrace();
						}
						log.info("Store saved successfully");
						responseBean.setMessage("Store saved successfully");
						responseBean.setStatus(HttpStatus.OK);
						responseBean.setReturnCode(1);
						responseBean.setData(store);
					}
				}
			}

		} catch (Exception e) {
			log.error("Exception occured while creating store ", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured while creating the Store in store service" + e);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching Store record by id. Provide id as path param.")
	@GetMapping(value = "/v1/get-store-by-id/{storeId}", produces = "application/json")
	public ResponseBean getById(@PathVariable Long storeId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Store store = storeService.getById(storeId);
			if (store != null) {
				log.info("Store fetched successfully");
				responseBean.setMessage("Store fetched successfully");
				responseBean.setData(store);
			} else {
				log.info("No Store found");
				responseBean.setMessage("No Store found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Execption Occured while fetching Store Record", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured while fetching Store Record " + e);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting Store record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = storeService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all Store records. No params required.")
	@GetMapping(value = "/v1/get-stores-by-user", produces = "application/json")
	public ResponseBean getAllStoresForUser(@RequestParam Integer userId, @RequestParam Integer pranthId, Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Map<String, Object>> storeRecords = storeService.getAllStoresForUser(userId, pranthId, pageable);
			if (!storeRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(storeRecords);
				responseBean.setReturnCode(1);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(null);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured while fetching store records for user ", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occured while fetching store records for user" + e);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for get all stores under pranth")
	@GetMapping(value = "/v1/get-all-stores-by-filter")
	public ResponseBean getAllStoresBasedOnDomain(@RequestParam(value = "pranthId") Long pranthId,
			@RequestParam(required = false, value = "storeName") String storeName,
			@RequestParam(required = false, value = "tagName") String tagName, Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		StoreDetails storeDetails = null;
		try {
			List<StoreFiltersDTO> listOfStores = storeService.getAllStoresBasedOnPranth(pranthId, storeName, tagName,
					pageable);
			Long totalRecordCount = listOfStores != null && !listOfStores.isEmpty()
					? listOfStores.get(0).getStoreCount()
					: 0;
			storeDetails = StoreDetails.builder().storeFiltersDTOs(listOfStores).totalRecordCount(totalRecordCount)
					.build();
			if (listOfStores != null && !listOfStores.isEmpty()) {
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(storeDetails);
			} else {
				responseBean.setMessage("No records found");
				responseBean.setData(null);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured while for get all stores under domain : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption occured for get all stores under domain " + e);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for get store under pranth ")
	@GetMapping(value = "/v1/get-store")
	public ResponseBean getAllStoreDataByStoreId(@RequestParam Integer pranthId, @RequestParam Integer storeId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Map<String, Object> StoreData = storeService.getAllStoreDataByStoreId(storeId, pranthId);
			if (!StoreData.isEmpty()) {
				responseBean.setMessage("Records fethed successfully");
				responseBean.setData(StoreData);
			} else {
				responseBean.setMessage("No records found");
				responseBean.setData(null);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured while get-store details : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption occured while get-store details :" + e);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for get mapping stores based on pranth and store ")
	@GetMapping(value = "/v1/get-mapping-stores")
	public ResponseBean getMappingStores(@RequestParam Integer storeId, @RequestParam String mapType) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Map<String, Object>> storeData = storeService.getMappingStores(storeId, mapType);
			if (!storeData.isEmpty()) {
				responseBean.setMessage("Records fethed successfully");
				responseBean.setData(storeData);
			} else {
				responseBean.setMessage("No records found");
				responseBean.setData(null);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured whilemapping stores details : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption occured while mapping stores details :" + e);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetch the products wise batch level data.")
	@GetMapping(value = "/v1/get-products-by-batch", produces = "application/json")
	public ResponseBean getAllProductsByBatch(@RequestParam(value = "productId", required = false) Optional<Long> productIdOptional, @RequestParam Long storeId, Pageable pageable) {
		List<Map<String, Object>> fetchMaterialsList = null;
		
		try {
			Long productId = null;
			if(!productIdOptional.isEmpty()) {
				productId = productIdOptional.get();
			}
			fetchMaterialsList = storeService.getAllProductsByBatch(productId, storeId, pageable);
		} catch (Exception e) {
			log.error("Exception occured while for fetch the products wise batch level data: {}", e);
			return ResponseBean.builder().data(null)
					.message("Exception occured while for fetch the products wise batch level data" + e.getMessage())
					.status(HttpStatus.INTERNAL_SERVER_ERROR).returnCode(0).build();
		}
		if (fetchMaterialsList.isEmpty()) {
			return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message("No records found")
					.build();
		}
		return ResponseBean.builder().data(fetchMaterialsList).status(HttpStatus.OK).returnCode(1)
				.message("Records fetched successfully").build();
	}

	@ApiOperation("Use this api for fetch store level pranth level transaction details.")
	@PostMapping(value = "/v1/get-all-stores-txns", produces = "application/json")
	public ResponseBean getAllStoresByTransactionLevel(@RequestBody TxnPayload txnPayload, Pageable pageable,
			@RequestParam("userId") Long userId, @RequestParam("pranthId") Long pranthId) throws CustomException {

		List<Long> totalStoreIds = storeService.getTotalStoreIdsWithLocationFilters(pranthId, userId,
				txnPayload.getState(), txnPayload.getDistrict(), txnPayload.getBlock());
		StoresTransactionDetails storesTransactionDetails = null ;
		try {
			StringBuilder builder = new StringBuilder();
			storesTransactionDetails = storeService.getAllStoresByTransactionLevel(txnPayload, pageable, totalStoreIds, userId,
					pranthId, builder);
		} catch (Exception e) {
			log.error("Exception occured while for fetch store level pranth level transaction details: {}", e);
			return ResponseBean.builder().data(null).message(
					"Please contact your admin ")
					.status(HttpStatus.INTERNAL_SERVER_ERROR).returnCode(0).build();
		}
		
		if(storesTransactionDetails.getStoresTransactionDTOs() != null && !storesTransactionDetails.getStoresTransactionDTOs().isEmpty()) {
			return ResponseBean.builder().data(storesTransactionDetails).status(HttpStatus.OK).returnCode(1)
					.message("Records fetched successfully").build();
		 }
		return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message("No records found")
				.build();
	}

	@ApiOperation("Use this api for fetch pranth level store level product name as stock count.")
	@GetMapping(value = "/v1/get-products-by-store-id", produces = "application/json")
	public ResponseBean getAllMaterails(@RequestParam(value = "storeId") Long storeId,
			@RequestParam(required = false, value = "type") Integer type,
			@RequestParam(required = false, value = "productId") Long productId,
			@RequestParam(required = true, value = "userId") Long userId,
			@RequestParam(required = true, value = "txnTypeId") Integer txnTypeId,
			@RequestParam(required = true, value = "pranthId") Long pranthId, Pageable pageable) {
		List<ProductsDTO> fetchStoresList = null;
		ProductsDetails productsDetails = null;
		try {
			fetchStoresList = storeService.getAllMaterails(storeId, type, productId, pageable, userId, txnTypeId,
					pranthId);
			fetchStoresList.parallelStream().forEach(materialDTO -> {
				materialDTO.setAbnormalityType(EvinUtility.renderAbnormalityType(materialDTO.getInvMin(),
						materialDTO.getInvMax(), materialDTO.getTotalStock()));
				if (materialDTO.getAbnormalityType() != null) {
					if (materialDTO.getAbnormalityType() == 200) {
						materialDTO.setStockIndicator(StockIndicator.getStockOutIndicator());
					} else if (materialDTO.getAbnormalityType() == 201) {
						materialDTO.setStockIndicator(StockIndicator.getMinimumStockIndicator());
					} else if (materialDTO.getAbnormalityType() == 202) {
						materialDTO.setStockIndicator(StockIndicator.getMaximumStockIndicator());
					}
				} else {
					materialDTO.setStockIndicator(null);
				}
			});
			Long totalRecordsCount = storeService.getAllMaterailsCount(storeId, type, txnTypeId, userId, pranthId);
			productsDetails = ProductsDetails.builder().productsDTOs(fetchStoresList)
					.totalRecordCount(totalRecordsCount).build();

		} catch (Exception e) {
			log.error("Exception occured while get product by id : {}", e);
			return ResponseBean.builder().data(null)
					.message("Exception occured while get product by id :" + e.getMessage())
					.status(HttpStatus.INTERNAL_SERVER_ERROR).returnCode(0).build();
		}
		if (fetchStoresList.isEmpty()) {
			return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message("No records found")
					.build();
		}
		return ResponseBean.builder().data(productsDetails).status(HttpStatus.OK).returnCode(1)
				.message("Records fetched successfully").build();
	}

	@ApiOperation("Use this api for fetch pranth level store level product name as stock count.")
	@GetMapping(value = "/v1/get-products-by-store-id-orders", produces = "application/json")
	public ResponseBean getAllMaterails(@RequestParam(value = "storeId") Long storeId,
			@RequestParam(required = false, value = "rstoreId") Long rstoreId,
			@RequestParam(required = false, value = "type") Integer type,
			@RequestParam(required = false, value = "productId") Long productId, Pageable pageable,
			HttpServletRequest request) {
		if (request.getParameter("page") == null) {
			pageable = PageRequest.of(0, Integer.MAX_VALUE);
		}
		List<ProductsDTO> fetchStoresList = null;
		ProductsDetails productsDetails = null;
		try {
			fetchStoresList = storeService.getAllMaterails(storeId, rstoreId, type, productId, pageable);
			fetchStoresList.parallelStream().forEach(materialDTO -> {
				materialDTO.setAbnormalityType(EvinUtility.renderAbnormalityType(materialDTO.getInvMin(),
						materialDTO.getInvMax(), materialDTO.getTotalStock()));
				if (materialDTO.getAbnormalityType() != null) {
					if (materialDTO.getAbnormalityType() == 200) {
						materialDTO.setStockIndicator(StockIndicator.getStockOutIndicator());
					} else if (materialDTO.getAbnormalityType() == 201) {
						materialDTO.setStockIndicator(StockIndicator.getMinimumStockIndicator());
					} else if (materialDTO.getAbnormalityType() == 202) {
						materialDTO.setStockIndicator(StockIndicator.getMaximumStockIndicator());
					}
				} else {
					materialDTO.setStockIndicator(null);
				}

			});
			Long totalRecordsCount = storeService.getAllMaterailsCountOrders(storeId, type);
			productsDetails = ProductsDetails.builder().productsDTOs(fetchStoresList)
					.totalRecordCount(totalRecordsCount).build();

		} catch (Exception e) {
			log.error("Exception occured while get product by id : {}", e);
			return ResponseBean.builder().data(null)
					.message("Exception occured while get product by id :" + e.getMessage())
					.status(HttpStatus.INTERNAL_SERVER_ERROR).returnCode(0).build();
		}
		if (fetchStoresList.isEmpty()) {
			return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message("No records found")
					.build();
		}
		return ResponseBean.builder().data(productsDetails).status(HttpStatus.OK).returnCode(1)
				.message("Records fetched successfully").build();
	}

	@ApiOperation("use this api for get all stores based on domain")
	@GetMapping(value = "/get-stores-by-pranth")
	public ResponseBean getStoresByPranth(@RequestParam Long pranthId, Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		List<StoreDetailsDTO> storesList = null;
		try {
			storesList = storeService.getStroesBasedOnPranth(pranthId, pageable);
		} catch (Exception e) {
			log.error("Exception occured whilemapping stores details : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption occured while mapping stores details :" + e);
		}
		if (storesList != null) {
			responseBean.setData(storesList);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setMessage("record fetched successfully");
			responseBean.setReturnCode(1);
		} else {
			responseBean.setData(null);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setMessage("no record found");
			responseBean.setReturnCode(1);
		}
		return responseBean;
	}

	@ApiOperation("use this api for get all users based on domain")
	@GetMapping(value = "/get-users-by-pranth")
	public ResponseBean getUsersByPranth(@RequestParam Long pranthId, Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		List<UserDetailsDTO> userList = null;
		try {
			userList = storeService.getUsersByPranth(pranthId, pageable);
		} catch (Exception e) {
			log.error("Exception occured whilemapping stores details : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption occured while mapping stores details :" + e);
		}
		if (userList != null) {
			responseBean.setData(userList);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setMessage("record fetched successfully");
			responseBean.setReturnCode(1);
		} else {
			responseBean.setData(null);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setMessage("no record found");
			responseBean.setReturnCode(1);
		}
		return responseBean;
	}

	@ApiOperation("use this api for get all users based on domain")
	@GetMapping(value = "/get-users-by-store-id")
	public ResponseBean getUsersByPranthAndStore(@RequestParam Long storeId, @RequestParam Long pranthId,
			Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		List<UserDetailsDTO> userList = null;
		try {
			userList = storeService.getUsersByPranthAndStore(storeId, pranthId, pageable);
		} catch (Exception e) {
			log.error("Exception occured while fetching users stores details : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Exception occured while fetching users stores details :" + e);
		}
		if (userList != null) {
			responseBean.setData(userList);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setMessage("record fetched successfully");
			responseBean.setReturnCode(1);
		} else {
			responseBean.setData(null);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setMessage("no record found");
			responseBean.setReturnCode(1);
		}
		return responseBean;
	}

	@ApiOperation("use this api for get all stores based on pranthId")
	@GetMapping(value = "/v1/get-all-stores-by-pranth-id")
	public ResponseBean getAllStoresByPranthId(@RequestParam Long pranthId, @RequestParam Long userId,
			@RequestParam Optional<String> storeName, @RequestParam Optional<Long> storeId) {
		ResponseBean responseBean = new ResponseBean();
		List<StoreFilterDTO> storesList = null;
		try {
			storesList = storeService.getAllStroesBasedOnPranthId(pranthId, userId, storeName, storeId);
		} catch (Exception e) {
			log.error("Exception occured whilemapping stores details : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption occured while mapping stores details :" + e);
		}
		if (storesList != null) {
			responseBean.setData(storesList);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setMessage("record fetched successfully");
			responseBean.setReturnCode(1);
		} else {
			responseBean.setData(null);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setMessage("no record found");
			responseBean.setReturnCode(1);
		}
		return responseBean;
	}

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class TxnPayload {
		private Long storeId;
		private Long productId;
		private Long pranthId;
		private String txnType;
		private String txnReason;
		private Date txnsFromDate;
		private Date txnsToDate;
		private Boolean isActualTxn;
		private List<String> storeBadge;
		private List<String> productBadge;
		private Integer state;
		private Integer district;
		private Integer country;
		private Integer block;
	}

	@Builder
	@Data
	public static class ProductsDTO {

		private Integer storeId;
		private String storeName;
		private Integer productId;
		private String productName;
		private Long allocatedStock;
		private Long intransitStock;
		private Long availableStock;
		private Long totalStock;
		private Long rcvngStoreAvlStock;
		private Long rcvngStoreTotalStock;
		private Long rcvngStoreIntransitStock;
		private Long rcvngStoreMinStock;
		private Long rcvngStoreMaxStock;
		private Long rcvngStoreAllocatedStock;
//		recommended stock
		// int
		private Integer days;
		private Long invMin;
		private Long invMax;
		// timestamp
		private Date lastUpdated;
		private String productBadge;
		private Long productBadgeId;
		private boolean batchManagement;
		private BigDecimal handlingQuantity;
		private Integer abnormalityType;
		private StockIndicator stockIndicator;
		private Long rcmndQuty;

	}

	@Builder
	@Data
	public static class ProductsDetails {
		private List<ProductsDTO> productsDTOs;
		private Long totalRecordCount;
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class StoresTransactionDetails {
		private List<StoresTransactionDTO> storesTransactionDTOs;
		private Long totalRecordCount;
		private String lastUpdatedOn;
	}

	@Builder
	@Data
	public static class StoreDetails {
		private List<StoreFiltersDTO> storeFiltersDTOs;
		private Long totalRecordCount;
	}
}
