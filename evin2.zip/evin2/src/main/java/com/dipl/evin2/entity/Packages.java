/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "packages")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder 
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Packages extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Long id;
	@Column(name = "package_no")
	private String packageNo;
	@Column(name = "arrival_date")
	@Temporal(TemporalType.DATE)
	private Date arrivalDate;
	@Column(name = "carrier_id")
	private Long carrierId;
	// @Max(value=?) @Min(value=?)//if you know range of your decimal fields
	// consider using these annotations to enforce field validation
	@Column(name = "package_quantity")
	private Long packageQuantity;
	@Column(name = "driver_mobile")
	private String driverMobile;
	@Column(name = "vehicle_info")
	private String vehicleInfo;
	@Column(name = "height")
	private Double height;
	@Column(name = "length")
	private Double length;
	@Column(name = "breadth")
	private Double breadth;
	@Column(name = "weight")
	private Double weight;
	@Column(name = "package_cost")
	private Double packageCost;
	@Column(name = "remarks")
	private String remarks;
	@Column(name = "package_type")
	private String packageType;
	@Column(name = "cargo_id")
	private Long cargoId;
	


}
