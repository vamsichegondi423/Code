package com.dipl.evin2.dto;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

public interface BookingDetailDTO {
	@Value(("#{target.booking_id}"))
	Long getBookingId();
	@Value(("#{target.status}"))
	 String getStatus();
	@Value(("#{target.order_reference_no}"))
	String getReference();
	@Value(("#{target.created_on}"))
	 Date getCreatedOn();
	@Value(("#{target.created_name}"))
	 String getCreatedName();
	@Value(("#{target.user_id}"))
	String getUserId();
	@Value(("#{target.updated_on}"))
	 Date getUpdatedOn();
	@Value(("#{target.updated_name}"))
	 String getUpdatedName();
	@Value(("#{target.booking_badge}"))
	 String getBookingBadge();
	@Value(("#{target.order_type_id}"))
	 Long getOrderTypeId();

		/*
		 * @Value(("#{target.processing_time}")) Date getProcessingTime();
		 */
//	@Value(("#{target.booking_id}"))
//	 Long getDeliveryLeadTime();
	@Value(("#{target.receiving_store_id}"))
	 Long getReceivingStoreId();
	@Value(("#{target.receiving_store_name}"))
	 String getReceivingStoreName();
	@Value(("#{target.receiving_store_location}"))
	 String getReceivingStoreLocation();
	@Value(("#{target.issuing_store_id}"))
	 Long getIssuingStoreId();
	@Value(("#{target.issuing_store_name}"))
	 String getIssuingStoreName();
	@Value(("#{target.issuing_store_location}"))
	 String getIssuingStoreLocation();
	@Value(("#{target.arrival_date}"))
	 Date getEstimatedDateOfArrival();  
	@Value(("#{target.booking_badge_id}"))
	Long getBookingBadgeId();
	@Value(("#{target.status_id}"))
	Long getStatusId();
	@Value(("#{target.receipt_date}"))
	 String getRequiredByDate();
	@Value(("#{target.source_type}"))
	 Integer getSourceType();
}
