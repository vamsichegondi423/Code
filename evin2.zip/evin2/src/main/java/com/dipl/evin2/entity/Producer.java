/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "producer")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder 
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Producer extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	@Basic(optional = false)
	@Column(name = "code")
	private String code;
	@Column(name = "description")
	private String description;
	@Column(name = "contact_name")
	private String contactName;
	@Column(name = "mobile")
	private String mobile;
	@Column(name = "alternate_contact_no")
	private String alternateContactNo;
	@Column(name = "email")
	private String email;
	@Column(name = "country_id")
	private Integer countryId;
	@Column(name = "state_id")
	private Integer stateId;
	@Column(name = "district_id")
	private Integer districtId;
	@Column(name = "block_id")
	private Integer blockId;
	@Column(name = "city")
	private String city;
	@Column(name = "pin")
	private String pin;
	@Column(name = "address")
	private String address;
	// @Max(value=?) @Min(value=?)//if you know range of your decimal fields
	// consider using these annotations to enforce field validation
	@Column(name = "latitude")
	private Double latitude;
	@Column(name = "logitude")
	private Double logitude;
	@Basic(optional = false)
	@Column(name = "name")
	private String name;
	@Column(name = "pranth_id")
	private Long pranthId;
	@Column(name = "is_enabled")
	private Boolean isEnabled;
	

	@Transient
	private List<ProducerBadge> producerBadges;
	@Transient
	private List<ProducerTm> producerTm;
	
	@Transient
	private String referenceId;
}
