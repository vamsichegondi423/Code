package com.dipl.evin2.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.dipl.evin2.dto.AllocatedStockDTO;
import com.dipl.evin2.dto.InTransitStockDTO;
import com.dipl.evin2.dto.StockDeviantProductsDTO;
import com.dipl.evin2.entity.Icatalogue;
import com.dipl.evin2.entity.IcatalogueLog;
import com.dipl.evin2.entity.IcataloguePranth;
import com.dipl.evin2.entity.IcatalogueProductBadge;
import com.dipl.evin2.entity.IcatalogueStoreBadge;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.service.BadgeService;
import com.dipl.evin2.service.ExecutorUtil;
import com.dipl.evin2.service.IcatalogueLogService;
import com.dipl.evin2.service.IcataloguePranthService;
import com.dipl.evin2.service.IcatalogueProductBadgeService;
import com.dipl.evin2.service.IcatalogueService;
import com.dipl.evin2.service.IcatalogueStoreBadgeService;
import com.dipl.evin2.service.PranthHierarchyService;
import com.dipl.evin2.service.RolePermissionConfigurationService;
import com.dipl.evin2.service.RolePermissionConfigurationService.RolePermissionConfigurationModel;
import com.dipl.evin2.service.StoreService;
import com.dipl.evin2.service.UsersService;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.EvinUtility;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/icatalogue")
public class IcatalogueController {

	private static final String RECORD_FETCHED_SUCCESSFULLY = "record fetched successfully";

	private static final String SUCCESSFULLY_FETCHED_DETIALS = "Successfully fetched detials";

	private static final String RECORDS_FETCHED_SUCCESSFULLY = "Records fetched successfully";

	private static final String NO_RECORDS_FOUND = "No records found";

	private static final String EXECPTION_OCCURED = "Execption Occured";

	private static final String NO_RECORD_FOUND = "No record found";

	private static final String EXCEPTION_OCCURED = "Exception occured";

	private static final String INVALID_PAYLOAD = "Invalid Payload";

	@Autowired
	private RolePermissionConfigurationService rolePermissionConfigurationService;

	@Autowired
	private IcatalogueService icatalogueService;

	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@Autowired
	private StoreService storeService;

	@Autowired
	private BadgeService badgeService;

	@Autowired
	private UsersService usersService;

	@Autowired
	private IcatalogueStoreBadgeService icatalogueStoreBadgeService;

	@Autowired
	private IcatalogueProductBadgeService icatalogueProductBadgeService;

	@Autowired
	private IcatalogueLogService icatalogueLogService;

	@Autowired
	private IcataloguePranthService icataloguePranthService;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Value("${DBURL}")
	private String dbUrl;

	@Value("${DBUSERNAME}")
	private String dbUserName;

	@Value("${DBPASSWORD}")
	private String dbPassword;

	@ApiOperation("Use this api for saving or updating Icatalogue. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	@Transactional(rollbackOn = Exception.class)
	public ResponseBean save(@RequestBody Icatalogue icatalogue, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error(INVALID_PAYLOAD);
				return ResponseBean.builder().data(null).message(INVALID_PAYLOAD).status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}

		try {
			if (icatalogue.getId() != null && icatalogue.getId() > 0) {
				Icatalogue existingIcatalogue = icatalogueService.getById(icatalogue.getId());

				if (existingIcatalogue != null) {
					icatalogue.setCreatedBy(existingIcatalogue.getCreatedBy());
					icatalogue.setCreatedOn(existingIcatalogue.getCreatedOn());
					icatalogue.setUpdatedBy(icatalogue.getCreatedBy());
					icatalogue = icatalogueService.save(icatalogue);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
				} else {
					log.info(NO_RECORD_FOUND);
					responseBean.setMessage(NO_RECORD_FOUND);
				}
			} else {
				icatalogue.setUpdatedBy(icatalogue.getUpdatedBy());
				icatalogue.setCreatedBy(icatalogue.getUpdatedBy());
				icatalogue = icatalogueService.save(icatalogue);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
			}

			if(!icatalogue.getStoreBadges().isEmpty()) {
				for (IcatalogueStoreBadge storeBadge : icatalogue.getStoreBadges()) {
					if(storeBadge.getId() != null && storeBadge.getId() > 0) {
						IcatalogueStoreBadge exIcatalogueStoreBadge = icatalogueStoreBadgeService.getById(storeBadge.getId());
						storeBadge.setCreatedBy(exIcatalogueStoreBadge.getCreatedBy());
						storeBadge.setCreatedOn(exIcatalogueStoreBadge.getCreatedOn());
					}
					IcatalogueStoreBadge icatalogueStoreBadge = IcatalogueStoreBadge.builder().badgeId(storeBadge.getBadgeId())
							.icatalogueId(icatalogue.getId()).id(storeBadge.getId()).storeId(icatalogue.getStoreId()).build();
					icatalogueStoreBadge.setCreatedBy(storeBadge.getCreatedBy());
					icatalogueStoreBadge.setUpdatedBy(storeBadge.getUpdatedBy());
					icatalogueStoreBadgeService.save(icatalogueStoreBadge);
				}
			}

			if(!icatalogue.getProductBadges().isEmpty()) {
				for (IcatalogueProductBadge productBadge : icatalogue.getProductBadges()) {
					IcatalogueProductBadge icatalogueProductBadge = null;
					if(productBadge.getId() != null && productBadge.getId() > 0) {
						IcatalogueProductBadge exIcatalogueProductBadge = icatalogueProductBadgeService.getById(productBadge.getId());
						productBadge.setCreatedBy(exIcatalogueProductBadge.getCreatedBy());
						productBadge.setCreatedOn(exIcatalogueProductBadge.getCreatedOn());
					}
					icatalogueProductBadge = IcatalogueProductBadge.builder().badgeId(productBadge.getBadgeId())
							.icatalogueId(icatalogue.getId()).id(productBadge.getId()).productId(icatalogue.getProductId()).build();
					icatalogueProductBadge.setCreatedBy(productBadge.getCreatedBy());
					icatalogueProductBadge.setUpdatedBy(productBadge.getUpdatedBy());
					icatalogueProductBadgeService.save(icatalogueProductBadge);
				}
			}

			List<IcatalogueStoreBadge> icatalogueStoreBadges = icatalogueStoreBadgeService.getByIcatalogueId(icatalogue.getId());
			List<IcatalogueProductBadge> icatalogueProductBadges = icatalogueProductBadgeService.getByIcatalogueId(icatalogue.getId());
			IcatalogueLog icatalogueLog = IcatalogueLog.builder().notes(icatalogue.getNotes()).pranthId(icatalogue.getPranthId()).productId(icatalogue.getProductId())
					.storeId(icatalogue.getStoreId()).txnId(icatalogue.getTxnId()).txnTypeId(icatalogue.getTxnTypeId()).icatalogueId(icatalogue.getId()).build();
			icatalogueLog.setCreatedBy(icatalogue.getCreatedBy());
			icatalogueLog.setUpdatedBy(icatalogue.getUpdatedBy());
			icatalogueLogService.save(icatalogueLog);

			IcataloguePranth icataloguePranth = IcataloguePranth.builder().icatalogueId(icatalogue.getId()).pranthId(icatalogue.getPranthId()).build();
			icataloguePranth.setCreatedBy(icatalogue.getCreatedBy());
			icataloguePranth.setUpdatedBy(icatalogue.getUpdatedBy());
			icataloguePranthService.save(icataloguePranth);

			icatalogue.setStoreBadges(icatalogueStoreBadges);
			icatalogue.setProductBadges(icatalogueProductBadges);
			responseBean.setData(icatalogue);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage(EXECPTION_OCCURED);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching Icatalogue record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Icatalogue icatalogue = icatalogueService.getById(id);
			if (icatalogue != null) {
				log.info(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setMessage(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setData(icatalogue);
			} else {
				log.info(NO_RECORD_FOUND);
				responseBean.setMessage(NO_RECORD_FOUND);
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage(EXECPTION_OCCURED);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting Icatalogue record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = icatalogueService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error(EXECPTION_OCCURED);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage(EXECPTION_OCCURED);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all Icatalogue records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Icatalogue> icatalogueRecords = icatalogueService.getAll();
			if (!icatalogueRecords.isEmpty()) {
				log.error(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setMessage(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setData(icatalogueRecords);
			} else {
				log.error(NO_RECORDS_FOUND);
				responseBean.setMessage(NO_RECORDS_FOUND);
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}
	@PostMapping(value = "/v1/get-abnormal-stocks", produces = "application/json")
	public ResponseBean getAbnormalStockDetails(@RequestBody IcatalogueDetailsPayload detailsPayload,
			Pageable pageable, @RequestParam(name = "pranthId") Long pranthId, @RequestParam(name="userId") Long userId) throws CustomException, JsonProcessingException {
		detailsPayload.setUserId(userId);
		ValidatorFactory validatorFactory = Validation.byDefaultProvider().configure().buildValidatorFactory();
		Validator validator = validatorFactory.getValidator();
		Set<ConstraintViolation<IcatalogueDetailsPayload>> constraintViolations = validator.validate(detailsPayload);
		validatorFactory.close();
		if (!constraintViolations.isEmpty()) {
			return ResponseBean.builder().data(null).status(HttpStatus.BAD_REQUEST).returnCode(0)
					.message(constraintViolations.iterator().next().getMessage()).build();
		}
		Users users = usersService.getById(userId);
		RolePermissionConfigurationModel permissionConfigurationModel = rolePermissionConfigurationService.getPermissionCodeValue("mnstomtbhfiv29", users.getRoleId(), pranthId);
		Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);
		List<Long> totalKioskIds = getToatalStoreIdsWithoutPagination(consolidatedPranthIds, userId, detailsPayload.getState(), detailsPayload.getDistrict(), detailsPayload.getBlock());
		List<Integer> materialTagsToHide = getMaterialTagsToHide(permissionConfigurationModel, pranthId);
		List<IcatalogueDetails> inventoryMaterialsList = icatalogueService.getAbnormalStrockDetails(detailsPayload, pageable, materialTagsToHide, totalKioskIds);
		inventoryMaterialsList.stream().forEach(inventoryMaterial -> 
			inventoryMaterial.setAbnormalityType(EvinUtility.renderAbnormalityType(inventoryMaterial.getInvMin(), inventoryMaterial.getInvMax(), inventoryMaterial.getCurrentStock()))
		);
		if(inventoryMaterialsList .isEmpty()) {
			return ResponseBean.builder().data(null).status(HttpStatus.OK).returnCode(1).message("No Record found").build();
		}

		Long totalNoOfRecordsCount = icatalogueService.getAbnormalStockCount(detailsPayload, materialTagsToHide, totalKioskIds);
		AbnormalStockData data = AbnormalStockData.builder().abnormalInventoryDetails(inventoryMaterialsList).totalRecordsCount(totalNoOfRecordsCount).build();
		return ResponseBean.builder().data(data).status(HttpStatus.OK).returnCode(1).message(SUCCESSFULLY_FETCHED_DETIALS).build();
	}

	private ResponseBean validatePayload(BindingResult bindingResult) {
		List<String> errors = null;
		try {
			if (bindingResult.hasErrors()) {
				log.error(INVALID_PAYLOAD);
				errors = bindingResult.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.toList());
				return ResponseBean.builder().data(StringUtils.collectionToCommaDelimitedString(errors)).message(INVALID_PAYLOAD).status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		}catch (Exception e) {
			return ResponseBean.builder().data(StringUtils.collectionToCommaDelimitedString(errors)).message(INVALID_PAYLOAD).status(HttpStatus.BAD_REQUEST)
					.returnCode(0).build();
		}
		return null;
	}


	@PostMapping(value = "/v1/get-stock-views")
	public ResponseBean getInventoryDetailsByFilter(@Valid @RequestBody IcatalogueDetailsPayload detailsPayload,
			Pageable pageable, BindingResult bindingResult, @RequestParam(value = "pranthId") Long pranthId, @RequestParam(value = "userId") Long userId) throws CustomException, JsonMappingException, JsonProcessingException {
		detailsPayload.setUserId(userId);
		ResponseBean responseBean = validatePayload(bindingResult);
		if(responseBean != null) {
			return responseBean;
		}
        String updatedOn = null;
		ExecutorService executor = null;
		Users users = usersService.getById(userId);
		RolePermissionConfigurationModel permissionConfigurationModel = rolePermissionConfigurationService.getPermissionCodeValue("mnstomtbhfiv29", users.getRoleId(), pranthId);
		List<Integer> materialTagsToHide = getMaterialTagsToHide(permissionConfigurationModel, pranthId);

		Map<String, List<IcatalogueDetails>> sortedResultMap = new LinkedHashMap<>();
		LinkedHashMap<String, Set<IcatalogueDetails>> inventoryDetailMap = new LinkedHashMap<>();
		Map<String, Long> totalMap = new HashMap<>();
		ValidatorFactory validatorFactory = Validation.byDefaultProvider().configure().buildValidatorFactory();
		Validator validator = validatorFactory.getValidator();
		Set<ConstraintViolation<IcatalogueDetailsPayload>> constraintViolations = validator.validate(detailsPayload);
		validatorFactory.close();
		if (!constraintViolations.isEmpty()) {
			return ResponseBean.builder().data(null).status(HttpStatus.BAD_REQUEST).returnCode(0)
					.message(constraintViolations.iterator().next().getMessage()).build();
		}
		List<Long> totalKioskIds = new ArrayList<>();
		executor = Executors.newFixedThreadPool(3);
		List<Callable<String>> callableTasks = new ArrayList<>();
		Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);
		List<Long> totalKioskIdsWithOutPagination = getToatalStoreIdsWithoutPagination(consolidatedPranthIds, userId, detailsPayload.getState(), detailsPayload.getDistrict(), detailsPayload.getBlock());
		PagedListHolder<Long> page = new PagedListHolder<>(totalKioskIdsWithOutPagination);
		page.setPageSize(pageable.getPageSize()); // number of items per page
		page.setPage(pageable.getPageNumber());  
		totalKioskIds.addAll(page.getPageList());
		if(totalKioskIds.isEmpty()) {
			return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message(NO_RECORDS_FOUND)
					.build();
		}
		try {
			Connection connection = getConnection(dbUrl, dbUserName, dbPassword);
			Statement statement = connection.createStatement();
			List<IcatalogueDetails> inventoryMaterialsList = new ArrayList<>();
			Callable<String> inventoryMaterialsListTask = () -> {
				if (detailsPayload.getIncludeStoreBadge()==null) {
				inventoryMaterialsList.addAll(icatalogueService.getInventoryDetails(detailsPayload,
						totalKioskIds, materialTagsToHide, consolidatedPranthIds));
				}
				else if(detailsPayload.getIncludeStoreBadge()!=null) {
                  List<Long> totalStoresByStoreBadge = getStoresByStoreBadgeId(consolidatedPranthIds ,detailsPayload.getIncludeStoreBadge(), userId, detailsPayload.getState(), detailsPayload.getDistrict(), detailsPayload.getBlock());
					PagedListHolder<Long> page1 = new PagedListHolder<>(totalStoresByStoreBadge);
					page1.setPageSize(pageable.getPageSize()); // number of items per page
					page1.setPage(pageable.getPageNumber());
					List<Long> totalStoresByBadge = new ArrayList<>();

					totalStoresByBadge.addAll(page1.getPageList());
					inventoryMaterialsList.addAll(icatalogueService.getInventoryDetails(detailsPayload,
							totalStoresByBadge, materialTagsToHide, consolidatedPranthIds));	
				}
				inventoryMaterialsList.stream().forEach(inventoryDetails -> {
					// Setting colors
					setColors(inventoryDetails);

					// Adding inventory materials to the map
					if (!inventoryDetailMap.containsKey(inventoryDetails.getStoreName())) {
						Set<IcatalogueDetails> inventoryDetailsList = new HashSet<>();
						inventoryDetailsList.add(inventoryDetails);
						inventoryDetailMap.put(inventoryDetails.getStoreName(), inventoryDetailsList);
					} else {
						Set<IcatalogueDetails> inventoryDetailsList = inventoryDetailMap
								.get(inventoryDetails.getStoreName());
						inventoryDetailsList.add(inventoryDetails);
						inventoryDetailMap.put(inventoryDetails.getStoreName(), inventoryDetailsList);
					}
				});
				return "Done";
			};
			callableTasks.add(inventoryMaterialsListTask);
			List<IcatalogueTotalDetails> icatalogueTotalDetails = new ArrayList<>();

			Callable<String> icatalogueTotalDetailsTask = () -> {
				icatalogueTotalDetails.addAll(icatalogueService.getInventoryTotalDetails(detailsPayload, totalKioskIdsWithOutPagination, materialTagsToHide, consolidatedPranthIds));
				icatalogueTotalDetails.stream().forEach(inventoryDetails -> totalMap.put(inventoryDetails.getProductName(), inventoryDetails.getStockTotal()));
				return "Done";
			};
			callableTasks.add(icatalogueTotalDetailsTask);
			List<Future<String>> futures = executor.invokeAll(callableTasks);
			if(inventoryMaterialsList.isEmpty()) {
				return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message(NO_RECORDS_FOUND)
						.build(); 
			}

			// Adding non inventory materials to the map
			if (detailsPayload.getProductId() == null || detailsPayload.getProductId() == 0) {

				Map<String, Long> materials = icatalogueTotalDetails.stream()
						.collect(Collectors.toMap(IcatalogueTotalDetails::getProductName, IcatalogueTotalDetails::getProductId,
								(existingValue, newValue) -> newValue));
				if (!inventoryMaterialsList.isEmpty()) {
					for (Entry<String, Long> materialEntry : materials.entrySet()) {
						Set<IcatalogueDetails> inventoryDetailsList = null;
						for (Entry<String, Set<IcatalogueDetails>> entry : inventoryDetailMap.entrySet()) {

							inventoryDetailsList = entry.getValue();
							Set<String> inventoryMaterialsStringList = entry.getValue().stream()
									.map(e -> e.getProductName()).collect(Collectors.toSet());
							IcatalogueDetails inventoryDetails = entry.getValue().iterator().next();
							if (!totalMap.containsKey(materialEntry.getKey())) {
								totalMap.put(materialEntry.getKey(), 0L);
							}
							if (!inventoryMaterialsStringList.contains(materialEntry.getKey())) {
								inventoryDetailsList.add(IcatalogueDetails.builder().city(inventoryDetails.getCity())
										.country(inventoryDetails.getCountry()).storeId(inventoryDetails.getStoreId())
										.storeName(inventoryDetails.getStoreName()).productId(materialEntry.getValue())
										.productName(materialEntry.getKey()).state(inventoryDetails.getState())
										.build());
								inventoryDetailMap.put(inventoryDetails.getStoreName(), inventoryDetailsList);
							}
						}
					}
				}
			}

			for(Entry<String, Set<IcatalogueDetails>> entry : inventoryDetailMap.entrySet()) {
				Set<IcatalogueDetails> inventoryDetailsSet = entry.getValue();
				List<IcatalogueDetails> inventoryDetailsList = new ArrayList<>(inventoryDetailsSet);
				Collections.sort(inventoryDetailsList, new Comparator<IcatalogueDetails>() {
					@Override
					public int compare(IcatalogueDetails o1, IcatalogueDetails o2) {
						return o1.getProductName().compareTo(o2.getProductName());
					}
				});
				sortedResultMap.put(entry.getKey(), inventoryDetailsList);
			}
			
			String sql = "select j.jobname, max(r.start_time) as updated_on from cron.job j join cron.job_run_details r on j.jobid=r.jobid "
					+ "where r.status='succeeded' and  j.jobname = 'mvw_stock_report' group by 1 "; 
			ResultSet resultSet = statement.executeQuery(sql);
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			while(resultSet.next()) {
				updatedOn = dateFormat.format(resultSet.getTimestamp("updated_on"));	
			}	
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
			return ResponseBean.builder().data(null).message("something went wrong").status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}finally {
			if(executor != null) {
				ExecutorUtil.shutdownAndAwaitTermination(executor);
			}
		}
		if (sortedResultMap.isEmpty()) {
			return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message(NO_RECORDS_FOUND)
					.build();
		}
		Long totalRecCount = 0L;
        if(detailsPayload.getIncludeStoreBadge()==null) {
	    totalRecCount = (long) totalKioskIdsWithOutPagination.size();
        }
	   else if(detailsPayload.getIncludeStoreBadge()!=null) {
		List<Long> totalStoresByStoreBadge = getStoresByStoreBadgeId(consolidatedPranthIds ,detailsPayload.getIncludeStoreBadge(), userId, detailsPayload.getState(), detailsPayload.getDistrict(), detailsPayload.getBlock());
        totalRecCount = (long) totalStoresByStoreBadge.size();
	    }		
        InventoryData data = InventoryData.builder().inventoryDetailMap(sortedResultMap).totalMap(totalMap)
				.totalRecordsCount(totalRecCount).lastUpdatedOn(updatedOn).build();
		return ResponseBean.builder().data(data).status(HttpStatus.OK).returnCode(1)
				.message(SUCCESSFULLY_FETCHED_DETIALS).build();
	}

	public List<Integer> getMaterialTagsToHide(RolePermissionConfigurationModel permissionConfigurationModel, Long pranthId) {
		List<Integer> materialTagIdsToHide = new ArrayList<>();
		List<Integer> materialTagsToHide = new ArrayList<>();
		if(permissionConfigurationModel != null) {
			JsonElement jsonObject = JsonParser.parseString(permissionConfigurationModel.getConfiguredValue().toString());
			JsonObject object = jsonObject.getAsJsonObject();
			if(object != null && !object.get("value").isJsonNull()) {
				JsonArray integers = object.get("value").getAsJsonArray();
				integers.forEach(m -> materialTagIdsToHide.add(m.getAsInt()));
			}
			if(!materialTagIdsToHide.isEmpty()) {
				materialTagsToHide = badgeService.getAllByIds(materialTagIdsToHide, pranthId);
			}
		}
		return materialTagsToHide;
	}

	public List<Long> getToatalStoreIdsWithoutPagination(Set<Long> pranthIds, Long userId, Integer stateId, Integer districtId, Integer blockId) {
		Set<Long> domainStoreIds = new HashSet<>();
		Users users = usersService.getById(userId);
		if(users.getRoleId() == Constants.ADMINISTRATOR_ROLE.intValue() || users.getRoleId() == Constants.OWNER_ROLE.intValue()) {
			if (!pranthIds.isEmpty()) {
				if(blockId != null) {
					domainStoreIds.addAll(storeService.getStoresByPranthIdsWithoutPagination(pranthIds, blockId, "Block"));
				} else if(districtId != null) {
					domainStoreIds.addAll(storeService.getStoresByPranthIdsWithoutPagination(pranthIds, districtId, "District"));
				} else if(stateId != null) {
					domainStoreIds.addAll(storeService.getStoresByPranthIdsWithoutPagination(pranthIds, stateId, "State"));
				} else {
					domainStoreIds.addAll(storeService.getStoresByPranthIdsWithoutPagination(pranthIds, null, null));
				}
			}
		}else {
			List<Map<String, Object>> maps = storeService.getAllStoresForUser(userId.intValue(), pranthIds.iterator().next().intValue(), null);
			maps.forEach(m -> domainStoreIds.add(Long.valueOf(m.get("store_id")+"")));
		}

		return new ArrayList<>(domainStoreIds);
	}
	
	public List<Long> getStoresByStoreBadgeId(Set<Long> pranthIdsList,List<Long> storeBadgeId, Long userId,Integer stateId, Integer districtId, Integer blockId){
		Users users = usersService.getById(userId);
		String query = null;
		int i = 0;
		StringBuilder storeBadgeIdsBuilder = new StringBuilder();
		storeBadgeIdsBuilder.append(" (");
		for (Long e : storeBadgeId) {
			storeBadgeIdsBuilder.append(e.toString());
			if (i < storeBadgeId.size() - 1) {
				storeBadgeIdsBuilder.append(" ,");
			}
			i++;
		}
		storeBadgeIdsBuilder.append(" )");
		
		int j = 0;
		StringBuilder pranthIdsBuilder = new StringBuilder();
		pranthIdsBuilder.append(" (");
		for (Long e : pranthIdsList) {
			pranthIdsBuilder.append(e.toString());
			if (j < pranthIdsList.size() - 1) {
				pranthIdsBuilder.append(" ,");
			}
			j++;
		}
		pranthIdsBuilder.append(" )");

		if(users.getRoleId() == Constants.ADMINISTRATOR_ROLE.intValue() || users.getRoleId() == Constants.OWNER_ROLE.intValue()) {
			query = " select distinct i.store_id from icatalogue i "
			 + " join store s on s.id = i.store_id "
			 + " left join store_badge sb on s.id=sb.store_id  and sb.is_deleted=false "
			 + " left join badge bd on bd.id=sb.badge_id and bd.badge_type_id=2 where i.is_deleted =false and s.is_deleted=false and bd.id in "+(storeBadgeIdsBuilder.toString()) + " and "
			 		+ " s.pranth_id in "+(pranthIdsBuilder.toString()) + " ";
		if(blockId != null) {
			query = query+" and s.block_id = "+blockId;
		}else if(districtId != null) {
			query = query+" and s.district_id = "+districtId;
		}else if(stateId != null) {
			query = query+" and s.state_id = "+stateId;
		}
		}

		return jdbcTemplate.query(query, new RowMapper<Long>() {
			@Override
			public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
				return (Long) rs.getLong("store_id");
			}
		});		
	}

	private void setColors(IcatalogueDetails inventoryDetails) {
		if (inventoryDetails.getCurrentStock() == 0) {
			inventoryDetails.setStockIndicator(StockIndicator.getStockOutIndicator());
		} else if (inventoryDetails.getCurrentStock() < inventoryDetails.getInvMin()) {
			inventoryDetails.setStockIndicator(StockIndicator.getMinimumStockIndicator());
		} else if (inventoryDetails.getCurrentStock() > inventoryDetails.getInvMax()) {
			inventoryDetails.setStockIndicator(StockIndicator.getMaximumStockIndicator());
		}
	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class StockIndicator {

		private String color;
		private String backgroundColor;
		private String borderColor;

		public static StockIndicator getStockOutIndicator() {
			return StockIndicator.builder().backgroundColor(Constants.STOCK_OUT_BACKGROUND_COLOR).borderColor(Constants.STOCK_OUT_BORDER_COLOR).color(Constants.STOCK_OUT_COLOR).build();
		}

		public static StockIndicator getMinimumStockIndicator() {
			return StockIndicator.builder().backgroundColor(Constants.MIN_STOCK_BACKGROUND_COLOR).borderColor(Constants.MIN_STOCK_BORDER_COLOR).color(Constants.MIN_STOCK_COLOR).build();
		}

		public static StockIndicator getMaximumStockIndicator() {
			return StockIndicator.builder().backgroundColor(Constants.MAX_STOCK_BACKGROUND_COLOR).borderColor(Constants.MAX_STOCK_BORDER_COLOR).color(Constants.MAX_STOCK_COLOR).build();
		}

	}

	@PostMapping("/v1/inventory-chart")
	public ResponseBean getInventoryChartDetails(@RequestBody InventoryChartPayload inventoryChartPayload) {
		IcatalogueChartDetails icatalogueChartDetails = new IcatalogueChartDetails();
		List<ChartData> chartDataList = new ArrayList<>();
		try {
			List<IcatalogueChartDetails> iicatalogueChartDetailsList = icatalogueService
					.getIcatalogueLogChartDetails(inventoryChartPayload.getPranthId());
			if (!iicatalogueChartDetailsList.isEmpty()) {
				icatalogueChartDetails = iicatalogueChartDetailsList.iterator().next();
				Long totalStock = icatalogueChartDetails.getNormalStock() + icatalogueChartDetails.getMaxStock()
				+ icatalogueChartDetails.getMinStock() + icatalogueChartDetails.getZeroStock();
				icatalogueChartDetails.setTotalStock(totalStock);
				Long normalStock = icatalogueChartDetails.getNormalStock();
				Long minStock = icatalogueChartDetails.getMinStock();
				Long maxStock = icatalogueChartDetails.getMaxStock();
				Long zeroStock = icatalogueChartDetails.getZeroStock();

				if(maxStock > 0L) {
					icatalogueChartDetails.setMaxStockPercentage(getRoundedValue(maxStock.doubleValue() / totalStock.doubleValue() * 100));
				}else {
					icatalogueChartDetails.setMaxStockPercentage(0D);
				}
				if(minStock > 0L) {
					icatalogueChartDetails.setMinStockPercentage(getRoundedValue(minStock.doubleValue() / totalStock.doubleValue() * 100));
				}else {
					icatalogueChartDetails.setMinStockPercentage(0D);
				}
				if(zeroStock > 0L) {
					icatalogueChartDetails.setZeroStockPercentage(getRoundedValue(zeroStock.doubleValue() / totalStock * 100));
				}else {
					icatalogueChartDetails.setZeroStockPercentage(0D);
				}
				if(normalStock > 0L) {
					icatalogueChartDetails.setNormalStockPercentage(getRoundedValue(normalStock.doubleValue() / totalStock.doubleValue() * 100));
				}else {
					icatalogueChartDetails.setNormalStockPercentage(0D);
				}

				chartDataList.add(ChartData.builder().isSliced("1").label("Normal").tooltext("Normal: "+icatalogueChartDetails.getNormalStock() +" of Total ("+icatalogueChartDetails.getTotalStock()+") icatalogue items").value(icatalogueChartDetails.getNormalStockPercentage()).backgroundColor(Constants.CHART_NORMAL_STOCK_BACKGROUND_COLOR).build());
				chartDataList.add(ChartData.builder().isSliced("0").label("Zero stock").tooltext("Zero stock: "+icatalogueChartDetails.getZeroStock() +" of Total ("+icatalogueChartDetails.getTotalStock()+") icatalogue items").value(icatalogueChartDetails.getZeroStockPercentage()).backgroundColor(Constants.CHART_ZERO_STOCK_BACKGROUND_COLOR).build());
				chartDataList.add(ChartData.builder().isSliced("0").label("Min").tooltext("Min: "+icatalogueChartDetails.getMinStock() +" of Total ("+icatalogueChartDetails.getTotalStock()+") icatalogue items").value(icatalogueChartDetails.getMinStockPercentage()).backgroundColor(Constants.CHART_MIN_STOCK_BACKGROUND_COLOR).build());
				chartDataList.add(ChartData.builder().isSliced("0").label("Max").tooltext("Max: "+icatalogueChartDetails.getMaxStock() +" of Total ("+icatalogueChartDetails.getTotalStock()+") icatalogue items").value(icatalogueChartDetails.getMaxStockPercentage()).backgroundColor(Constants.CHART_MAX_STOCK_BACKGROUND_COLOR).build());
			} else {
				return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message(NO_RECORDS_FOUND)
						.build();
			}
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
			return ResponseBean.builder().data(null).message("something went wrong").status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}

		return ResponseBean.builder().data(chartDataList).status(HttpStatus.OK).returnCode(1)
				.message(SUCCESSFULLY_FETCHED_DETIALS).build();
	}

	private Double getRoundedValue(Double value) {
		DecimalFormat format2Places = new DecimalFormat("0.00");
		return Double.valueOf(format2Places.format(value));
	}
	@ApiOperation("use this api to get allocated stock detilas of booking")
	@GetMapping(value="/get-allocated-stock")
	public ResponseBean getAllocatedStock (@RequestParam Long storeId, @RequestParam Long productId) {
		ResponseBean responseBean = new ResponseBean();
		List<AllocatedStockDTO> allocatedStockDTOs = null;
		try {
			allocatedStockDTOs = icatalogueService.getAllocatedStock(storeId,productId);
		} catch (Exception e) {
			responseBean.setMessage("Exception occured while getting allocated stock details" + e.getMessage());
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setReturnCode(0);
		}
		if(allocatedStockDTOs != null) {
			responseBean.setData(allocatedStockDTOs);
			responseBean.setMessage(RECORD_FETCHED_SUCCESSFULLY);
		}else {
			responseBean.setData(null);
			responseBean.setMessage(NO_RECORD_FOUND);
		}
		responseBean.setReturnCode(1);
		responseBean.setStatus(HttpStatus.OK);
		return responseBean;
	}
	@ApiOperation("use this api to get in transit stock detilas of booking")
	@GetMapping(value="/get-in-transit-stock")
	public ResponseBean getInTransitStock (@RequestParam Long storeId, @RequestParam Long productId) {
		ResponseBean responseBean = new ResponseBean();
		List<InTransitStockDTO> inTransitStockDTOs = null;
		try {
			inTransitStockDTOs = icatalogueService.getInTransitStock(storeId,productId);
		} catch (Exception e) {
			responseBean.setMessage("something went wrong");
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setReturnCode(0);
		}
		if(inTransitStockDTOs != null) {
			responseBean.setData(inTransitStockDTOs);
			responseBean.setMessage(RECORD_FETCHED_SUCCESSFULLY);
		}else {
			responseBean.setData(null);
			responseBean.setMessage(NO_RECORD_FOUND);
		}
		responseBean.setReturnCode(1);
		responseBean.setStatus(HttpStatus.OK);
		return responseBean;
	}

	@PostMapping(value="/get-stock-deviant-product")
	public ResponseBean getStockDeviantProducts (@RequestBody StockDeviantPaylod  stockDeviantPaylod) {
		ResponseBean responseBean = new ResponseBean();
		List<StockDeviantProductsDTO> stockDeviantProductsDTOs = null;
		try {
			stockDeviantProductsDTOs = icatalogueService.getStockDeviantProducts(stockDeviantPaylod);
		} catch (Exception e) {
			responseBean.setMessage("something went wrong");
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setReturnCode(0);
		}
		if(stockDeviantProductsDTOs != null) {
			responseBean.setData(stockDeviantProductsDTOs);
			responseBean.setMessage(RECORD_FETCHED_SUCCESSFULLY);
		}else {
			responseBean.setData(null);
			responseBean.setMessage(NO_RECORD_FOUND);
		}
		responseBean.setReturnCode(1);
		responseBean.setStatus(HttpStatus.OK);
		return responseBean;
	}
	
	
	@ApiOperation("Use this api for fetch pranth level  stock view product name as stock count.")
	@GetMapping(value = "/v1/get-stock-view-products-by-filter", produces = "application/json")
	public ResponseBean getAllMaterails(@RequestParam(required = true,value = "productId") Long productId,@RequestParam(required = true,value = "pranthId") Long pranthId,
			@RequestParam(required = false, value = "abnormalityType") Integer abnormalityType,
			@RequestParam(required = false, value = "duration") Long duration, Pageable pageable) {
		ProductsDetails productsDetails = null;
		ResponseBean responseBean = new ResponseBean();
		try {
			productsDetails = icatalogueService.getAllProductsBasedOnPranth(productId, abnormalityType, pranthId,
					duration, pageable);
			productsDetails.getStockViewProductsDTO().forEach(materialDTO -> {
				if (materialDTO.getAbnormalityType() != null) {
					if (materialDTO.getAbnormalityType().equals(200)) {
						materialDTO.setStockIndicator(StockIndicator.getStockOutIndicator());
					} else if (materialDTO.getAbnormalityType().equals(201)) {
						materialDTO.setStockIndicator(StockIndicator.getMinimumStockIndicator());
					} else if (materialDTO.getAbnormalityType().equals(202)) {
						materialDTO.setStockIndicator(StockIndicator.getMaximumStockIndicator());
					}
				} else {
					materialDTO.setStockIndicator(null);
				}
			});
		} catch (Exception e) {
			log.error("Exception occured while get stock view products by id : {}", e.getCause());
			e.printStackTrace();
			responseBean.setData(null);
			responseBean.setMessage("something went wrong");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if (productsDetails == null) {
			responseBean.setData(null);
			responseBean.setMessage(NO_RECORDS_FOUND);
		} else {
			responseBean.setData(productsDetails);
			responseBean.setMessage(RECORDS_FETCHED_SUCCESSFULLY);
		}
		responseBean.setReturnCode(1);
		responseBean.setStatus(HttpStatus.OK);
		return responseBean;
	}

	@ApiOperation("Use this api for fetch pranth level  stock view products based on expired date.")
	@GetMapping(value = "/v1/get-stock-view-products-by-expired-date", produces = "application/json")
	public ResponseBean getAllProductsByExpierDate(@RequestParam(required = true,value = "toDate")@DateTimeFormat(pattern="yyyy-MM-dd") Date expireBefore,@RequestParam(required = true,value = "pranthId") Long pranthId, Pageable pageable) {
		List<Map<String,Object>> fetchProductsListBasedOnExpire = null; 
		StockViewExpiredData stockViewExpiredData = null;
		try {
			fetchProductsListBasedOnExpire = icatalogueService.getAllProductsByExpierDateBasedOnPranth(pranthId,expireBefore,pageable);
			Long totalRecordsCount = icatalogueService.getAllProductsByExpierDateCount(pranthId,expireBefore);
			stockViewExpiredData = StockViewExpiredData.builder().fetchProductsListBasedOnExpire(fetchProductsListBasedOnExpire).totalRecordsCount(totalRecordsCount).build();
		} catch (Exception e) {
			log.error("Exception occured while get products by expired date : {}", e);
			return ResponseBean.builder().data(null).message("something went wrong").status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		if (fetchProductsListBasedOnExpire.isEmpty()) {
			return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message(NO_RECORDS_FOUND)
					.build();
		}
		return ResponseBean.builder().data(stockViewExpiredData).status(HttpStatus.OK).returnCode(1)
				.message(RECORDS_FETCHED_SUCCESSFULLY).build();
	}



	@ApiOperation("Use this api for update the min and max stock from excel")
	@PostMapping(value = "/v1/bulksave")
	public ResponseBean exportImportIcatalogueDetails(@RequestParam("file") MultipartFile file
			,@RequestParam (value = "userId") Long userId,@RequestParam (value = "pranthId") Long pranthId,@RequestParam (value = "userName") String  userName) {
		ResponseBean responseBean = new ResponseBean();
		try {
			responseBean = icatalogueService.uploadRecords(file, userId,pranthId, userName);
		} catch (Exception e) {
			log.error("Exception occured while fetching data", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Exception occured while fetching data" + e.getMessage());
		}
		return responseBean;
	}
	
	
	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	static class InventoryChartPayload {
		private Long pranthId;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class IcatalogueChartDetails {

		private Long pranthId;
		private Long totalStock;
		private Long normalStock;
		private Long zeroStock;
		private Long minStock;
		private Long maxStock;
		private Double normalStockPercentage;
		private Double zeroStockPercentage;
		private Double minStockPercentage;
		private Double maxStockPercentage;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class ChartData{
		private String label;
		private Double value;
		private String isSliced;
		private String tooltext;
		private String backgroundColor;
	}

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class IcatalogueDetailsPayload {
		private Long storeId;
		private Long ProductId;
		private Integer abnormalityType;
		private Date expireBefore;
		private Integer state;
		private Integer district;
		private Integer country;
		private Integer block;
		private List<Long> includeStoreBadge;
		private List<Integer> includeALLStoreBadge;
		private List<Integer> includeProductBadge;
		private List<Integer> includeAllProductBadge;
		private Long pranthId;
		private Long duration;
		private Long userId;
	}

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class StockDeviantPaylod {
		private Long storeId;
		private Long productId;
		private Integer abnormalityType;
	}
	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class IcatalogueDetails {
		private String storeName;
		private String productName;
		private Long currentStock;
		private Long invMin;
		private Long invMax;
		private Long storeId;
		private Long productId;
		private String city;
		private String state;
		private String country;
		@NotNull(message = "Pranth is mandatory")
		private Long pranthId;
		private String storageBadge;
		private String productBage;
		private String district;
		private String block;
		private String street;
		private StockIndicator stockIndicator;
		private String batchManagement;
		private Integer abnormalityType;
		private Date until;
		private String duration;
	}


	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class IcatalogueTotalDetails {
		private Long allocatedStockTotal;
		private Long inTransitStockTotal;
		private Long stockTotal;
		private Long productId;
		private String productName;
	}


	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class InventoryData {
		private Map<String, List<IcatalogueDetails>> inventoryDetailMap;
		private Map<String, Long> totalMap;
		private Long totalRecordsCount;
		private String lastUpdatedOn;

	}

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class StockViewExpiredData {
		private List<Map<String, Object>> fetchProductsListBasedOnExpire;
		private Long totalRecordsCount;
	}
	
	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class StockReportData {
		private Object stockReportDetails;
		private Long totalRecordsCount;
		
	}
	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class stockReportTotalDetails {
		private Long allocatedStockTotal;
		private Long inTransitStockTotal;
		private Long stockTotal;
		private Long productId;
		private String productName;
		private Long districtId;
		private String districtName;
		private Long stateId;
		private String stateName; 
	}

	

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class AbnormalStockData {
		private List<IcatalogueDetails> abnormalInventoryDetails;
		private Long totalRecordsCount;
	}



	@Builder
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class StockViewProductsDTO {
		private Long storeId;
		private String storeName;
		private Long productId;
		private String productName;
		private Long allocatedStock;
		private Long intransitStock;
		private Long availableStock;
		private Long totalStock;
		private Integer daysOfStock;
		private Long minStock;
		private Long maxStock;
		private Date UpdatedOn;
		private boolean isBatchEnabled;
		private Integer abnormalityType;
		private StockIndicator stockIndicator;
		private String location;
		private Long pranthId;


	}
	@Builder
	@Data
	public static class ProductsDetails{
		private List<StockViewProductsDTO> stockViewProductsDTO;
		private Long totalRecordCount;
	}
	

	private static Connection getConnection(String dbUrl, String dbUserName, String dbPaswrd) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection(dbUrl, dbUserName, dbPaswrd);
			return conn;
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
