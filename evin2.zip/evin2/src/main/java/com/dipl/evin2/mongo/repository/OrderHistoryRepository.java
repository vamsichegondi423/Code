package com.dipl.evin2.mongo.repository;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.dipl.evin2.model.OrderHistory;

@Repository
public interface OrderHistoryRepository extends MongoRepository<OrderHistory, String> {

	@Query(value = "{'orderId' : ?0}", fields = "{}")
	List<OrderHistory> findByOrderId(String orderId);

	Long countByOrderId(String orderId);

	List<OrderHistory> findByOrderIdOrderByIdAsc(String orderId);

	@Query(value = "{'status' : ?0}", fields = "{}")
	List<OrderHistory> findByStatus(String status);

	void save(String message);

}
