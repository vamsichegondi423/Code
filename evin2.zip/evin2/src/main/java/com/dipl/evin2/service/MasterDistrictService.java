package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterDistrict;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterDistrictRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterDistrictService {

	@Autowired
	private MasterDistrictRepository masterDistrictRepository;

	@Cacheable(value = "district", key = "#id")
	public MasterDistrict getById(Integer id) throws CustomException {
		try {
			Optional<MasterDistrict> masterDistrictOptional = masterDistrictRepository.getById(id);
			if (masterDistrictOptional.isPresent()) {
				return masterDistrictOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "district", key = "#masterDistrict.id")
	public MasterDistrict save(MasterDistrict masterDistrict) throws CustomException {
		try {
			if (masterDistrict.getId() != null && masterDistrict.getId() > 0) {
				Optional<MasterDistrict> existingMasterDistrictRecord = masterDistrictRepository
						.getById(masterDistrict.getId());
				if (existingMasterDistrictRecord.isPresent()) {
					masterDistrict = masterDistrictRepository.save(masterDistrict);
				}
			} else {
				masterDistrict = masterDistrictRepository.save(masterDistrict);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterDistrict;
	}

	@CacheEvict(value = "district", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterDistrict> existingMasterDistrictRecord = masterDistrictRepository.getById(id);
			if (existingMasterDistrictRecord.isPresent()) {
				masterDistrictRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "district")
	public List<MasterDistrict> getAll() {
		try {
			return masterDistrictRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}