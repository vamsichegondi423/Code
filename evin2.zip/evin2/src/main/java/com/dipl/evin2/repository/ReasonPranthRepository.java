package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.ReasonPranth;

@Repository
public interface ReasonPranthRepository extends JpaRepository<ReasonPranth, Integer> {

	@Query(value = "select * from reason_pranth where id = ?1 and is_active = true", nativeQuery = true)
	public Optional<ReasonPranth> getById(Integer id);

	
	@Query(value = " select * from reason_pranth where  pranth_id = ?1 and is_active = true", nativeQuery = true)
	public List<ReasonPranth> getAllReasonByPranthId( Long pranthId);

	@Modifying
	@Transactional
	@Query(value = "update reason_pranth set is_active = false where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

	public ReasonPranth findByPranthIdAndReasonIdAndIsActiveTrue(Long pranthId, Integer id);


	public ReasonPranth getByReasonId(Integer id);

	@Query(value = "select rp.* from reason_pranth rp join master_reason mr on mr.id = rp.reason_id where  rp.pranth_id = ?1 and mr.reason_type =?2  and mr.is_deleted = false", nativeQuery = true)
	public List<ReasonPranth> findAllByPranthId(Long pranthId, String reasonType);


	public ReasonPranth findByPranthIdAndReasonId(Long pranthId, Integer id);

}