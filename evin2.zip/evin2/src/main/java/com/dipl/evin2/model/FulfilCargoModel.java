package com.dipl.evin2.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FulfilCargoModel {

	private Long bookingId;
	private String cargoNo;
	private Long cargoId;
	private Long receievingStoreId;
	private Long issuingStoreId;
	private Long userId;
	private Long pranthId;
	private Date dateOfActualReciet;
	private String comments;
	private String sourceType;
	private Date bookingFulfilDate;
	private List<FulfillProducts> fulfillProducts;
	private List<FulfillProductBatch> fulfillProductBatch;

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class FulfillProducts {
		private Integer productId;
		private Long shippedQuantity;
		private Long fulfillQuantity;
		private Integer reasonId;
		private Long quantity;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class FulfillProductBatch extends FulfillProducts {
		private String batchNo;
		private Date expiryDate;
		private Date manufacturedDate;
		private Integer producerId;
		

	}

}
