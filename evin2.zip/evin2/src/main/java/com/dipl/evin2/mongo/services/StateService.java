package com.dipl.evin2.mongo.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.dipl.evin2.model.MasterState;
import com.dipl.evin2.mongo.repository.StateRepository;

@Service
public class StateService {
	@Autowired
	private MongoOperations mongoOperations;
	@Autowired
	MongoTemplate mongoTemplate;
	/**
	 * Atrribute logger for current class
	 */
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private StateRepository stateRepository;

	public MasterState save(MasterState state) {

		return stateRepository.save(state);
	}

	public List<MasterState> getblockc(String blockCode) {
		Query query = new Query();
		query.addCriteria(Criteria.where("districts.blocks.blockCode").is(blockCode));
		query.fields().include("districts.$");
		return mongoTemplate.find(query, MasterState.class);
	}

	public List<MasterState> getblock(String blockCode) {
		return stateRepository.findByBlockCode(blockCode);
	}
}
