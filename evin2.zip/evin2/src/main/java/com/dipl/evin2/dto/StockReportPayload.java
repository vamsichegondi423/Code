package com.dipl.evin2.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class StockReportPayload {	
	
	
		private Integer state;
		private Integer district;
		private Integer country;
		private Integer block;
		private List<Integer> materialBadge;		
	    private List<Integer> material;
	    private List<Long> storeId;

}
