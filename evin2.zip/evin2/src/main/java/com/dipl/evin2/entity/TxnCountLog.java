package com.dipl.evin2.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Siddesh.V
 *
 */
@Entity
@Table(name = "txn_count_log")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TxnCountLog  {
	@Id
	@Column(name = "id")
	private Long id;
	@Column(name = "txn_type_id")
	private Integer txnTypeId;
	@Column(name = "store_id")
	private Long storeId;
	@Column(name = "product_id")
	private Long productId;
	@Column(name = "created_date")
	@Temporal(TemporalType.DATE)
	private Date created_date;
	@Column(name = "is_read")
	private Boolean isRead;
	@Column(name = "stock")
	private Long stock;
}


