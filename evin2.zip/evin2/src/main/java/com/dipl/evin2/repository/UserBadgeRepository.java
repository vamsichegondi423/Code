package com.dipl.evin2.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dipl.evin2.entity.UserBadge;

@Repository
public interface UserBadgeRepository extends JpaRepository<UserBadge, Long>{

	@Query(value = "select  string_agg(b.name,',') as badge  from user_badge ub "
			+ " join badge b on b.id = ub.badge_id where ub.user_id = ?1 and ub.is_deleted = false", nativeQuery = true)
   List<String> getBadgeInfoByUid(Long id);

	@Query(value = "select * from user_badge where badge_id in (?1) and is_deleted = false", nativeQuery = true)
	public List<UserBadge> findAllByBadgeId(List<Integer> badgeIds);
	
	@Query(value = "select b.name as badge  from user_badge ub "
			+ " join badge b on b.id = ub.badge_id where ub.user_id = ?1 and ub.is_deleted = false", nativeQuery = true)
   List<String> getBadgeInfoByuid(Long id);
	
}
