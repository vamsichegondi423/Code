package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.Users;

@Repository
public interface UsersRepository extends JpaRepository<Users, Long> {

	@Query(value = "select * from users where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<Users> getById(Long id);



	@Modifying
	@Transactional
	@Query(value = "delete from users where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update users set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select u.* from users u join asset_users au on u.id = au.user_id and au.role_id = ?1 and u.id = ?2", nativeQuery = true)
	public List<Users> getByAssetIdAndRole(Long assetId, Integer roleId);
	
@Query(value="select u.id,u.role_id,r.name as role,u.user_id as username,bd.badges,u.last_login_time,u.last_reconnected_time,   " + 
		" concat(u.f_name,' ',u.l_name) as full_name,u.mobile,u.email,u.country_id,c.name as country,u.state_id,s.name as state,   " + 
		" u.district_id,d.name as district,u.language_id, l.name as language,u.time_zone_id,t.name as time_zone,   " + 
		" u.browser_details,u.ip_address,u.mobile_app_version,u.last_remote_login_time,u.is_deleted,  " + 
		" u.created_on,u.updated_on,u.created_by,cu.user_id as created_user,u.updated_by,uu.user_id as updated_user " + 
		" from users u    " + 
		" join master_role r on u.role_id=r.id left join master_country c on u.country_id=c.id  " + 
		" left join master_state s on u.state_id=s.id left join master_district d on u.district_id=d.id  " + 
		" left join master_language l on u.language_id=l.id left join master_time_zone t on u.time_zone_id=t.id  " + 
		" left join users cu on u.created_by=cu.id left join users uu on u.updated_by=uu.id " + 
		" left join (select user_id,string_agg(b.name,',') as badges " + 
		" from user_badge ub left join badge b on b.id=ub.badge_id group by user_id)bd on bd.user_id=u.id    " + 
		" where u.id=?1", nativeQuery = true)
	public List<Map<String, Object>> findUserDetailsById(Long userId);

@Query(value = "select * from users where user_id = ?1 ", nativeQuery = true)
public Users checkUserByName(String userName);

@Query(value = "select * from users where role_id = ?1 and is_deleted = false", nativeQuery = true)
public List<Users>  getUsersBasedOnRoleId(Integer roleId);

@Query(value = "select * from users where is_deleted = false", nativeQuery = true)
public List<Users> getAllUsers();

@Query(value = "select * from users where id in (?1) and is_deleted = false", nativeQuery = true)
public List<Users> findAllByUserIds(List<Long> userIds);

}