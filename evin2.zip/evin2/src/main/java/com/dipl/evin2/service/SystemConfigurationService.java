package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterReason;
import com.dipl.evin2.entity.PranthHierarchy;
import com.dipl.evin2.entity.SystemConfiguration;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.SystemConfigurationRepository;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SystemConfigurationService {

	@Autowired
	private SystemConfigurationRepository systemConfigurationRepository;
	
	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	public SystemConfiguration getById(Integer id) throws CustomException {
		Optional<SystemConfiguration> systemConfigurationOptional = systemConfigurationRepository.getById(id);
		if (systemConfigurationOptional.isPresent()) {
			return systemConfigurationOptional.get();
		} else {
			return null;
		}
	}

	public SystemConfiguration save(SystemConfiguration systemConfiguration) throws CustomException {
		if (systemConfiguration.getId() != null && systemConfiguration.getId() > 0) {
			Optional<SystemConfiguration> existingSystemConfigurationRecord = systemConfigurationRepository.getById(systemConfiguration.getId());
			if (existingSystemConfigurationRecord.isPresent()) {
				return systemConfigurationRepository.save(systemConfiguration);
			}
		} else {
			systemConfiguration = systemConfigurationRepository.save(systemConfiguration);
		}
		return systemConfiguration;
	}

	public Integer deleteById(Integer id) throws CustomException {
		Optional<SystemConfiguration> existingSystemConfigurationRecord = systemConfigurationRepository.getById(id);
		if (existingSystemConfigurationRecord.isPresent()) {
			systemConfigurationRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	public List<SystemConfiguration> getAll(Long pranthId) {
		List<SystemConfiguration> systemConfigurations = systemConfigurationRepository.findAll(pranthId);
		return systemConfigurations;
	}

	public SystemConfiguration getByConfigutationType(Integer configutationTypeId, Long pranthId) {
		Optional<SystemConfiguration> systemConfigurationOptional = systemConfigurationRepository.getByConfigutationType(configutationTypeId, pranthId);
		if (systemConfigurationOptional.isPresent()) {
			return systemConfigurationOptional.get();
		} else {
			return null;
		}
	}
	
	@Transactional(rollbackOn = { Exception.class , CustomException.class })
	public ResponseBean updateParentSystemConfigurationToChild(Long pranthId, Long mappedPranthId, Long userId)  throws CustomException{
		ResponseBean responseBean  = new ResponseBean();
		Long pranthid = 0L;
		List<SystemConfiguration> mrList= new ArrayList<>();
		Optional<PranthHierarchy> pranthHierarchy = pranthHierarchyService.getByMappingId(mappedPranthId);
		try {
			if(pranthHierarchy.isPresent()) {
				if(pranthId != null && pranthId != 0) {
					pranthid = pranthId;
				} else {
					pranthid = pranthHierarchy.get().getPranthId();
				}
				List<SystemConfiguration> systemConfigurationsList = systemConfigurationRepository.findAll(pranthid);
				for(SystemConfiguration sc: systemConfigurationsList) {
					Optional<SystemConfiguration> esc = systemConfigurationRepository.getByConfigutationType(sc.getConfigTypeId(), mappedPranthId);
					SystemConfiguration configuration = new SystemConfiguration();
					if (esc.isPresent()) {
						configuration = SystemConfiguration.builder().configJson(esc.get().getConfigJson()).configTypeId(esc.get().getConfigTypeId()).pranthId(mappedPranthId)
								.versionNo(esc.get().getVersionNo()+1).build();
						configuration.setCreatedBy(esc.get().getUpdatedBy());
						configuration.setCreatedOn(new Date());
						configuration.setUpdatedBy(userId);
						configuration.setUpdatedOn(new Date());
					} else {
						 configuration = SystemConfiguration.builder().configJson(sc.getConfigJson()).configTypeId(sc.getConfigTypeId()).pranthId(mappedPranthId)
								.versionNo(1).build();
						configuration.setCreatedBy(sc.getUpdatedBy());
						configuration.setCreatedOn(new Date());
						configuration.setUpdatedBy(userId);
						configuration.setUpdatedOn(new Date());
					}
					mrList.add(configuration);
				}
				systemConfigurationRepository.saveAll(mrList);
				responseBean.setMessage("SystemConfiguration has been updated for child");
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
			} else {
				responseBean.setMessage("No Record found with mappedPranthId");
				responseBean.setReturnCode(0);
				responseBean.setStatus(HttpStatus.NO_CONTENT);
			}
		}catch(Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseBean;
	}
}