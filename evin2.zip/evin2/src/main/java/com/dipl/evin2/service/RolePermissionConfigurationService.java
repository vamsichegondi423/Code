package com.dipl.evin2.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.dipl.evin2.controller.RolePermissionConfigurationController.RolePermissionDTO;
import com.dipl.evin2.controller.RolePermissionConfigurationController.RolePermissionGroupedDTO;
import com.dipl.evin2.controller.RolePermissionConfigurationController.RolePermissionGroupedDTO.ModulePermissionRoles;
import com.dipl.evin2.controller.RolePermissionConfigurationController.RolePermissionGroupedDTO.ModulePermissionRoles.PermissionRoles;
import com.dipl.evin2.entity.MasterModule;
import com.dipl.evin2.entity.MasterParentModule;
import com.dipl.evin2.entity.MasterPermission;
import com.dipl.evin2.entity.PranthHierarchy;
import com.dipl.evin2.entity.RolePermissionConfiguration;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.RolePermissionConfigurationRepository;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RolePermissionConfigurationService {

	@Autowired
	private RolePermissionConfigurationRepository rolePermissionConfigurationRepository;

	@Autowired
	private MasterPermissionService masterPermissionService;

	@Autowired
	private MasterModuleService masterModuleService;

	@Autowired
	private MasterParentModuleService masterParentModuleService;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private UsersService usersService;

	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@Autowired
	private CacheEvictor cacheEvictor;

	@Cacheable(value = "role_permission_configuration", key = "#id")
	public RolePermissionConfiguration getById(Integer id) {
		Optional<RolePermissionConfiguration> rolePermissionConfigurationOptional = rolePermissionConfigurationRepository.getById(id);
		if (rolePermissionConfigurationOptional.isPresent()) {
			return rolePermissionConfigurationOptional.get();
		} else {
			return null;
		}
	}

	public Integer getRoleTokenExpiry(String userName) throws Exception{
		Users users = usersService.findUserDetailsByName(userName);
		RolePermissionConfigurationModel configurationModel = getPermissionCodeValue("mnate45", users.getRoleId(), users.getPranthId());
		if(configurationModel != null) {
			JsonNode valueJsonNode = (JsonNode) configurationModel.getConfiguredValue();
			if(valueJsonNode != null) {
				return valueJsonNode.get("value").asInt();
			}
		}
		return null;
	}

	@CachePut(value = "role_permission_configuration", key = "#rolePermissionConfiguration.id")
	public RolePermissionConfiguration save(RolePermissionConfiguration rolePermissionConfiguration) {
		if (rolePermissionConfiguration.getId() != null && rolePermissionConfiguration.getId() > 0) {
			Optional<RolePermissionConfiguration> existingRolePermissionConfigurationRecord = rolePermissionConfigurationRepository.getById(rolePermissionConfiguration.getId());
			if (existingRolePermissionConfigurationRecord.isPresent()) {
				rolePermissionConfiguration = rolePermissionConfigurationRepository.save(rolePermissionConfiguration);
			}
		} else {
			rolePermissionConfiguration = rolePermissionConfigurationRepository.save(rolePermissionConfiguration);
		}
		cacheEvictor.evictAllCacheValues("role_permission_configuration_model");
		cacheEvictor.evictAllCacheValues("role_permission_configuration");
		cacheEvictor.evictAllCacheValues("role_permission_grouped_dto");

		return rolePermissionConfiguration;
	}

	@CacheEvict(value = "role_permission_configuration_model", allEntries = true)
	public Integer deleteById(Integer id) {
		Optional<RolePermissionConfiguration> existingRolePermissionConfigurationRecord = rolePermissionConfigurationRepository.getById(id);
		if (existingRolePermissionConfigurationRecord.isPresent()) {
			rolePermissionConfigurationRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	public RolePermissionConfiguration getByRoleAndPermission(Integer roleId, Integer permissionId, Long pranthId) {
		RolePermissionConfiguration rolePermissionConfigurations = rolePermissionConfigurationRepository.getByRoleAndPermission(roleId, permissionId, pranthId);
		return rolePermissionConfigurations;
	}

	public List<RolePermissionConfiguration> getAllByRole(Integer roleId, Long pranthId) {
		List<RolePermissionConfiguration> rolePermissionConfigurations = rolePermissionConfigurationRepository.getAllByRole(roleId, pranthId);
		return rolePermissionConfigurations;
	}

	public List<RolePermissionDTO> getRolePermissionsByRole(Integer roleId, Long pranthId) {
		List<RolePermissionDTO> rolePermissionDTOs = jdbcTemplate.query("select mp.module_id as moduleId, rp.role_id as roleId, rp.permission_id as permissionId, mp.permission_label as \n"
				+ "permissionLabel, mp.permission_code as permissionCode, rp.configured_value::text as configuredValueString, \n"
				+ "mm.module_name as moduleName, mpm.parent_module_name as parentModuleName, mpm.id as parentModuleId from master_permission mp \n"
				+ "join role_permission_configuration rp on \n"
				+ "mp.id = rp.permission_id and rp.role_id = "+roleId+" left join master_module mm on mm.id = mp.module_id left join master_parent_module mpm on mpm.id = mm.parent_module_id \n"
				+ "where mp.is_deleted = false and rp.pranth_id = "+pranthId, new BeanPropertyRowMapper<RolePermissionDTO>(RolePermissionDTO.class));
		return rolePermissionDTOs;
	}

	@Cacheable(value = "role_permission_configuration", key = "#pranthId")
	public List<RolePermissionConfiguration> getAll(Long pranthId) {
		List<RolePermissionConfiguration> rolePermissionConfigurations = rolePermissionConfigurationRepository.findAllByPranth(pranthId);
		return rolePermissionConfigurations;
	}

	public List<RolePermissionConfiguration> saveAll(List<RolePermissionConfiguration> rolePermissionConfigurations) {
		List<RolePermissionConfiguration> configurations = rolePermissionConfigurationRepository.saveAll(rolePermissionConfigurations);
		cacheEvictor.evictAllCacheValues("role_permission_configuration_model");
		cacheEvictor.evictAllCacheValues("role_permission_configuration");
		cacheEvictor.evictAllCacheValues("role_permission_grouped_dto");
		return configurations;
	}

	private List<RolePermissionConfigurationModel> findAllByPermissionCodeAndRole(List<String> permissions, int roleId, Long pranthId) {

		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("select rpc.id as rolePermissionConfigurationId, rpc.configured_value::text as configuredValueString, rpc.pranth_id as pranthId,\r\n"
				+ "rpc.role_id as roleId, mp.id as permissionId, mp.permission_code as permissionCode,\r\n"
				+ "mp.permission_label as permissionLabel, mm.id as moduleId, mm.module_name as moduleName, mpm.id as parentModuleId,\r\n"
				+ "mpm.parent_module_name as parentModuleName from role_permission_configuration rpc join master_permission mp on \r\n"
				+ "mp.id = rpc.permission_id join master_module mm on mm.id = mp.module_id join master_parent_module mpm on \r\n"
				+ "mpm.id = mm.parent_module_id where ");
		List<String> list = permissions;
		int i = 0;
		stringBuilder.append("(");
		for (String e : list) {
			stringBuilder.append(" mp.permission_code like '" + e + "'");
			if (i < list.size() - 1) {
				stringBuilder.append("  or ");
			}
			i++;
		}
		stringBuilder.append(")");
		stringBuilder.append("and rpc.pranth_id = "+pranthId+" and rpc.role_id = "+roleId+"");


		return jdbcTemplate.query(stringBuilder.toString(), new BeanPropertyRowMapper<RolePermissionConfigurationModel>(RolePermissionConfigurationModel.class));
	}

	@Cacheable(value = "role_permission_configuration_model", key = "{#permission, #roleId, #pranthId}")
	public RolePermissionConfigurationModel getPermissionCodeValue(String permission, Integer roleId, Long pranthId) {
		List<String> permissions = new ArrayList<String>();
		permissions.add(permission);
		List<RolePermissionConfigurationModel> configurationModels = findAllByPermissionCodeAndRole(permissions, roleId, pranthId);
		Optional<RolePermissionConfigurationModel> configurationModelOptional = configurationModels.stream().filter(r -> r.getPermissionCode().equals(permission)).findFirst();
		if(configurationModelOptional.isPresent()) {
			return configurationModelOptional.get();
		}
		return null;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class RolePermissionConfigurationModel implements Serializable{

		private static final long serialVersionUID = 2132465878943436740L;

		private Integer rolePermissionConfigurationId;
		private Long pranthId;
		private Integer roleId;
		private Integer permissionId;
		private String permissionCode;
		private String permissionLabel;
		private Integer moduleId;
		private String moduleName;
		private Integer parentModuleId;
		private String parentModuleName;
		
		@JsonIgnore
		private String configuredValueString;

		public JsonNode getConfiguredValue(){
			try {
				return this.configuredValueString != null ? new ObjectMapper().readTree(this.configuredValueString) : null;
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			return null;
		}

	}

	@Cacheable(value = "role_permission_grouped_dto", key = "{#roleId, #pranthId}")
	public List<RolePermissionGroupedDTO> getRolePermissions(Integer roleId, Long pranthId) {
		List<RolePermissionDTO> rolePermissionDTOs = getRolePermissionsByRole(roleId, pranthId);

		Map<String, RolePermissionDTO> rolePermissionDTOMap = rolePermissionDTOs.stream().collect(Collectors.toMap(r -> r.getPermissionId()+"-"+r.getRoleId()+"-"+pranthId, r -> r));

		List<MasterModule> masterModules = masterModuleService.getAll();
		List<MasterParentModule> masterParentModules = masterParentModuleService.getAll();
		List<MasterPermission> masterPermissions = masterPermissionService.getAll();

		Map<Integer, MasterParentModule> masterParentModulesMap = masterParentModules.stream().collect(Collectors.toMap(MasterParentModule::getId, MasterParentModule->MasterParentModule));
		Map<Integer, List<MasterModule>> masterModulesByParentModuleMap = masterModules.stream().collect(Collectors.groupingBy(MasterModule::getParentModuleId));
		Map<Integer, List<MasterPermission>> masterPermissionsByModuleMap = masterPermissions.stream().collect(Collectors.groupingBy(MasterPermission::getModuleId));

		List<RolePermissionGroupedDTO> rolesPermissionGroupedDTOs = new ArrayList<>();
		for(Entry<Integer, MasterParentModule> masterParentModuleEntry : masterParentModulesMap.entrySet()) {
			List<ModulePermissionRoles> modulePermissionRolesList = new ArrayList<>();
			for(MasterModule masterModule : masterModulesByParentModuleMap.get(masterParentModuleEntry.getKey())) {
				List<PermissionRoles> permissionRolesList = new ArrayList<>();
				for(MasterPermission masterPermission : masterPermissionsByModuleMap.get(masterModule.getId())) {
					RolePermissionDTO rolePermissionDTO = rolePermissionDTOMap.get(masterPermission.getId()+"-"+roleId+"-"+pranthId);
					String configuredValueString = rolePermissionDTO != null ? rolePermissionDTO.getConfiguredValueString() : null;
					PermissionRoles permissionRoles = PermissionRoles.builder().inputType(masterPermission.getInputType()).configuredValueString(configuredValueString)
							.permissionCode(masterPermission.getPermissionCode()).permissionId(masterPermission.getId())
							.permissionLabel(masterPermission.getPermissionLabel()).roleId(roleId).build();
					permissionRolesList.add(permissionRoles);
				}
				ModulePermissionRoles modulePermissionRoles = ModulePermissionRoles.builder().moduleId(masterModule.getId()).moduleName(masterModule.getModuleName()).permissionRoles(permissionRolesList).build();
				modulePermissionRolesList.add(modulePermissionRoles);				}
			RolePermissionGroupedDTO rolePermissionGroupedDTO = RolePermissionGroupedDTO.builder().modulePermissionRoles(modulePermissionRolesList)
					.parentModuleId(masterParentModuleEntry.getValue().getId()).parentModuleName(masterParentModuleEntry.getValue().getParentModuleName()).build();
			rolesPermissionGroupedDTOs.add(rolePermissionGroupedDTO);
		}
		return rolesPermissionGroupedDTOs;
	}
	
	
	@Transactional(rollbackOn = { Exception.class , CustomException.class })
	public ResponseBean updateParentRoleToChild(Long pranthId, Long mappedPranthId, Long userId) throws CustomException {
		ResponseBean responseBean  = new ResponseBean();
		Long pranthid = 0L;
		List<RolePermissionConfiguration> rpList= new ArrayList<>();
		Optional<PranthHierarchy> pranthHierarchy = pranthHierarchyService.getByMappingId(mappedPranthId);
		try {
			if(pranthHierarchy.isPresent()) {
				if(pranthId != null && pranthId != 0) {
					pranthid = pranthId;
				} else {
					pranthid = pranthHierarchy.get().getPranthId();
				}
				List<RolePermissionConfiguration> permissionConfigurationsList = rolePermissionConfigurationRepository.findAllByPranth(pranthid);
				for(RolePermissionConfiguration rp:permissionConfigurationsList) {
					RolePermissionConfiguration configuration = new RolePermissionConfiguration();
					RolePermissionConfiguration rpExists = rolePermissionConfigurationRepository.getByRoleAndPermission(rp.getRoleId(),rp.getPermissionId(),mappedPranthId);
					if(rpExists == null) {
						configuration = RolePermissionConfiguration.builder().configuredValue(rp.getConfiguredValue()).permissionId(rp.getPermissionId())
								.pranthId(mappedPranthId).roleId(rp.getRoleId()).build();
						configuration.setCreatedBy(userId);
						configuration.setUpdatedBy(userId);
						rpList.add(configuration);
					}
					
				}
				rolePermissionConfigurationRepository.saveAll(rpList);
				responseBean.setMessage("RoleConfiguartions has been updated for child");
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
			} else {
				responseBean.setMessage("No Record found with mappedPranthId");
				responseBean.setReturnCode(0);
				responseBean.setStatus(HttpStatus.NO_CONTENT);
			}
		}catch(Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseBean;
	}
}