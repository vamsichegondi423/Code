package com.dipl.evin2.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.dipl.evin2.model.TxnLogDetails;

public interface TxnLogDetailsRepository extends MongoRepository<TxnLogDetails, String> {

}
