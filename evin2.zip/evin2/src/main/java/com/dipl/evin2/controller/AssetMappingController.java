package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.controller.AssetController.AssetModelDetailsDTO;
import com.dipl.evin2.entity.AssetMapping;
import com.dipl.evin2.entity.AssetModelSensorMapping;
import com.dipl.evin2.entity.AssetMonitoringPointSensor;
import com.dipl.evin2.entity.AssetTypeMonitoringPoint;
import com.dipl.evin2.service.AssetMappingService;
import com.dipl.evin2.service.AssetMappingService.AssetMappingDTO;
import com.dipl.evin2.service.AssetModelSensorMappingService;
import com.dipl.evin2.service.AssetMonitoringPointSensorService;
import com.dipl.evin2.service.AssetService;
import com.dipl.evin2.service.AssetTypeMonitoringPointService;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/asset-mapping")
public class AssetMappingController {

	@Autowired
	private AssetMappingService assetMappingService;

	@Autowired
	private AssetModelSensorMappingService assetModelSensorMappingService;

	@Autowired
	private AssetTypeMonitoringPointService assetTypeMonitoringPointService;

	@Autowired
	private AssetMonitoringPointSensorService assetMonitoringPointSensorService;

	@Autowired
	private AssetService assetService;

	@Transactional(rollbackFor = Exception.class)
	@ApiOperation("Use this api for saving or updating AssetMapping. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody AssetMapping assetMapping, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {

			AssetMapping mapping = assetMappingService.getAssetMapping(assetMapping.getAssetId(), assetMapping.getMappedAssetId());
			if(mapping != null) {
				log.info("Asset mapping already exists.");
				return ResponseBean.builder().data(null).message("Asset mapping already exists.").status(HttpStatus.EXPECTATION_FAILED).returnCode(0).build();

			}

			AssetMappingDTO mappedAsset = assetMappingService.getMappedAssetByAssetId(assetMapping.getAssetId());
			if(mappedAsset != null) {
				log.error("Asset mapping already exists for this asset.");
				return ResponseBean.builder().data(null).message("Asset mapping already exists for this asset.").status(HttpStatus.EXPECTATION_FAILED).returnCode(0).build();

			}
			
			AssetModelDetailsDTO assetModelDetailsDTO = assetService.getAssetModelDetails(assetMapping.getAssetId());
			AssetModelDetailsDTO mappedAssetModelDetailsDTO = assetService.getAssetModelDetails(assetMapping.getMappedAssetId());
			if(assetModelDetailsDTO.getAssetTypeId().equals(Constants.ASSET_TYPE_TEMPERATURE_LOGGER)) {
				log.error("Temperature logger cannot be a Mapping asset.");
				return ResponseBean.builder().data(null).message("Temperature logger cannot be a Mapping asset.").status(HttpStatus.EXPECTATION_FAILED)
						.returnCode(0).build();
			}
			if(!mappedAssetModelDetailsDTO.getAssetTypeId().equals(Constants.ASSET_TYPE_TEMPERATURE_LOGGER)) {
				log.error("Mapped asset should be a temeperature logger.");
				return ResponseBean.builder().data(null).message("Mapped asset should be a temeperature logger.").status(HttpStatus.EXPECTATION_FAILED)
						.returnCode(0).build();
			}
			List<AssetTypeMonitoringPoint> assetTypeMonitoringPoints = assetTypeMonitoringPointService.getByAssetType(Long.valueOf(assetModelDetailsDTO.getAssetTypeId()));
			if(assetTypeMonitoringPoints.isEmpty()) {
				log.error("No monitoring points exists for this asset type.");
				return ResponseBean.builder().data(null).message("No monitoring points exists for this asset type.").status(HttpStatus.EXPECTATION_FAILED)
						.returnCode(0).build();
			}
			List<AssetModelSensorMapping> assetModelSensorMappings = assetModelSensorMappingService.getByAssetModel(Long.valueOf(mappedAssetModelDetailsDTO.getModelId()));
			if(assetModelSensorMappings.isEmpty()) {
				log.error("No sensors exists for this asset model.");
				return ResponseBean.builder().data(null).message("No sensors exists for this asset model.").status(HttpStatus.EXPECTATION_FAILED)
						.returnCode(0).build();
			}
			if(assetTypeMonitoringPoints.size() > assetModelSensorMappings.size()) {
				log.error("Number of monitor points for this asset is greater than number of sensors in mapped temperature logger.");
				return ResponseBean.builder().data(null).message("Number of monitor points for this asset is greater than number of sensors in mapped temperature logger.").status(HttpStatus.EXPECTATION_FAILED)
						.returnCode(0).build();
			}
			if (assetMapping.getId() != null && assetMapping.getId() > 0) {
				AssetMapping existingAssetMapping = assetMappingService.getById(assetMapping.getId());
				if (existingAssetMapping != null) {
					assetMapping = assetMappingService.save(assetMapping);
					saveAssetMonitoringPointSensor(assetMapping, assetTypeMonitoringPoints, assetModelSensorMappings);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(assetMapping);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				assetMapping = assetMappingService.save(assetMapping);
				saveAssetMonitoringPointSensor(assetMapping, assetTypeMonitoringPoints, assetModelSensorMappings);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(assetMapping);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	private void saveAssetMonitoringPointSensor(AssetMapping assetMapping, List<AssetTypeMonitoringPoint> assetTypeMonitoringPoints, List<AssetModelSensorMapping> assetModelSensorMappings) {
		if(!assetTypeMonitoringPoints.isEmpty() && !assetModelSensorMappings.isEmpty()) {
			Set<String> monitoringPoints = null;
			List<AssetMonitoringPointSensor> assetMonitoringPointSensors = new ArrayList<>();
			monitoringPoints = assetTypeMonitoringPoints.stream().map(AssetTypeMonitoringPoint::getMonitoringPoint).collect(Collectors.toSet());
			if(monitoringPoints.stream().anyMatch("Middle"::equalsIgnoreCase)) {
				addMonitoringPointSensor(assetMapping, assetMonitoringPointSensors, "Middle", "B");
			}
			if(monitoringPoints.stream().anyMatch("Ambient"::equalsIgnoreCase)) {
				addMonitoringPointSensor(assetMapping, assetMonitoringPointSensors, "Ambient", "D");
			}
			if(monitoringPoints.stream().anyMatch("Left"::equalsIgnoreCase)) {
				addMonitoringPointSensor(assetMapping, assetMonitoringPointSensors, "Left", "A");
			}
			if(monitoringPoints.stream().anyMatch("Top"::equalsIgnoreCase)) {
				addMonitoringPointSensor(assetMapping, assetMonitoringPointSensors, "Top", "C");
			}
			if(monitoringPoints.stream().anyMatch("Right"::equalsIgnoreCase)) {
				addMonitoringPointSensor(assetMapping, assetMonitoringPointSensors, "Right", "E");
			}
			assetMonitoringPointSensorService.saveAll(assetMonitoringPointSensors);
		}
	}

	private void addMonitoringPointSensor(AssetMapping assetMapping,
			List<AssetMonitoringPointSensor> assetMonitoringPointSensors, String monitoringPoint, String sensor) {
		AssetMonitoringPointSensor existingAssetMonitoringPointSensor = assetMonitoringPointSensorService.getByMonitoringPointAndAsset(monitoringPoint, assetMapping.getMappedAssetId());
		AssetMonitoringPointSensor assetMonitoringPointSensor = AssetMonitoringPointSensor.builder().assetId(assetMapping.getMappedAssetId()).monitoringPoint(monitoringPoint).sensor(sensor).build();
		if(existingAssetMonitoringPointSensor != null) {
			assetMonitoringPointSensor.setId(existingAssetMonitoringPointSensor.getId());
			assetMonitoringPointSensor.setSensor(sensor);
		}
		assetMonitoringPointSensors.add(assetMonitoringPointSensor);
	}

	@ApiOperation("Use this api for fetching AssetMapping record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			AssetMapping assetMapping = assetMappingService.getById(id);
			if (assetMapping != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(assetMapping);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting AssetMapping record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = assetMappingService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all AssetMapping records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<AssetMapping> assetMappingRecords = assetMappingService.getAll();
			if (!assetMappingRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(assetMappingRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
}