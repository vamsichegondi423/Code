package com.dipl.evin2.entity;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author madhumohan.p 27-Aug-2021
 */
@Entity
@Table(name = "txn_consumption_log")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TxnConsumptionLog {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	private Long id;
	@Column(name = "store_id")
	private Long storeId;
	@Column(name = "product_id")
	private Long productId;
	@Column(name = "txn_date")
	private Date txnDate;
	@Column(name = "is_consumption_read")
	private Boolean isConsumptionRead;
	@Column(name = "txn_type_id")
	private Integer txnTypeId;
	@Column(name = "txn_count")
	private Integer txnCount;
	@Column(name = "is_txn_count_read")
	private Boolean isTxnCountRead;
}
