package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.dto.BatchProductDTO;
import com.dipl.evin2.dto.StockDetailsDTO;
import com.dipl.evin2.dto.TxnDTO;
import com.dipl.evin2.entity.IcatalogueBatch;

@Repository
public interface IcatalogueBatchRepository extends JpaRepository<IcatalogueBatch, Long> {

	@Query(value = "select * from icatalogue_batch where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<IcatalogueBatch> getById(Long id);

	@Query(value = "select * from icatalogue_batch where is_deleted = false", nativeQuery = true)
	public List<IcatalogueBatch> findAll();

	@Query(value = "select * from icatalogue_batch where icatalogue_id = ?1 and batch_no = ?2 and is_deleted = false", nativeQuery = true)
	public IcatalogueBatch getIcatalogueBatch(Long icatalogueId, String batchNo);

	@Modifying
	@Transactional
	@Query(value = "delete from icatalogue_batch where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update icatalogue_batch set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "SELECT * from icatalogue_batch icb "
			+ " join icatalogue ic on icb.icatalogue_id = ic.id and ic.is_deleted = false "
			+ " where icb.is_deleted = false and icb.product_id  = ?1 and icb.batch_no=?2 and icb.icatalogue_id =?3 order by icb.created_on desc limit 1", nativeQuery = true)
	public IcatalogueBatch findIcatalogueBatchByBId(Integer productId, String bid, Long IcatId);

	@Query(value = "select sum(icb.available_stock) as quantity from icatalogue_batch icb  "
			+ " join icatalogue ic on icb.icatalogue_id = ic.id and ic.is_deleted = false  "
			+ " where icb.is_deleted = false and icb.product_id  = ?1 and icatalogue_id =?2 order by 1", nativeQuery = true)
	public Long getTotalStockQuantity(Integer productId, Long icatId);

	@Query(value = "select sum(icb.allocated_stock) as quantity from icatalogue_batch icb "
			+ " join icatalogue ic on icb.icatalogue_id = ic.id and ic.is_deleted = false where icb.icatalogue_id=?1 and icb.product_id  = ?2 and icb.is_deleted = false order by 1", nativeQuery = true)
	public Long getTotalAllocatedStockQuantity(Long icatId, Integer productId);

	@Query(value = "select sum(icb.allocated_stock) :::: bigint as allocatedStock,sum(icb.quantity):::: bigint as quantity,sum(icb.total_stock):::: bigint as totalStock,sum(icb.available_stock):::: bigint as availableStock,ic.in_transit_stock as intransitStock   "
			+ "from icatalogue_batch icb "
			+ "join icatalogue ic on icb.icatalogue_id = ic.id and ic.is_deleted = false "
			+ "where icb.is_deleted = false and icb.icatalogue_id=?1 and icb.product_id  = ?2 group by 5 order by 1", nativeQuery = true)
	public StockDetailsDTO getTotalAlc_Cur_Total_StockQuantity(Long icatId, Integer productId);

	@Query(value = "SELECT * from icatalogue_batch ib"
			+ " join icatalogue i on i.id = ib.icatalogue_id and i.is_deleted = false "
			+ "where ib.is_deleted = false and ib.product_id = ?1 and i.store_id = ?2  "
			+ "and ib.expiry_date > current_date and i.current_stock > 0 and ib.available_stock > 0 order by ib.expiry_date asc", nativeQuery = true)
	public List<IcatalogueBatch> getBatchesByMID(Integer productId, Long StoreId);

	@Query(value = "select * from icatalogue_batch where icatalogue_id = ?1 and batch_no = ?2 and product_id = ?3 and producer_id = ?4 and is_deleted = false ", nativeQuery = true)
	public IcatalogueBatch getDetailsOfIcatalougeBatch(Long icatalougeId, String batchNo, Integer productId,
			Integer producerId);

	@Query(value = "select * from icatalogue_batch where  product_id = ?1 and batch_no = ?2 and icatalogue_id=?3 and producer_id =?4 and is_deleted = false", nativeQuery = true)
	public IcatalogueBatch getBatchDetails(Integer productId, String batchId, Long iCatId, Integer producerId);

	@Query(value = "select * from icatalogue_batch where  icatalogue_id = ?1 and product_id = ?2 and is_deleted = false", nativeQuery = true)
	public IcatalogueBatch totalStock(Long icatId, Long prodId);

	@Query(value = "select icb.manufactured_date,icb.expiry_date,p.name as manufacturer,txn.batch_no, txn.opening_stock_batch,txn.closing_stock_batch "
			+ "from icatalogue_batch icb "
			+ "join txn on txn.icatalogue_id = icb.icatalogue_id and   icb.batch_no=txn.batch_no  and  icb.producer_id=txn.producer_id "
			+ "join producer p on p.id = icb.producer_id "
			+ "where icb.batch_no =?1 and icb.product_id=?2 and icb.icatalogue_id =?3 and txn.id=?4 and icb.is_deleted = false and txn.is_deleted = false ", nativeQuery = true)
	public List<TxnDTO> getBatchDetailsBasedOnTxnIdAndBatchNo(String batchNo, Long productId, Long icatId, Long txnId);

	@Query(value = "select producer_id from icatalogue_batch where  icatalogue_id = ?1 and product_id = ?2 and batch_no=?3 and is_deleted = false", nativeQuery = true)
	public Integer findProducerId(Long icatId, Integer prodId, String batchNo);

	@Query(value = "select icb.batch_no,icb.manufactured_date,p.name as manufacture_name ,p.id as manufacture_id, icb.expiry_date,icb.total_stock,icb.allocated_stock,icb.available_stock,icb.quantity "
			+ "from icatalogue_batch icb " + "left join producer p on p.id = icb.producer_id "
			+ "where icb.icatalogue_id = ?1 and  icb.expiry_date  >= current_date  and icb.available_stock >0 and icb.is_deleted = false  order by icb.expiry_date ", nativeQuery = true)
	public List<BatchProductDTO> findByIcatalougeId(Long id);

	@Query(value = " SELECT * from icatalogue_batch icb where "
			+ " icb.product_id  =?1 and icb.batch_no=?2 and icb.icatalogue_id =?3 and icb.producer_id =?4 and icb.is_deleted = false order by icb.created_on desc limit 1", nativeQuery = true)
	public IcatalogueBatch findIcatalogueBatchByBIdAndPidIcatId(Integer productId, String bid, Long id,
			Integer producerId);

	@Query(value = "SELECT * from icatalogue_batch where batch_no=?1 and product_id=?2 and producer_id=?3 LIMIT 1", nativeQuery = true)
	public IcatalogueBatch findBatchDetails(String batchNo, Integer productId, Integer producerId);

}