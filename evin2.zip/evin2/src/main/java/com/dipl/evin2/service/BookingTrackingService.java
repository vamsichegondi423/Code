package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.BookingTracking;
import com.dipl.evin2.entity.Bookings;
import com.dipl.evin2.entity.Cargo;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.BookingTrackingRepository;
import com.dipl.evin2.repository.BookingsRepository;
import com.dipl.evin2.repository.CargoRepository;
import com.dipl.evin2.repository.UsersRepository;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BookingTrackingService {

	@Autowired
	private BookingTrackingRepository bookingTrackingRepository;
	@Autowired
	private BookingsRepository bookingRepository;

	@Autowired
	private CargoRepository cargoRepository;

	@Autowired
	private UsersRepository userRepository;

	@Value("${booking.pending}")
	private String pending;
	@Value("${booking.confirmed}")
	private String confirmed;
	@Value("${booking.readyForDispatch}")
	private String readyForDispatch;
	@Value("${booking.shiped}")
	private String shiped;
	@Value("${booking.fulfiled}")
	private String fulfiled;
	@Value("${booking.cancelled}")
	private String cancelled;

	public BookingTracking getById(Long id) throws CustomException {
		try {
			Optional<BookingTracking> bookingTrackingOptional = bookingTrackingRepository.getById(id);
			if (bookingTrackingOptional.isPresent()) {
				return bookingTrackingOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public BookingTracking save(BookingTracking bookingTracking) throws CustomException {
		try {
			if (bookingTracking.getId() != null && bookingTracking.getId() > 0) {
				Optional<BookingTracking> existingBookingTrackingRecord = bookingTrackingRepository
						.getById(bookingTracking.getId());
				if (existingBookingTrackingRecord.isPresent()) {
					return bookingTrackingRepository.save(bookingTracking);
				}
			} else {
				bookingTracking = bookingTrackingRepository.save(bookingTracking);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return bookingTracking;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<BookingTracking> existingBookingTrackingRecord = bookingTrackingRepository.getById(id);
			if (existingBookingTrackingRecord.isPresent()) {
				bookingTrackingRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<BookingTracking> getAll() {
		try {
			return bookingTrackingRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public List<BookingTracking> findByObjectid(Long cargoId) {
		try {
			List<BookingTracking> bookingTrackingList = bookingTrackingRepository.findByObjectId(cargoId);
			return bookingTrackingList;
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return null;
	}

	public ResponseBean getBookingStatus(Long bookingId) throws Exception {
		ResponseBean responseBean = new ResponseBean();
		List<BookingTracking> bookingTrackings = null;
		List<BookingStatus> BookingStatus = new ArrayList<BookingStatus>();
		boolean flag = false;
		boolean tflag = true;
		Date confirmeddate = null;
		Date pendingdate = null;
		Date fulfilleddate = null;
		Date shippeddate = null;
		Date rpdate = null;
		Date cndate = null;
		String pCreatedBy = null;
		String cCreatedBy = null;
		String rCreatedBy = null;
		String shCreatedBy = null;
		String fCreatedBy = null;
		String cndateCreatedBy = null;
		try {
			bookingTrackings = bookingTrackingRepository.getStatusByBooking(bookingId);
			if (!bookingTrackings.isEmpty() && bookingTrackings != null) {
				for (BookingTracking bkTracking : bookingTrackings) {
					if (bkTracking.getStatusId().equals(5)) {
						pendingdate = bkTracking.getCreatedOn();
						pCreatedBy = findUserById(bkTracking);
					}
					if (bkTracking.getStatusId().equals(6)) {
						confirmeddate = bkTracking.getCreatedOn();
						cCreatedBy = findUserById(bkTracking);
					}
					if (bkTracking.getStatusId().equals(4)) {
						rpdate = bkTracking.getCreatedOn();
						rCreatedBy = findUserById(bkTracking);
					}
					if (bkTracking.getStatusId().equals(7)) {
						shippeddate = bkTracking.getCreatedOn();
						shCreatedBy = findUserById(bkTracking);
					}
					if (bkTracking.getStatusId().equals(2)) {
						fulfilleddate = bkTracking.getCreatedOn();
						fCreatedBy = findUserById(bkTracking);
					}
					if (bkTracking.getStatusId().equals(1)) {
						cndate = bkTracking.getCreatedOn();
						cndateCreatedBy = findUserById(bkTracking);
					}
				}
				getBookingStatusByBooking(bookingId, responseBean, BookingStatus, flag, tflag, confirmeddate,
						pendingdate, fulfilleddate, shippeddate, rpdate, cndate, pCreatedBy, cCreatedBy, rCreatedBy,
						shCreatedBy, fCreatedBy, cndateCreatedBy);
			} else {
				responseBean.setMessage("No record found with this booking id " + bookingId);
				responseBean.setStatus(HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Exception occured booking tracking service" + e.getMessage());
			throw new Exception("Exception occured booking tracking service" + e.getCause());
		}

		return responseBean;
	}

	private String findUserById(BookingTracking bstatus) {
		Optional<Users> user;
		String createdBy = null;
		user = userRepository.findById(bstatus.getCreatedBy());
		if (bstatus.getStatusId().equals(5)) {
			createdBy = user.get().getUserId();
		}
		if (bstatus.getStatusId().equals(6)) {
			createdBy = user.get().getUserId();
		}
		if (bstatus.getStatusId().equals(4)) {
			createdBy = user.get().getUserId();
		}
		if (bstatus.getStatusId().equals(7)) {
			createdBy = user.get().getUserId();
		}
		if (bstatus.getStatusId().equals(2)) {
			createdBy = user.get().getUserId();
		}
		if (bstatus.getStatusId().equals(1)) {
			createdBy = user.get().getUserId();
		}
		return createdBy;
	}

	private void getBookingStatusByBooking(Long bookingId, ResponseBean responseBean, List<BookingStatus> BookingStatus,
			boolean flag, boolean tflag, Date confirmeddate, Date pendingdate, Date fulfilleddate, Date shippeddate,
			Date rpdate, Date cndate, String pCreatedBy, String cCreatedBy, String rCreatedBy, String shCreatedBy,
			String fCreatedBy, String cndateCreatedBy) {
		BookingTracking bookingTracking = null;
		bookingTracking = bookingTrackingRepository.getStatusByBkid(bookingId);
		if (bookingTracking != null) {
			if (bookingTracking.getStatusId().equals(5)) {
				BookingStatus.add(new BookingStatus(pending, tflag, pendingdate, pCreatedBy));
				BookingStatus.add(new BookingStatus(confirmed, flag, confirmeddate, null));
				BookingStatus.add(new BookingStatus(readyForDispatch, flag, rpdate, null));
				BookingStatus.add(new BookingStatus(shiped, flag, shippeddate, null));
				BookingStatus.add(new BookingStatus(fulfiled, flag, fulfilleddate, null));
			}
			if (bookingTracking.getStatusId().equals(6)) {
				BookingStatus.add(new BookingStatus(pending, tflag, pendingdate == null ? confirmeddate : pendingdate, pCreatedBy == null ? cCreatedBy : pCreatedBy ));
				BookingStatus.add(new BookingStatus(confirmed, tflag, confirmeddate, cCreatedBy));
				BookingStatus.add(new BookingStatus(readyForDispatch, flag, rpdate, null));
				BookingStatus.add(new BookingStatus(shiped, flag, shippeddate, null));
				BookingStatus.add(new BookingStatus(fulfiled, flag, fulfilleddate, null));
			}
			if (bookingTracking.getStatusId().equals(4)) {
				BookingStatus.add(new BookingStatus(pending, tflag, pendingdate == null ? confirmeddate : pendingdate, pCreatedBy == null ? cCreatedBy : pCreatedBy ));
				BookingStatus.add(new BookingStatus(confirmed, tflag, confirmeddate, cCreatedBy));
				BookingStatus.add(new BookingStatus(readyForDispatch, tflag, rpdate, rCreatedBy));
				BookingStatus.add(new BookingStatus(shiped, flag, shippeddate, null));
				BookingStatus.add(new BookingStatus(fulfiled, flag, fulfilleddate, null));
			}
			if (bookingTracking.getStatusId().equals(7)) {
				BookingStatus.add(new BookingStatus(pending, tflag, pendingdate == null ? confirmeddate : pendingdate, pCreatedBy == null ? cCreatedBy : pCreatedBy ));
				BookingStatus.add(new BookingStatus(confirmed, tflag, confirmeddate, cCreatedBy));
				BookingStatus.add(new BookingStatus(readyForDispatch, tflag, rpdate, rCreatedBy));
				BookingStatus.add(new BookingStatus(shiped, tflag, shippeddate, shCreatedBy));
				BookingStatus.add(new BookingStatus(fulfiled, flag, fulfilleddate, null));
			}
			if (bookingTracking.getStatusId().equals(2)) {
				BookingStatus.add(new BookingStatus(pending, tflag, pendingdate == null ? confirmeddate : pendingdate, pCreatedBy == null ? cCreatedBy : pCreatedBy ));
				BookingStatus.add(new BookingStatus(confirmed, tflag, confirmeddate, cCreatedBy));
				BookingStatus.add(new BookingStatus(readyForDispatch, tflag, rpdate, rCreatedBy));
				BookingStatus.add(new BookingStatus(shiped, tflag, shippeddate, shCreatedBy));
				BookingStatus.add(new BookingStatus(fulfiled, tflag, fulfilleddate, fCreatedBy));
			}
			if (bookingTracking.getStatusId().equals(1)) {
				BookingStatus.add(new BookingStatus(pending, tflag, pendingdate == null ? confirmeddate : pendingdate, pCreatedBy == null ? cCreatedBy : pCreatedBy ));
				if(confirmeddate != null) {
					BookingStatus.add(new BookingStatus(confirmed, tflag, confirmeddate, cCreatedBy));
				}
				if (rpdate != null) {
					BookingStatus.add(new BookingStatus(readyForDispatch, tflag, rpdate, rCreatedBy));
				}
				if (shippeddate != null) {
					BookingStatus.add(new BookingStatus(shiped, tflag, shippeddate, shCreatedBy));
				}
				if (cndate != null) {
					BookingStatus.add(new BookingStatus(cancelled, tflag, cndate, cndateCreatedBy));
				}
			}
			responseBean.setData(BookingStatus);
			responseBean.setReturnCode(1);
			responseBean.setMessage("record fetched sucessfully for booking id " + bookingId);
			responseBean.setStatus(HttpStatus.OK);
		} else {
			responseBean.setMessage("No Record found for this booking id " + bookingId);
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}

	}

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class BookingStatus {
		public String label;
		public Boolean active;
		public Date activityDate;
		public String createdBy;
	}

	public ResponseBean getCargoStatus(Long bookingId) throws Exception {
		ResponseBean responseBean = new ResponseBean();
		List<BookingTracking> bookingTrackings = null;
		Cargo cargo = null;
		List<CargoStatus> cargoStatus = new ArrayList<CargoStatus>();
		boolean flag = false;
		boolean tflag = true;
		Date pendingdate = null;
		Date fulfilleddate = null;
		Date shippeddate = null;
		Date cancelledDate = null;
		Optional<Users> user = null;
		String createdBy = null;
		String shipmentCreatedBy = null;
		String fulfilCreatedBy = null;
		String cacelledBy = null;
		try {
			cargo = cargoRepository.getStatusByCargoId(bookingId);
			if (cargo == null) {
				Bookings bking = bookingRepository.getStatusByBkid(bookingId);
				user = userRepository.findById(bking.getCreatedBy());
				cargoStatus.add(new CargoStatus(pending, tflag, bking.getCreatedOn(), user.get().getUserId()));
				cargoStatus.add(new CargoStatus(shiped, flag, shippeddate, null));
				cargoStatus.add(new CargoStatus(fulfiled, flag, fulfilleddate, null));
				responseBean.setData(cargoStatus);
				responseBean.setMessage("record fetched sucessfully");
				return responseBean;
			}
			bookingTrackings = bookingTrackingRepository.getStatusByBooking(bookingId);
			if (!bookingTrackings.isEmpty() && bookingTrackings != null) {
				for (BookingTracking bstatus : bookingTrackings) {
					if (bstatus.getStatusId().equals(6)) {
						pendingdate = bstatus.getCreatedOn();
						createdBy = findUserById(bstatus);
					}
					if (bstatus.getStatusId().equals(7)) {
						shippeddate = bstatus.getCreatedOn();
						shipmentCreatedBy = findUserById(bstatus);
					}
					if (bstatus.getStatusId().equals(2)) {
						fulfilleddate = bstatus.getCreatedOn();
						fulfilCreatedBy = findUserById(bstatus);
					}
					if (bstatus.getStatusId() .equals(1)) {
						cancelledDate = bstatus.getCreatedOn();
						cacelledBy = findUserById(bstatus);
					}
				}

			} else {
				responseBean.setMessage("No record found ");
				responseBean.setStatus(HttpStatus.OK);
			}
			getCargoStatusByCargoId(responseBean, cargoStatus, flag, tflag, pendingdate, fulfilleddate, shippeddate,
					bookingId, createdBy, shipmentCreatedBy, fulfilCreatedBy, cancelledDate, cacelledBy);
		} catch (Exception e) {
			log.error("Exception occured cargo tracking service" + e.getMessage());
			throw new Exception("Exception occured cargo tracking service" + e.getCause());
		}

		return responseBean;
	}

	private void getCargoStatusByCargoId(ResponseBean responseBean, List<CargoStatus> cargoStatus, boolean flag,
			boolean tflag, Date pendingdate, Date fulfilleddate, Date shippeddate, Long bookingId, String createdBy,
			String shipmentCreatedBy, String fulfilCreatedBy, Date cancelledDt, String cancelledBy) {
		Bookings bookingTracking = null;
		bookingTracking = bookingRepository.getStatusByBkid(bookingId);
		if (bookingTracking != null) {
			if (bookingTracking.getStatusId().equals(5)) {
				cargoStatus.add(new CargoStatus(pending, tflag, pendingdate, createdBy));
				cargoStatus.add(new CargoStatus(shiped, flag, shippeddate, null));
				cargoStatus.add(new CargoStatus(fulfiled, flag, fulfilleddate, null));
			}
			if (bookingTracking.getStatusId().equals(7)) {
				cargoStatus.add(new CargoStatus(pending, tflag, pendingdate, createdBy));
				cargoStatus.add(new CargoStatus(shiped, tflag, shippeddate, shipmentCreatedBy));
				cargoStatus.add(new CargoStatus(fulfiled, flag, fulfilleddate, null));
			}
			if (bookingTracking.getStatusId().equals(1)) {
				cargoStatus.add(new CargoStatus(pending, tflag, pendingdate, createdBy));
				cargoStatus.add(new CargoStatus(shiped, tflag, shippeddate, shipmentCreatedBy));
				cargoStatus.add(new CargoStatus(cancelled, tflag, cancelledDt, cancelledBy));
			}
			if (bookingTracking.getStatusId().equals(2)) {
				cargoStatus.add(new CargoStatus(pending, tflag, pendingdate, createdBy));
				cargoStatus.add(new CargoStatus(shiped, tflag, shippeddate, shipmentCreatedBy));
				cargoStatus.add(new CargoStatus(fulfiled, tflag, fulfilleddate, fulfilCreatedBy));
			}

			responseBean.setData(cargoStatus);
			responseBean.setReturnCode(1);
			responseBean.setMessage("record fetched sucessfully");
			responseBean.setStatus(HttpStatus.OK);
		} else {
			responseBean.setMessage("No Record found for this booking id ");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}

	}

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class CargoStatus {
		public String label;
		public Boolean active;
		public Date activityDate;
		public String createdBy;
	}

}