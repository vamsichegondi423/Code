package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.BookingItemPranth;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.BookingItemPranthRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BookingItemPranthService {

	@Autowired
	private BookingItemPranthRepository bookingItemPranthRepository;

	public BookingItemPranth getById(Long id) throws CustomException {
		try {
			Optional<BookingItemPranth> bookingItemPranthOptional = bookingItemPranthRepository.getById(id);
			if (bookingItemPranthOptional.isPresent()) {
				return bookingItemPranthOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public BookingItemPranth save(BookingItemPranth bookingItemPranth) throws CustomException {
		try {
			if (bookingItemPranth.getId() != null && bookingItemPranth.getId() > 0) {
				Optional<BookingItemPranth> existingBookingItemPranthRecord = bookingItemPranthRepository
						.getById(bookingItemPranth.getId());
				if (existingBookingItemPranthRecord.isPresent()) {
					return bookingItemPranthRepository.save(bookingItemPranth);
				}
			} else {
				bookingItemPranth = bookingItemPranthRepository.save(bookingItemPranth);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return bookingItemPranth;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<BookingItemPranth> existingBookingItemPranthRecord = bookingItemPranthRepository.getById(id);
			if (existingBookingItemPranthRecord.isPresent()) {
				bookingItemPranthRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<BookingItemPranth> getAll() {
		try {
			return bookingItemPranthRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}