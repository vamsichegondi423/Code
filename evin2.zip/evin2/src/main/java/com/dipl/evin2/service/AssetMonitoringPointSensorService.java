package com.dipl.evin2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.AssetMonitoringPointSensor;
import com.dipl.evin2.repository.AssetMonitoringPointSensorRepository;

@Service
public class AssetMonitoringPointSensorService {

	@Autowired
	private AssetMonitoringPointSensorRepository assetMonitoringPointSensorRepository;

	public AssetMonitoringPointSensor getById(Long id) {
		Optional<AssetMonitoringPointSensor> assetMonitoringPointSensorOptional = assetMonitoringPointSensorRepository.getById(id);
		if (assetMonitoringPointSensorOptional.isPresent()) {
			return assetMonitoringPointSensorOptional.get();
		} else {
			return null;
		}
	}

	public AssetMonitoringPointSensor save(AssetMonitoringPointSensor assetMonitoringPointSensor) {
		if (assetMonitoringPointSensor.getId() != null && assetMonitoringPointSensor.getId() > 0) {
			Optional<AssetMonitoringPointSensor> existingAssetMonitoringPointSensorRecord = assetMonitoringPointSensorRepository.getById(assetMonitoringPointSensor.getId());
			if (existingAssetMonitoringPointSensorRecord.isPresent()) {
				return assetMonitoringPointSensorRepository.save(assetMonitoringPointSensor);
			}
		} else {
			assetMonitoringPointSensor = assetMonitoringPointSensorRepository.save(assetMonitoringPointSensor);
		}
		return assetMonitoringPointSensor;
	}

	public Integer deleteById(Long id) {
		Optional<AssetMonitoringPointSensor> existingAssetMonitoringPointSensorRecord = assetMonitoringPointSensorRepository.getById(id);
		if (existingAssetMonitoringPointSensorRecord.isPresent()) {
			assetMonitoringPointSensorRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	public List<AssetMonitoringPointSensor> getAll() {
		return assetMonitoringPointSensorRepository.findAll();
	}

	public AssetMonitoringPointSensor getByMonitoringPointAndAsset(String monitoringPoint, Long assetId) {
		Optional<AssetMonitoringPointSensor> assetMonitoringPointSensorOptional = assetMonitoringPointSensorRepository.getByMonitoringPointAndAsset(monitoringPoint, assetId);
		if (assetMonitoringPointSensorOptional.isPresent()) {
			return assetMonitoringPointSensorOptional.get();
		} else {
			return null;
		}
	}

	public List<AssetMonitoringPointSensor> saveAll(List<AssetMonitoringPointSensor> monitoringPointSensors) {
		return assetMonitoringPointSensorRepository.saveAll(monitoringPointSensors);
	}

	public List<AssetMonitoringPointSensor> getByAssetId(Long assetId) {
		return assetMonitoringPointSensorRepository.getByAssetId(assetId);
	}
}