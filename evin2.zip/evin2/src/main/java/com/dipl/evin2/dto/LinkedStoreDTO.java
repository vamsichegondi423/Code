package com.dipl.evin2.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class LinkedStoreDTO {
	 private Long storeId;
		private String storeName;
		private String mappingType;
		private Long mappedStoreId;
		private String mappedStoreName;
		private String mappedLocation;
		private String storeLocation;
}
