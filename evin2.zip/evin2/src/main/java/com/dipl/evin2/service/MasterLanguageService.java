package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterLanguage;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterLanguageRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterLanguageService {

	@Autowired
	private MasterLanguageRepository masterLanguageRepository;

	@Cacheable(value = "language", key = "#id")
	public MasterLanguage getById(Integer id) {
		Optional<MasterLanguage> masterLanguageOptional = masterLanguageRepository.getById(id);
		if (masterLanguageOptional.isPresent()) {
			return masterLanguageOptional.get();
		} else {
			return null;
		}
	}

	@CachePut(value = "language", key = "#masterLanguage.id")
	public MasterLanguage save(MasterLanguage masterLanguage) throws CustomException {
		try {
			if (masterLanguage.getId() != null && masterLanguage.getId() > 0) {
				Optional<MasterLanguage> existingMasterLanguageRecord = masterLanguageRepository
						.getById(masterLanguage.getId());
				if (existingMasterLanguageRecord.isPresent()) {
					masterLanguage = masterLanguageRepository.save(masterLanguage);
				}
			} else {
				masterLanguage = masterLanguageRepository.save(masterLanguage);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterLanguage;
	}

	@CacheEvict(value = "language", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterLanguage> existingMasterLanguageRecord = masterLanguageRepository.getById(id);
			if (existingMasterLanguageRecord.isPresent()) {
				masterLanguageRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "language")
	public List<MasterLanguage> getAll() {
		try {
			return masterLanguageRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}