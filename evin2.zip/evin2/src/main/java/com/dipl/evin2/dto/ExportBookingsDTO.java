package com.dipl.evin2.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExportBookingsDTO {
	

	private Long pranthId;
	private Long bookingId;
	private Integer bookingItemsCount;
	private Integer statusId;
	private String	status;
	private String orderReferenceNo;
	private Long receivingStoreId;
	private Integer indentTypeId;
	private String recevingStoreName;
	private String rsCity;
	private String rsDistrict;
	private String rsState;
	private String rsCountry;
	private String createdBy;
	private Date createdOn;
	private Long issuingStoreId;
	private String issuingStoreName;
	private String isCity;
	private String isDistrict;
	private String isState;
	private String isCountry;
	private String bookingBadge;
	private Integer bookingBadgeId;
	private Integer sourceType;
	private String receivingStoreBadge;
	private String issuingStoreBadge;
	private Integer productId;
	private String  productBadge;
	private Long  orderedQuantity;
	private Long recommandedStock;
	private Date updatedOn;
	private String reason;
	private String updatedBy;
}
