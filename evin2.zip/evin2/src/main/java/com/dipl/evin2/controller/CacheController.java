package com.dipl.evin2.controller;

import java.util.Iterator;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("cache")
@Slf4j
public class CacheController {

	@Autowired
	private StringRedisTemplate stringRedisTemplate;

	@Autowired
	private CacheManager cacheManager; 

	@DeleteMapping("clearRedisCache")
	public ResponseEntity<String> deleteRedisCache() {

		try {
			Set<String> keys = stringRedisTemplate.keys("*");
			Iterator<String> it1 = keys.iterator();
			while (it1.hasNext()) {
				stringRedisTemplate.delete(it1.next());
			}

			return ResponseEntity.ok("Flushed redis cache");
		}catch (Exception e) {
			log.error("Error while clearing redis cache: {}", e.getLocalizedMessage());
			if(e.getLocalizedMessage().contains("Cannot get Jedis connection")) {
				return ResponseEntity.badRequest().body("Redis not configured");
			}
			return ResponseEntity.badRequest().body("Failed to flush redis cache: "+ e.getLocalizedMessage());
		}
		
	}

	@DeleteMapping(value = "clearCache")
	public ResponseEntity<String> clearCache(){
		for(String name:cacheManager.getCacheNames()){
			if(name != null && cacheManager.getCache(name) != null) {
				cacheManager.getCache(name).clear();
			}
		}
		return ResponseEntity.ok("Flushed cache");
	}

}
