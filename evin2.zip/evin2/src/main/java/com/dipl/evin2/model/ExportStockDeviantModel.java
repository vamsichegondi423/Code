package com.dipl.evin2.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExportStockDeviantModel {
	private ExportStockDeviantPayload exportStockDeviantPayload;
	private Long pranthId;
	private Long userId;
	private String userName;
	private String email;
	private List<Integer> materialTagsToHide;
	private List<Long> totalStoreIds;

}
