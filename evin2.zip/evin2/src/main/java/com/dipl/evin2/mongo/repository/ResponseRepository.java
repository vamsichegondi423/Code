package com.dipl.evin2.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.dipl.evin2.util.ResponseBean;

public interface ResponseRepository extends MongoRepository<ResponseBean, String> {

}
