package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterBadgeType;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterBadgeTypeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterBadgeTypeService {

	@Autowired
	private MasterBadgeTypeRepository masterBadgeTypeRepository;

	@Cacheable(value = "badge_type", key = "#id")
	public MasterBadgeType getById(Integer id) throws CustomException {
		try {
			Optional<MasterBadgeType> masterBadgeTypeOptional = masterBadgeTypeRepository.getById(id);
			if (masterBadgeTypeOptional.isPresent()) {
				return masterBadgeTypeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "badge_type", key = "#masterBadgeType.id")
	public MasterBadgeType save(MasterBadgeType masterBadgeType) throws CustomException {
		try {
			if (masterBadgeType.getId() != null && masterBadgeType.getId() > 0) {
				Optional<MasterBadgeType> existingMasterBadgeTypeRecord = masterBadgeTypeRepository
						.getById(masterBadgeType.getId());
				if (existingMasterBadgeTypeRecord.isPresent()) {
					masterBadgeType = masterBadgeTypeRepository.save(masterBadgeType);
				}
			} else {
				masterBadgeType = masterBadgeTypeRepository.save(masterBadgeType);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterBadgeType;
	}

	@CacheEvict(value = "badge_type", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterBadgeType> existingMasterBadgeTypeRecord = masterBadgeTypeRepository.getById(id);
			if (existingMasterBadgeTypeRecord.isPresent()) {
				masterBadgeTypeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "badge_type")
	public List<MasterBadgeType> getAll() {
		try {
			return masterBadgeTypeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}