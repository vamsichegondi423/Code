package com.dipl.evin2.dto;

import org.springframework.beans.factory.annotation.Value;

public interface RcmndQutyDTO {

	@Value(("#{target.store_id}"))
	Long getStroeId();
	@Value(("#{target.material_id}"))
	 Long getProductId();
	@Value(("#{target.maximum_stock}"))
	 Long getMaxStock();
	@Value(("#{target.available_stk}"))
	 Long getAvailableStk();
	@Value(("#{target.expired_stk}"))
	 Long getExpiredStk();
	@Value(("#{target.transit_stk}"))
	 Long getInTransitStk();


}
