package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.StoreMappings;

@Repository
public interface StoreMappingsRepository extends JpaRepository<StoreMappings, Integer> {

	@Query(value = "select * from store_mappings where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<StoreMappings> getById(Integer id);

	@Query(value = "select * from store_mappings where is_deleted = false", nativeQuery = true)
	public List<StoreMappings> findAll();
	
	@Query(value = "select * from store_mappings where store_id = ?1 and mapped_store_id = ?2 and mapping_type = ?3 and is_deleted = false", nativeQuery = true)
	public StoreMappings getStoreMappings(Long storeId, Long mappedStoreId, String mappingType);

	@Modifying
	@Transactional
	@Query(value = "delete from store_mappings where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);

	@Modifying
	@Transactional
	@Query(value = "update store_mappings set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

	@Query(value = "select * from store_mappings where store_id = ?1 and mapped_store_id=?2 and mapping_type= ?3", nativeQuery = true)
	public Optional<StoreMappings> getByStoreIdAndMappedId(Long storeId, Long mappedStoreId, String mappingType);

}