package com.dipl.evin2.dto;

import java.util.List;

import javax.validation.constraints.Min;

import com.dipl.evin2.entity.Badge;
import com.dipl.evin2.entity.StoreBadgeRank;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BadgeConfigurationDTO {
	
	private List<Badge> productBadges;
	private List<Badge> storeBadges;
	private List<Badge> bookingBadges;
	private List<Badge> routeBadges;
	private List<Badge> userBadges;
	private List<Badge> producerBadges;
	private List<StoreBadgeRank> storeBadgeRanks;
	private Long updatedBy;

}
