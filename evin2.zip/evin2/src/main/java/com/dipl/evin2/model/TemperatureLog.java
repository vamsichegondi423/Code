package com.dipl.evin2.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.domain.Persistable;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(value = "temperature_log")
@JsonIgnoreProperties(ignoreUnknown = true)
public class TemperatureLog implements Persistable<String>{

	@Id
	private String id;
	
	@JsonProperty("vId")
	private String vId;
	@JsonProperty("data")
	private List<Datum> data;
	@JsonProperty("asm")
	private Integer asm;
	private Date updatedOn;
	private Date createdOn;
	private Long updatedBy;
	private Long createdBy;
	@Builder.Default
	private Boolean isDeleted = false;
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	public static class Datum {

		@JsonProperty("dId")
		private String dId;
		@JsonProperty("assetDId")
		private String assetDId;
		@JsonProperty("tmps")
		private List<Tmp> tmps;
		@JsonProperty("pwa")
		private Pwa pwa;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
		public static class Pwa {

			@JsonProperty("stat")
			private Integer stat;
			@JsonProperty("time")
			private Integer time;

		}

		@Data
		@AllArgsConstructor
		@NoArgsConstructor
		@Builder
		public static class Tmp {

			@JsonProperty("sId")
			private String sId;
			@JsonProperty("time")
			private Integer time;
			@JsonProperty("typ")
			private Integer typ;
			@JsonProperty("tmp")
			private Double tmp;

		}

		@Override
		public boolean isNew() {
			 return id == null;
		}

}
