package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.MasterState;

@Repository
public interface MasterStateRepository extends JpaRepository<MasterState, Integer> {

	@Query(value = "select * from master_state where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterState> getById(Integer id);

	@Query(value = "select * from master_state where is_deleted = false", nativeQuery = true)
	public List<MasterState> findAll();
	
	@Query(value = "select * from master_state where code = ? and is_deleted = false", nativeQuery = true)
	public MasterState getMasterStateByCode(String code);
	
	@Query(value = "select * from master_state where \"name\" = ?1 and country_id = ?2 and is_deleted = false", nativeQuery = true)
	public MasterState getMasterState(String name, Integer countryId);

	@Modifying
	@Transactional
	@Query(value = "delete from master_state where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);

	@Modifying
	@Transactional
	@Query(value = "update master_state set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

	@Query(value = "select id as stateId,name as stateName from master_state where country_id = ?1 and is_deleted = false", nativeQuery = true)
	public List<Map<String, Object>> findSatesByCid(Integer countrtyId);

	@Query(value = "select id as districtId,name as districtName from master_district where state_id =?1 and is_deleted = false", nativeQuery = true)
	public List<Map<String, Object>> findDistrictBySid(Integer stateId);

	@Query(value = "select id as blockId,name as blockName from master_block where district_id =?1 and is_deleted = false", nativeQuery = true)
	public List<Map<String, Object>> findBlocksByDid(Integer districtId);

}