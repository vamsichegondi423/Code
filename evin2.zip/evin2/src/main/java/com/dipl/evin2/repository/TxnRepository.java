package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.dto.TxnDTO;
import com.dipl.evin2.entity.Txn;

@Repository
public interface TxnRepository extends JpaRepository<Txn, Long> {

	@Query(value = "select * from txn where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<Txn> getById(Long id);

	@Query(value = "select * from txn where is_deleted = false", nativeQuery = true)
	public List<Txn> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from txn where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update txn set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from txn where product_id= ?1 and source_store_id=?2 order by created_on desc LIMIT 1", nativeQuery = true)
	public Txn getClosingStockDetailsByProductAndStore(Long productId, Long storeId);

	@Query(value = "select * from txn where product_id= ?1 and source_store_id=?2 and batch_no =?3 order by created_on desc LIMIT 1", nativeQuery = true)
	public Txn getClosingStockDetailsByBatchProductAndStore(Long productId, Long storeId, String BatchNo);

	@Query(value = "select * from txn where product_id= ?1 order by created_on desc LIMIT 1", nativeQuery = true)
	public Txn getClosingStockDetailsByMid(Integer productId);

	@Query(value = "select * from txn where product_id= ?1 and source_store_id=?2 and batch_no =?3 and icatalogue_id =?4 order by created_on desc LIMIT 1", nativeQuery = true)
	public Txn getTxnDetailsByProductAndStore(Long productId, Long rStoreId, String batchId, Long ictalougeId);

	@Query(value = "select * from txn where id =?1 and is_deleted = false", nativeQuery = true)
	public Txn getBatchDetailsBasedOnTxnId(Long txnId);

	@Query(value = "select source_store_id, dest_store_id, product_id, cast(created_on as date) as created_on,cargo_id,count(id) from txn where id > (select coalesce(max(table_id),0) from report_sync_status where name_table='txn') group by 1,2,3,cast(created_on as date),5 order by 1,4", nativeQuery = true)
	public List<Map<Object, Object>> findConsumptionReportDetails();

	@Query(value = "select t.source_store_id as store_id,m.id as stock_trend_type_id,t.product_id,t.stock as quantity,cast(max(t.created_on) as date) as stock_trend_date,\n"
			+ "date_part('month',max(t.created_on)) as stock_trend_month, date_part('year',max(t.created_on)) as stock_trend_year\n"
			+ "from txn t join master_txn_type m on t.txn_type_id=m.id group by 1,2,3,4", nativeQuery = true)
	public List<Map<Object, Object>> findStockTrendTypeReportsDetails();

	@Query(value = "select product_id,source_store_id as store_id,closing_stock,cast(max(created_on) as date) as stock_trend_date,\n"
			+ "date_part('month',max(created_on)) as stock_trend_month, date_part('year',max(created_on)) as stock_trend_year\n"
			+ "from txn group by 1,2,3 ", nativeQuery = true)
	public List<Map<Object, Object>> findStockTrendsReportsDetails();

}