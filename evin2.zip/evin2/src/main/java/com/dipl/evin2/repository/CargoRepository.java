package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.dto.BookingCargoDTO;
import com.dipl.evin2.dto.CargoBatchDTO;
import com.dipl.evin2.dto.CargoDTO;
import com.dipl.evin2.dto.CargoProductsDTO;
import com.dipl.evin2.entity.Cargo;

@Repository
public interface CargoRepository extends JpaRepository<Cargo, Long> {

	@Query(value = "select * from cargo where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<Cargo> getById(Long id);

	@Query(value = "select * from cargo where is_deleted = false", nativeQuery = true)
	public List<Cargo> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from cargo where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update cargo set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);
	
	@Query(value = "select distinct b.id as booking_id,c.cargo_no,c.id as cargo_id,ms.name as cargo_status,ca.carrier_name,c.order_reference_no,\n" + 
			" b.arrival_date,concat(u.f_name,' ',u.l_name) as created_by,u.sex as gender,b.created_on,u.user_id,b.items_count\n" + 
			"from bookings b left join cargo c on c.booking_id=b.id left join cargo_item ci on c.id=ci.cargo_id\n" + 
			"left join users u on b.created_by=u.id left join master_status ms on ms.id=b.status_id\n" + 
			"left join packages p on p.cargo_id=c.id left join carrier ca on ca.id=p.carrier_id \n" + 
			"where b.id = ?1", nativeQuery = true)
	public List<BookingCargoDTO> getCargoByBookingId(Long bookingId);

	@Query(value = "select cargo_id,cr.product_id,product_name,cr.fulfilled_stock,ordered_stock,cr.batch_no,batch_expiry_date,batch_quantity,reason,cargo_stock,manufactured_date,producer_id,producer_name\n" + 
			"from\n" + 
			"(select c.id as cargo_id,c.store_id,pr.id as product_id, pr.name as product_name,cib.fulfilled_stock,ci.ordered_stock, cib.batch_no, \n" + 
			"cib.batch_expiry_date,cib.ordered_stock as batch_quantity,mr.name as reason, cib.cargo_stock \n" + 
			"from cargo c join cargo_item ci on c.id=ci.cargo_id join cargo_item_batch cib on cib.cargo_item_id=ci.id \n" + 
			"join product pr on ci.product_id=pr.id left join master_reason mr on mr.id=cib.discarded_reason_id)cr\n" + 
			"left join \n" + 
			"(select ib.product_id,ib.batch_no,ib.expiry_date,ib.manufactured_date,ib.producer_id,p.name as producer_name,i.store_id \n" + 
			"from icatalogue_batch ib join producer p on p.id=ib.producer_id join icatalogue i on ib.icatalogue_id=i.id)ir \n" + 
			"on ir.product_id=cr.product_id and ir.batch_no=cr.batch_no and ir.expiry_date=cr.batch_expiry_date and cr.store_id=ir.store_id\n" + 
			"where cargo_id= ?1 and cr.product_id =?2", nativeQuery = true)
	public List<CargoBatchDTO> getBatchDetailsByCargoId(Long cargoId, Long productId);

	@Query(value = "select distinct c.id as cargo_id,c.cargo_no,pr.handling_unit as handling_unit,pr.id as product_id,pr.name as product_name,pr.is_batch_enabled,bi.ordered_stock,p.package_quantity,ci.cargo_stock, " + 
			"ci.fulfilled_stock,i.min_stock,i.max_stock, bi.id as booking_item_id from cargo c left join cargo_item ci on c.id=ci.cargo_id " + 
			"left join bookings b on b.id=c.booking_id left join product pr on pr.id=ci.product_id  " + 
			"left join booking_items bi on bi.booking_id=b.id " + 
			"and bi.product_id=ci.product_id left join icatalogue i on i.store_id=c.store_id and i.product_id=ci.product_id " + 
			"left join packages p on p.cargo_id=c.id " + 
			"where c.id= ?1 and ci.is_deleted=false ", nativeQuery = true)
	public List<CargoProductsDTO> getProductsByCargoId(Long cargoId);

	@Query(value = "select distinct c.id as cargo_id,c.cargo_no,b.id as booking_id,ms.name as status,b.order_reference_no as booking_reference_no,b.created_on,concat(uc.f_name,' ',uc.l_name) as created_name,uc.user_id,b.updated_on, " + 
			"concat(uu.f_name,' ',uu.l_name) as updated_name,string_agg(bb.name,',') as booking_badge,b.receiving_store_id,rs.name as receiving_store_name, " + 
			"concat(rs.city,', ',rd.name,', ',rst.name,', ',rc.name) as receiving_store_location,b.issuing_store_id,s.name as issuing_store_name, " + 
			"concat(s.city,', ',d.name,', ',ist.name,', ',ic.name) as issuing_store_location,p.package_quantity,p.weight, " + 
			"concat( 'L', ':', p.length, 'W', ':', p.breadth, 'H', ':', p.height ) as Volume, p.remarks,p.package_cost,c.order_reference_no,ca.carrier_name,c.arrival_date, " + 
			"ca.contact_no as carrier_contact_no,p.vehicle_info,b.source_type from bookings b left join cargo c on b.id=c.booking_id " + 
			"left join users uc on b.created_by=uc.id left join users uu on uu.id=b.updated_by left join booking_badge bd on bd.booking_id=b.id  " + 
			"left join badge bb on bb.id=bd.badge_id left join store rs on rs.id=b.receiving_store_id left join store s on s.id=b.issuing_store_id " + 
			"left join master_status ms on ms.id=b.status_id left join master_district rd on rd.id=rs.district_id left join master_state rst on rst.id=rs.state_id " + 
			"left join master_country rc on rc.id=rs.country_id left join master_district d on d.id=s.district_id left join master_state ist on ist.id=s.state_id " + 
			"left join master_country ic on ic.id=s.country_id left join packages p on c.id=p.cargo_id left join carrier ca on ca.id=p.carrier_id " + 
			"where c.id= ?1 " + 
			"group by c.id,c.cargo_no,b.id,ms.name,uc.f_name,uc.l_name,uc.user_id,uu.f_name,uu.l_name,rs.name,rs.city,rd.name,rst.name,rc.name,s.name,s.city, " + 
			"d.name,ist.name,ic.name,p.package_quantity,p.weight,p.length,p.breadth,p.height,p.remarks,p.package_cost,ca.carrier_name,ca.contact_no, " + 
			"p.vehicle_info,b.source_type ", nativeQuery = true)
	public CargoDTO getCargoDetailsByCargoId(Long cargoId);
	
	@Query(value="select * from cargo where cargo_no=?1 and booking_id=?2 and store_id=?3 and is_deleted =false order by  created_on desc limit 1 ",nativeQuery = true)
	public Cargo getCargoDetailsByCidAndBid(String cargoNo, Long bookingId, Long isStoreId);

	@Query(value="select * from cargo where booking_id = ?1 and is_deleted = false order by created_on desc limit 1", nativeQuery = true)
	public Cargo getStatusByCargoId(Long bookingId);


}