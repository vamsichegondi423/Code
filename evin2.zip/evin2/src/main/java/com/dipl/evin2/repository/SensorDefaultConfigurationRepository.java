package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.SensorDefaultConfiguration;

@Repository
public interface SensorDefaultConfigurationRepository extends JpaRepository<SensorDefaultConfiguration, Long> {

	@Query(value = "select * from sensor_default_configuration where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<SensorDefaultConfiguration> getById(Long id);

	@Query(value = "select * from sensor_default_configuration where is_deleted = false and pranth_id=?1", nativeQuery = true)
	public List<SensorDefaultConfiguration> findAll(Long pranthId);

	@Modifying
	@Transactional
	@Query(value = "delete from sensor_default_configuration where id = ?1", nativeQuery = true)
	public void deleteById(Long id);
	
	@Modifying
	@Transactional
	@Query(value = "update sensor_default_configuration set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from sensor_default_configuration where sensor_id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<SensorDefaultConfiguration> getBySensorId(String sensorId);

	@Query(value = "select * from sensor_default_configuration where sensor_id = ?1 and pranth_id =?2 and is_deleted = false", nativeQuery = true)
	public List<SensorDefaultConfiguration> findBySensorAndPranthId(String sensorId,Long pranthid);
	
}