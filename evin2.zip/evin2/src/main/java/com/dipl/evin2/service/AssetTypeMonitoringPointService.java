package com.dipl.evin2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.AssetTypeMonitoringPoint;
import com.dipl.evin2.repository.AssetTypeMonitoringPointRepository;

@Service
public class AssetTypeMonitoringPointService {

	@Autowired
	private AssetTypeMonitoringPointRepository assetTypeMonitoringPointRepository;

	public AssetTypeMonitoringPoint getById(Long id) {
		Optional<AssetTypeMonitoringPoint> assetTypeMonitoringPointOptional = assetTypeMonitoringPointRepository.getById(id);
		if (assetTypeMonitoringPointOptional.isPresent()) {
			return assetTypeMonitoringPointOptional.get();
		} else {
			return null;
		}
	}

	public AssetTypeMonitoringPoint save(AssetTypeMonitoringPoint assetTypeMonitoringPoint) {
		if (assetTypeMonitoringPoint.getId() != null && assetTypeMonitoringPoint.getId() > 0) {
			Optional<AssetTypeMonitoringPoint> existingAssetTypeMonitoringPointRecord = assetTypeMonitoringPointRepository.getById(assetTypeMonitoringPoint.getId());
			if (existingAssetTypeMonitoringPointRecord.isPresent()) {
				return assetTypeMonitoringPointRepository.save(assetTypeMonitoringPoint);
			}
		} else {
			assetTypeMonitoringPoint = assetTypeMonitoringPointRepository.save(assetTypeMonitoringPoint);
		}
		return assetTypeMonitoringPoint;
	}

	public Integer deleteById(Long id) {
		Optional<AssetTypeMonitoringPoint> existingAssetTypeMonitoringPointRecord = assetTypeMonitoringPointRepository.getById(id);
		if (existingAssetTypeMonitoringPointRecord.isPresent()) {
			assetTypeMonitoringPointRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	public List<AssetTypeMonitoringPoint> getAll() {
		return assetTypeMonitoringPointRepository.findAll();
	}

	public List<AssetTypeMonitoringPoint> getByAssetType(Long assetTypeId) {
		return assetTypeMonitoringPointRepository.getByAssetType(assetTypeId);
	}
}