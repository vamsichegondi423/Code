/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "master_reason")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder 
@JsonIgnoreProperties(ignoreUnknown = true)
public class MasterReason implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	@NotEmpty(message = "Name cannot null or empty")
	@Column(name = "name")
	private String name;
	@NotEmpty(message = "Reason type cannot null or empty")
	@Column(name = "reason_type")
	private String reasonType;
	@Column(name = "updated_on")
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	private Date updatedOn;
	@Column(name = "created_on", updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date createdOn;
	@Column(name = "updated_by")
	private Long updatedBy;
	@Column(name = "created_by")
	private Long createdBy;
	@Column(name = "is_deleted")
	@Builder.Default
	private Boolean isDeleted = false;
	@Transient
	@Builder.Default
	private Boolean isDefault = false;
	@Transient
	private Long pranthId;
	
	@Transient
	@Builder.Default
	private Boolean isReasonMandatory  = false;
	
	

}
