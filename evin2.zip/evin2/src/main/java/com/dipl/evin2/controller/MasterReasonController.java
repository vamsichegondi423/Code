package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.MasterReason;
import com.dipl.evin2.repository.MasterReasonRepository;
import com.dipl.evin2.service.CacheEvictor;
import com.dipl.evin2.service.MasterReasonService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/master-reason-type")
public class MasterReasonController {

	@Autowired
	private MasterReasonService masterReasonTypeService;
	@Autowired
	private MasterReasonRepository masterReasonRepository;
	@Autowired
	private CacheEvictor cacheEvictor;

	@ApiOperation("Use this api for saving or updating MasterReason. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody MasterReason masterReasonType, BindingResult result, @RequestParam("pranthId") Long pranthId) {
		masterReasonType.setPranthId(pranthId);
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message(result.getAllErrors().get(0).getDefaultMessage()).status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (masterReasonType.getId() != null && masterReasonType.getId() > 0) {
				MasterReason existingMasterReason = masterReasonTypeService.getById(masterReasonType.getId());
				if (existingMasterReason != null) {
					masterReasonType.setCreatedBy(existingMasterReason.getCreatedBy());
					masterReasonType.setCreatedOn(existingMasterReason.getCreatedOn());
					masterReasonType.setIsDeleted(false);
					masterReasonType.setUpdatedOn(new Date());
					masterReasonType = masterReasonTypeService.save(masterReasonType,pranthId);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(masterReasonType);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				masterReasonType.setCreatedBy(masterReasonType.getUpdatedBy());
				masterReasonType.setCreatedOn(new Date());
				masterReasonType.setUpdatedOn(new Date());
				masterReasonType.setIsDeleted(false);
				masterReasonType = masterReasonTypeService.save(masterReasonType,pranthId);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(masterReasonType);
			}
			cacheEvictor.evictAllCacheValues("reason_type");
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for saving or updating MasterReason. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/save-or-update-list")
	@Transactional(rollbackFor = Exception.class)
	public ResponseBean saveList(@RequestBody List<MasterReason> masterReasonTypes, BindingResult result, @RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message(result.getAllErrors().get(0).getDefaultMessage()).status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			masterReasonTypes.forEach(mr -> {
				mr.setPranthId(pranthId);
				mr.setCreatedBy(mr.getUpdatedBy());
				mr.setCreatedOn(new Date());
				mr.setUpdatedOn(new Date());
				mr.setIsDeleted(false);
				mr = masterReasonTypeService.save(mr,pranthId);
			});
			
			cacheEvictor.evictAllCacheValues("reason_type");
			log.info("Record saved successfully");
			responseBean.setMessage("Record saved successfully");
			responseBean.setData(masterReasonTypes);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}


	@ApiOperation("Use this api for fetching MasterReason record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			MasterReason masterReasonType = masterReasonTypeService.getById(id);
			if (masterReasonType != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterReasonType);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting MasterReason record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Integer id, @RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = masterReasonTypeService.deleteById(id,pranthId);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all MasterReason records. No params required.")
	@GetMapping(value = "/v1/get-all", produces = "application/json")
	public ResponseBean getAll(@RequestParam (required = false,value= "resonType") String reasonType, @RequestParam (required = false,value= "pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<MasterReasonDTO> masterReasonTypeRecords = masterReasonTypeService.fetchAllByReasonType(reasonType, pranthId);
			if (!masterReasonTypeRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterReasonTypeRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for updating MasterReason to child pranth.")
	@GetMapping(value = "/v1/update-reason-to-child/{userId}", produces = "application/json")
	public ResponseBean updateParentStatusToChild(@PathVariable(value = "userId") Long userId,@RequestParam(value = "pranthId",required = false) Long pranthId , @RequestParam(value = "mappedPranthId") Long mappedPranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			responseBean = masterReasonTypeService.updateParentReasonToChild(pranthId, mappedPranthId, userId);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occurred");
		}
		return responseBean;
	}
	
	
	public interface MasterReasonDTO{
		@Value(("#{target.master_reason_id}"))
		Long getReasonId();
		@Value(("#{target.reason_name}"))
		String getReasonName();
		@Value(("#{target.reason_type}"))
		String getReasonType();
		@Value(("#{target.is_default}"))
		Boolean getIsDefault();
		@Value(("#{target.is_reason_mandatory}"))
		Boolean getisReasonMandatory();
		@Value(("#{target.badge_id}"))
		Long getBadgeId();
	}
}