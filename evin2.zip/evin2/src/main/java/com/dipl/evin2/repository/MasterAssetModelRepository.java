package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.dto.AssetModelDTO;
import com.dipl.evin2.entity.MasterAssetModel;

@Repository
public interface MasterAssetModelRepository extends JpaRepository<MasterAssetModel, Long> {

	@Query(value = "select * from master_asset_model where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterAssetModel> getById(Long id);

	@Query(value = "select * from master_asset_model where is_deleted = false", nativeQuery = true)
	public List<MasterAssetModel> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from master_asset_model where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update master_asset_model set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select msm.asset_type_id as assetTypeId,mat.\"name\" as assetTypeName,msm.model_name as modelName ,msm.id as modelId,msm.is_active as modelIsActive ,msm.asset_vendor_id as assetVendorid,mav.\"name\" as vendorName, mav.is_active as vendorIsActive,msm.default_censor as  defaultCensor ,atmp.monitoring_point as monitoringPoint,atmp.id as monitoringId from master_asset_model msm join master_asset_type mat on mat.id = msm.asset_type_id join master_asset_vendor mav on mav.id = msm.asset_vendor_id left join asset_type_monitoring_point atmp on msm.asset_type_id = atmp.asset_type_id where msm.asset_type_id = ?1  and msm.is_deleted = false", nativeQuery = true)
	public List<AssetModelDTO> findByMasterAssetTypeId(Long assestTypeId);

	@Query(value = "select * from master_asset_model where asset_vendor_id = ?1 and is_deleted = false", nativeQuery = true)
	public List<MasterAssetModel> getByVendorId(Long vendorId);

	@Query(value = "select * from master_asset_model where asset_vendor_id = ?1 and is_active = ?2 and is_deleted = false", nativeQuery = true)
	public List<MasterAssetModel> getActiveModelsByVendorId(Long vendorId, Boolean isActive);
	
}