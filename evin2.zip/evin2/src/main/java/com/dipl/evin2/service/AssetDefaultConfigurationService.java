package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.AssetDefaultConfiguration;
import com.dipl.evin2.entity.PranthHierarchy;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.AssetDefaultConfigurationRepository;
import com.dipl.evin2.util.ResponseBean;

@Service
public class AssetDefaultConfigurationService {

	@Autowired
	private AssetDefaultConfigurationRepository assetDefaultConfigurationRepository;

	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	public AssetDefaultConfiguration getById(Long id) {
		Optional<AssetDefaultConfiguration> assetDefaultConfigurationOptional = assetDefaultConfigurationRepository.getById(id);
		if (assetDefaultConfigurationOptional.isPresent()) {
			return assetDefaultConfigurationOptional.get();
		} else {
			return null;
		}
	}

	public AssetDefaultConfiguration save(AssetDefaultConfiguration assetDefaultConfiguration) {
		if (assetDefaultConfiguration.getId() != null && assetDefaultConfiguration.getId() > 0) {
			Optional<AssetDefaultConfiguration> existingAssetDefaultConfigurationRecord = assetDefaultConfigurationRepository.getById(assetDefaultConfiguration.getId());
			if (existingAssetDefaultConfigurationRecord.isPresent()) {
				return assetDefaultConfigurationRepository.save(assetDefaultConfiguration);
			}
		} else {
			assetDefaultConfiguration = assetDefaultConfigurationRepository.save(assetDefaultConfiguration);
		}
		return assetDefaultConfiguration;
	}

	public Integer deleteById(Long id) {
		Optional<AssetDefaultConfiguration> existingAssetDefaultConfigurationRecord = assetDefaultConfigurationRepository.getById(id);
		if (existingAssetDefaultConfigurationRecord.isPresent()) {
			assetDefaultConfigurationRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	public List<AssetDefaultConfiguration> getAll(Long pranthId) {
		return assetDefaultConfigurationRepository.findAll(pranthId);
	}


	@Transactional(rollbackOn = { Exception.class , CustomException.class })
	public ResponseBean updateParentAssestDefaultConfigToChild(Long pranthId, Long mappedPranthId, Long userId)  throws CustomException{
		ResponseBean responseBean  = new ResponseBean();
		Long pranthid = 0L;
		List<AssetDefaultConfiguration> adcList= new ArrayList<>();
		Optional<PranthHierarchy> pranthHierarchy = pranthHierarchyService.getByMappingId(mappedPranthId);
		try {
			if(pranthHierarchy.isPresent()) {
				if(pranthId != null && pranthId != 0) {
					pranthid = pranthId;
				} else {
					pranthid = pranthHierarchy.get().getPranthId();
				}
				List<AssetDefaultConfiguration> defaultConfigurationList = assetDefaultConfigurationRepository.findAll(pranthid);
				for(AssetDefaultConfiguration adc: defaultConfigurationList) {
					List<AssetDefaultConfiguration> defaultConfigurations =  assetDefaultConfigurationRepository.findAll(mappedPranthId);
					if(defaultConfigurations.isEmpty()) {
						AssetDefaultConfiguration configuration = AssetDefaultConfiguration.builder().alarmFrequencyNotificationDuration(adc.getAlarmFrequencyNotificationDuration())
								.alarmFrequencyNotificationNumber(adc.getAlarmFrequencyNotificationNumber()).alarmPushUrl(adc.getAlarmPushUrl())
								.communicationChannelId(adc.getCommunicationChannelId()).configurationPullUrl(adc.getConfigurationPullUrl())
								.countryId(adc.getCountryId()).deviceAlarmPushNotification(adc.getDeviceAlarmPushNotification()).deviceReadyStatusPushUrl(adc.getDeviceReadyStatusPushUrl())
								.disableAssetManagement(adc.getDisableAssetManagement()).enableAssetManagement(adc.getEnableAssetManagement()).enableAssetManagementLogistics(adc.getEnableAssetManagementLogistics())
								.highAlarmTemperature(adc.getHighAlarmTemperature()).highAlarmTemperatureDuration(adc.getHighAlarmTemperatureDuration()).highWarningTemperature(adc.getHighWarningTemperature())
								.highWarningTemperatureDuration(adc.getHighWarningTemperatureDuration()).languageId(adc.getLanguageId()).lowAlarmTemperature(adc.getLowAlarmTemperature()).lowAlarmTemperatureDuration(adc.getLowAlarmTemperatureDuration())
								.lowBatteryAlarmThresholdLimit(adc.getLowBatteryAlarmThresholdLimit()).lowWarningTemperature(adc.getLowWarningTemperature()).lowWarningTemperatureDuration(adc.getLowWarningTemperatureDuration())
								.nameSpace(adc.getNameSpace()).phoneNumbersToSendSmsNotification(adc.getPhoneNumbersToSendSmsNotification()).powerOutageAlarmDuration(adc.getPowerOutageAlarmDuration())
								.pranthId(mappedPranthId).pushInterval(adc.getPushInterval()).samplingInterval(adc.getSamplingInterval()).sensorDefaultConfigurationList(adc.getSensorDefaultConfigurationList()).smsGatewayKeyword(adc.getSmsGatewayKeyword())
								.smsGatewayPhoneNumber(adc.getSmsGatewayPhoneNumber()).smsGatewaySenderId(adc.getSmsGatewaySenderId()).statsPushNotification(adc.getStatsPushNotification()).statsPushUrl(adc.getStatsPushUrl())
								.temperatureAlarmPushNotifications(adc.getTemperatureAlarmPushNotifications()).temperatureIncursionExcursionPushNotification(adc.getTemperatureIncursionExcursionPushNotification())
								.temperaturePushNotification(adc.getTemperaturePushNotification()).timeZoneId(adc.getTimeZoneId()).wifiPassword(adc.getWifiPassword()).wifiSecurity(adc.getWifiSecurity()).wifiSsid(adc.getWifiSsid())
								.temperaturePushUrl(adc.getTemperaturePushUrl()).build();
						configuration.setUpdatedBy(userId);
						configuration.setUpdatedOn(new Date());
						configuration.setCreatedBy(adc.getCreatedBy());
						configuration.setCreatedOn(adc.getCreatedOn());
						adcList.add(configuration);
					}
				}
				assetDefaultConfigurationRepository.saveAll(adcList);
				responseBean.setMessage("Asset default config has been updated for child");
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
			} else {
				responseBean.setMessage("No Record found with mappedPranthId");
				responseBean.setReturnCode(0);
				responseBean.setStatus(HttpStatus.NO_CONTENT);
			}
		} catch(Exception e) {
			//			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseBean;
	}


}