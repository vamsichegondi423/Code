package com.dipl.evin2.mongo.repository;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.dipl.evin2.model.SmsNotificationModel;

@EnableAutoConfiguration
public interface SmsRepository extends MongoRepository<SmsNotificationModel, String> {

}
