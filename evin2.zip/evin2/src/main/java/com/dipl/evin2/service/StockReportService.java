package com.dipl.evin2.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.dipl.evin2.dto.StockReportDetails;
import com.dipl.evin2.dto.StockReportPayload;
import com.dipl.evin2.exceptions.CustomException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class StockReportService {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<StockReportDetails> getInventoryDetails(StockReportPayload detailsPayload,List<Long> storeIds,Pageable pageable) throws CustomException {
		StringBuilder builder = new StringBuilder();

		if((detailsPayload.getCountry() != null || detailsPayload.getCountry() != 0) && (detailsPayload.getState() == null || detailsPayload.getState() == 0)) {

			builder.append("select distinct a.state_id,state_name,a.district_id,district_name,material_name,sum(total_stock) as total_stock from "
					+ "	(select s.name as store_name,sb.store_category,s.city,d.id as district_id,d.name as district_name,st.id as state_id,st.name as state_name,c.id as country_id, c.name as country_name, "
					+ "	p.id as material,p.name as material_name,pb.material_category, case when p.is_batch_enabled=true then 'With Batch' else 'Without Batch' end as batch,"
					+ "	 coalesce(i.updated_on,i.created_on) as updated_on, "
					+ "	coalesce(i.updated_by,i.created_by) as updated_by,i.total_stock from icatalogue i join store s on i.store_id=s.id "
					+ "	left join (select store_id, string_agg(b.name,',') as store_category from store_badge sb join badge b on sb.badge_id=b.id "
					+ "	where sb.is_deleted=false group by 1)sb on s.id=sb.store_id join master_country c on s.country_id=c.id "
					+ "	left join master_state st on s.state_id=st.id left join master_district d on s.district_id=d.id "
					+ "	join product p on i.product_id=p.id "
					+ "	left join (select product_id, pb.badge_id  as material_category from product_badge pb join badge b on pb.badge_id=b.id "
					+ "	where pb.is_deleted=false group by 1,2)pb on p.id=pb.product_id where i.is_deleted=false)a "
					+ "	join users u on a.updated_by=u.id where  ");
			addFilterConditionsForStockViewByDistrict(detailsPayload,storeIds, builder);
			builder.append(" group by a.state_id,a.state_name,a.material_name, a.district_id,a.district_name");
			//builder.append(" order by district_name asc ");

			log.info(builder.toString());
			return jdbcTemplate.query(builder.toString(), new RowMapper<StockReportDetails>() {
				@Override
				public StockReportDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
					return StockReportDetails.builder()
							.state(rs.getString("state_name"))
							.districtId(rs.getLong("district_id"))
							.productName(rs.getString("material_name"))
							.district(rs.getString("district_name"))
							.totalStock(rs.getLong("total_stock"))
							.build();
				}
			});
		}
		else if(detailsPayload.getState() != null || detailsPayload.getState() != 0) {
			builder.append("select distinct a.state_id,state_name,a.district_id,district_name,a.store_id, a.store_name, store_category,material_name,sum(total_stock) as total_stock from "
					+ "	(select s.id as store_id, s.name as store_name,sb.store_category,s.city,d.id as district_id,d.name as district_name,st.id as state_id,st.name as state_name,c.name as country_name, c.id as country_id, bl.name as block_name, bl.id as block_id, "
					+ "	p.id as material,p.name as material_name,pb.material_category, case when p.is_batch_enabled=true then 'With Batch' else 'Without Batch' end as batch,"
					+ "	 coalesce(i.updated_on,i.created_on) as updated_on, "
					+ "	coalesce(i.updated_by,i.created_by) as updated_by,i.total_stock from icatalogue i join store s on i.store_id=s.id "
					+ "	left join (select store_id, string_agg(b.name,',') as store_category from store_badge sb join badge b on sb.badge_id=b.id "
					+ "	where sb.is_deleted=false group by 1)sb on s.id=sb.store_id join master_country c on s.country_id=c.id "
					+ "	left join master_state st on s.state_id=st.id left join master_district d on s.district_id=d.id left join master_block bl on bl.id=s.block_id"
					+ "	join product p on i.product_id=p.id "
					+ "	left join (select product_id, pb.badge_id as material_category from product_badge pb join badge b on pb.badge_id=b.id "
					+ "	where pb.is_deleted=false group by 1,2)pb on p.id=pb.product_id where i.is_deleted=false)a "
					+ "	join users u on a.updated_by=u.id where  ");
			addFilterConditionsForStockViewByStore(detailsPayload, storeIds,builder);
			builder.append(" group by a.state_id,a.state_name,a.district_id,a.district_name,a.material_name,a.store_id, a.store_name,a.store_category");
			//builder.append(" order by store_name asc ");

			log.info(builder.toString());
			return jdbcTemplate.query(builder.toString(), new RowMapper<StockReportDetails>() {
				@Override
				public StockReportDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
					return StockReportDetails.builder()
							.state(rs.getString("state_name"))
							.district(rs.getString("district_name"))
							.districtId(rs.getLong("district_id"))
							.productName(rs.getString("material_name"))
							.store(rs.getString("store_name"))
							.storeId(rs.getLong("store_id"))
							.totalStock(rs.getLong("total_stock"))
							.build();
				}
			});


		}
		return null;
	}

	private void addFilterConditionsForStockViewByStore(StockReportPayload detailsPayload,List<Long> offsetKioskIds, StringBuilder builder) {
		StringBuilder paramBuilder = new StringBuilder();
		if (offsetKioskIds != null && !offsetKioskIds.isEmpty()) {
			//paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;

			paramBuilder.append("  a.store_id in ( " + StringUtils.join(offsetKioskIds, " ,") + "  ) ");
		}
		if (detailsPayload.getCountry() != null && detailsPayload.getCountry() != 0) {
			paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
			paramBuilder.append(" a.country_id = " + detailsPayload.getCountry());
		}
		if (detailsPayload.getState() != null && detailsPayload.getState() != 0) {
			paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
			paramBuilder.append(" a.state_id = " + detailsPayload.getState());
		}
		if (detailsPayload.getDistrict() != null && detailsPayload.getDistrict() != 0) {
			paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
			paramBuilder.append(" a.district_id = " + detailsPayload.getDistrict());
		}
		if (detailsPayload.getBlock() != null && detailsPayload.getBlock()!= 0) {
			paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
			paramBuilder.append(" a.block_id = " + detailsPayload.getBlock());
		}		
		if (!detailsPayload.getMaterial().isEmpty()){
			int i = 0;
		paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;

		StringBuilder materials = new StringBuilder();
		materials.append(" (");
		List<Integer> materilsList = detailsPayload.getMaterial();

		for (Integer e : materilsList) {
			materials.append(e.toString());
			if (i < materilsList.size() - 1) {
				materials.append(" ,");
			}
			i++;
		}
		materials.append(" )");
		paramBuilder.append("  a.material in "+(materials.toString()));

		}
		if (!detailsPayload.getMaterialBadge().isEmpty()) {
		paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
		int j = 0;
		StringBuilder materialBadges = new StringBuilder();
		materialBadges.append(" (");
		List<Integer> materialBadgeList = detailsPayload.getMaterialBadge();

		for (Integer e : materialBadgeList) {
			materialBadges.append(e.toString());
			if (j < materialBadgeList.size() - 1) {
				materialBadges.append(" ,");
			}
			j++;
		}
		materialBadges.append(" )");
		paramBuilder.append("  a.material_category in "+(materialBadges));

		}
		
		/*if (!detailsPayload.getStoreBadge().isEmpty()) {
			paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
			int j = 0;
			StringBuilder storeTags = new StringBuilder();
			storeTags.append(" (");
			List<String> storeBadgeList = detailsPayload.getStoreBadge();

			for (String e : storeBadgeList) {
				storeTags.append("  a.store_category like '" + e.toString() + "'");

				if (j < storeBadgeList.size() - 1) {
					storeTags.append(" or ");
				}
				j++;
			}
			storeTags.append(" )");
			paramBuilder.append(storeTags);

			}*/
		
		if (!detailsPayload.getStoreId().isEmpty()) {
			paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
			int j = 0;
			StringBuilder storeIds = new StringBuilder();
			storeIds.append(" (");
			List<Long> storeIdList = detailsPayload.getStoreId();

			for (Long e : storeIdList) {
				storeIds.append(e.toString());
				if (j < storeIdList.size() - 1) {
					storeIds.append(" ,");
				}
				j++;
			}
			storeIds.append(" )");
			paramBuilder.append("  a.store_id in "+(storeIds));
			}
		
		builder.append(paramBuilder);
	}
	
	
	private void addFilterConditionsForStockViewByDistrict(StockReportPayload detailsPayload,List<Long> districtIds, StringBuilder builder) {
		StringBuilder paramBuilder = new StringBuilder();
		if (districtIds != null && !districtIds.isEmpty()) {
			//paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;

			paramBuilder.append("  a.district_id in ( " + StringUtils.join(districtIds, " ,") + "  ) ");
		}
		if (detailsPayload.getCountry() != null && detailsPayload.getCountry() != 0) {
			paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
			paramBuilder.append(" a.country_id = " + detailsPayload.getCountry());
		}
		if (detailsPayload.getState() != null && detailsPayload.getState() != 0) {
			paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
			paramBuilder.append(" a.state_id = " + detailsPayload.getState());
		}
		if (detailsPayload.getBlock() != null && detailsPayload.getBlock()!= 0) {
			paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
			paramBuilder.append(" a.block_id = " + detailsPayload.getBlock());
		}		
		/*if (detailsPayload.getMaterial() != null) {
			paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
			List<Integer> list = detailsPayload.getMaterial();
			paramBuilder.append("  a.material in ( " + StringUtils.join(list, " ,") + "  ) ");

		}	*/
		if (!detailsPayload.getMaterial().isEmpty()) {
			int i = 0;
		paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;

		StringBuilder materials = new StringBuilder();
		materials.append(" (");
		List<Integer> materilsList = detailsPayload.getMaterial();

		for (Integer e : materilsList) {
			materials.append(e.toString());
			if (i < materilsList.size() - 1) {
				materials.append(" ,");
			}
			i++;
		}
		materials.append(" )");
		paramBuilder.append("  a.material in "+(materials.toString()));

		}
		/*if (detailsPayload.getMaterialBadge() != null) {
			paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
			List<Integer> list = detailsPayload.getMaterialBadge();
			paramBuilder.append("  a.material_category in ( " + StringUtils.join(list, " ,") + "  ) ");
		}	*/
		if (!detailsPayload.getMaterialBadge().isEmpty()) {
			paramBuilder = paramBuilder.length() > 0 ?  paramBuilder.append(" and ") : paramBuilder;
			int j = 0;
			StringBuilder materialBadges = new StringBuilder();
			materialBadges.append(" (");
			List<Integer> materialBadgeList = detailsPayload.getMaterialBadge();

			for (Integer e : materialBadgeList) {
				materialBadges.append(e.toString());
				if (j < materialBadgeList.size() - 1) {
					materialBadges.append(" ,");
				}
				j++;
			}
			materialBadges.append(" )");
			paramBuilder.append("  a.material_category in "+(materialBadges));

			}
		builder.append(paramBuilder);
	}
}
