package com.dipl.evin2.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.dipl.evin2.entity.ReportEmailLogs;


@Repository
public interface ReportsEmailLogsRepository extends MongoRepository<ReportEmailLogs,Long> {

}
