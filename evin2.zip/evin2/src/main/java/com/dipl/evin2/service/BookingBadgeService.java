package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.BookingBadge;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.BookingBadgeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BookingBadgeService {

	@Autowired
	private BookingBadgeRepository bookingBadgeRepository;

	public BookingBadge getById(Long id) throws CustomException {
		try {
			Optional<BookingBadge> bookingBadgeOptional = bookingBadgeRepository.getById(id);
			if (bookingBadgeOptional.isPresent()) {
				return bookingBadgeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public BookingBadge save(BookingBadge bookingBadge) throws CustomException {
		try {
			if (bookingBadge.getId() != null && bookingBadge.getId() > 0) {
				Optional<BookingBadge> existingBookingBadgeRecord = bookingBadgeRepository.getById(bookingBadge.getId());
				if (existingBookingBadgeRecord.isPresent()) {
					return bookingBadgeRepository.save(bookingBadge);
				}
			} else {
				bookingBadge = bookingBadgeRepository.save(bookingBadge);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return bookingBadge;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<BookingBadge> existingBookingBadgeRecord = bookingBadgeRepository.getById(id);
			if (existingBookingBadgeRecord.isPresent()) {
				bookingBadgeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<BookingBadge> getAll() {
		try {
			return bookingBadgeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}