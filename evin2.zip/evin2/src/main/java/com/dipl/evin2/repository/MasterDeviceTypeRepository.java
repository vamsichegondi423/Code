package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import com.dipl.evin2.entity.MasterDeviceType;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface MasterDeviceTypeRepository extends JpaRepository<MasterDeviceType, Long> {

	@Query(value = "select * from master_device_type where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterDeviceType> getById(Long id);

	@Query(value = "select * from master_device_type where is_deleted = false", nativeQuery = true)
	public List<MasterDeviceType> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from master_device_type where id = ?1", nativeQuery = true)
	public void deleteById(Long id);
	
	@Modifying
	@Transactional
	@Query(value = "update master_device_type set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);
	
}