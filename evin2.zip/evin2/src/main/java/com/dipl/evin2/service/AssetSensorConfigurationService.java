package com.dipl.evin2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.AssetSensorConfiguration;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.AssetSensorConfigurationRepository;

@Service
public class AssetSensorConfigurationService {

	@Autowired
	private AssetSensorConfigurationRepository assetSensorConfigurationRepository;

	public AssetSensorConfiguration getById(Long id) throws CustomException {
		Optional<AssetSensorConfiguration> assetSensorConfigurationOptional = assetSensorConfigurationRepository.getById(id);
		if (assetSensorConfigurationOptional.isPresent()) {
			return assetSensorConfigurationOptional.get();
		} else {
			return null;
		}
	}

	public AssetSensorConfiguration save(AssetSensorConfiguration assetSensorConfiguration) throws CustomException {
		if (assetSensorConfiguration.getId() != null && assetSensorConfiguration.getId() > 0) {
			Optional<AssetSensorConfiguration> existingAssetSensorConfigurationRecord = assetSensorConfigurationRepository.getById(assetSensorConfiguration.getId());
			if (existingAssetSensorConfigurationRecord.isPresent()) {
				return assetSensorConfigurationRepository.save(assetSensorConfiguration);
			}
		} else {
			assetSensorConfiguration = assetSensorConfigurationRepository.save(assetSensorConfiguration);
		}
		return assetSensorConfiguration;
	}

	public Integer deleteById(Long id) throws CustomException {
		Optional<AssetSensorConfiguration> existingAssetSensorConfigurationRecord = assetSensorConfigurationRepository.getById(id);
		if (existingAssetSensorConfigurationRecord.isPresent()) {
			assetSensorConfigurationRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	public List<AssetSensorConfiguration> getAll() {
		return assetSensorConfigurationRepository.findAll();
	}

	public List<AssetSensorConfiguration> saveAll(List<AssetSensorConfiguration> assetSensorConfigurations) {
		return assetSensorConfigurationRepository.saveAll(assetSensorConfigurations);
	}

	public List<AssetSensorConfiguration> getByAssetId(Long assetId) {
		return assetSensorConfigurationRepository.getByAssetId(assetId);
	}

	public AssetSensorConfiguration getByAssetIdAndSensorId(Long assetId, String sensorId) {
		return assetSensorConfigurationRepository.getByAssetIdAndSensorId(assetId, sensorId) ;
	}
}