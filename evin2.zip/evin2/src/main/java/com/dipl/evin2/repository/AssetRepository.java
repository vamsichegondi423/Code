package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.dipl.evin2.controller.AssetController.AssetModelDetailsDTO;
import com.dipl.evin2.entity.Asset;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface AssetRepository extends JpaRepository<Asset, Long> {

	@Query(value = "select * from asset where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<Asset> getById(Long id);

	@Query(value = "select * from asset where is_deleted = false", nativeQuery = true)
	public List<Asset> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from asset where id = ?1", nativeQuery = true)
	public void deleteById(Long id);
	
	@Modifying
	@Transactional
	@Query(value = "update asset set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from asset where serial_number = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<Asset> getBySerialNumber(String serialNumber);

	@Query(value = "select * from asset where serial_number = ?1 and asset_model_id = ?2 and is_deleted = false order by serial_number asc", nativeQuery = true)
	public Optional<Asset> getBySerialNumberAndAssetModel(String serialNumber, Long assetModelId);

	@Query(value = "select * from (select * FROM asset a join master_asset_model mam on a.asset_model_id = mam.id\n"
			+ "left join asset_mapping am on a.id=am.mapped_asset_id where a.is_deleted = false order by a.serial_number asc)t\n"
			+ "where mapped_asset_id is null and asset_type_id=?1", nativeQuery = true)
	public List<Asset> getAvailableTemperatureLoggers(Integer assetType);

	@Query(value = "select * from (SELECT a.*,am.mapped_asset_id,mam.asset_type_id FROM asset a join master_asset_model mam on a.asset_model_id = mam.id \n"
			+ "left join asset_mapping am on a.id=am.mapped_asset_id where a.is_deleted = false order by a.serial_number asc)t\n"
			+ "where mapped_asset_id is null and asset_type_id=?1 and serial_number like %?2% ", nativeQuery = true)
	public List<Asset> getAvailableTemperatureLoggers(Integer assetType, String serialNumber);

	@Query(value = "select * from asset where id in ?1 and is_deleted = false order by serial_number asc", nativeQuery = true)
	public List<Asset> getAllBySerialNumber(List<Long> values);

	@Query(value = "select * from asset where serial_number=?1 and is_deleted = false ", nativeQuery = true)
	public List<Map<String, Object>> findAssestSerialNumber(String assestSerialNum);
	
}