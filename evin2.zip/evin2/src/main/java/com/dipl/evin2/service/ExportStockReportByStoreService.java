package com.dipl.evin2.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dipl.evin2.dto.ExportStockReportDTO;
import com.dipl.evin2.model.ExportStockReportByOneStoreModel;
import com.dipl.evin2.model.FileReportResponse;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.JdbcTemplateHelper;
import com.dipl.evin2.util.KafkaProducer;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ExportStockReportByStoreService {
	
	@Autowired
	private SendEmailService sendEmailService;
	@Autowired
	private UploadFileService uploadFileService;
	@Autowired
	private JdbcTemplateHelper jdbcTemplateHelper;
//	@Autowired
//	private KafkaProducer kafkaProducer;
	
	public ResponseBean getStockReportByStoreService(ExportStockReportByOneStoreModel exportStockReportByOneStoreModel) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<ExportStockReportDTO> storesList = null;
		Object fileData;
		String url = null;
		Workbook workbook = null;
		FileOutputStream outputStream  = null;
		Sheet sheet = null;
		try {
			this.getStockReportByStoreWithoutBatchData(exportStockReportByOneStoreModel);
//			kafkaProducer.sendStockReportByStoreWithoutBatchExportToProducer(exportStockReportByOneStoreModel);
			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
					+ exportStockReportByOneStoreModel.getEmail()
					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
			responsebean.setReturnCode(1);
			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting stock report by store : " + e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		return responsebean;
	}
	
	public void getStockReportByStoreWithoutBatchData(ExportStockReportByOneStoreModel exportStockReportByOneStoreModel) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<ExportStockReportDTO> storesList = null;
		Object fileData;
		String url = null;
		Workbook workbook = null;
		FileOutputStream outputStream  = null;
		Sheet sheet = null;
		try {
			storesList = getAllMaterails(exportStockReportByOneStoreModel);
			//creating workbook
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0, cellIndex2 = 0, cellIndex3 = 0;
			// Creating row
			Row row = sheet.createRow(0);

			row.createCell(cellIndex++).setCellValue("Title");
			row.createCell(cellIndex++).setCellValue(""+Constants.stock_report_by_store+"");
			Row row1 = sheet.createRow(1);
			row1.createCell(cellIndex1++).setCellValue("StoreName");
			row1.createCell(cellIndex1++).setCellValue(storesList.get(0).getStoreName()+"");
			Row row2 = sheet.createRow(2);
			row2.createCell(cellIndex2++).setCellValue("Generated on");
			row2.createCell(cellIndex2++).setCellValue("" + uploadFileService.dateWithHoursMinutes());

			Row row4 = sheet.createRow(4);
            //creating excelsheet headers
			row4.createCell(cellIndex3++).setCellValue("Material Name");
			row4.createCell(cellIndex3++).setCellValue("Material Tags");
			row4.createCell(cellIndex3++).setCellValue("Store Name");
			row4.createCell(cellIndex3++).setCellValue("Store Tags");
			row4.createCell(cellIndex3++).setCellValue("Country");
			row4.createCell(cellIndex3++).setCellValue("State");
			row4.createCell(cellIndex3++).setCellValue("District/County");
			row4.createCell(cellIndex3++).setCellValue("Taluk/Block");
			row4.createCell(cellIndex3++).setCellValue("Village/City");
			row4.createCell(cellIndex3++).setCellValue("Total Stock");
			row4.createCell(cellIndex3++).setCellValue("Days Of Stock");
			row4.createCell(cellIndex3++).setCellValue("Allocated Stock");
			row4.createCell(cellIndex3++).setCellValue("In Transit Stock");
			row4.createCell(cellIndex3++).setCellValue("Min Stock");
			row4.createCell(cellIndex3++).setCellValue("Max Stock");
			row4.createCell(cellIndex3++).setCellValue("Abnormality Type");
			row4.createCell(cellIndex3++).setCellValue("Abnormality Duration-Days");
			row4.createCell(cellIndex3++).setCellValue("Updated On");

			//fetching data under headers
			for (int i = 0; i < storesList.size(); i++) {
				Row dataRow = sheet.createRow(i + 5);
				int rowIndex1 = 0;
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getProductName() == null ? "" : storesList.get(i).getProductName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getProductBadge() == null ? "" : storesList.get(i).getProductBadge() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getStoreName() == null ? "" : storesList.get(i).getStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getStoreBadge() == null ? "" : storesList.get(i).getStoreBadge() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getCountryName() == null ? "" : storesList.get(i).getCountryName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getStateName() == null ? "" : storesList.get(i).getStateName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getDistrictName() == null ? "" : storesList.get(i).getDistrictName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getBlock_name() == null ? "" : storesList.get(i).getBlock_name() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getCity() == null ? "" : storesList.get(i).getCity() + "");
				
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getTotalStock() == null ? 0 : storesList.get(i).getTotalStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getDaysOfStock() == null ? 0 : storesList.get(i).getDaysOfStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getAllocatedStock() == null ? 0 : storesList.get(i).getAllocatedStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getInTransitStock() == null ? 0 : storesList.get(i).getInTransitStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getMinStock() == null ? 0 : storesList.get(i).getMinStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getMaxStock() == null ? 0 : storesList.get(i).getMaxStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getAbnormalityType() == null ? "" : storesList.get(i).getAbnormalityType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getAbnormalityDurationDays() == null ? 0 : storesList.get(i).getAbnormalityDurationDays());
				Cell cell = dataRow.createCell(rowIndex1++);
				cell.setCellValue(
						storesList.get(i).getUpdatedOn() == null ? null : storesList.get(i).getUpdatedOn());
				cell.setCellStyle(dateCellStyle);
				
			}

			File tempFile = null;
			tempFile = File.createTempFile("StockReportByStore", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
			workbook.write(outputStream);			
			//uploading excel file
			HttpResponse<String> response = uploadFileService.uploadFile(url,exportStockReportByOneStoreModel.getUserName(), tempFile, "StockReportByStore");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			tempFile.delete();

			HashMap<String, Object> emailbody = new HashMap<>();
		
			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";
			
			//sending excel file to particular user email
			emailbody = sendEmailService.getStockReportByStoreEmail(link, exportStockReportByOneStoreModel.getUserName(), exportStockReportByOneStoreModel.getEmail());

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, exportStockReportByOneStoreModel.getEmail(), exportStockReportByOneStoreModel.getUserName(),
					fileDownloadUrl, fileType, fileName, fileSystemPath);
	
//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ exportStockReportByOneStoreModel.getEmail()
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting stock report by store : " + e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		finally {
			
			outputStream.close();
			workbook.close();
		}
//		return responsebean;
	}
	
	// query withtout pagination
	public List<ExportStockReportDTO> getAllMaterails(ExportStockReportByOneStoreModel exportStockReportByOneStoreModel) {
		List<ExportStockReportDTO> materialsResult = null;
		StringBuilder builder = new StringBuilder();

		builder.append(" select distinct product_name,product_badge,product_badge_id,store_name,store_badge,country_name,state_name, "
				+ " s.district_name,s.block_name,s.city, i.total_stock,i.days_of_stock,i.allocated_stock,i.in_transit_stock,"
				+ " i.min_stock,i.max_stock,case when i.total_stock = 0 then 200 "
				+ " when i.total_stock<i.min_stock then 201 when i.total_stock >i.max_stock then 202 else 0 end as abnormality_id,"
				+ " case when i.total_stock = 0 then 'Zero Stock'  when i.total_stock<i.min_stock  then '< Min' "
				+ "  when i.total_stock >i.max_stock then '> Max'  else 'Normal' end as abnormality_type,  "
				+ " EXTRACT(epoch from age(coalesce(i.updated_on, now()), i.created_on)/ 86400)as abnormality_duration_days,"
				+ " i.updated_on  from icatalogue i left join(select s.id,s.name as store_name, "
				+ " c.name as country_name,st.name as state_name, d.name as district_name,"
				+ " bl.name as block_name,city,address , string_agg(distinct bd.name,',') as store_badge "
				+ " from store s  left join store_badge sb on s.id=sb.store_id left join badge bd "
				+ " on bd.id=sb.badge_id  and bd.badge_type_id=2 and bd.is_deleted=false left join "
				+ " master_district d on d.id=s.district_id left join master_state st on st.id=s.state_id"
				+ " left join master_country c on c.id=s.country_id left join master_block bl"
				+ "  on s.block_id=bl.id group by 1,2,3,4,5,6)s on s.id = i.store_id  left join"
				+ "  (select p.id,p.name as product_name, is_batch_enabled,bd.id as product_badge_id, "
				+ " string_agg(distinct bd.name,',') as product_badge from product p  "
				+ " left join product_badge pb on pb.product_id=p.id left join badge bd on bd.id=pb.badge_id "
				+ " and bd.badge_type_id=1 and bd.is_deleted=false group by p.id,bd.id)p on p.id=i.product_id "
				+ " left join icatalogue_batch ib on ib.icatalogue_id = i.id left join producer pr "
				+ " on pr.id = ib.producer_id ");
		if (exportStockReportByOneStoreModel.getStoreId() > 0) {
			builder.append( " where i.store_id =" + "'" + exportStockReportByOneStoreModel.getStoreId() + "'");
		}
		if (exportStockReportByOneStoreModel.getProductId() != null && exportStockReportByOneStoreModel.getProductId() > 0) {
			builder.append(" and p.id =" + "'" + exportStockReportByOneStoreModel.getProductId() + "'");
		}
		if (exportStockReportByOneStoreModel.getRstoreId() != null && exportStockReportByOneStoreModel.getRstoreId() > 0) {
			builder.append( " and ir.store_id =" + "'" + exportStockReportByOneStoreModel.getRstoreId() + "'");
		}
		if (exportStockReportByOneStoreModel.getType() != null && exportStockReportByOneStoreModel.getType() > 0) {
			builder.append (" and mbt.name =" + "'" + exportStockReportByOneStoreModel.getType() + "'");
		}
		if (exportStockReportByOneStoreModel.getIncludeAllProductBadge() != null && !exportStockReportByOneStoreModel.getIncludeAllProductBadge().isEmpty()) {
			StringBuilder paramBuilder = new StringBuilder();

			int j = 0;
			StringBuilder productBadges = new StringBuilder();
			builder.append("  and ");

			productBadges.append(" (");
			List<Integer> materialBadgeList = exportStockReportByOneStoreModel.getIncludeAllProductBadge();

			for (Integer e : materialBadgeList) {
				productBadges.append(e.toString());
				if (j < materialBadgeList.size() - 1) {
					productBadges.append(" ,");
				}
				j++;
			}
			productBadges.append(" )");
			paramBuilder.append("  p.product_badge_id in "+(productBadges));
			builder.append(paramBuilder);
			}
		if (exportStockReportByOneStoreModel.getAbnormalityType() != null && exportStockReportByOneStoreModel.getAbnormalityType() == 200) {
			builder.append("  and i.total_stock=0  ");
		} else if (exportStockReportByOneStoreModel.getAbnormalityType() != null && exportStockReportByOneStoreModel.getAbnormalityType() == 201) {
			builder.append("  and i.total_stock<i.min_stock and i.total_stock<>0 ");
		} else if (exportStockReportByOneStoreModel.getAbnormalityType() != null && exportStockReportByOneStoreModel.getAbnormalityType() == 202) {
			builder.append("  and i.total_stock>i.max_stock ");
		} else if (exportStockReportByOneStoreModel.getAbnormalityType() == null) {
			builder.append(
					"  and (i.total_stock = 0 or i.total_stock<i.min_stock and i.total_stock<>0 or i.total_stock>i.max_stock ) ");
		}
		
		builder.append( " and i.is_deleted=false " );

		builder.append("  order by store_name " );
		try {
			materialsResult = jdbcTemplateHelper.getResults(builder.toString(), ExportStockReportDTO.class);

		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return materialsResult;
	
	}
	
	public ResponseBean getStockReportByStoreServiceWithBatch(ExportStockReportByOneStoreModel exportStockReportByOneStoreModel) throws IOException {
		ResponseBean responsebean = new ResponseBean();
		try {
			this.getStockReportByStoreWithBatchData(exportStockReportByOneStoreModel);
//			kafkaProducer.sendStockReportByStoreWithBatchExportToProducer(exportStockReportByOneStoreModel);
			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
					+ exportStockReportByOneStoreModel.getEmail()
					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
			responsebean.setReturnCode(1);
			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting stock report by store : " + e.getStackTrace());
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		return responsebean;
	}
	
	public void getStockReportByStoreWithBatchData(ExportStockReportByOneStoreModel exportStockReportByOneStoreModel) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<ExportStockReportDTO> storesList = null;
		Object fileData;
		String url =  null;
		Workbook workbook = null;
		FileOutputStream outputStream = null;
		Sheet sheet = null;
		try {
			storesList = getAllMaterailsWithBatch(exportStockReportByOneStoreModel);
			//creating workbook
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0, cellIndex2 = 0, cellIndex3 = 0;
			// Creating row
			Row row = sheet.createRow(0);

			row.createCell(cellIndex++).setCellValue("Title");
			row.createCell(cellIndex++).setCellValue(""+Constants.stock_report_by_store+"");
			Row row1 = sheet.createRow(1);
			row1.createCell(cellIndex1++).setCellValue("StoreName");
			row1.createCell(cellIndex1++).setCellValue(storesList.get(0).getStoreName()+"");
			Row row2 = sheet.createRow(2);
			row2.createCell(cellIndex2++).setCellValue("Generated on");
			row2.createCell(cellIndex2++).setCellValue("" + uploadFileService.dateWithHoursMinutes());

			Row row4 = sheet.createRow(4);
            //creating excelsheet headers
			row4.createCell(cellIndex3++).setCellValue("Material Name");
			row4.createCell(cellIndex3++).setCellValue("Material Tags");
			row4.createCell(cellIndex3++).setCellValue("Store Name");
			row4.createCell(cellIndex3++).setCellValue("Store Tags");
			row4.createCell(cellIndex3++).setCellValue("Country");
			row4.createCell(cellIndex3++).setCellValue("State");
			row4.createCell(cellIndex3++).setCellValue("District/County");
			row4.createCell(cellIndex3++).setCellValue("Taluk/Block");
			row4.createCell(cellIndex3++).setCellValue("Village/City");
			
			row4.createCell(cellIndex3++).setCellValue("Batch ID");
			row4.createCell(cellIndex3++).setCellValue("Stock In Batch");
			row4.createCell(cellIndex3++).setCellValue("Batch Expiry");
			row4.createCell(cellIndex3++).setCellValue("Batch Manufacturer");
			row4.createCell(cellIndex3++).setCellValue("Batch Manufactured Date");
			row4.createCell(cellIndex3++).setCellValue("Batch Updated On");

			row4.createCell(cellIndex3++).setCellValue("Total Stock");
			row4.createCell(cellIndex3++).setCellValue("Days Of Stock");
			row4.createCell(cellIndex3++).setCellValue("Allocated Stock");
			row4.createCell(cellIndex3++).setCellValue("In Transit Stock");
			row4.createCell(cellIndex3++).setCellValue("Min Stock");
			row4.createCell(cellIndex3++).setCellValue("Max Stock");
			row4.createCell(cellIndex3++).setCellValue("Abnormality Type");
			row4.createCell(cellIndex3++).setCellValue("Abnormality Duration-Days");
			row4.createCell(cellIndex3++).setCellValue("Updated On");

			//fetching data under headers
			for (int i = 0; i < storesList.size(); i++) {
				Row dataRow = sheet.createRow(i + 5);
				int rowIndex1 = 0;
				

				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getProductName() == null ? "" : storesList.get(i).getProductName() + "");

				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getProductBadge() == null ? "" : storesList.get(i).getProductBadge() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getStoreName() == null ? "" : storesList.get(i).getStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getStoreBadge() == null ? "" : storesList.get(i).getStoreBadge() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getCountryName() == null ? "" : storesList.get(i).getCountryName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getStateName() == null ? "" : storesList.get(i).getStateName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getDistrictName() == null ? "" : storesList.get(i).getDistrictName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getBlock_name() == null ? "" : storesList.get(i).getBlock_name() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getCity() == null ? "" : storesList.get(i).getCity() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getBatchNo() == null ? null : storesList.get(i).getBatchNo());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getStockInBatch() == null ? 0 : storesList.get(i).getStockInBatch());
				
				Cell cell = dataRow.createCell(rowIndex1++);
				cell.setCellValue(
						storesList.get(i).getBatchExpiry()
						== null ? null : storesList.get(i).getBatchExpiry());
				cell.setCellStyle(dateCellStyle);

				
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getBatchManufacturer() == null ? "" : storesList.get(i).getBatchManufacturer() +"");
				
				Cell cell1 = dataRow.createCell(rowIndex1++);
				cell1.setCellValue(
						storesList.get(i).getBatchManufacturedDate()
						== null ? null : storesList.get(i).getBatchManufacturedDate());
				cell1.setCellStyle(dateCellStyle);

				
				Cell cell2 = dataRow.createCell(rowIndex1++);
				cell2.setCellValue(
						storesList.get(i).getBatchUpdatedOn()
						== null ? null : storesList.get(i).getBatchUpdatedOn());
				cell2.setCellStyle(dateCellStyle);

				
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getTotalStock() == null ? 0 : storesList.get(i).getTotalStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getDaysOfStock() == null ? 0 : storesList.get(i).getDaysOfStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getAllocatedStock() == null ? 0 : storesList.get(i).getAllocatedStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getInTransitStock() == null ? 0 : storesList.get(i).getInTransitStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getMinStock() == null ? 0 : storesList.get(i).getMinStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getMaxStock() == null ? 0 : storesList.get(i).getMaxStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getAbnormalityType() == null ? "" : storesList.get(i).getAbnormalityType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						storesList.get(i).getAbnormalityDurationDays() == null ? 0 : storesList.get(i).getAbnormalityDurationDays());
				
				Cell cell3 = dataRow.createCell(rowIndex1++);

				cell3.setCellValue(
						storesList.get(i).getUpdatedOn() == null ? null : storesList.get(i).getUpdatedOn());
				cell3.setCellStyle(dateCellStyle);
			}

			File tempFile = null;
			tempFile = File.createTempFile("StockReportByStore", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
			workbook.write(outputStream);
			//uploading excel file
			HttpResponse<String> response = uploadFileService.uploadFile(url,exportStockReportByOneStoreModel.getUserName(), tempFile, "StockReportByStore");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			tempFile.delete();

			HashMap<String, Object> emailbody = new HashMap<>();
		
			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";
			
			//sending excel file to particular user email
			emailbody = sendEmailService.getStockReportByStoreEmail(link, exportStockReportByOneStoreModel.getUserName(), exportStockReportByOneStoreModel.getEmail());

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, exportStockReportByOneStoreModel.getEmail(), exportStockReportByOneStoreModel.getUserName(),
					fileDownloadUrl, fileType, fileName, fileSystemPath);
	
//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ exportStockReportByOneStoreModel.getEmail()
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting stock report by store : " + e.getStackTrace());
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		finally {
			outputStream.close();
			workbook.close();
		}
//		return responsebean;
	}
	
	// query withtout pagination
	public List<ExportStockReportDTO> getAllMaterailsWithBatch(ExportStockReportByOneStoreModel exportStockReportByOneStoreModel) {
		List<ExportStockReportDTO> materialsResult = null;
		StringBuilder builder = new StringBuilder();

		builder.append(" select distinct product_name,product_badge,product_badge_id,store_name,store_badge,country_name,state_name,"
				+ " s.district_name,s.block_name,s.city,ib.batch_no,ib.total_stock as stock_in_batch, ib.expiry_date as batch_expiry, "
				+ "	pr.name as batch_manufacturer, ib.manufactured_date as batch_manufactured_date,ib.updated_on as batch_updated_on, "
				+ " i.total_stock,i.days_of_stock,i.allocated_stock,i.in_transit_stock,i.min_stock,i.max_stock,	case when i.total_stock = 0 "
				+ " then 200  when i.total_stock<i.min_stock then 201 when i.total_stock >i.max_stock then 202 else 0 end as abnormality_id,"
				+ " case when i.total_stock = 0 then 'Zero Stock'  when i.total_stock<i.min_stock  then '< Min' when i.total_stock >i.max_stock then '> Max'"
				+ "  else 'Normal' end as abnormality_type,   EXTRACT(epoch from age(coalesce(i.updated_on, now()), i.created_on)/ 86400)as abnormality_duration_days,"
				+ "  i.updated_on  from icatalogue i  left join(select s.id,s.name as store_name, c.name as country_name,st.name as state_name,"
				+ " d.name as district_name,bl.name as block_name,city,address , string_agg(distinct bd.name,',') as store_badge from store s "
				+ " left join store_badge sb on s.id=sb.store_id left join badge bd on bd.id=sb.badge_id and bd.badge_type_id=2 and bd.is_deleted=false "
				+ " left join master_district d on d.id=s.district_id left join master_state st on st.id=s.state_id left join master_country c on c.id=s.country_id "
				+ " left join master_block bl on s.block_id=bl.id group by 1,2,3,4,5,6)s on s.id = i.store_id "
				+ "  left join (select p.id,p.name as product_name, is_batch_enabled, bd.id as product_badge_id,string_agg(distinct bd.name,',') as product_badge from product p  "
				+ " left join product_badge pb on pb.product_id=p.id left join badge bd on bd.id=pb.badge_id and bd.badge_type_id=1 "
				+ " and bd.is_deleted=false group by p.id,bd.id)p on p.id=i.product_id 	left join icatalogue_batch ib on ib.icatalogue_id = i.id "
				+ " left join producer pr on pr.id = ib.producer_id ");
		if (exportStockReportByOneStoreModel.getStoreId() > 0) {
			builder.append( " where i.store_id =" + "'" + exportStockReportByOneStoreModel.getStoreId() + "'");
		}
		if (exportStockReportByOneStoreModel.getProductId() != null && exportStockReportByOneStoreModel.getProductId() > 0) {
			builder.append( " and p.id =" + "'" + exportStockReportByOneStoreModel.getProductId() + "'");
		}
		if (exportStockReportByOneStoreModel.getRstoreId() != null && exportStockReportByOneStoreModel.getRstoreId() > 0) {
			builder.append( " and ir.store_id =" + "'" + exportStockReportByOneStoreModel.getRstoreId() + "'" );
		}
		if (exportStockReportByOneStoreModel.getType() != null && exportStockReportByOneStoreModel.getType() > 0) {
			builder.append( " and mbt.name =" + "'" + exportStockReportByOneStoreModel.getType() + "'");
		}
	
		if (exportStockReportByOneStoreModel.getIncludeAllProductBadge() != null && !exportStockReportByOneStoreModel.getIncludeAllProductBadge().isEmpty()) {
			builder.append(" and p.product_badge_id in ("+ StringUtils.join(exportStockReportByOneStoreModel.getIncludeAllProductBadge(), ",") + ")");

			/*StringBuilder paramBuilder = new StringBuilder();

			int j = 0;
			StringBuilder productBadges = new StringBuilder();
			builder.append("  and ");

			productBadges.append(" (");
			List<Integer> materialBadgeList = exportStockReportByOneStoreModel.getIncludeAllProductBadge();

			for (Integer e : materialBadgeList) {
				productBadges.append(e.toString());
				if (j < materialBadgeList.size() - 1) {
					productBadges.append(" ,");
				}
				j++;
			}
			productBadges.append(" )");
			paramBuilder.append("  p.product_badge_id in "+(productBadges));
			builder.append(paramBuilder);*/
			}
		
		if (exportStockReportByOneStoreModel.getAbnormalityType() != null && exportStockReportByOneStoreModel.getAbnormalityType() == 200) {
			builder.append("  and i.total_stock=0  ");
		} else if (exportStockReportByOneStoreModel.getAbnormalityType() != null && exportStockReportByOneStoreModel.getAbnormalityType() == 201) {
			builder.append("  and i.total_stock<i.min_stock and i.total_stock<>0 ");
		} else if (exportStockReportByOneStoreModel.getAbnormalityType() != null && exportStockReportByOneStoreModel.getAbnormalityType() == 202) {
			builder.append("  and i.total_stock>i.max_stock ");
		} else if (exportStockReportByOneStoreModel.getAbnormalityType() == null) {
			builder.append(
					"  and (i.total_stock = 0 or i.total_stock<i.min_stock and i.total_stock<>0 or i.total_stock>i.max_stock ) ");
		}
		
		builder.append( " and i.is_deleted=false " );

		builder.append("  order by store_name " );
		
			try {
			materialsResult = jdbcTemplateHelper.getResults(builder.toString(), ExportStockReportDTO.class);
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return materialsResult;
	}	
}