package com.dipl.evin2.service;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.dipl.evin2.dto.UserAccountFilterModel;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.UsersRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UsersService {

	@Autowired
	private UsersRepository usersRepository;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private PranthHierarchyService pranthHierarchyService; 

	public Users getById(Long id) {
			Optional<Users> usersOptional = usersRepository.getById(id);
			if (usersOptional.isPresent()) {
				return usersOptional.get();
			} else {
				return null;
			}
	}

	public Users save(Users users) {
			if (users.getId() != null && users.getId() > 0) {
				Optional<Users> existingUsersRecord = usersRepository.getById(users.getId());
				if (existingUsersRecord.isPresent()) {
					return usersRepository.save(users);
				}
			} else {
				users = usersRepository.save(users);
			}
		return users;
	}

	public Integer deleteById(Long id) {
			Optional<Users> existingUsersRecord = usersRepository.getById(id);
			if (existingUsersRecord.isPresent()) {
				usersRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
	}

	public List<Users> getAll() {
			return usersRepository.findAll();
	}

	public List<Users> getByAssetIdAndRole(Long assetId, Integer roleId) {
		return usersRepository.getByAssetIdAndRole(assetId, roleId);
	}
	public List<Map<String, Object>> getAllUsersByPranthId(UserAccountFilterModel userPayLoad, Pageable pageable) throws CustomException {
		Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(userPayLoad.getPranthId().longValue());
		try {
			String sql = "select u.id,u.user_id as username,concat(u.f_name,' ',u.l_name) as full_name,u.role_id, bd.badges,r.name as role,  " + 
					"concat(d.name,', ',st.name) as location,u.mobile,mobile_app_version,last_login_time,logged_from_mobile,u.is_deleted  " + 
					"from users u   " + 
					"join master_role r on u.role_id=r.id   " + 
					"join master_state st on st.id=u.state_id   " + 
					"left join master_district d on d.id=u.district_id  " + 
					"left join (select user_id,string_agg(b.name,',') as badges from user_badge ub   " + 
					" left join badge b on b.id=ub.badge_id group by user_id)bd on bd.user_id=u.id where ";
			sql = addUsersFilter(userPayLoad, sql ,consolidatedPranthIds);
			sql = sql + " order by u.user_id   LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset();
			log.info(sql);
			return jdbcTemplate.queryForList(sql);
			
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return null;
	}

	private String addUsersFilter(UserAccountFilterModel userPayLoad, String sql ,Set<Long> consolidatedPranthIds) {
		if(userPayLoad.getPranthId()!= null) {
		  sql += "u.pranth_id in ( " + StringUtils.join(consolidatedPranthIds, ",") + ")";
		}
		if(userPayLoad.getFirstName()!= "" && userPayLoad.getFirstName() != null) {
			  sql += " and f_name like "+ "'%"+ userPayLoad.getFirstName()+"%'";
			}
		if(userPayLoad.getMobilePhoneNumber() != "" && userPayLoad.getMobilePhoneNumber()!= null) {
			  sql += " and u.mobile ="+"'"+ userPayLoad.getMobilePhoneNumber()+"'";
			}
		if(userPayLoad.getUserId()!= "" && userPayLoad.getUserId()!= null) {
			  sql += " and u.user_id ="+"'"+ userPayLoad.getUserId()+"'";
			}
		if(userPayLoad.getRole()!= "" && userPayLoad.getRole()!= null) {
			  sql += " and r.name ="+"'"+ userPayLoad.getRole()+"'";
			}
		if(userPayLoad.getIsDeleted() != null) {
			  sql += " and u.is_deleted ="+ userPayLoad.getIsDeleted();
			}
		if(userPayLoad.getMobileAppVersion() != "" && userPayLoad.getMobileAppVersion() != null) {
			  sql += " and mobile_app_version ="+"'"+ userPayLoad.getMobileAppVersion()+"'";
			}
		if(userPayLoad.getUserBadge() != "" && userPayLoad.getUserBadge() != null) {
			  sql += " and bd.badges ="+"'"+ userPayLoad.getUserBadge()+"'";
			}
		if(userPayLoad.getFromLastLoginDate() != null && userPayLoad.getToLastLoginDate() != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			  sql += " and cast(last_login_time as date) between "+"'"+ dateFormat.format(userPayLoad.getFromLastLoginDate())+"' and "+"'"+ dateFormat.format(userPayLoad.getToLastLoginDate())+"'";
			}
		return sql;
	}

	public Long findAllUserCount(UserAccountFilterModel userPayLoad) throws CustomException {
		Set<Long> consolidatedPranthIds =pranthHierarchyService.getConsolidatedPranthIds(userPayLoad.getPranthId().longValue());
		Long count = null;
		try {
			String sql = "select count(distinct id) from (select u.id,u.user_id as username,concat(u.f_name,' ',u.l_name) as full_name,u.role_id, bd.badges,r.name as role,  " + 
					"concat(d.name,', ',st.name) as location,u.mobile,mobile_app_version,last_login_time,logged_from_mobile,u.is_deleted  " + 
					"from users u   " + 
					"join master_role r on u.role_id=r.id   " + 
					"join master_state st on st.id=u.state_id   " + 
					"left join master_district d on d.id=u.district_id  " + 
					"left join (select user_id,string_agg(b.name,',') as badges from user_badge ub   " + 
					" left join badge b on b.id=ub.badge_id group by user_id)bd on bd.user_id=u.id where ";
			sql = addUsersFilter(userPayLoad, sql,consolidatedPranthIds);
			sql = sql + ")a";
			log.info(sql);
			count = jdbcTemplate.queryForObject(sql,Long.class);
			return count;
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return null;
	}

	public List<Map<String, Object>> getUserDetails(Long userId) throws CustomException {
		List<Map<String, Object>> result = null;
		try {
			result = usersRepository.findUserDetailsById(userId);
		} catch (Exception e) {
			log.error("Exception occured while fetching user details : {}", e.getCause());
		}
		return result;
	}

	public Users findUserDetailsByName(String userName) throws CustomException {
		Users result = null;
		try {
			result = usersRepository.checkUserByName(userName);
		} catch (Exception e) {
			log.error("Exception occured while fetching user details : {}", e.getCause());
		}
		return result;
	}

	public List<Users>  getAllUsersBasedOnRole(Integer roleId) throws CustomException{
		List<Users> usersListBasedOnRole = null;
		if(roleId != null && roleId > 0 ) {
		usersListBasedOnRole = usersRepository.getUsersBasedOnRoleId(roleId);
		}else {
			usersListBasedOnRole = usersRepository.getAllUsers();
		}
		return usersListBasedOnRole;
	}
 
	public List<Users> findAllByUserIds(List<Long> userIds) {
		return usersRepository.findAllByUserIds(userIds);
	}
	
}