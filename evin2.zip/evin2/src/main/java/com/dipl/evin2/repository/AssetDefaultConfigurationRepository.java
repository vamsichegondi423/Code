package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import com.dipl.evin2.entity.AssetDefaultConfiguration;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface AssetDefaultConfigurationRepository extends JpaRepository<AssetDefaultConfiguration, Long> {

	@Query(value = "select * from asset_default_configuration where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<AssetDefaultConfiguration> getById(Long id);

	@Query(value = "select * from asset_default_configuration where is_deleted = false and pranth_id = ?1", nativeQuery = true)
	public List<AssetDefaultConfiguration> findAll(Long pranthId);
	
	@Query(value = "select * from asset_default_configuration where is_deleted = false", nativeQuery = true)
	public List<AssetDefaultConfiguration> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from asset_default_configuration where id = ?1", nativeQuery = true)
	public void deleteById(Long id);
	
	@Modifying
	@Transactional
	@Query(value = "update asset_default_configuration set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from asset_default_configuration where sensor_id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<AssetDefaultConfiguration> getBySensorId(String sensorId);
	
}