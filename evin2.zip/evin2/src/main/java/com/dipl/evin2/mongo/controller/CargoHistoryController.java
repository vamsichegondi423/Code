package com.dipl.evin2.mongo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.model.CargoHistory;
import com.dipl.evin2.mongo.services.CargoHistoryService;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/api/")
public class CargoHistoryController {
	@Autowired
	private CargoHistoryService cargoHistoryService;

	@KafkaListener(topics = "CARGO-TOPIC", groupId = "group_id")
	public CargoHistory save(String cargoHistory) {
		ObjectMapper obj = new ObjectMapper();
		CargoHistory cargohistory = null;
		try {
			cargohistory = obj.readValue(cargoHistory, CargoHistory.class);
			cargoHistoryService.save(cargohistory);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return cargohistory;
	}
	@GetMapping(value = "/get-all-cargo-hist")
	public Object get() {
		ResponseBean responseBean = new ResponseBean();
		List<CargoHistory> cargoHistList = null;
		try {
			cargoHistList =	cargoHistoryService.getAll();
		} catch (Exception e) {
			responseBean.setData(null);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occured in get all cargohist service" + e.getMessage());
		}
		if(!cargoHistList.isEmpty() && cargoHistList != null ) {
			responseBean.setData(cargoHistList);
			responseBean.setMessage("record fetched successfully");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}else {
			responseBean.setData(null);
			responseBean.setMessage("no record found");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}	
		return responseBean;
	}

	@GetMapping(value = "/get-cargo-hist/{cargo_id}")
	public Object getCargoHist(@PathVariable(value = "cargo_id") String cargoId) {
		ResponseBean responseBean = new ResponseBean();
		List<CargoHistory> cargoHistList = null;
		try {
			cargoHistList = cargoHistoryService.getCargoHist(cargoId);
		} catch (Exception e) {
			responseBean.setData(null);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		if(!cargoHistList.isEmpty() && cargoHistList != null ) {
			responseBean.setData(cargoHistList);
			responseBean.setMessage("record fetched successfully");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}else {
			responseBean.setData(null);
			responseBean.setMessage("no record found");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}
		return responseBean;
	}

}
