package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.entity.UserRoles;
import com.dipl.evin2.repository.UserRolesRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserRolesService {
	
	@Autowired
	private UserRolesRepository userRolesRepository;

	public UserRoles getById(Long id) throws CustomException {
		try {
			Optional<UserRoles> userRolesOptional = userRolesRepository.getById(id);
			if (userRolesOptional.isPresent()) {
				return userRolesOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public UserRoles save(UserRoles userRoles) throws CustomException {
		try {
			if (userRoles.getId() != null && userRoles.getId() > 0) {
				Optional<UserRoles> existingUserRolesRecord = userRolesRepository.getById(userRoles.getId());
				if (existingUserRolesRecord.isPresent()) {
					return userRolesRepository.save(userRoles);
				}
			} else {
				userRoles = userRolesRepository.save(userRoles);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return userRoles;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<UserRoles> existingUserRolesRecord = userRolesRepository.getById(id);
			if (existingUserRolesRecord.isPresent()) {
				userRolesRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<UserRoles> getAll() {
		try {
			return userRolesRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}