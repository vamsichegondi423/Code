package com.dipl.evin2.dto;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

public interface TxnDTO {
	@Value(("#{target.batch_no}"))
	String getBatchNo();
	@Value(("#{target.manufactured_date}"))
	Date getManufacturedDate();
	@Value(("#{target.manufacturer}"))
	String getManufacturer();
	@Value(("#{target.expiry_date}"))
	Date getExpiryDate();
	@Value(("#{target.opening_stock_batch}"))
	Long getOpeningBatchStock();
	@Value(("#{target.closing_stock_batch}"))
	Long getClosingBatchStock();
}
