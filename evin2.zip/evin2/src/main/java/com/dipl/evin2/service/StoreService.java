package com.dipl.evin2.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.dipl.evin2.controller.StoreController.ProductsDTO;
import com.dipl.evin2.controller.StoreController.StoresTransactionDetails;
import com.dipl.evin2.controller.StoreController.TxnPayload;
import com.dipl.evin2.dto.StoreFilterDTO;
import com.dipl.evin2.dto.StoreFilterMapper;
import com.dipl.evin2.dto.StoreFiltersDTO;
import com.dipl.evin2.dto.StoresTransactionDTO;
import com.dipl.evin2.entity.Store;
import com.dipl.evin2.entity.StoreBadge;
import com.dipl.evin2.entity.StoreUsers;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.jackson.StoreBadgeModel;
import com.dipl.evin2.jackson.StoreModel;
import com.dipl.evin2.jackson.StoreUserModel;
import com.dipl.evin2.repository.StoreBadgeRepository;
import com.dipl.evin2.repository.StoreRepository;
import com.dipl.evin2.repository.StoreUsersRepository;
import com.dipl.evin2.service.RolePermissionConfigurationService.RolePermissionConfigurationModel;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.JdbcTemplateHelper;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StoreService {

	@Autowired
	private StoreRepository storeRepository;

	@Autowired
	private StoreUsersRepository storeUsersRepository;

	@Autowired
	private StoreBadgeRepository storeBadgeRepository;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@Autowired
	private UsersService usersService;

	@Autowired
	private BadgeService badgeService;

	@Autowired
	private RolePermissionConfigurationService rolePermissionConfigurationService;

	@Autowired
	JdbcTemplateHelper jdbcTemplateHelper;
	
	@Value("${DBURL}")
	private String dbUrl;

	@Value("${DBUSERNAME}")
	private String dbUserName;

	@Value("${DBPASSWORD}")
	private String dbPassword;

	public Store getById(Long storeId) throws CustomException {
		try {
			Optional<Store> storeOptional = storeRepository.getById(storeId);
			if (storeOptional.isPresent()) {
				return storeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public Store save(Store store) throws CustomException {
		try {
			if (store.getId() != null && store.getId() > 0) {
				Optional<Store> existingStoreRecord = storeRepository.getById(store.getId());
				if (existingStoreRecord.isPresent()) {
					return storeRepository.save(store);
				}
			} else {
				store = storeRepository.save(store);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return store;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<Store> existingStoreRecord = storeRepository.getById(id);
			if (existingStoreRecord.isPresent()) {
				storeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<Store> getAll() {
		try {
			return storeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public Store createStore(StoreModel storeModel) throws Exception {
		Store store = null;
		try {
			store = Store.builder().name(storeModel.getName()).countryId(storeModel.getCountryId())
					.stateId(storeModel.getStateId()).districtId(storeModel.getDistrictId())
					.blockId(storeModel.getBlockId()).city(storeModel.getCity()).pin(storeModel.getPin())
					.address(storeModel.getAddress()).latitude(storeModel.getLatitude())
					.longitude(storeModel.getLongitude()).pranthId(storeModel.getPranthId()).build();
			store.setCreatedBy(Long.valueOf(storeModel.getUserId()));
			store.setUpdatedBy(Long.valueOf(storeModel.getUserId()));
			store = storeRepository.save(store);
			if (store != null) {
				List<StoreUserModel> stUsers = storeModel.getStoreUserModel();
				for (StoreUserModel user : stUsers) {
					StoreUsers strUsr = StoreUsers.builder().storeId(store.getId()).userId(user.getUserId()).build();
					strUsr.setCreatedBy(Long.valueOf(storeModel.getUserId()));
					strUsr.setUpdatedBy(Long.valueOf(storeModel.getUserId()));
					strUsr.setPranthId(storeModel.getPranthId());
					strUsr = storeUsersRepository.save(strUsr);
				}
				List<StoreBadgeModel> strBadges = storeModel.getStoreBadgeModel();
				for (StoreBadgeModel stBadge : strBadges) {
					StoreBadge strbadge = StoreBadge.builder().storeId(store.getId()).badgeId(stBadge.getBadgeId())
							.build();
					strbadge.setCreatedBy(Long.valueOf(storeModel.getUserId()));
					strbadge.setUpdatedBy(Long.valueOf(storeModel.getUserId()));
					strbadge = storeBadgeRepository.save(strbadge);
				}
			} else {
				log.error("store record not saved ");
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured : {}", e);
			throw new Exception("Exception occured while adding store ", e.getCause());
		}

		return store;
	}

	public Store getStoreByName(String name) {
		try {
			Store st = storeRepository.getStoreByStoreName(name);
			if (st != null) {
				return st;
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured while checking store name is exits or not: {}", e);
		}
		return null;
	}

	public List<Map<String, Object>> getAllStoresForUser(int userId, int pranthId, Pageable pageable) {
		List<Map<String, Object>> result = null;
		try {
			result = storeRepository.getAllStoresForUser(userId, pranthId, pageable);
			if (result != null) {
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured while fetching store records for user", e);
		}
		return result;
	}
	public List<StoreFiltersDTO> getAllStoresBasedOnPranth(Long pranthId, String storeName, String tagName,
			Pageable pageable) throws CustomException {
		Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);
		List<StoreFiltersDTO> storesUnderdomain = null;
		try {
			String query1 = "select s.name as store_name,s.id as store_id, concat(s.city,', ',d.name,', ',st.name,', ',c.name) as location,b.name as tag, "
					+ "s.updated_on as lastupdated,u.user_id as updated_by from store s "
					+ "left join master_district d on d.id=s.district_id left join master_state st on st.id=s.state_id "
					+ "left join master_country c on c.id=s.country_id "
					+ "left join store_badge sb on sb.store_id=s.id left join badge b on b.id=sb.badge_id  "
					+ "left join users u on u.id=s.updated_by "
					+ "left join master_badge_type mbt on mbt.id=b.badge_type_id and mbt.name='Store' where s.pranth_id in ( "
					+ StringUtils.join(consolidatedPranthIds, ",") + ")";
			query1 = addStoreFilters(storeName, tagName, query1);
			Long count = getTotalRecrdCuntStoresBasedOnPranth(query1);
			query1 = query1 + " order by store_name LIMIT " + pageable.getPageSize() + " OFFSET "
					+ pageable.getOffset();
			storesUnderdomain = jdbcTemplate.query(query1, new StoreFilterMapper());
			if(!storesUnderdomain.isEmpty()) {
				storesUnderdomain.get(0).setStoreCount(count);
			} 
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return storesUnderdomain;
	}

	private String addStoreFilters(String storeName, String tagName, String query1) {
		if ((storeName != null && !storeName.isEmpty() && tagName != null && !tagName.isEmpty())) {
			query1 += " and  s.name like '%" + storeName + "%' and b.name like '%" + tagName + "%'";
		} else {
			if (storeName != null && !storeName.isEmpty()) {
				query1 += " and s.name like '%" + storeName + "%'";
			}
			if (tagName != null && !tagName.isEmpty()) {
				query1 += " and b.name like '%" + tagName + "%'";
			}
		}
		return query1;
	}

	public Long getTotalRecrdCuntStoresBasedOnPranth( String query1)
			throws CustomException {
		List<StoreFiltersDTO> storesUnderdomain =  new ArrayList<>();
		String query = query1;
		query = query + " order by store_name";
		storesUnderdomain = jdbcTemplate.query(query, new StoreFilterMapper());
		return Long.valueOf(storesUnderdomain.size());
	}

	public Map<String, Object> getAllStoreDataByStoreId(Integer storeId, Integer pranthId) {
		try {
			return storeRepository.getAllStoreDataByStoreId(pranthId, storeId);
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return null;
	}

	public List<Map<String, Object>> getMappingStores(Integer storeId, String mapType) {
		List<Map<String, Object>> result = null;
		try {
			result = storeRepository.getMappingStores(storeId, mapType);
			if (result != null) {
				return result;
			}
		} catch (Exception e) {
			log.error("Exception occured while getting mapping stores ", e.getMessage());
		}
		return null;
	}

	public List<Map<String, Object>> getAllProductsByBatch(Long productId, Long storeId, Pageable pageable) {
		List<Map<String, Object>> fetchMaterialsList = null;
		try {
			if(productId == null) {
				fetchMaterialsList = storeRepository.getProductsByBacth(storeId, pageable);
			}else {
				fetchMaterialsList = storeRepository.getProductsByBacth(productId, storeId, pageable);
			}
		} catch (Exception e) {
			log.error("Exception occured while getting products details", e.getCause());
		}
		return fetchMaterialsList;
	}

	/**
	 * To fetch store txn's
	 * @param transactionsPayload request payload
	 * @param pageable for pagination
	 * @param totalKioskIds to fetch store wise txn's
	 * @param userId  to fetch mapped store id's based on user id
	 * @param pranthId to fetch consolidate pranth id's
	 * @param builder to build query
	 * @return {@link List}
	 * @throws JsonMappingException
	 * @throws JsonProcessingException
	 * @throws CustomException
	 * @throws InterruptedException 
	 */
	
	public StoresTransactionDetails getTransactionsDataByQuery(TxnPayload transactionsPayload, Pageable pageable,
			List<Long> totalKioskIds, Long userId, Long pranthId,StringBuilder builder) throws JsonMappingException, JsonProcessingException, CustomException, InterruptedException{
		StoresTransactionDetails storesTransactionDetails = new StoresTransactionDetails();
		ExecutorService service =Executors.newFixedThreadPool(2);
		Set<Long> consolidatedPranthIds = pranthHierarchyService
				.getConsolidatedPranthIds(transactionsPayload.getPranthId());

		builder.append("select distinct pranth_id, store_id, receiving_store_id,receiving_store_name, "
				+ " store_name,initial_txn_date, store_location,store_badges,material_badges, "
				+ "	transaction_reason,product_id,product_name,opening_stock,transaction_type_operation,"
				+ " stock,closing_stock,created_on, user_id,f_name,l_name,source_type,expiry_date, manufactured_date, "
				+ " batch_manufacturer_name,batch_no,quantity, txn_id,is_batch_enabled, "
				+ " material_status from mvw_txn_report where");
		addFiltersForGetAllTxns(transactionsPayload, consolidatedPranthIds, builder, totalKioskIds, userId, pranthId);
		builder.append(
				" ORDER by created_on  DESC ");
		List<Callable<String>> callableTasks = new ArrayList<>();
		StringBuilder countBuilder = new  StringBuilder(builder);
		try {
			Callable<String> fetchStoreDetailsTask = () -> {
				builder.append(" LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset());
				storesTransactionDetails.setStoresTransactionDTOs(jdbcTemplate.query(builder.toString(), new StoreTransactionsMapper()));
				log.info("Transactions Query:"+builder.toString());
				return "Fetching transactions done.";
			};
			callableTasks.add(fetchStoreDetailsTask);
			Callable<String> fetchCountTask = () -> {
				storesTransactionDetails.setTotalRecordCount(getCountForTxnList(countBuilder));
				return "Fetching transactions count done.";
			};
			callableTasks.add(fetchCountTask);
			List<Future<String>> futures = service.invokeAll(callableTasks);
			if(!futures.isEmpty()) {
				futures.forEach(future -> {
					try {
						log.info(future.get());
					} catch (InterruptedException | ExecutionException e) {
						log.error("Exception occurred while fecthing txn's list", e);
					}
				});
			}
		} catch (Exception e) {
			log.error("Exception occurred while fecthing txn's list", e);
		}finally {
			if(service != null) {
				ExecutorUtil.shutdownAndAwaitTermination(service);
			}
		}
		return storesTransactionDetails;
	}

	private Long getCountForTxnList(StringBuilder countBuilder)  {
		Long count;
		String mainQuery = "SELECT COUNT(*) FROM (" + countBuilder.toString() + " ) as cnt";
		count = jdbcTemplate.queryForObject(mainQuery, Long.class);
		return count;
	}

	
	public StoresTransactionDetails getAllStoresByTransactionLevel(TxnPayload transactionsPayload, Pageable pageable,
			List<Long> totalKioskIds, Long userId, Long pranthId,StringBuilder builder) throws Exception {
		StoresTransactionDetails storesTransactionDetails = null ;
		String updatedOn = null;
		try {
			Connection connection = getConnection(dbUrl, dbUserName, dbPassword);
			Statement statement = connection.createStatement();
			storesTransactionDetails = getTransactionsDataByQuery(transactionsPayload, pageable, totalKioskIds, userId, pranthId,builder);
			String sql = "select j.jobname, max(r.start_time) as updated_on from cron.job j join cron.job_run_details r on j.jobid=r.jobid "
					+ "where r.status='succeeded' and  j.jobname = 'mvw_txn_report' group by 1 "; 
			ResultSet resultSet = statement.executeQuery(sql);
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			while(resultSet.next()) {
				updatedOn = dateFormat.format(resultSet.getTimestamp("updated_on"));	
			}			
			if(storesTransactionDetails.getStoresTransactionDTOs()!= null && !storesTransactionDetails.getStoresTransactionDTOs().isEmpty()) {
				storesTransactionDetails.setLastUpdatedOn(updatedOn);
				return storesTransactionDetails;
			}
		} catch (Exception e) {
			log.error("Exception occured while get the tnx : {}", e.getCause());
			throw new Exception("Exception occured while get the tnx ", e.getCause());
		}
		return storesTransactionDetails;
	}


	private void addFiltersForGetAllTxns(TxnPayload transactionsPayload, Set<Long> consolidatedPranthIds,
			StringBuilder builder, List<Long> offsetKioskIds, Long userId, Long pranthId)
					throws JsonMappingException, JsonProcessingException {
		if (consolidatedPranthIds != null && !consolidatedPranthIds.isEmpty()) {
			builder.append(" pranth_id in  ( " + StringUtils.join(consolidatedPranthIds, ",") + " ) ");
		}
		if (offsetKioskIds != null && !offsetKioskIds.isEmpty()) {
			builder.append(" and store_id in ( " + StringUtils.join(offsetKioskIds, " ,") + ")");
		}
		if (transactionsPayload.getStoreId() != null) {
			builder.append(" and store_id = " + transactionsPayload.getStoreId() + " ");
		}
		if (transactionsPayload.getProductId() != null) {
			builder.append(" and product_id = " + transactionsPayload.getProductId() + " ");
		}
		if (transactionsPayload.getTxnType() != null && !transactionsPayload.getTxnType().isEmpty()) {
			builder.append(" and transaction_type_operation = '" + transactionsPayload.getTxnType() + "' ");
		}
		if (transactionsPayload.getStoreBadge() != null) {
			builder.append("  and store_badge_id in (" +StringUtils.join(transactionsPayload.getStoreBadge(),",")+ ")");
		}
		if (transactionsPayload.getProductBadge() != null) {
			builder.append("  and material_badge_id in (" +StringUtils.join(transactionsPayload.getProductBadge(),",")+ ")");
		}

		if (transactionsPayload.getTxnReason() != null) {
			builder.append(" and transaction_reason = '" + transactionsPayload.getTxnReason() + "' ");
		}
		if (transactionsPayload.getIsActualTxn() != null && transactionsPayload.getIsActualTxn() == true) {
			builder.append(" and initial_txn_date is not null ");
		}
		if (transactionsPayload.getTxnsFromDate() != null && transactionsPayload.getTxnsToDate() != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			builder.append(" and created_on between " + "'"
					+ dateFormat.format(transactionsPayload.getTxnsFromDate()) + "' and " + "'"
					+ dateFormat.format(transactionsPayload.getTxnsToDate()) + "'");
		} else {
			if (transactionsPayload.getTxnsFromDate() != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				builder.append(
						" and created_on >= '" + dateFormat.format(transactionsPayload.getTxnsFromDate()) + "' ");
			}
			if (transactionsPayload.getTxnsToDate() != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				builder.append(
						" and created_on <= '" + dateFormat.format(transactionsPayload.getTxnsToDate()) + "' ");
			}
		}
	/*	if (transactionsPayload.getCountry() != null) {
			builder.append("  and s.country_id = " + transactionsPayload.getCountry());
		}*/
		if (transactionsPayload.getState() != null) {
			builder.append("  and state_id = " + transactionsPayload.getState());
		}
		if (transactionsPayload.getDistrict() != null) {
			builder.append("  and district_id = " + transactionsPayload.getDistrict());
		}
		if (transactionsPayload.getBlock() != null) {
			builder.append("  and block_id = " + transactionsPayload.getBlock());
		}		
	}

	public List<ProductsDTO> getAllMaterails(Long storeId, Long rstoreId, Integer type, Long productId,
			Pageable pageable) {
		List<ProductsDTO> materialsResult = null;
		String adder = "";
		String groupByClause = "";
		if (rstoreId != null && rstoreId > 0) {
			adder = "ir.current_stock as rcvng_store_avl_stock,ir.min_stock as rcvng_store_min_stock ," + 
					"ir.max_stock as rcvng_store_max_stock,ir.allocated_stock as rcvng_store_allocated_stock,ir.in_transit_stock as rcvng_store_intransit_stock," + 
					"ir.total_stock as rcvng_store_total_stock ";
			groupByClause = "ir.current_stock,ir.min_stock,ir.max_stock,ir.allocated_stock,ir.in_transit_stock," + 
					"ir.total_stock, ";
		} else {
			adder = "null as rcvng_store_avl_stock,null as rcvng_store_min_stock ," + 
					"null as rcvng_store_max_stock,null as rcvng_store_allocated_stock,null as rcvng_store_intransit_stock," + 
					"null as rcvng_store_total_stock ";
		}

		String sql = "select st.store_id,st.store_name,p.id as product_id,p.name as product_name,i.allocated_stock,i.in_transit_stock, i.current_stock as available_stock,"
				+ adder + "," + "EXTRACT(epoch from age(coalesce(i.updated_on, now()), i.created_on)/ 86400) as days, "
				+ "i.total_stock,i.min_stock,i.max_stock,i.updated_on, p.is_batch_enabled,string_agg(distinct b.name,',') as product_badge,string_agg( distinct b.id :: text,',') as product_badge_id,  "
				+ " p.handling_unit from icatalogue i"
				+ " left join ( select s.id as store_id,s.name as store_name,sm.mapping_type,sm.mapped_store_id,s1.name as mapped_store_name,  " + 
				" concat(coalesce(d.name,''),', ',coalesce(st.name,'')) as mapped_store_location   " + 
				" from store s " + 
				" left join store_mappings sm on s.id=sm.store_id and sm.is_deleted=false and s.is_deleted=false " + 
				" left join store s1 on s1.id=sm.mapped_store_id  and s1.is_deleted=false " + 
				" left join master_district d on d.id=s.district_id " + 
				" left join master_state st on st.id=s.state_id ) st on st.store_id = i.store_id  and i.is_deleted=false " + 
				"join icatalogue ir on ir.store_id = st.mapped_store_id and i.product_id = ir.product_id and ir.is_deleted=false " + 
				"left join store s on ir.store_id=s.id and s.is_deleted=false " + 
				"left join product p on p.id=i.product_id and p.is_deleted=false " + 
				"left join product_badge pb on pb.product_id=p.id and pb.is_deleted=false " + 
				"left join badge b on b.id=pb.badge_id and b.is_deleted=false " + 
				"left join master_badge_type mbt on mbt.id=b.badge_type_id ";
		if (storeId > 0) {
			sql = sql + " where i.store_id =" + "'" + storeId + "'";
		}
		if (productId != null && productId > 0) {
			sql = sql + " and p.id =" + "'" + productId + "'";
		}
		if (rstoreId != null && rstoreId > 0) {
			sql = sql + " and ir.store_id =" + "'" + rstoreId + "'";
		}
		if (type != null && type > 0) {
			sql = sql + " and mbt.name =" + "'" + type + "'";
		}

		sql = sql + " group by st.store_id,st.store_name,p.id,p.name,i.allocated_stock,i.in_transit_stock,i.current_stock,"
				+ groupByClause
				+ "i.updated_on,i.created_on,i.total_stock,i.min_stock,i.max_stock,i.updated_on, p.handling_unit order by store_id LIMIT "
				+ pageable.getPageSize() + " OFFSET " + pageable.getOffset();
		try {
			materialsResult = jdbcTemplate.query(sql, new StoreWiseOrderProductsMapper());
		} catch (Exception e) {
			log.error("Exception occured while getting products based on store to create indent: {}", e);
		}
		return materialsResult;
	}

	public List<ProductsDTO> getAllMaterails(Long storeId, Integer type, Long productId, Pageable pageable, Long userId,
			Integer txnTypeId, Long pranthId) throws Exception {
		List<ProductsDTO> materialsResult = null;

		Users users = usersService.getById(userId);
		String sql = "select s.id as store_id,s.name as store_name,p.id as product_id,p.name as product_name,i.allocated_stock,i.in_transit_stock, i.current_stock as available_stock,"
				+ "EXTRACT(epoch from age(coalesce(i.updated_on, now()), i.created_on)/ 86400) as days, "
				+ "i.total_stock,i.min_stock,i.max_stock,i.updated_on, p.is_batch_enabled,string_agg(distinct b.name,',') as product_badge,string_agg(distinct b.id :: text,',') as product_badge_id,  "
				+ "p.handling_unit from icatalogue i left join store s on i.store_id=s.id left join product p on p.id=i.product_id "
				+ "left join product_badge pb on pb.product_id=p.id left join badge b on b.id=pb.badge_id "
				+ "left join master_badge_type mbt on mbt.id=b.badge_type_id";
		if (storeId > 0) {
			sql = sql + " where p.is_deleted=false and pb.is_deleted=false and s.is_deleted=false and i.is_deleted=false and i.store_id =" + "'" + storeId + "'";
		}
		if (type != null && type > 0) {
			sql = sql + " and mbt.name =" + "'" + type + "'";
		}
		if (productId != null && productId > 0) {
			sql = sql + " and p.id =" + "'" + productId + "'";
		}
		List<Integer> materialIdsToHide = new ArrayList<Integer>();
		if (txnTypeId.equals(1)) {
			materialIdsToHide.addAll(getMetarialIdsToHide("mnstomtbhfivfinu31", users.getRoleId(), pranthId));
		} else if (txnTypeId.equals(4)) {
			materialIdsToHide.addAll(getMetarialIdsToHide("mnstomtbhfivfd34", users.getRoleId(), pranthId));
		} else if (txnTypeId.equals(2)) {
			materialIdsToHide.addAll(getMetarialIdsToHide("mnstomtbhfivfr32", users.getRoleId(), pranthId));
		} else if (txnTypeId.equals(5)) {
			materialIdsToHide.addAll(getMetarialIdsToHide("mnstomtbhfivft35", users.getRoleId(), pranthId));
		} else if (txnTypeId.equals(3)) {
			materialIdsToHide.addAll(getMetarialIdsToHide("mnstomtbhfivfsc33", users.getRoleId(), pranthId));
		}
		if (materialIdsToHide != null && !materialIdsToHide.isEmpty()) {
			sql = sql + " and p.id not in " + "("
					+ materialIdsToHide.stream().map(String::valueOf).collect(Collectors.joining(",")) + ")";
		}
		sql = sql
				+ " group by s.id,s.name,p.id,p.name,i.allocated_stock,in_transit_stock,i.current_stock,i.updated_on,i.created_on,i.total_stock,i.min_stock,i.max_stock,i.updated_on, p.handling_unit LIMIT "
				+ pageable.getPageSize() + " OFFSET " + pageable.getOffset();
		try {
			materialsResult = jdbcTemplate.query(sql, new StoreWiseProductsMapper());
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return materialsResult;
	}

	private List<Integer> getMetarialIdsToHide(String permissionCode, Integer roleId, Long pranthId) throws Exception {

		RolePermissionConfigurationModel configurationModel = rolePermissionConfigurationService
				.getPermissionCodeValue(permissionCode, roleId, pranthId);
		List<Integer> materialIdsToHide = new ArrayList<>();

		List<Integer> materialTagIdsToHide = new ArrayList<Integer>();
		List<Integer> materialTagsToHide = new ArrayList<Integer>();
		if (configurationModel != null) {
			JsonElement jsonObject = JsonParser.parseString(configurationModel.getConfiguredValue().toString());
			JsonObject object = jsonObject.getAsJsonObject();
			if (object != null && !object.get("value").isJsonNull()) {
				JsonArray integers = object.get("value").getAsJsonArray();
				integers.forEach(m -> materialTagIdsToHide.add(m.getAsInt()));
			}
			if (materialTagIdsToHide != null && !materialTagIdsToHide.isEmpty()) {
				materialTagsToHide = badgeService.getAllByIds(materialTagIdsToHide, pranthId);
			}
		}

		if (!materialTagsToHide.isEmpty()) {
			StringBuilder builder = new StringBuilder("select distinct p.id from "
					+ "		product join product_badge pb on pb.product_id = p.id "
					+ "	join badge bad on bad.id = pb.badge_id  where  bad.name in (" + StringUtils.join(materialTagsToHide, ",")+ ")");
			materialIdsToHide = jdbcTemplate.queryForList(builder.toString(), Integer.class);
			return materialIdsToHide;
		}
		return materialTagIdsToHide;
	}

	public class StoreWiseOrderProductsMapper implements RowMapper<ProductsDTO> {

		@Override
		public ProductsDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
			return ProductsDTO.builder().storeId(rs.getInt("store_id"))
					.storeName(rs.getString("store_name")).productId(rs.getInt("product_id"))
					.productName(rs.getString("product_name")).totalStock(rs.getLong("total_stock"))
					.days(rs.getInt("days")).invMin(rs.getLong("min_stock")).invMax(rs.getLong("max_stock"))
					.lastUpdated(rs.getTimestamp("updated_on")).batchManagement(rs.getBoolean("is_batch_enabled"))
					.productBadge(rs.getString("product_badge")).handlingQuantity(rs.getBigDecimal("handling_unit"))
					.intransitStock(rs.getLong("in_transit_stock")).availableStock(rs.getLong("available_stock"))
					.allocatedStock(rs.getLong("allocated_stock"))
					.rcvngStoreAvlStock(rs.getLong("rcvng_store_avl_stock"))
					.rcvngStoreAllocatedStock(rs.getLong("rcvng_store_allocated_stock"))
					.rcvngStoreIntransitStock(rs.getLong("rcvng_store_intransit_stock"))
					.rcvngStoreMaxStock(rs.getLong("rcvng_store_max_stock"))
					.rcvngStoreMinStock(rs.getLong("rcvng_store_min_stock"))
					.rcvngStoreTotalStock(rs.getLong("rcvng_store_total_stock"))
					.productBadgeId(Long.valueOf(rs.getString("product_badge_id"))).build();
		}

	}

	public class StoreWiseProductsMapper implements RowMapper<ProductsDTO> {

		@Override
		public ProductsDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
			ProductsDTO materialsResult = ProductsDTO.builder().storeId(rs.getInt("store_id"))
					.storeName(rs.getString("store_name")).productId(rs.getInt("product_id"))
					.productName(rs.getString("product_name")).totalStock(rs.getLong("total_stock"))
					.days(rs.getInt("days")).invMin(rs.getLong("min_stock")).invMax(rs.getLong("max_stock"))
					.lastUpdated(rs.getTimestamp("updated_on")).batchManagement(rs.getBoolean("is_batch_enabled"))
					.productBadge(rs.getString("product_badge")).handlingQuantity(rs.getBigDecimal("handling_unit"))
					.intransitStock(rs.getLong("in_transit_stock")).availableStock(rs.getLong("available_stock"))
					.allocatedStock(rs.getLong("allocated_stock"))
					.productBadgeId(Long.valueOf(rs.getString("product_badge_id"))).build();
			return materialsResult;
		}

	}

	public List<Long> getStoresByPranthIdsWithoutPagination(Set<Long> pranthIdsList, Integer locationId, String locationType){

		String query = "select distinct i.store_id from icatalogue i join store s on s.id = i.store_id join product p on p.id=i.product_id where i.is_deleted =false and s.is_deleted=false and p.is_deleted=false and s.pranth_id in ("
				+ StringUtils.join(pranthIdsList, ",") + ") ";
		if(locationType != null && locationType.equalsIgnoreCase("Block")) {
			query = query+" and s.block_id = "+locationId;
		}else if(locationType != null && locationType.equalsIgnoreCase("District")) {
			query = query+" and s.district_id = "+locationId;
		}else if(locationType != null && locationType.equalsIgnoreCase("State")) {
			query = query+" and s.state_id = "+locationId;
		}

		return jdbcTemplate.query(query, new RowMapper<Long>() {
			@Override
			public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
				return (Long) rs.getLong("store_id");
			}
		});
	}

	public List<Long> getAllStores(Set<Long> pranthIdsList, Integer stateId,Integer districtId, String locationType){

		String query = "select distinct i.store_id,s.name as store_name from icatalogue i join store s on s.id = i.store_id  where i.is_deleted =false and s.is_deleted=false  and s.pranth_id in ("
				+ StringUtils.join(pranthIdsList, ",") + ") ";
		if(locationType != null && locationType.equalsIgnoreCase("District")) {
			query = query+" and  s.state_id = "+stateId+" and s.district_id = "+districtId;
		}else if(locationType != null && locationType.equalsIgnoreCase("State")) {
			query = query+" and s.state_id = "+stateId;
		}
		query = query+" order by s.name ";


		List<Long> storeIds = jdbcTemplate.query(query, new RowMapper<Long>() {
			@Override
			public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
				return (Long) rs.getLong("store_id");
			}
		});

		return storeIds;
	}

	public List<Long> getStoresByPranthIds(Set<Long> pranthIdsList, int pageNo, int pageSize) {
		String query = "select distinct i.store_id, s.name from icatalogue i join store s on s.id = i.store_id where s.pranth_id in ("
				+ StringUtils.join(pranthIdsList, ",") + ") order by s.name LIMIT " + pageSize + " OFFSET " + (pageNo * pageSize);
		List<Long> storeIds = jdbcTemplate.query(query, new RowMapper<Long>() {

			@Override
			public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
				return (Long) rs.getLong("store_id");
			}

		});
		return storeIds;
	}

	public Long getAllMaterailsCountOrders(Long storeId, Integer type) {
		Long materialsResult = null;

		String sql = "select count( distinct product_id ) from (select s.id as store_id,s.name as store_name,p.id as product_id,p.name as product_name,i.allocated_stock,i.in_transit_stock, i.current_stock as available_stock,"
				+ "EXTRACT(epoch from age(coalesce(i.updated_on, now()), i.created_on)/ 86400) as days, "
				+ "i.total_stock,i.min_stock,i.max_stock,i.updated_on, p.is_batch_enabled,string_agg(b.name,',') as product_badge, "
				+ "p.handling_unit from icatalogue i "
				+ " left join store s on i.store_id=s.id and s.is_deleted=false "
				+ "left join product p on p.id=i.product_id and p.is_deleted=false "
				+ "left join product_badge pb on pb.product_id=p.id and pb.is_deleted=false "
				+ "left join badge b on b.id=pb.badge_id and b.is_deleted=false "
				+ "left join master_badge_type mbt on mbt.id=b.badge_type_id ";

		if (storeId > 0) {
			sql = sql + " where i.store_id =" + "'" + storeId + "'";
		}
		if (type != null && type > 0) {
			sql = sql + " and mbt.name =" + "'" + type + "'";
		}
		sql = sql
				+ "group by s.id,s.name,p.id,p.name,i.allocated_stock,in_transit_stock,i.current_stock,i.updated_on,i.created_on,i.total_stock,i.min_stock,i.max_stock,i.updated_on, p.handling_unit)a ";
		try {
			materialsResult = jdbcTemplate.queryForObject(sql, Long.class);
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return materialsResult;
	}

	public Long getAllMaterailsCount(Long storeId, Integer type, Integer txnTypeId, Long userId, Long pranthId)
			throws Exception {
		Long materialsResult = null;
		Users users = usersService.getById(userId);
		String sql = "select count( distinct product_id ) from (select s.id as store_id,s.name as store_name,p.id as product_id,p.name as product_name,i.allocated_stock,i.in_transit_stock, i.current_stock as available_stock,"
				+ "EXTRACT(epoch from age(coalesce(i.updated_on, now()), i.created_on)/ 86400) as days, "
				+ "i.total_stock,i.min_stock,i.max_stock,i.updated_on, p.is_batch_enabled,string_agg(b.name,',') as product_badge, "
				+ "p.handling_unit from icatalogue i left join store s on i.store_id=s.id left join product p on p.id=i.product_id "
				+ "left join product_badge pb on pb.product_id=p.id left join badge b on b.id=pb.badge_id "
				+ "left join master_badge_type mbt on mbt.id=b.badge_type_id";

		if (storeId > 0) {
			sql = sql + " where p.is_deleted=false and pb.is_deleted=false and s.is_deleted=false and i.is_deleted=false and i.store_id =" + "'" + storeId + "'";
		}
		if (type != null && type > 0) {
			sql = sql + " and mbt.name =" + "'" + type + "'";
		}
		List<Integer> materialIdsToHide = new ArrayList<Integer>();
		if (txnTypeId.equals(1)) {
			materialIdsToHide.addAll(getMetarialIdsToHide("mnstomtbhfivfinu31", users.getRoleId(), pranthId));
		} else if (txnTypeId.equals(4)) {
			materialIdsToHide.addAll(getMetarialIdsToHide("mnstomtbhfivfd34", users.getRoleId(), pranthId));
		} else if (txnTypeId.equals(2)) {
			materialIdsToHide.addAll(getMetarialIdsToHide("mnstomtbhfivfr32", users.getRoleId(), pranthId));
		} else if (txnTypeId.equals(5)) {
			materialIdsToHide.addAll(getMetarialIdsToHide("mnstomtbhfivft35", users.getRoleId(), pranthId));
		} else if (txnTypeId.equals(3)) {
			materialIdsToHide.addAll(getMetarialIdsToHide("mnstomtbhfivfsc33", users.getRoleId(), pranthId));
		}
		if (materialIdsToHide != null && !materialIdsToHide.isEmpty()) {
			sql = sql + " and pb.badge_id not in " + "("
					+ materialIdsToHide.stream().map(String::valueOf).collect(Collectors.joining(",")) + ")";
		}
		sql = sql
				+ "group by s.id,s.name,p.id,p.name,i.allocated_stock,in_transit_stock,i.current_stock,i.updated_on,i.created_on,i.total_stock,i.min_stock,i.max_stock,i.updated_on, p.handling_unit)a ";
		try {
			materialsResult = jdbcTemplate.queryForObject(sql, Long.class);
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return materialsResult;
	}


	public List<StoreDetailsDTO> getStroesBasedOnPranth(Long pranthId, Pageable pageable) throws CustomException {
		List<StoreDetailsDTO> storesList = null;
		Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);
		if (consolidatedPranthIds != null && !consolidatedPranthIds.isEmpty()) {
			String query = "select distinct s.id as storeId,s.name as storeName,sb.badge_id as badgeId,pranth_id as pranthId, concat(s.city,', ',d.name,', ',st.name,', ',c.name) as storeLocation from \"store\" s "
					+ " left join store_badge sb on sb.store_id = s.id  "
					+ " left join master_district d on d.id=s.district_id  "
					+ " left join master_state st on st.id=s.state_id  "
					+ " left join master_country c on c.id=s.country_id  " + " where pranth_id in ("
					+ StringUtils.join(consolidatedPranthIds, ",") + ") LIMIT " + pageable.getPageSize() + " OFFSET "
					+ (pageable.getPageNumber() * pageable.getPageSize());
			storesList = jdbcTemplate.query(query, new BeanPropertyRowMapper<StoreDetailsDTO>(StoreDetailsDTO.class));

		}
		return storesList;
	}

	public List<UserDetailsDTO> getUsersByPranth(Long pranthId, Pageable pageable) throws CustomException {
		List<UserDetailsDTO> storesList = null;
		Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);
		if (consolidatedPranthIds != null && !consolidatedPranthIds.isEmpty()) {
			String query = "select u.id as Id,u.user_id as userId, concat(u.f_name,' ',u.l_name) as userName,u.address as address, "
					+ "u.sex as gender,u.dob as DOB,u.mobile as phoneNumber, u.pranth_id as pranthId, "
					+ "u.email as emailId,u.mobile_brand as mobile,mr.\"name\" as roleName from users u "
					+ "left join master_role mr on mr.id = u.role_id " + "where u.is_deleted = false and pranth_id in ("
					+ StringUtils.join(consolidatedPranthIds, ",") + ") LIMIT " + pageable.getPageSize() + " OFFSET "
					+ (pageable.getPageNumber() * pageable.getPageSize());
			storesList = jdbcTemplate.query(query, new BeanPropertyRowMapper<UserDetailsDTO>(UserDetailsDTO.class));

		}
		return storesList;
	}

	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@Data
	public static class StoreDetailsDTO {
		private Integer pranthId;
		private Integer storeId;
		private String storeName;
		private String badgeId;
		private String storeLocation;
	}

	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@Data
	public static class UserDetailsDTO {
		private Long Id;
		private Long pranthId;
		private String userId;
		private String userName;
		private String address;
		private String gender;
		private Date dob;
		private String phoneNumber;
		private String emailId;
		private String mobile;
		private String roleName;
		private String userBadge;
	}

	public List<UserDetailsDTO> getUsersByPranthAndStore(Long storeId, Long pranthId, Pageable pageable)
			throws CustomException {
		List<UserDetailsDTO> storesList = null;
		StringBuilder builder = new StringBuilder();
		Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);
		if (consolidatedPranthIds != null && !consolidatedPranthIds.isEmpty()) {
			builder.append(
					"select u.id as Id,u.user_id as userId, concat(u.f_name,' ',u.l_name) as userName,u.address as address, \n"
							+ " u.sex as gender,u.dob as DOB,u.mobile as phoneNumber, u.pranth_id as pranthId, \n"
							+ " u.email as emailId,u.mobile_brand as mobile,mr.name as roleName,b.name as userBadge from users u \n"
							+ "  join user_badge ub on ub.user_id = u.id \n"
							+ "  join badge b on b.id = ub.badge_id \n"
							+ " left join master_role mr on mr.id = u.role_id  \n"
							+ " left join store_users s on s.user_id = u.id  and s.is_deleted = false "
							+ " where u.is_deleted = false and ub.is_deleted = false "
							+ " and s.store_id = " + storeId + " and u.pranth_id in ("
							+ StringUtils.join(consolidatedPranthIds, ",") + ")" + " LIMIT " + pageable.getPageSize()
							+ " OFFSET " + (pageable.getPageNumber() * pageable.getPageSize()));
			storesList = jdbcTemplate.query(builder.toString(), new BeanPropertyRowMapper<UserDetailsDTO>(UserDetailsDTO.class));

		}
		return storesList;
	}

	public List<StoreFilterDTO> getAllStroesBasedOnPranthId(Long pranthId, Long userId,Optional<String> storeName
			,  Optional<Long> storeId) throws CustomException {
		List<StoreFilterDTO> storesUnderdomain = null;
		Users users = usersService.getById(userId);

		Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);
		try {
			String query1 = "select distinct s.name as store_name,s.id as store_id, concat(s.city,', ',d.name,', ',st.name,', ',c.name) as location "
					+ "from store s "
					+ "left join master_district d on d.id=s.district_id left join master_state st on st.id=s.state_id "
					+ "left join master_country c on c.id=s.country_id "
					+ "left join store_badge sb on sb.store_id=s.id left join badge b on b.id=sb.badge_id  "
					+ "left join store_users su on su.store_id = s.id " + "left join users u on u.id=su.user_id "
					+ "left join master_badge_type mbt on mbt.id=b.badge_type_id and mbt.name='Store' where s.pranth_id in ( "
					+ StringUtils.join(consolidatedPranthIds, ",") + ")";
			if (users.getRoleId() != Constants.ADMINISTRATOR_ROLE.intValue() && users.getRoleId() != Constants.OWNER_ROLE.intValue()) {
				query1 = query1 + " and u.id = " + userId;
			}
			if(storeName.isPresent()) {
				query1 = query1 + " and s.name like '%" + storeName.get() + "%'";
			}
			if(storeId.isPresent()) {
				query1 = query1 + " and s.id  = " + storeId.get();
			}
			query1 = query1 + " order by store_name ";
			storesUnderdomain = jdbcTemplate.query(query1, new StoreFiltersMapper());
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return storesUnderdomain;
	}

	class StoreFiltersMapper implements RowMapper<StoreFilterDTO> {

		public StoreFilterDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
			StoreFilterDTO storeResult = StoreFilterDTO.builder().storeName(rs.getString("store_name"))
					.location(rs.getString("location")).storeId(rs.getLong("store_id")).build();

			return storeResult;
		}
	}

	public List<Long> getToatalStoreIds(Long pranthId, Long userId) throws CustomException {
		Set<Long> domainStoreIds = new HashSet<>();
		Users users = usersService.getById(userId);
		if (users.getRoleId() == Constants.ADMINISTRATOR_ROLE.intValue() || users.getRoleId() == Constants.OWNER_ROLE.intValue()) {
			Set<Long> pranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);
			pranthIds.add(pranthId);
		} else {
			List<Map<String, Object>> maps = getAllStoresForUser(userId.intValue(), pranthId.intValue(), null);
			maps.forEach(m -> {
				domainStoreIds.add(Long.valueOf(m.get("store_id") + ""));
			});
		}

		return new ArrayList<>(domainStoreIds);
	}

	public List<Long> getTotalStoreIdsWithLocationFilters(Long pranthId, Long userId, Integer stateId, Integer districtId, Integer blockId) throws CustomException {

		Set<Long> domainStoreIds = new HashSet<>();
		Users users = usersService.getById(userId);	
		Set<Long> pranthIds = null;
		if(users.getRoleId() == Constants.ADMINISTRATOR_ROLE.intValue() || users.getRoleId() == Constants.OWNER_ROLE.intValue() || users.getRoleId() == Constants.MANAGER_ROLE.intValue() || users.getRoleId()== Constants.OPERATOR_ROLE.intValue()){

			pranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);

			pranthIds.add(pranthId);

			if (!pranthIds.isEmpty()) {
				if(blockId != null) {
					domainStoreIds.addAll(getStoresByPranthIdsWithoutPagination(pranthIds, blockId, "Block"));
				} else if(districtId != null) {
					domainStoreIds.addAll(getStoresByPranthIdsWithoutPagination(pranthIds, districtId, "District"));
				} else if(stateId != null) {
					domainStoreIds.addAll(getStoresByPranthIdsWithoutPagination(pranthIds, stateId, "State"));
				} else {
					domainStoreIds.addAll(getStoresByPranthIdsWithoutPagination(pranthIds, null, null));
				}
			}
		}else {
			List<Map<String, Object>> maps = getAllStoresForUser(userId.intValue(), pranthIds.iterator().next().intValue(), null);
			maps.forEach(m -> domainStoreIds.add(Long.valueOf(m.get("store_id")+"")));
		}

		return new ArrayList<>(domainStoreIds);
	}

	public List<StoreBadgeDetails> getStoreBadgeDetails(Set<Long> storeIds){
		String stroreIdsString = StringUtils.join(storeIds.toArray(), ",");
		String query = "select distinct s.id as storeId, s.\"name\" as storeName, b.id as badgeId, b.\"name\" as badgeName, ms.id as stateId, ms.\"name\" as stateName,\r\n"
				+ "md.id as districtId, md.\"name\" as districtName, mb.id as blockId, mb.\"name\" as blockName\r\n"
				+ "from store s join store_badge sb on s.id = sb.store_id join badge b on sb.badge_id = b.id\r\n"
				+ "left join master_state ms on s.state_id = ms.id\r\n"
				+ "left join master_district md on s.district_id = md.id \r\n"
				+ "left join master_block mb on s.block_id = mb.id"
				+ " where s.id in ("+stroreIdsString+")";
		return jdbcTemplateHelper.getResults(query, StoreBadgeDetails.class);
	}

	public List<Long> getDistrictByStateIds(Set<Long> stateIds, Integer locationId, String locationType){

		String query = "select distinct md.id as district_id from master_state ms join master_district md s on ms.id = md.district_id join product p on p.id=i.product_id where i.is_deleted =false and s.is_deleted=false and p.is_deleted=false and md.district_id in ("
				+ StringUtils.join(stateIds, ",") + ") ";
		if(locationType != null && locationType.equalsIgnoreCase("Block")) {
			query = query+" and s.block_id = "+locationId;
		}else if(locationType != null && locationType.equalsIgnoreCase("District")) {
			query = query+" and s.district_id = "+locationId;
		}else if(locationType != null && locationType.equalsIgnoreCase("State")) {
			query = query+" and s.state_id = "+locationId;
		}

		return jdbcTemplate.query(query, new RowMapper<Long>() {
			@Override
			public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
				return (Long) rs.getLong("store_id");
			}
		});
	}

	public List<Long> getTotalDistricts(Set<Long> pranthIdsList, Integer locationId, String locationType){

		String query = "select distinct s.district_id,md.name from icatalogue i join store s on s.id = i.store_id "
				+ " join master_district md on md.id = s.district_id where i.is_deleted =false and s.is_deleted=false and s.pranth_id in ("
				+ StringUtils.join(pranthIdsList, ",") + ") ";
		if(locationType != null && locationType.equalsIgnoreCase("Block")) {
			query = query+" and s.block_id = "+locationId;
		}else if(locationType != null && locationType.equalsIgnoreCase("District")) {
			query = query+" and s.district_id = "+locationId;
		}else if(locationType != null && locationType.equalsIgnoreCase("State")) {
			query = query+" and s.state_id = "+locationId;
		}
		else if(locationType != null && locationType.equalsIgnoreCase("Country")){
			query = query+" and s.country_id = "+locationId;

		}
		query = query +" and s.district_id is not null ";
		query = query +" order by md.name";

		List<Long> districtIds = jdbcTemplate.query(query, new RowMapper<Long>() {
			@Override
			public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
				return (Long) rs.getLong("district_id");
			}
		});
		return districtIds;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class StoreBadgeDetails{
		private Long storeId;
		private String storeName;
		private Long badgeId;
		private String badgeName;
		private Long stateId;
		private String stateName;
		private Long districtId;
		private String districtName;
		private Long blockId;
		private String blockName;

	}
	
	private static Connection getConnection(String dbUrl, String dbUserName, String dbPaswrd) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection(dbUrl, dbUserName, dbPaswrd);
			return conn;
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}