package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.PranthHierarchy;
import com.dipl.evin2.entity.SensorDefaultConfiguration;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.SensorDefaultConfigurationRepository;
import com.dipl.evin2.util.ResponseBean;

@Service
public class SensorDefaultConfigurationService {

	@Autowired
	private SensorDefaultConfigurationRepository sensorDefaultConfigurationRepository;


	@Autowired
	private PranthHierarchyService pranthHierarchyService;
	
	public SensorDefaultConfiguration getById(Long id) {
		Optional<SensorDefaultConfiguration> sensorDefaultConfigurationOptional = sensorDefaultConfigurationRepository.getById(id);
		if (sensorDefaultConfigurationOptional.isPresent()) {
			return sensorDefaultConfigurationOptional.get();
		} else {
			return null;
		}
	}

	public SensorDefaultConfiguration save(SensorDefaultConfiguration sensorDefaultConfiguration) {
		if (sensorDefaultConfiguration.getId() != null && sensorDefaultConfiguration.getId() > 0) {
			Optional<SensorDefaultConfiguration> existingSensorDefaultConfigurationRecord = sensorDefaultConfigurationRepository.getById(sensorDefaultConfiguration.getId());
			if (existingSensorDefaultConfigurationRecord.isPresent()) {
				return sensorDefaultConfigurationRepository.save(sensorDefaultConfiguration);
			}
		} else {
			sensorDefaultConfiguration = sensorDefaultConfigurationRepository.save(sensorDefaultConfiguration);
		}
		return sensorDefaultConfiguration;
	}

	public Integer deleteById(Long id) {
		Optional<SensorDefaultConfiguration> existingSensorDefaultConfigurationRecord = sensorDefaultConfigurationRepository.getById(id);
		if (existingSensorDefaultConfigurationRecord.isPresent()) {
			sensorDefaultConfigurationRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	public List<SensorDefaultConfiguration> getAll(Long pranthId) {
		return sensorDefaultConfigurationRepository.findAll(pranthId);
	}

	public SensorDefaultConfiguration getBySensorId(String sensorId) {
		Optional<SensorDefaultConfiguration> sensorDefaultConfigurationOptional = sensorDefaultConfigurationRepository.getBySensorId(sensorId);
		if (sensorDefaultConfigurationOptional.isPresent()) {
			return sensorDefaultConfigurationOptional.get();
		} else {
			return null;
		}
	}

	public List<SensorDefaultConfiguration> saveAll(List<SensorDefaultConfiguration> sensorDefaultConfigurations) {
		if (sensorDefaultConfigurations != null && !sensorDefaultConfigurations.isEmpty()) {
			sensorDefaultConfigurations = sensorDefaultConfigurationRepository.saveAll(sensorDefaultConfigurations);
		}
		return sensorDefaultConfigurations;
	}
	
	@Transactional(rollbackOn = { Exception.class , CustomException.class })
	public ResponseBean updateParentSensorDefaultConfigToChild(Long pranthId, Long mappedPranthId, Long userId)  throws CustomException{
		ResponseBean responseBean  = new ResponseBean();
		Long pranthid = 0L;
		List<SensorDefaultConfiguration> sdcList= new ArrayList<>();
		Optional<PranthHierarchy> pranthHierarchy = pranthHierarchyService.getByMappingId(mappedPranthId);
		try {
			if(pranthHierarchy.isPresent()) {
				if(pranthId != null && pranthId != 0) {
					pranthid = pranthId;
				} else {
					pranthid = pranthHierarchy.get().getPranthId();
				}
				List<SensorDefaultConfiguration> defaultConfigurationList = sensorDefaultConfigurationRepository.findAll(pranthid);
				for(SensorDefaultConfiguration sdc: defaultConfigurationList) {
					List<SensorDefaultConfiguration> defaultConfigurations =  sensorDefaultConfigurationRepository.findBySensorAndPranthId(sdc.getSensorId(),mappedPranthId);
					if(defaultConfigurations.isEmpty()) {
						SensorDefaultConfiguration configuration = SensorDefaultConfiguration.builder().alarmFrequencyNotificationDuration(sdc.getAlarmFrequencyNotificationDuration())
								.alarmFrequencyNotificationNumber(sdc.getAlarmFrequencyNotificationNumber()).deviceAlarmPushNotification(sdc.getDeviceAlarmPushNotification()).highAlarmTemperature(sdc.getHighAlarmTemperature())
								.highAlarmTemperatureDuration(sdc.getHighAlarmTemperatureDuration()).highWarningTemperature(sdc.getHighWarningTemperature()).highWarningTemperatureDuration(sdc.getHighWarningTemperatureDuration())
								.lowAlarmTemperature(sdc.getLowAlarmTemperature()).lowAlarmTemperatureDuration(sdc.getLowAlarmTemperatureDuration()).lowWarningTemperature(sdc.getLowWarningTemperature()).lowWarningTemperatureDuration(sdc.getLowWarningTemperatureDuration())
								.pranthId(mappedPranthId).pushInterval(sdc.getPushInterval()).samplingInterval(sdc.getSamplingInterval()).sensorId(sdc.getSensorId()).statsPushNotification(sdc.getStatsPushNotification())
								.temperatureAlarmPushNotifications(sdc.getTemperatureAlarmPushNotifications()).temperatureIncursionExcursionPushNotification(sdc.getTemperatureIncursionExcursionPushNotification())
								.temperaturePushNotification(sdc.getTemperaturePushNotification()).useDefaultConfiguration(sdc.getUseDefaultConfiguration()).build();
						configuration.setUpdatedBy(userId);
						configuration.setUpdatedOn(new Date());
						configuration.setCreatedBy(sdc.getCreatedBy());
						configuration.setCreatedOn(sdc.getCreatedOn());
						sdcList.add(configuration);
					}
				}
				sensorDefaultConfigurationRepository.saveAll(sdcList);
				responseBean.setMessage("Sensor default config has been updated for child");
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
			} else {
				responseBean.setMessage("No Record found with mappedPranthId");
				responseBean.setReturnCode(0);
				responseBean.setStatus(HttpStatus.NO_CONTENT);
			}
		} catch(Exception e) {
//			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseBean;
	}
}