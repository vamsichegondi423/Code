package com.dipl.evin2.mongo.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.config.MongoConfig;
import com.dipl.evin2.controller.BookingsController.BookingsExportModel;
import com.dipl.evin2.controller.CargoController.ShipmentExportModel;
import com.dipl.evin2.model.ExportStockDeviantModel;
import com.dipl.evin2.model.ExportStockReportByOneStoreModel;
import com.dipl.evin2.model.ExportStockReportModel;
import com.dipl.evin2.model.ExportTransactionModel;
import com.dipl.evin2.model.SmsNotificationModel;
import com.dipl.evin2.mongo.repository.ResponseRepository;
import com.dipl.evin2.mongo.repository.SmsRepository;
import com.dipl.evin2.service.ExportBookingService;
import com.dipl.evin2.service.ExportShimpentService;
import com.dipl.evin2.service.ExportStockDeviantService;
import com.dipl.evin2.service.ExportStockReportByStoreService;
import com.dipl.evin2.service.ExportStockReportService;
import com.dipl.evin2.service.ExportTransactionService;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/kafka")
public class KafkaConsumer {
	/**
	 * Atrribute logger for current class
	 */
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	/**
	 * Atrribute for ResponseRepository
	 */
	@Autowired
	ResponseRepository ResponseRepository;
	/**
	 * Atrribute for MongoConfig
	 */
	@Autowired
	MongoConfig MongoConfig;
	@Autowired
	SmsRepository smsRepository;
	@Autowired
	ExportStockReportService exportStockReportService;
	@Autowired
	ExportTransactionService exportTransactionService;
	@Autowired
	private ExportStockDeviantService exportStockDeviantService;
	@Autowired
	private ExportBookingService exportBookingService;
	@Autowired
	private ExportShimpentService exportShipmentService;
	@Autowired
	private ExportStockReportByStoreService exportStockReportByStoreService;

	@RequestMapping(value = "/get", method = RequestMethod.GET)
	@KafkaListener(topics = "sms_topic", groupId = "group_id")
	public void consume(String smsNotificationModel) throws JsonMappingException, JsonProcessingException {
		ObjectMapper obj = new ObjectMapper();
		SmsNotificationModel obi = obj.readValue(smsNotificationModel, SmsNotificationModel.class);
		logger.info(String.format("#### -> Consumed message -> %s", obi));
		smsRepository.save(obi);
	}

	@KafkaListener(topics = "send_sms_data_topic", groupId = "group_id")
	public void getSMSReponses(String reponseModel) throws JsonMappingException, JsonProcessingException {
		ObjectMapper obj = new ObjectMapper();
		try {
			ResponseBean response = obj.readValue(reponseModel, ResponseBean.class);
			ResponseRepository.save(response);
			System.out.println(" Response :" + response);
		} catch (Exception e) {
			logger.error(" Exception occured while saving data in sms topic", e);
		}

	}
  
//	@KafkaListener(topics = "STOCK_EXPORT_WITHOUT_BATCH_TOPIC", groupId = "exports")
//	public void consumeStockWithoutBatchReport(String strExportStockReportModel) throws JsonMappingException, JsonProcessingException {
//		ObjectMapper obj = new ObjectMapper();
//		ExportStockReportModel exportStockReportModel = obj.readValue(strExportStockReportModel, ExportStockReportModel.class);
//		try {
//			exportStockReportService.getStockWithoutBatch(exportStockReportModel);
//		} catch (IOException e) {
//			log.error("Exception occured in  export stock report consumer", e);
//		}
//	}
	
//	@KafkaListener(topics = "STOCK_EXPORT_WITH_BATCH_TOPIC", groupId = "exports")
//	public void consumeStockWithBatchReport(String strExportStockReportModel) throws JsonMappingException, JsonProcessingException {
//		ObjectMapper obj = new ObjectMapper();
//		ExportStockReportModel exportStockReportModel = obj.readValue(strExportStockReportModel, ExportStockReportModel.class);
//		try {
//			exportStockReportService.getStockWithBatch(exportStockReportModel);
//		} catch (IOException e) {
//			log.error("Exception occured in export stock report consumer", e);
//		}
//	}
	
 	
//	@KafkaListener(topics = "TXN_EXPORT_WITHOUT_BATCH_TOPIC", groupId = "exports")
//	public void consumeTransactionDataWithoutBatch(String strExportTransactionModel)
//			throws JsonMappingException, JsonProcessingException {
//		ObjectMapper obj = new ObjectMapper();
//		ExportTransactionModel exportTransactionModel = obj.readValue(strExportTransactionModel,
//				ExportTransactionModel.class);
//		try {
//			exportTransactionService.getTransactionDataWithoutBatch(exportTransactionModel.getExportTxnModel(),
//					exportTransactionModel.getPranthId(), exportTransactionModel.getUserId(),
//					exportTransactionModel.getUserName(), exportTransactionModel.getEmail(),
//					exportTransactionModel.getOffsetStoreIds());
//		} catch (IOException e) {
//			log.error("Exception occured in transaction data consumer", e);
//		}
//	}
	 
	
//	@KafkaListener(topics = "TXN_EXPORT_WITH_BATCH_TOPIC", groupId = "exports")
//	public void consumeTransactionWithBatch(String strExportTransactionModel) throws JsonMappingException, JsonProcessingException {
//		ObjectMapper obj = new ObjectMapper();
//		ExportTransactionModel exportTransactionModel = obj.readValue(strExportTransactionModel, ExportTransactionModel.class);
//		try {
//			exportTransactionService.getTransactionDataWithBatch(exportTransactionModel.getExportTxnModel(),
//					exportTransactionModel.getUserName(), exportTransactionModel.getEmail(),
//					exportTransactionModel.getPranthId(), exportTransactionModel.getUserId(), 
//					exportTransactionModel.getOffsetStoreIds());
//		} catch (IOException e) {
//			log.error("Exception occured in  export stock report consumer", e);
//		}
//	}
	 
//	@KafkaListener(topics = "STOCK_DEVIANT_EXPORT_TOPIC", groupId = "exports")
//	public void consumeStockDeviantExportData(String strExportStockDeviantModel)
//			throws JsonMappingException, JsonProcessingException, Exception {
//		ObjectMapper obj = new ObjectMapper();
//		ExportStockDeviantModel exportStockDeviantModel = obj.readValue(strExportStockDeviantModel,
//				ExportStockDeviantModel.class);
//		try {
//			exportStockDeviantService.getStockDeviantDataToExport(
//					exportStockDeviantModel.getExportStockDeviantPayload(), exportStockDeviantModel.getPranthId(),
//					exportStockDeviantModel.getUserId(), exportStockDeviantModel.getUserName(),
//					exportStockDeviantModel.getEmail(), exportStockDeviantModel.getMaterialTagsToHide(),
//					exportStockDeviantModel.getTotalStoreIds());
//		} catch (IOException e) {
//			log.error("Exception occured in  export stock deviant consumer", e);
//		}
//	}
	
//	@KafkaListener(topics = "BOOKINGS_EXPORT_TOPIC", groupId = "exports")
//	public void consumeBookingsExportData(String strBookingsExportModel)
//			throws JsonMappingException, JsonProcessingException, Exception {
//		ObjectMapper obj = new ObjectMapper();
//		BookingsExportModel bookingsExportModel = obj.readValue(strBookingsExportModel, BookingsExportModel.class);
//		try {
//			exportBookingService.getBookingsExportData(bookingsExportModel.getBookingsByFilterPayload(),
//					bookingsExportModel.getPranthId(), bookingsExportModel.getUserId(),
//					bookingsExportModel.getUserName(), bookingsExportModel.getEmail(),
//					bookingsExportModel.getOffsetStoreIds());
//		} catch (IOException e) {
//			log.error("Exception occured in bookings export consumer", e);
//		}
//	}
	
//	@KafkaListener(topics = "SHIPMENTS_EXPORT_TOPIC", groupId = "exports")
//	public void consumeShipmentsExportData(String strShipmentExportModel)
//			throws JsonMappingException, JsonProcessingException, Exception {
//		ObjectMapper obj = new ObjectMapper();
//		ShipmentExportModel shipmentExportModel = obj.readValue(strShipmentExportModel, ShipmentExportModel.class);
//		try {
//			exportShipmentService.getShipmentExportData(shipmentExportModel.getCargoFilterModel(),
//					shipmentExportModel.getPranthId(), shipmentExportModel.getUserId(),
//					shipmentExportModel.getUserName(), shipmentExportModel.getEmail(),
//					shipmentExportModel.getOffsetStoreIds());
//		} catch (IOException e) {
//			log.error("Exception occured in shipments export consumer", e);
//		}
//	}
	
//	@KafkaListener(topics = "STOCK_REPORT_BY_STORE_WITH_BATCH_EXPORT_TOPIC", groupId = "exports")
//	public void consumeStockReportByStoreWithBatchExportData(String strShipmentExportModel)
//			throws JsonMappingException, JsonProcessingException, Exception {
//		ObjectMapper obj = new ObjectMapper();
//		ExportStockReportByOneStoreModel exportStockReportByOneStoreModel = obj.readValue(strShipmentExportModel, ExportStockReportByOneStoreModel.class);
//		try {
//			exportStockReportByStoreService.getStockReportByStoreWithBatchData(exportStockReportByOneStoreModel);
//		} catch (IOException e) {
//			log.error("Exception occured in shipments export consumer", e);
//		}
//	}
	
//	@KafkaListener(topics = "STOCK_REPORT_BY_STORE_WITHOUT_BATCH_EXPORT_TOPIC", groupId = "exports")
//	public void consumeStockReportByStoreWithoutBatchExportData(String strShipmentExportModel)
//			throws JsonMappingException, JsonProcessingException, Exception {
//		ObjectMapper obj = new ObjectMapper();
//		ExportStockReportByOneStoreModel exportStockReportByOneStoreModel = obj.readValue(strShipmentExportModel, ExportStockReportByOneStoreModel.class);
//		try {
//			exportStockReportByStoreService.getStockReportByStoreWithoutBatchData(exportStockReportByOneStoreModel);
//		} catch (IOException e) {
//			log.error("Exception occured in shipments export consumer", e);
//		}
//	}
	
}
