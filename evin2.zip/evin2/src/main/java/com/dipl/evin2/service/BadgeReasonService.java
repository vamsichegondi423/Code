package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.BadgeReason;
import com.dipl.evin2.entity.MasterReason;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.BadgeReasonRepository;
import com.dipl.evin2.util.JdbcTemplateHelper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BadgeReasonService {

	@Autowired
	private BadgeReasonRepository badgeReasonRepository;

	@Autowired
	private MasterReasonService masterReasonService;

	@Autowired
	private JdbcTemplateHelper jdbcTemplateHelper;

	public BadgeReason getById(Integer id) throws CustomException {
		try {
			Optional<BadgeReason> badgeReasonOptional = badgeReasonRepository.getById(id);
			if (badgeReasonOptional.isPresent()) {
				return badgeReasonOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}


	public List<MasterReason> getByBadgeId(Long badgeId, Long pranthId, String transactionType) throws CustomException {
		List<MasterReason> masterReasonsList = new ArrayList<MasterReason>();
		try {
			String query = "select mr.id,mr.name,mr.created_by,mr.created_on,mr.is_deleted,mr.updated_by,mr.updated_on,mr.reason_type,mr.is_default, " + 
					"rp.pranth_id from badge_reason bg join master_reason mr on bg.reason_id = mr.id join reason_pranth rp on rp.reason_id= mr.id"
					+ " where bg.badge_id = "+badgeId +"  and mr.reason_type = '"+transactionType+"' and bg.pranth_id="+pranthId+" and bg.is_deleted = false";
			masterReasonsList = jdbcTemplateHelper.getResults(query, MasterReason.class); 
			if (!masterReasonsList.isEmpty()) {
				return masterReasonsList;
			} else {
				return masterReasonsList;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Excpection while fecth data", HttpStatus.BAD_REQUEST);
		}
	}

	public BadgeReason save(BadgeReason badgeReason) {
		try {
			if (badgeReason.getId() != null && badgeReason.getId() > 0) {
				Optional<BadgeReason> existingBadgeReasonRecord = badgeReasonRepository.getById(badgeReason.getId());
				if (existingBadgeReasonRecord.isPresent()) {
					badgeReason = verifyMasterReason(badgeReason);
					return badgeReasonRepository.save(badgeReason);
				}
			} else {
				badgeReason = verifyMasterReason(badgeReason);
				badgeReason = badgeReasonRepository.save(badgeReason);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return badgeReason;
	}


	private BadgeReason verifyMasterReason(BadgeReason badgeReason) throws CustomException {
		if(badgeReason.getCreatedBy() == null) {
			badgeReason.setCreatedBy(badgeReason.getUpdatedBy());
		}
		MasterReason findDuplicateReason = masterReasonService.findDuplicateReason(badgeReason.getMasterReason().getName(), badgeReason.getMasterReason().getReasonType(), badgeReason.getPranthId());
		if(findDuplicateReason == null) {
			badgeReason.getMasterReason().setIsDeleted(false);
			MasterReason save = masterReasonService.save(badgeReason.getMasterReason(), badgeReason.getPranthId());
			badgeReason.setReasonId(save.getId().longValue());
		} else {
			if(findDuplicateReason != null && findDuplicateReason.getIsDeleted()) {
				findDuplicateReason.setIsDeleted(false);
				masterReasonService.save(findDuplicateReason, badgeReason.getPranthId());
			}
			badgeReason.setReasonId(findDuplicateReason.getId().longValue());
			badgeReason.setMasterReason(findDuplicateReason);
		}
		BadgeReason byBadgeIdAndReasonId = getByBadgeIdAndReasonId(badgeReason);
		if(byBadgeIdAndReasonId != null) {
			badgeReason = byBadgeIdAndReasonId;
		} 
		return badgeReason;
	}

	public Integer deleteById(Integer id,Long pranthId) throws CustomException {
		try {
			Optional<BadgeReason> existingBadgeReasonRecord = badgeReasonRepository.findByReasonId(id.longValue());
			if (existingBadgeReasonRecord.isPresent()) {
				badgeReasonRepository.deleteByReasonIdSoft(id.longValue());
				masterReasonService.deleteById(id, pranthId);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<BadgeReason> getAll() {
		try {
			return badgeReasonRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public BadgeReason getByBadgeIdAndReasonId(BadgeReason reason) {
		Optional<BadgeReason> badgeReasonOptional = badgeReasonRepository.getByBadgeIdAndReasonIdAndPranthId(reason.getBadgeId(), reason.getReasonId(), reason.getPranthId());
		if (badgeReasonOptional.isPresent()) {
			return badgeReasonOptional.get();
		} else {
			return null;
		}
	}

}