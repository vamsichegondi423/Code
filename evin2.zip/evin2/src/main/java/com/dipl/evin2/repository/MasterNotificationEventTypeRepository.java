package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import com.dipl.evin2.entity.MasterNotificationEventType;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface MasterNotificationEventTypeRepository extends JpaRepository<MasterNotificationEventType, Integer> {

	@Query(value = "select * from master_notification_event_type where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterNotificationEventType> getById(Integer id);

	@Query(value = "select * from master_notification_event_type where is_deleted = false", nativeQuery = true)
	public List<MasterNotificationEventType> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from master_notification_event_type where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);
	
	@Modifying
	@Transactional
	@Query(value = "update master_notification_event_type set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);
	
}