package com.dipl.evin2.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dipl.evin2.dto.ProductDTO;
import com.dipl.evin2.dto.StoresDTO;
import com.dipl.evin2.dto.StoresTransactionDTO;

public class StoreTransactionsMapper implements RowMapper<StoresTransactionDTO> {

	@Override
	public StoresTransactionDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		StoresDTO storesDTO = StoresDTO.builder().pranthId(rs.getInt("pranth_id")).storeId(rs.getInt("store_id"))
				.storeName(rs.getString("store_name")).productId(rs.getInt("product_id"))
				.productName(rs.getString("product_name")).rcvngStoreId(rs.getInt("receiving_store_id"))
				.rcvngStoreName(rs.getString("receiving_store_name")).build();

		ProductDTO materialDTO = ProductDTO.builder().productId(rs.getInt("product_id"))
				.productName(rs.getString("product_name")).totalStock(rs.getLong("stock"))
				.batchId(rs.getString("batch_no")).batchManufacturerDate(rs.getDate("manufactured_date"))
				.batchManufacturerName(rs.getString("batch_manufacturer_name")).batchExpiry(rs.getDate("expiry_date"))
				.isBatchEnabled(rs.getBoolean("is_batch_enabled")).build();

		StoresTransactionDTO materialResult = StoresTransactionDTO.builder().storeDto(storesDTO).productDto(materialDTO)
				.storeLocation(rs.getString("store_location")).txnId(rs.getLong("txn_id"))
				.storeBadge(rs.getString("store_badges")).productBadge(rs.getString("material_badges"))
				.transactionReason(rs.getString("transaction_reason")).openingStock(rs.getLong("opening_stock"))
				.transactionTypeOperation(rs.getString("transaction_type_operation")).quantity(rs.getLong("stock"))
				.closingStock(rs.getLong("closing_stock")).timeStamp(rs.getTimestamp("created_on"))
				.userId(rs.getString("user_id")).firstName(rs.getString("f_name")).lastName(rs.getString("l_name"))
				.sourceType(rs.getInt("source_type")).intialTxnDate(rs.getDate("initial_txn_date")).materialStatus(rs.getString("material_status"))
				.build();
		return materialResult;
	}
}
