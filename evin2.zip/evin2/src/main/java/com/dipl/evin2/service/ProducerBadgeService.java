package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.ProducerBadge;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.ProducerBadgeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProducerBadgeService {
	
	@Autowired
	private ProducerBadgeRepository producerBadgeRepository;

	public ProducerBadge getById(Long id){
		try {
			Optional<ProducerBadge> producerBadgeOptional = producerBadgeRepository.getById(id);
			if (producerBadgeOptional.isPresent()) {
				return producerBadgeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public ProducerBadge save(ProducerBadge producerBadge) {
		try {
			if (producerBadge.getId() != null && producerBadge.getId() > 0) {
				Optional<ProducerBadge> existingProducerBadgeRecord = producerBadgeRepository.getById(producerBadge.getId());
				if (existingProducerBadgeRecord.isPresent()) {
					return producerBadgeRepository.save(producerBadge);
				}
			} else {
				producerBadge = producerBadgeRepository.save(producerBadge);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return producerBadge;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<ProducerBadge> existingProducerBadgeRecord = producerBadgeRepository.getById(id);
			if (existingProducerBadgeRecord.isPresent()) {
				producerBadgeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<ProducerBadge> getAll() {
		try {
			return producerBadgeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
	
	public List<ProducerBadge> getAllByProducerId(Integer producerId) {
		try {
			return producerBadgeRepository.findAllByProducerId(producerId);
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}