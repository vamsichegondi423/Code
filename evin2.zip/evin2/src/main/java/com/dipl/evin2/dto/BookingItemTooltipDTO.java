package com.dipl.evin2.dto;

import org.springframework.beans.factory.annotation.Value;

public interface BookingItemTooltipDTO {
	 @Value(("#{target.recommanded_stock}"))
	 Long getRecommendedQuantity();
	 @Value(("#{target.orginial_ordered_stock}"))
	 Long getOriginallyOrdered();
	 @Value(("#{target.reason}"))
	 String  getReasonForOrderingDiscrepancy();
	 @Value(("#{target.modified_stock}"))
	 Long getModifiedQuantity();
	 @Value(("#{target.modified_reason}"))
	 String getReasonForModifyingOrderQuantity();

}
	
	