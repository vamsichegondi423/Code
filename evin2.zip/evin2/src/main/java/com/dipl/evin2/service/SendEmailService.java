package com.dipl.evin2.service;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.dipl.evin2.mongo.services.ReportEmailLogsService;
import com.dipl.evin2.util.Constants;
import com.google.gson.Gson;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SendEmailService {

	@Autowired
	private ReportEmailLogsService reportEmailLogsService;

	@Autowired
	private EurekaClient eurekaClient;

	@Autowired
	RestTemplate restTemplate;

	@Value("${BASE_URL}")
	private String fileUrl;
	
	public HashMap<String, Object> getBookngEmail(String link, String userName, String email) {
		SimpleDateFormat emaildateformatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date emaildate = new Date();
		HashMap<String, Object> emailbody = new HashMap<>();
		Map<String, Object> map = new HashMap<>();
		map.put("toMails", new String[] { email });
		map.put("ccMails", new String[] {});
		map.put("bccMails", new String[] {});
		map.put("subject", "Export of " + Constants.booking + " on " + emaildateformatter.format(emaildate));

		emailbody.put("email", map);
		emailbody.put("contentType", "text/html");

		String emailcontent = null;

		emailcontent = htmlContent.concat("<p>Dear " + userName + ",</p>\r\n" + "    <p>The Export of "
				+ Constants.booking + " is now complete. Please click " + link + " to download the file.</p>\r\n"
				+ "    <p>Thank you.</p>\r\n" + "  </div>\r\n" + "</div>");

		emailbody.put("content", emailcontent);
		return emailbody;
	}

	public HashMap<String, Object> getShipmentEmail(String link, String userName, String email) {
		SimpleDateFormat emaildateformatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date emaildate = new Date();
		HashMap<String, Object> emailbody = new HashMap<>();
		Map<String, Object> map = new HashMap<>();
		map.put("toMails", new String[] { email });
		map.put("ccMails", new String[] {});
		map.put("bccMails", new String[] {});
		map.put("subject", "Export of " + Constants.shipment + " on " + emaildateformatter.format(emaildate));

		emailbody.put("email", map);
		emailbody.put("contentType", "text/html");

		String emailcontent = null;

		emailcontent = htmlContent.concat("<p>Dear " + userName + ",</p>\r\n" + "    <p>The Export of "
				+ Constants.shipment + " is now complete. Please click " + link + " to download the file.</p>\r\n"
				+ "    <p>Thank you.</p>\r\n" + "  </div>\r\n" + "</div>");

		emailbody.put("content", emailcontent);
		return emailbody;
	}

	public HashMap<String, Object> getStockDeviantEmail(String link, String userName, String email) {
		SimpleDateFormat emaildateformatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date emaildate = new Date();
		HashMap<String, Object> emailbody = new HashMap<>();
		Map<String, Object> map = new HashMap<>();
		map.put("toMails", new String[] { email });
		map.put("ccMails", new String[] {});
		map.put("bccMails", new String[] {});
		map.put("subject", "Export of " + Constants.stock_deviannt + " on " + emaildateformatter.format(emaildate));

		emailbody.put("email", map);
		emailbody.put("contentType", "text/html");

		String emailcontent = null;

		emailcontent = htmlContent.concat("<p>Dear " + userName + ",</p>\r\n" + "    <p>The Export of "
				+ Constants.stock_deviannt + " is now complete. Please click " + link + " to download the file.</p>\r\n"
				+ "    <p>Thank you.</p>\r\n" + "  </div>\r\n" + "</div>");

		emailbody.put("content", emailcontent);
		return emailbody;
	}

	public HashMap<String, Object> getStockReportEmail(String link, String userName, String email) {
		SimpleDateFormat emaildateformatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date emaildate = new Date();
		HashMap<String, Object> emailbody = new HashMap<>();
		Map<String, Object> map = new HashMap<>();
		map.put("toMails", new String[] { email });
		map.put("ccMails", new String[] {});
		map.put("bccMails", new String[] {});
		map.put("subject", "Export of " + Constants.stock_report + " on " + emaildateformatter.format(emaildate));

		emailbody.put("email", map);
		emailbody.put("contentType", "text/html");

		String emailcontent = null;

		emailcontent = htmlContent.concat("<p>Dear " + userName + ",</p>\r\n" + "    <p>The Export of "
				+ Constants.stock_report + " is now complete. Please click " + link + " to download the file.</p>\r\n"
				+ "    <p>Thank you.</p>\r\n" + "  </div>\r\n" + "</div>");

		emailbody.put("content", emailcontent);
		return emailbody;
	}

	public HashMap<String, Object> getTransactionEmail(String link, String userName, String email) {
		SimpleDateFormat emaildateformatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date emaildate = new Date();
		HashMap<String, Object> emailbody = new HashMap<>();
		Map<String, Object> map = new HashMap<>();
		map.put("toMails", new String[] { email });
		map.put("ccMails", new String[] {});
		map.put("bccMails", new String[] {});
		map.put("subject", "Export of " + Constants.transaction + " on " + emaildateformatter.format(emaildate));

		emailbody.put("email", map);
		emailbody.put("contentType", "text/html");

		String emailcontent = null;

		emailcontent = htmlContent.concat(" <p>Dear " + userName + ",</p>\r\n" + "    <p>The Export of "
				+ Constants.transaction + " is now complete. Please click " + link + " to download the file.</p>\r\n"
				+ "    <p>Thank you.</p>\r\n" + "  </div>\r\n" + "</div>");

		emailbody.put("content", emailcontent);
		return emailbody;
	}
	public HashMap<String, Object> getStockReportByStoreEmail(String link, String userName, String email) {
		SimpleDateFormat emaildateformatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date emaildate = new Date();
		HashMap<String, Object> emailbody = new HashMap<>();
		Map<String, Object> map = new HashMap<>();
		map.put("toMails", new String[] { email });
		map.put("ccMails", new String[] {});
		map.put("bccMails", new String[] {});
		map.put("subject", "Export of " + Constants.stock_report_by_store + " on " + emaildateformatter.format(emaildate));

		emailbody.put("email", map);
		emailbody.put("contentType", "text/html");

		String emailcontent = null;

		emailcontent = htmlContent.concat("<p>Dear " + userName + ",</p>\r\n" + "    <p>The Export of "
				+ Constants.stock_report_by_store + " is now complete. Please click " + link + " to download the file.</p>\r\n"
				+ "    <p>Thank you.</p>\r\n" + "  </div>\r\n" + "</div>");

		emailbody.put("content", emailcontent);
		return emailbody;
	}

	public ResponseEntity<String> sendemail(HashMap<String, Object> emailbody, String email, String userName,
			String fileDownloadUrl, String fileType, String fileName, String fileSystemPath) throws UnirestException {

		HttpHeaders emailHeaders = new HttpHeaders();
		emailHeaders.setContentType(MediaType.APPLICATION_JSON);
		emailHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		String emailjson = new Gson().toJson(emailbody);
		HttpEntity<String> emailentity = new HttpEntity<String>(emailjson, emailHeaders);

		Application applicationEmail = eurekaClient.getApplication("evin-notifications");
		InstanceInfo instanceInfoEmail = applicationEmail.getInstances().get(0);

		String emailurl = "http://" + instanceInfoEmail.getIPAddr() + ":" + instanceInfoEmail.getPort() + "/"
				+ "evin-notifications" + "/" + "notifications" + "/" + "send-email";

		ResponseEntity<String> emailresponse = this.restTemplate.postForEntity(emailurl, emailentity, String.class);

		reportEmailLogsService.getReportLogs(fileDownloadUrl.toString(), email, userName, fileType, fileName,
				fileSystemPath);
		return emailresponse;
	}
	
	private static final String htmlContent = "<div style=\"font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2\">\r\n"
			+ "    </div>\r\n" + "";
}