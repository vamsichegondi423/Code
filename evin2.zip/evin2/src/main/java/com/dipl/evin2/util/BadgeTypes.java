package com.dipl.evin2.util;

public enum BadgeTypes {
	
		Product, Store, User, Booking, Producer

}
