package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.ProducerTm;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.ProducerTmRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProducerTmService {

	@Autowired
	private ProducerTmRepository producerTmRepository;

	public ProducerTm getById(Integer id) throws CustomException {
		try {
			Optional<ProducerTm> producerTmOptional = producerTmRepository.getById(id);
			if (producerTmOptional.isPresent()) {
				return producerTmOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public ProducerTm save(ProducerTm producerTm) throws CustomException {
		try {
			if (producerTm.getId() != null && producerTm.getId() > 0) {
				Optional<ProducerTm> existingProducerTmRecord = producerTmRepository
						.getById(producerTm.getId());
				if (existingProducerTmRecord.isPresent()) {
					return producerTmRepository.save(producerTm);
				}
			} else {
				producerTm = producerTmRepository.save(producerTm);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return producerTm;
	}

	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<ProducerTm> existingProducerTmRecord = producerTmRepository.getById(id);
			if (existingProducerTmRecord.isPresent()) {
				producerTmRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<ProducerTm> getAll() {
		try {
			return producerTmRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}