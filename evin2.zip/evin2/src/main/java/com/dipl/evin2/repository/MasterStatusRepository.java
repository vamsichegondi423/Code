package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.MasterStatus;

@Repository
public interface MasterStatusRepository extends JpaRepository<MasterStatus, Integer> {

	@Query(value = "select * from master_status where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterStatus> getById(Integer id);

	@Query(value = "select * from master_status where pranth_id = ?1 and is_deleted = false", nativeQuery = true)
	public List<MasterStatus> findAll(Long pranthId);

	@Query(value = "select count(1) from master_status ms join status_pranth sp on sp.status_id = ms.id where \"name\" = ?1 and status_type = ?2 and sp.pranth_id = ?3 and is_deleted = false", nativeQuery = true)
	public Integer getMasterStatus(String name, String statusType, Long pranthId);
	
	@Query(value = "select * from master_status where status_type = ?1 and pranth_id = ?2 and is_deleted = false", nativeQuery = true)
	public List<MasterStatus> getMasterStatusByType(String statusType, Long pranthId);

	@Modifying
	@Transactional
	@Query(value = "delete from master_status where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);

	@Modifying
	@Transactional
	@Query(value = "update master_status set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

}