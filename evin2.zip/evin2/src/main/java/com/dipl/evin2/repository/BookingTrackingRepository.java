package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.BookingTracking;

@Repository
public interface BookingTrackingRepository extends JpaRepository<BookingTracking, Long> {

	@Query(value = "select * from booking_tracking where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<BookingTracking> getById(Long id);

	@Query(value = "select * from booking_tracking where is_deleted = false", nativeQuery = true)
	public List<BookingTracking> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from booking_tracking where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update booking_tracking set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from booking_tracking where cargo_id=?1 and is_deleted = false", nativeQuery = true)
	public List<BookingTracking> findByObjectId(Long cargoId);
	
	@Query(value = "select * from booking_tracking where booking_id=?1 and is_deleted = false ", nativeQuery = true)
	public List<BookingTracking> getStatusByBooking(Long bookingId);
	
	@Query(value = "select * from booking_tracking where booking_id=?1 and is_deleted = false order by created_on desc limit 1", nativeQuery = true)
	public BookingTracking getStatusByBkid(Long bookingId);

}