package com.dipl.evin2.entity;

import java.util.Date;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Document(collection = "ReportEmailLogs")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReportEmailLogs {

	@Id
	private String id;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "IST")
	private Date createdOn;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "IST")
	private Date updateddOn;
	private String userId;
	private String email;
	private String url;
	private String downloadpath;
	private String fileName;
	private String fileSystemPath;
	private String fileType;

}