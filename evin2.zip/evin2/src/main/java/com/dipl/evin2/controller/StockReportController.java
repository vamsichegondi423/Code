package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.controller.IcatalogueController.StockReportData;
import com.dipl.evin2.dto.StockReportDetails;
import com.dipl.evin2.dto.StockReportPayload;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.service.PranthHierarchyService;
import com.dipl.evin2.service.StockReportService;
import com.dipl.evin2.service.StoreService;
import com.dipl.evin2.service.UsersService;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/report")
public class StockReportController {

	private static final String SUCCESSFULLY_FETCHED_DETIALS = "Successfully fetched detials";

	private static final String INVALID_PAYLOAD = "Invalid Payload";

	@Autowired
	private StockReportService stockReportService;
	@Autowired
	private UsersService usersService;
	@Autowired
	private PranthHierarchyService pranthHierarchyService;
	@Autowired
	private StoreService storeService;

	@PostMapping(value = "/v1/get-stock-report")
	public ResponseBean getInventoryDetailsByFilter(@Valid @RequestBody StockReportPayload detailsPayload,
			BindingResult bindingResult,@RequestParam(value = "pranthId") Long pranthId, @RequestParam(value = "userId") Long userId, Pageable pageable) throws CustomException {
		ResponseBean responseBean = validatePayload(bindingResult);
		if(responseBean != null) {
			return responseBean;
		}
		
		/*Integer materialBadge = detailsPayload.getMaterialBadge() != null ? Integer.parseInt(detailsPayload.getMaterialBadge()) : null;
		if(materialBadge != null && materialBadge != 0) {
			detailsPayload.setMaterialBadge(badgeService.getById(materialBadge).getName());
		}*/
		
		List<StockReportDetails> stockReportDetailsList = null;
		Object lists = null;
		int totalRecCount = 0;
		try {

			if((detailsPayload.getCountry() != null || detailsPayload.getCountry() != 0) && (detailsPayload.getState() == null || detailsPayload.getState() == 0)) {
				Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);
				List<Long> totalDistricts = new ArrayList<>();

				List<Long> totalDistrictIds  = getToatalDistrictIds(consolidatedPranthIds, userId, detailsPayload.getCountry(),detailsPayload.getState(), detailsPayload.getDistrict(), detailsPayload.getBlock());

				PagedListHolder<Long> page = new PagedListHolder<>(totalDistrictIds);
				page.setPageSize(pageable.getPageSize()); // number of items per page
				page.setPage(pageable.getPageNumber());  
				totalDistricts.addAll(page.getPageList());
				if(totalDistricts.isEmpty()) {
					return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message("NO_RECORDS_FOUND")
							.build();
				}
				totalRecCount = totalDistrictIds.size();
				stockReportDetailsList = stockReportService.getInventoryDetails(detailsPayload,totalDistricts,pageable);

				Map<String, List<StockReportDetails>> stockDetailsMap = stockReportDetailsList.stream().collect(Collectors.groupingBy(s -> s.getState()+"||"+s.getDistrict()+"||"+s.getDistrictId()));
				TreeMap<String, List<StockReportDetails>> treeMap=new TreeMap<>();    
				treeMap.putAll(stockDetailsMap);
				log.info(" treeMap "+treeMap);
				for(Entry<String, List<StockReportDetails>> entry : treeMap.entrySet()) {
					List<StockReportDetails> stockReportDetailsSet = entry.getValue();
					List<StockReportDetails> stockReportList = new ArrayList<>(stockReportDetailsSet);
					Collections.sort(stockReportList, new Comparator<>() {
						@Override
						public int compare(StockReportDetails o1, StockReportDetails o2) {
							return o1.getDistrict().compareTo(o2.getDistrict());
						}
					});
					treeMap.put(entry.getKey(), stockReportList);
					log.info("stores:"+entry.getKey());
				}
				lists = treeMap;
			}	

			else if(detailsPayload.getState() != null || detailsPayload.getState() != 0) {
				Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);

				List<Long> totalStores = new ArrayList<>();

				List<Long> totalStoreIds = getToatalStoreIds(consolidatedPranthIds, userId, detailsPayload.getState(), detailsPayload.getDistrict(), detailsPayload.getBlock());
				
				if(detailsPayload.getStoreId().isEmpty()) {
					PagedListHolder<Long> page = new PagedListHolder<>(totalStoreIds);
					page.setPageSize(pageable.getPageSize()); // number of items per page
					page.setPage(pageable.getPageNumber());  
					totalStores.addAll(page.getPageList());
				stockReportDetailsList = stockReportService.getInventoryDetails(detailsPayload,totalStores,pageable);
				if(totalStores.isEmpty()) {
					return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message("NO_RECORDS_FOUND")
							.build();
				}
				
				}
				
				else if(!detailsPayload.getStoreId().isEmpty()) {
					
				stockReportDetailsList = stockReportService.getInventoryDetails(detailsPayload,detailsPayload.getStoreId(),pageable);
				
				}			
				
				totalRecCount = totalStoreIds.size();				


				Map<String, List<StockReportDetails>> stockDetailsMap = stockReportDetailsList.stream().collect(Collectors.groupingBy(s -> s.getState()+"||"+s.getDistrict()+"||"+s.getStore()+"||"+s.getStoreId()));
				TreeMap<String, List<StockReportDetails>> treeMap=new TreeMap<>();    

				treeMap.putAll(stockDetailsMap);
				
				if(!detailsPayload.getStoreId().isEmpty()) {
					totalRecCount = stockDetailsMap.size();

				}
				

				for(Entry<String, List<StockReportDetails>> entry : treeMap.entrySet()) {
					List<StockReportDetails> stockReportDetailsSet = entry.getValue();
					List<StockReportDetails> stockReportList = new ArrayList<>(stockReportDetailsSet);
					Collections.sort(stockReportList, new Comparator<StockReportDetails>() {
						@Override
						public int compare(StockReportDetails o1, StockReportDetails o2) {
							return o1.getStore().compareTo(o2.getStore());
						}
					});
					treeMap.put(entry.getKey(), stockReportList);
					log.info("stores:"+entry.getKey());
				}

				lists = treeMap;
			}

			StockReportData data = StockReportData.builder().stockReportDetails(lists).totalRecordsCount(Long.valueOf(totalRecCount)).build();
			return ResponseBean.builder().data(data).status(HttpStatus.OK).returnCode(1)
					.message(SUCCESSFULLY_FETCHED_DETIALS).build(); 

		} catch (Exception e) {
			log.error("Exception occured : {}", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
	}


	private ResponseBean validatePayload(BindingResult bindingResult) {
		List<String> errors = null;
		try {
			if (bindingResult.hasErrors()) {
				log.error(INVALID_PAYLOAD);
				errors = bindingResult.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.toList());
				return ResponseBean.builder().data(StringUtils.collectionToCommaDelimitedString(errors)).message(INVALID_PAYLOAD).status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		}catch (Exception e) {
			return ResponseBean.builder().data(StringUtils.collectionToCommaDelimitedString(errors)).message(INVALID_PAYLOAD).status(HttpStatus.BAD_REQUEST)
					.returnCode(0).build();
		}
		return null;
	}

	public List<Long> getToatalStoreIds(Set<Long> pranthIds, Long userId, Integer stateId, Integer districtId, Integer blockId) {
		Set<Long> domainStoreIds = new HashSet<>();
		Users users = usersService.getById(userId);
		if(users.getRoleId() == Constants.ADMINISTRATOR_ROLE.intValue() || users.getRoleId() == Constants.OWNER_ROLE.intValue()) {
			if (!pranthIds.isEmpty()) {
				if(districtId != 0) {
					domainStoreIds.addAll(storeService.getAllStores(pranthIds, stateId,districtId, "District"));
				}
				else if(stateId != 0) {
					domainStoreIds.addAll(storeService.getAllStores(pranthIds, stateId,districtId, "State"));
				}
			}
		}else {
			List<Map<String, Object>> maps = storeService.getAllStoresForUser(userId.intValue(), pranthIds.iterator().next().intValue(), null);
			maps.forEach(m -> domainStoreIds.add(Long.valueOf(m.get("store_id")+"")));
		}

		return new ArrayList<>(domainStoreIds);
	}

	public List<Long> getToatalDistrictIds(Set<Long> pranthIds, Long userId, Integer countryId,Integer stateId, Integer districtId, Integer blockId) {
		Set<Long> domainStoreIds = new HashSet<>();

		Users users = usersService.getById(userId);
		if(users.getRoleId() == Constants.ADMINISTRATOR_ROLE.intValue() || users.getRoleId() == Constants.OWNER_ROLE.intValue()) {
			if (!pranthIds.isEmpty()) {
				if(districtId != 0) {
					domainStoreIds.addAll(storeService.getTotalDistricts(pranthIds, districtId, "District"));
				} else if(stateId != 0) {
					domainStoreIds.addAll(storeService.getTotalDistricts(pranthIds, stateId, "State"));
				} else {
					domainStoreIds.addAll(storeService.getTotalDistricts(pranthIds, countryId, "Country"));
				}
			}
		}

		return new ArrayList<>(domainStoreIds);
	}
}