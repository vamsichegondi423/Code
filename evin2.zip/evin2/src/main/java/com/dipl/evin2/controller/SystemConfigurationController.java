package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.dto.BadgeConfigurationDTO;
import com.dipl.evin2.entity.Badge;
import com.dipl.evin2.entity.PranthHierarchy;
import com.dipl.evin2.entity.StoreBadgeRank;
import com.dipl.evin2.entity.SystemConfiguration;
import com.dipl.evin2.service.BadgeService;
import com.dipl.evin2.service.PranthHierarchyService;
import com.dipl.evin2.service.PranthMappingService;
import com.dipl.evin2.service.StoreBadgeRankService;
import com.dipl.evin2.service.SystemConfigurationService;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/system-configuration")
public class SystemConfigurationController {

	@Autowired
	private SystemConfigurationService systemConfigurationService;

	@Autowired
	private BadgeService badgeService;

	@Autowired
	private StoreBadgeRankService storeBadgeRankService;

	@Autowired
	private PranthMappingService pranthMappingService;

	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@ApiOperation("Use this api for saving or updating SystemConfiguration. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody @Valid SystemConfiguration systemConfiguration, BindingResult result, @RequestParam("pranthId") Long pranthId) {
		systemConfiguration.setPranthId(pranthId);
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				List<String> errors = result.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.toList());
				return ResponseBean.builder().data(StringUtils.collectionToCommaDelimitedString(errors)).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if(systemConfiguration.getConfigTypeId() != null) {
				if (systemConfiguration.getConfigTypeId() != null && systemConfiguration.getConfigTypeId() > 0) {
					SystemConfiguration existingSystemConfiguration = systemConfigurationService.getByConfigutationType(systemConfiguration.getConfigTypeId(), pranthId);
					if (existingSystemConfiguration != null) {
						systemConfiguration.setCreatedBy(systemConfiguration.getUpdatedBy());
						systemConfiguration.setCreatedOn(new Date());
						systemConfiguration.setUpdatedBy(systemConfiguration.getUpdatedBy());
						systemConfiguration.setUpdatedOn(new Date());
						systemConfiguration.setId(0);
						systemConfiguration.setVersionNo(existingSystemConfiguration.getVersionNo()+1);
						systemConfiguration = systemConfigurationService.save(systemConfiguration);
						log.info("Record updated successfully");
						responseBean.setMessage("Record updated successfully");
						responseBean.setData(systemConfiguration);
					} else {
						systemConfiguration.setVersionNo(1);
						systemConfiguration.setCreatedBy(systemConfiguration.getUpdatedBy());
						systemConfiguration.setCreatedOn(new Date());
						systemConfiguration.setUpdatedBy(systemConfiguration.getUpdatedBy());
						systemConfiguration.setUpdatedOn(new Date());
						systemConfiguration = systemConfigurationService.save(systemConfiguration);
						log.info("Record saved successfully");
						responseBean.setMessage("Record saved successfully");
						responseBean.setData(systemConfiguration);
					}
				}
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setReturnCode(1);
			}else {
				responseBean.setStatus(HttpStatus.EXPECTATION_FAILED);
				responseBean.setReturnCode(0);
				responseBean.setMessage("Configuration type is mandatory.");
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}


	@ApiOperation("Use this api for saving or updating SystemConfiguration. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/updateimages")
	public ResponseBean saveImages(@RequestParam("configTypeId") Integer configTypeId, @RequestParam("picURLs")  List<String> picURLS, @RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();

		try {
			if(configTypeId != null) {
				SystemConfiguration existingSystemConfiguration = systemConfigurationService.getByConfigutationType(configTypeId, pranthId);
				JSONObject jsonObject = new JSONObject(new ObjectMapper().writeValueAsString(existingSystemConfiguration.getConfigJson()));
				if (existingSystemConfiguration != null) {
					jsonObject.put("domain_photos", picURLS);
				}
				existingSystemConfiguration.setConfigJson(new ObjectMapper().readTree(jsonObject.toString()));
				systemConfigurationService.save(existingSystemConfiguration);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for saving or updating SystemConfiguration. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/badge-config/saveorupdate")
	public ResponseBean save(@RequestBody @Valid BadgeConfigurationDTO badgeConfigurationDTO, BindingResult result, @RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message(StringUtils.collectionToCommaDelimitedString(result.getAllErrors())).status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if(badgeConfigurationDTO != null) {
				if(badgeConfigurationDTO.getBookingBadges() != null && !badgeConfigurationDTO.getBookingBadges().isEmpty()) {
					badgeConfigurationDTO.setBookingBadges(updateAuditData(badgeConfigurationDTO.getBookingBadges(), badgeConfigurationDTO.getUpdatedBy()));
					List<Badge> bookingBadges = badgeConfigurationDTO.getBookingBadges();
					bookingBadges = badgeService.saveAll(bookingBadges, pranthId);
					badgeConfigurationDTO.setBookingBadges(bookingBadges);
				}
				if(badgeConfigurationDTO.getProducerBadges() != null && !badgeConfigurationDTO.getProducerBadges().isEmpty()) {
					badgeConfigurationDTO.setProducerBadges(updateAuditData(badgeConfigurationDTO.getProducerBadges(), badgeConfigurationDTO.getUpdatedBy()));
					badgeConfigurationDTO.setProducerBadges(badgeService.saveAll(badgeConfigurationDTO.getProducerBadges(), pranthId));
				}
				if(badgeConfigurationDTO.getRouteBadges() != null && !badgeConfigurationDTO.getRouteBadges().isEmpty()) {
					badgeConfigurationDTO.setRouteBadges(updateAuditData(badgeConfigurationDTO.getRouteBadges(), badgeConfigurationDTO.getUpdatedBy()));
					badgeConfigurationDTO.setRouteBadges(badgeService.saveAll(badgeConfigurationDTO.getRouteBadges(), pranthId));
				}
				if(badgeConfigurationDTO.getStoreBadges() != null && !badgeConfigurationDTO.getStoreBadges().isEmpty()) {
					badgeConfigurationDTO.setStoreBadges(updateAuditData(badgeConfigurationDTO.getStoreBadges(), badgeConfigurationDTO.getUpdatedBy()));
					badgeConfigurationDTO.setStoreBadges(badgeService.saveAll(badgeConfigurationDTO.getStoreBadges(), pranthId));
				}
				if(badgeConfigurationDTO.getUserBadges() != null && !badgeConfigurationDTO.getUserBadges().isEmpty()) {
					badgeConfigurationDTO.setUserBadges(updateAuditData(badgeConfigurationDTO.getUserBadges(), badgeConfigurationDTO.getUpdatedBy()));
					badgeConfigurationDTO.setUserBadges(badgeService.saveAll(badgeConfigurationDTO.getUserBadges(), pranthId));
				}
				if(badgeConfigurationDTO.getProductBadges() != null && !badgeConfigurationDTO.getProductBadges().isEmpty()) {
					badgeConfigurationDTO.setProductBadges(updateAuditData(badgeConfigurationDTO.getProductBadges(), badgeConfigurationDTO.getUpdatedBy()));
					badgeConfigurationDTO.setProductBadges(badgeService.saveAll(badgeConfigurationDTO.getProductBadges(), pranthId));
				}

				if(badgeConfigurationDTO.getStoreBadgeRanks() != null && !badgeConfigurationDTO.getStoreBadgeRanks().isEmpty()) {
					List<StoreBadgeRank> badgeRanks = badgeConfigurationDTO.getStoreBadgeRanks();
					for(StoreBadgeRank b : badgeRanks)
						if(b.getId() != null && b.getId() > 0) {
							b.setCreatedBy(b.getCreatedBy() != null ? b.getCreatedBy() : badgeConfigurationDTO.getUpdatedBy());
							b.setCreatedOn(b.getCreatedOn() != null ? b.getCreatedOn() : new Date());
							b.setUpdatedOn(new Date());
							b.setUpdatedBy(badgeConfigurationDTO.getUpdatedBy());
						}else {
							b.setUpdatedOn(new Date());
							b.setCreatedOn(new Date());
							b.setUpdatedBy(badgeConfigurationDTO.getUpdatedBy());
							b.setCreatedBy(badgeConfigurationDTO.getUpdatedBy());
						}
					badgeConfigurationDTO.setStoreBadgeRanks(badgeRanks);
				}
				badgeConfigurationDTO.getStoreBadgeRanks().forEach(sbr -> {
					StoreBadgeRank storeBadgeRank = storeBadgeRankService.getByStorageBadgeId(sbr.getStoreBadgeId(), pranthId);
					if(storeBadgeRank != null && storeBadgeRank.getIsDeleted()) {
						sbr.setIsDeleted(false);
						sbr.setId(storeBadgeRank.getId());
						sbr.setPranthId(pranthId);
					}
				});
				badgeConfigurationDTO.setStoreBadgeRanks(storeBadgeRankService.saveAll(badgeConfigurationDTO.getStoreBadgeRanks()));

				log.info("Records saved successfully");
				responseBean.setMessage("Records saved successfully");
				responseBean.setData(badgeConfigurationDTO);
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setReturnCode(1);
			}else {
				responseBean.setStatus(HttpStatus.EXPECTATION_FAILED);
				responseBean.setReturnCode(0);
				responseBean.setMessage("Configuration type is mandatory.");
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	private List<Badge> updateAuditData(List<Badge> badges, Long updatedBy) {
		badges.forEach(b -> {
			if(b.getId() != null && b.getId() > 0) {
				b.setUpdatedOn(new Date());
				b.setUpdatedBy(updatedBy);
			}else {
				b.setUpdatedOn(new Date());
				b.setCreatedOn(new Date());
				b.setUpdatedBy(updatedBy);
				b.setCreatedBy(updatedBy);
			}
		});
		return badges;
	}

	private List<StoreBadgeRank> updateRankAuditData(List<StoreBadgeRank> storeBadgeRanks, Long updatedBy) {
		storeBadgeRanks.forEach(b -> {
			if(b.getId() != null && b.getId() > 0) {
				b.setUpdatedOn(new Date());
				b.setUpdatedBy(updatedBy);
			}else {
				b.setUpdatedOn(new Date());
				b.setCreatedOn(new Date());
				b.setUpdatedBy(updatedBy);
				b.setCreatedBy(updatedBy);
			}
		});
		return storeBadgeRanks;
	}

	@ApiOperation("Use this api for fetching SystemConfiguration record by id. Provide id as path param.")
	@GetMapping(value = "/v1/get-by-configutation-type/{configutationtypeid}", produces = "application/json")
	public ResponseBean getByConfigutationType(@PathVariable(value = "configutationtypeid") Integer configutationTypeId, @RequestParam(value = "pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if(configutationTypeId.equals(Constants.TAGS_CONFIG_TYPE_ID)) {
				List<Badge> badges = badgeService.getAll(pranthId);
				BadgeConfigurationDTO badgeConfigurationDTO = new BadgeConfigurationDTO();

				if(!badges.isEmpty()) {
					Map<Integer, List<Badge>> map = badges.stream().collect(Collectors.groupingBy(Badge::getBadgeTypeId));
					if(map.containsKey(Constants.PRODUCT_BADGE_TYPE)) {
						badgeConfigurationDTO.setProductBadges(map.get(Constants.PRODUCT_BADGE_TYPE));
					}
					if(map.containsKey(Constants.STORE_BADGE_TYPE)) {
						badgeConfigurationDTO.setStoreBadges(map.get(Constants.STORE_BADGE_TYPE));
					}
					if(map.containsKey(Constants.USER_BADGE_TYPE)) {
						badgeConfigurationDTO.setUserBadges(map.get(Constants.USER_BADGE_TYPE));
					}
					if(map.containsKey(Constants.ORDER_BADGE_TYPE)) {
						badgeConfigurationDTO.setBookingBadges(map.get(Constants.ORDER_BADGE_TYPE));
					}
					if(map.containsKey(Constants.MANUFACTURER_BADGE_TYPE)) {
						badgeConfigurationDTO.setProducerBadges(map.get(Constants.MANUFACTURER_BADGE_TYPE));
					}
					if(map.containsKey(Constants.ROUTE_BADGE_TYPE)) {
						badgeConfigurationDTO.setRouteBadges(map.get(Constants.ROUTE_BADGE_TYPE));
					}
				}
				List<StoreBadgeRank> storeBadgeRanks = storeBadgeRankService.getAll(pranthId);
				badgeConfigurationDTO.setStoreBadgeRanks(storeBadgeRanks);
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(badgeConfigurationDTO);
			} else {
				SystemConfiguration systemConfiguration = systemConfigurationService.getByConfigutationType(configutationTypeId, pranthId);
				if (systemConfiguration != null) {
					log.info("Records fetched successfully");
					return ResponseBean.builder().data(systemConfiguration).message("Records fetched successfully").status(HttpStatus.OK)
							.returnCode(1).build();
				} 
			}
			log.info("No record found");
			responseBean.setMessage("No record found");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching SystemConfiguration record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			SystemConfiguration systemConfiguration = systemConfigurationService.getById(id);
			if (systemConfiguration != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(systemConfiguration);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting SystemConfiguration record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Integer id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = systemConfigurationService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all SystemConfiguration records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll(@RequestParam(value = "pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<SystemConfiguration> systemConfigurationRecords = systemConfigurationService.getAll(pranthId);
			if (!systemConfigurationRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(systemConfigurationRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for updating system configurations to child pranth.")
	@GetMapping(value = "/v1/update-system-config-to-child/{userId}", produces = "application/json")
	public ResponseBean updateParentSystemConfigurationToChild(@PathVariable(value = "userId") Long userId,@RequestParam(value = "pranthId",required = false) Long pranthId , @RequestParam(value = "mappedPranthId") Long mappedPranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			responseBean = systemConfigurationService.updateParentSystemConfigurationToChild(pranthId, mappedPranthId, userId);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occurred");
		}
		return responseBean;
	}
}