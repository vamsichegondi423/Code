package com.dipl.evin2.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.dipl.evin2.controller.BookingsController.BookingsByFilterPayload;
import com.dipl.evin2.controller.BookingsController.BookingsExportModel;
import com.dipl.evin2.dto.ExportBookingsDTO;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.model.FileReportResponse;
import com.dipl.evin2.service.RolePermissionConfigurationService.RolePermissionConfigurationModel;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.JdbcTemplateHelper;
import com.dipl.evin2.util.KafkaProducer;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ExportBookingService {

	@Autowired
	private BookingsService bookingsService;
	@Autowired
	private SendEmailService sendEmailService;
	@Autowired
	private UploadFileService uploadFileService;
	@Autowired
	private PranthHierarchyService pranthHierarchyService;
	@Autowired
	private UsersService usersService;
	@Autowired
	private RolePermissionConfigurationService rolePermissionConfigurationService;
	@Autowired
	private JdbcTemplateHelper jdbcTemplateHelper;
//	@Autowired
//	private KafkaProducer kafkaProducer;
	@Autowired
	@Lazy
	private ExportExcelAsyncService exportExcelAsyncService;

	public ResponseBean getBookingService(BookingsByFilterPayload bookingsByFilterPayload, Long pranthId, Long userId,
			String userName, String email, List<Long> offsetStoreIds) throws IOException {
		ResponseBean responsebean = new ResponseBean();
		try {
			BookingsExportModel bookingsExportModel = new BookingsExportModel();
//			this.getBookingsExportData(bookingsByFilterPayload, pranthId, userId, userName, email, offsetStoreIds);
			exportExcelAsyncService.getBookingsExportData(bookingsByFilterPayload, pranthId, userId, userName, email, offsetStoreIds);
//			this.setBookingExportData(bookingsExportModel, bookingsByFilterPayload, pranthId, userId, userName, email,
//					offsetStoreIds);
//			kafkaProducer.sendBookingsExportToProducer(bookingsExportModel);
			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
					+ email
					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
			responsebean.setReturnCode(1);
			responsebean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured while exporting booking report : " + e.getStackTrace());
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting booking report ");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		return responsebean;
	}
//	void setBookingExportData(BookingsExportModel bookingsExportModel, BookingsByFilterPayload bookingsByFilterPayload,
//			Long pranthId, Long userId, String userName, String email, List<Long> offsetStoreIds) {
//		bookingsExportModel.setBookingsByFilterPayload(bookingsByFilterPayload);
//		bookingsExportModel.setPranthId(pranthId);
//		bookingsExportModel.setUserId(userId);
//		bookingsExportModel.setUserName(userName);
//		bookingsExportModel.setEmail(email);
//		bookingsExportModel.setOffsetStoreIds(offsetStoreIds);
//	}
	public void getBookingsExportData(BookingsByFilterPayload bookingsByFilterPayload, Long pranthId, Long userId,
			String userName, String email, List<Long> offsetStoreIds) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<ExportBookingsDTO> bookings = null;
		Object fileData;
		StringBuilder builder = new StringBuilder();
		String url = null;
		Workbook workbook = null;
		Sheet sheet = null;
		FileOutputStream outputStream = null;

		try {

			Set<Long> consolidatedDomainIds = pranthHierarchyService
					.getConsolidatedPranthIds(bookingsByFilterPayload.getPranthId());
			String queryForConsolidatedDomainIds = pranthHierarchyService.buildQuery(consolidatedDomainIds);

			// fetching booking details from query
			bookings = getBookingsData(bookingsByFilterPayload, builder, queryForConsolidatedDomainIds, null, userId,
					offsetStoreIds, pranthId);
			//creating workbook
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0, cellIndex3 = 0;
			// Creating row
			Row row = sheet.createRow(0);

			row.createCell(cellIndex++).setCellValue("Title");
			row.createCell(cellIndex++).setCellValue("" + Constants.booking + "");
			Row row1 = sheet.createRow(1);
			row1.createCell(cellIndex1++).setCellValue("Generated on");
			row1.createCell(cellIndex1++).setCellValue("" + uploadFileService.dateWithHoursMinutes());

			// creating headers/columns
			Row row3 = sheet.createRow(3);
			row3.createCell(cellIndex3++).setCellValue("Booking Id");
			row3.createCell(cellIndex3++).setCellValue("Booking Items Count");
			row3.createCell(cellIndex3++).setCellValue("Booking Badge");
			row3.createCell(cellIndex3++).setCellValue("Booking Ref No");
			row3.createCell(cellIndex3++).setCellValue("Status");
			row3.createCell(cellIndex3++).setCellValue("Issuing Store Name");
			row3.createCell(cellIndex3++).setCellValue("Issuing Store Tag");
			row3.createCell(cellIndex3++).setCellValue("Country");
			row3.createCell(cellIndex3++).setCellValue("State");
			row3.createCell(cellIndex3++).setCellValue("District");
			// row3.createCell(cellIndex3++).setCellValue("Taluk/Block");
			row3.createCell(cellIndex3++).setCellValue("Village/City");
			row3.createCell(cellIndex3++).setCellValue("Receiving Store Name");
			row3.createCell(cellIndex3++).setCellValue("Receiving Store Tag");
			row3.createCell(cellIndex3++).setCellValue("Country");
			row3.createCell(cellIndex3++).setCellValue("State");
			row3.createCell(cellIndex3++).setCellValue("District");
			// row3.createCell(cellIndex3++).setCellValue("Taluk/Block");
			row3.createCell(cellIndex3++).setCellValue("Village/City");

			// row3.createCell(cellIndex3++).setCellValue("Products");
			row3.createCell(cellIndex3++).setCellValue("Product Tag");
			row3.createCell(cellIndex3++).setCellValue("Recommended Quantity");
			row3.createCell(cellIndex3++).setCellValue("Ordered Quantity");
			row3.createCell(cellIndex3++).setCellValue("Reason");
			row3.createCell(cellIndex3++).setCellValue("CreatedBy");
			row3.createCell(cellIndex3++).setCellValue("CreatedOn");
			row3.createCell(cellIndex3++).setCellValue("UpdatedBy");
			row3.createCell(cellIndex3++).setCellValue("UpdatedOn");

			// displaying data under headers
			for (int i = 0; i < bookings.size(); i++) {
				Row dataRow = sheet.createRow(i + 4);
				int rowIndex1 = 0;
				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getBookingId() == null ? "" : bookings.get(i).getBookingId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getBookingItemsCount() == null ? 0
						: bookings.get(i).getBookingItemsCount());
				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getBookingBadge() == null ? "" : bookings.get(i).getBookingBadge() + "");

				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getOrderReferenceNo() == null ? ""
						: bookings.get(i).getOrderReferenceNo() + "");
				dataRow.createCell(rowIndex1++)
						.setCellValue(bookings.get(i).getStatus() == null ? "" : bookings.get(i).getStatus() + "");

				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getIssuingStoreName() == null ? ""
						: bookings.get(i).getIssuingStoreName() + "");

				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getIssuingStoreBadge() == null ? ""
						: bookings.get(i).getIssuingStoreBadge() + "");

				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getIsCountry() == null ? "" : bookings.get(i).getIsCountry() + "");
				dataRow.createCell(rowIndex1++)
						.setCellValue(bookings.get(i).getIsState() == null ? "" : bookings.get(i).getIsState() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getIsDistrict() == null ? "" : bookings.get(i).getIsDistrict() + "");
				dataRow.createCell(rowIndex1++)
						.setCellValue(bookings.get(i).getIsCity() == null ? "" : bookings.get(i).getIsCity() + "");
				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getRecevingStoreName() == null ? ""
						: bookings.get(i).getRecevingStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getReceivingStoreBadge() == null ? ""
						: bookings.get(i).getReceivingStoreBadge() + "");

				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getRsCountry() == null ? "" : bookings.get(i).getRsCountry() + "");
				dataRow.createCell(rowIndex1++)
						.setCellValue(bookings.get(i).getRsState() == null ? "" : bookings.get(i).getRsState() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getRsDistrict() == null ? "" : bookings.get(i).getRsDistrict() + "");
				dataRow.createCell(rowIndex1++)
						.setCellValue(bookings.get(i).getRsCity() == null ? "" : bookings.get(i).getRsCity() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getProductBadge() == null ? "" : bookings.get(i).getProductBadge() + "");

				dataRow.createCell(rowIndex1++).setCellValue(bookings.get(i).getRecommandedStock() == null ? 0
						: bookings.get(i).getRecommandedStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getOrderedQuantity() == null ? 0 : bookings.get(i).getOrderedQuantity());

				dataRow.createCell(rowIndex1++)
						.setCellValue(bookings.get(i).getReason() == null ? "" : bookings.get(i).getReason() + "");

				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getCreatedBy() == null ? "" : bookings.get(i).getCreatedBy() + "");

				Cell cell = dataRow.createCell(rowIndex1++);
				cell.setCellValue(
						bookings.get(i).getCreatedOn() == null ? null : bookings.get(i).getCreatedOn());
				cell.setCellStyle(dateCellStyle);

				dataRow.createCell(rowIndex1++).setCellValue(
						bookings.get(i).getUpdatedBy() == null ? "" : bookings.get(i).getUpdatedBy() + "");

				Cell cell1 = dataRow.createCell(rowIndex1++);

				cell1.setCellValue(
						bookings.get(i).getUpdatedOn() == null ? null : bookings.get(i).getUpdatedOn());
				cell1.setCellStyle(dateCellStyle);

			}

			// creatng temporary excel file
			File tempFile = null;
			tempFile = File.createTempFile("BookingsReport", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
			workbook.write(outputStream);
			sheet.getWorkbook().close();
			// uploading file
			HttpResponse<String> response = uploadFileService.uploadFile(url,userName, tempFile, "Bookings");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			// deleting temporary excel file
			tempFile.delete();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";
			// sending email to particular user
			HashMap<String, Object> emailbody = new HashMap<>();
			emailbody = sendEmailService.getBookngEmail(link, userName, email);

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, email, userName,
					fileDownloadUrl, fileType, fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ email
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured while exporting booking report : " + e.getStackTrace());
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting booking report ");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		finally{
			
			outputStream.close();
			workbook.close();
		}
//		return responsebean;
	}

	public List<ExportBookingsDTO> getBookingsData(BookingsByFilterPayload bookingsByFilterPayload,
			StringBuilder builder, String queryForConsolidatedDomainIds, Pageable pageable, Long userId,
			List<Long> offsetKioskIds, Long pranthId) throws JsonMappingException, JsonProcessingException {

		List<ExportBookingsDTO> bookingsList = null;

		Users users = usersService.getById(userId);
		RolePermissionConfigurationModel configurationModel = rolePermissionConfigurationService
				.getPermissionCodeValue("mnstomtbhfov30", users.getRoleId(), bookingsByFilterPayload.getPranthId());

		builder.append("select b.pranth_id,b.id as booking_id,b.items_count as booking_items_count ,"
				+ " ms.id as status_id,ms.name as status,b.order_reference_no,"
				+ " b.receiving_store_id,b.order_type_id as indent_type_id,rs.name as receving_store_name,"
				+ " rs.city as rs_city,rd.name as rs_district,rst.name as rs_state,rc.name as rs_country,"
				+ " u.user_id as created_by,b.created_on,b.issuing_store_id, s.name as issuing_store_name,"
				+ " s.city as is_city,id.name as is_district,ist.name as is_state,ic.name as is_country,"
				+ " string_agg(bd.name,',') as booking_badge," + " bb.badge_id as booking_badge_id ,b.source_type  ,"
				+ " string_agg(rb.name,',') as receiving_store_badge,"
				+ " string_agg(rba.name,',') as issuing_store_badge,p.product_id,p.product_badge,"
				+ " bi.ordered_stock as ordered_quantity,bi.recommanded_stock,b.updated_on,bi.reason,ub.user_id as updated_by"
				+ " from bookings b " + " inner join booking_items bi on bi.booking_id = b.id"
				+ " left join master_status ms on b.status_id=ms.id "
				+ " left join store rs on b.receiving_store_id=rs.id "
				+ " left join master_district rd on rs.district_id=rd.id "
				+ " left join master_state rst on rs.state_id=rst.id "
				+ " left join master_country rc on rc.id=rs.country_id "
				+ " left join store_badge sb on sb.store_id = rs.id " + " left join badge rb on rb.id = sb.badge_id"
				+ " left join users u on b.created_by=u.id " + " left join users ub on b.updated_by=ub.id"
				+ " left join store s on b.issuing_store_id=s.id "
				+ " left join master_district id on s.district_id=id.id "
				+ " left join master_state ist on s.state_id=ist.id "
				+ " left join master_country ic on ic.id=s.country_id "
				+ " left join store_badge sba on sba.store_id = s.id " + " left join badge rba on rba.id = sba.badge_id"
				+ " left join booking_badge bb on b.id=bb.booking_id " + " left join badge bd on bb.badge_id=bd.id  "
				+ " left join (select p.id as product_id,p.name as product_name,"
				+ " is_batch_enabled,string_agg(distinct bd.name,',') as product_badge    " + " from product p     "
				+ " left join product_badge pb on pb.product_id=p.id    "
				+ " left join badge bd on bd.id=pb.badge_id and bd.badge_type_id=1   "
				+ " group by p.id)p on p.product_id=bi.product_id  ");
		if (bookingsByFilterPayload.getStoreId() != null) {
			if (bookingsByFilterPayload.getIndentTypeId().equals(1)) {
				builder.append(" where s.id = " + bookingsByFilterPayload.getStoreId() + " ");
			} else if (bookingsByFilterPayload.getIndentTypeId().equals(2)) {
				builder.append(" where rs.id = " + bookingsByFilterPayload.getStoreId() + " ");
			}
		} else if (bookingsByFilterPayload.getStoreId() == null) {
			builder.append(" where b.pranth_id in " + queryForConsolidatedDomainIds);
			builder.append(" and b.order_type_id = " + bookingsByFilterPayload.getIndentTypeId() + " ");
		}
		if (offsetKioskIds != null && !offsetKioskIds.isEmpty()) {
			builder.append(" and (s.id in ( " + StringUtils.join(offsetKioskIds, " ,") + "  ) or rs.id in ( "
					+ StringUtils.join(offsetKioskIds, " ,") + "  ))");
		}
		if (bookingsByFilterPayload.getStatus() != null && !bookingsByFilterPayload.getStatus().isEmpty()) {
			builder.append(" and ms.name = '" + bookingsByFilterPayload.getStatus() + "'");
		}
		if (bookingsByFilterPayload.getFromDate() != null && bookingsByFilterPayload.getToDate() != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			builder.append(
					"and cast(b.created_on as date) between '" + sdf.format(bookingsByFilterPayload.getFromDate())
							+ "'  and '" + sdf.format(bookingsByFilterPayload.getToDate()) + "'");
		} else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			if (bookingsByFilterPayload.getFromDate() != null) {
				builder.append(" and cast(b.created_on as date) >= '"
						+ sdf.format(bookingsByFilterPayload.getFromDate()) + "'");
			} else if (bookingsByFilterPayload.getToDate() != null) {
				builder.append(
						" and cast(b.created_on as date) <= '" + sdf.format(bookingsByFilterPayload.getToDate()) + "'");
			}
		}
		if (bookingsByFilterPayload.getIssueReferenceId() != null
				&& !bookingsByFilterPayload.getIssueReferenceId().isEmpty()) {
			builder.append(" and b.order_reference_no = " + bookingsByFilterPayload.getIssueReferenceId() + "");
		}
		if (bookingsByFilterPayload.getReceiptReferenceId() != null
				&& !bookingsByFilterPayload.getReceiptReferenceId().isEmpty()) {
			builder.append(" and b.transfer_reference_no = " + bookingsByFilterPayload.getReceiptReferenceId() + "");
		}
		if (bookingsByFilterPayload.getBookingId() != null) {
			builder.append(" and b.id = " + bookingsByFilterPayload.getBookingId() + " ");
		}
		if (bookingsByFilterPayload.getBookingBadgeId() != null) {
			builder.append(" and bd.id = " + bookingsByFilterPayload.getBookingBadgeId() + " ");
		}

		List<Integer> materialTagsToHide = bookingsService.getMaterialTagsToHide(configurationModel, pranthId);
		if (materialTagsToHide != null && !materialTagsToHide.isEmpty()) {
			builder.append(
					"  and ( bi.product_id not in (select p.id from product p left join product_badge pb on pb.product_id = p.id left join badge bad on bad.id = pb.badge_id"
							+ " where bad.name in ( "+ StringUtils.join(materialTagsToHide, ",") + ")");
		}
		builder.append(
				"group by b.pranth_id,b.id ,b.items_count , ms.id,ms.name ,b.order_reference_no, b.receiving_store_id,b.order_type_id ,rs.name, rs.city ,rd.name ,rst.name, rs_state,rc.name, u.user_id,b.created_on,b.issuing_store_id, s.name , s.city ,id.name ,ist.name ,ic.name  , bb.badge_id ,b.source_type,p.product_id,p.product_badge, bi.ordered_stock ,bi.recommanded_stock,b.updated_on,bi.reason,ub.user_id order by b.created_on DESC ");
		log.info("Export Booking Query :"+builder.toString());
		bookingsList = jdbcTemplateHelper.getResults(builder.toString(), ExportBookingsDTO.class);

		return bookingsList;
	}

}