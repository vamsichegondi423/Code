package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.MasterCountry;

@Repository
public interface MasterCountryRepository extends JpaRepository<MasterCountry, Integer> {

	@Query(value = "select * from master_country where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterCountry> getById(Integer id);

	@Query(value = "select * from master_country where is_deleted = false", nativeQuery = true)
	public List<MasterCountry> findAll();
	
	@Query(value = "select * from master_country where code = ? and is_deleted = false", nativeQuery = true)
	public MasterCountry getMasterCountry(String code);
	
	@Query(value = "select * from master_country where \"name\" = ? and is_deleted = false", nativeQuery = true)
	public MasterCountry getMasterCountryByName(String name);

	@Modifying
	@Transactional
	@Query(value = "delete from master_country where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);

	@Modifying
	@Transactional
	@Query(value = "update master_country set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

	@Query(value = "select * from master_country where code = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterCountry> getByCode(String code);

}