package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.IcatalogueProductBadge;

@Repository
public interface IcatalogueProductBadgeRepository extends JpaRepository<IcatalogueProductBadge, Long> {

	@Query(value = "select * from icatalogue_product_badge where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<IcatalogueProductBadge> getById(Long id);

	@Query(value = "select * from icatalogue_product_badge where is_deleted = false", nativeQuery = true)
	public List<IcatalogueProductBadge> findAll();
	
	@Query(value = "select * from icatalogue_product_badge where icatalogue_id = ?1 and product_id = ?2 and badge_id = ?3 and is_deleted = false", nativeQuery = true)
	public IcatalogueProductBadge getIcatalogueProductBadge(Long icatalogueId, Integer productId, Integer badgeId);

	@Modifying
	@Transactional
	@Query(value = "delete from icatalogue_product_badge where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update icatalogue_product_badge set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from icatalogue_product_badge where is_deleted = false and icatalogue_id = ?1 order by created_on desc", nativeQuery = true)
	public List<IcatalogueProductBadge> findByIcatalogueId(Long id);

}