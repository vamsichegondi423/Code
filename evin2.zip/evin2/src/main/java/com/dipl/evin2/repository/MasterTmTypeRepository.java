package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.MasterTmType;

@Repository
public interface MasterTmTypeRepository extends JpaRepository<MasterTmType, Integer> {

	@Query(value = "select * from master_tm_type where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterTmType> getById(Integer id);

	@Query(value = "select * from master_tm_type where is_deleted = false", nativeQuery = true)
	public List<MasterTmType> findAll();
	
	@Query(value = "select * from master_tm_type where \"name\" = ? and   is_deleted = false", nativeQuery = true)
	public MasterTmType getMasterTmType(String name);

	@Modifying
	@Transactional
	@Query(value = "delete from master_tm_type where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);
	
	@Modifying
	@Transactional
	@Query(value = "update master_tm_type set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);
	
}