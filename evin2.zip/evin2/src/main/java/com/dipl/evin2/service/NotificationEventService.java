package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.entity.NotificationEvent;
import com.dipl.evin2.repository.NotificationEventRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class NotificationEventService {
	
	@Autowired
	private NotificationEventRepository notificationEventRepository;

	public NotificationEvent getById(Integer id) throws CustomException {
		try {
			Optional<NotificationEvent> notificationEventOptional = notificationEventRepository.getById(id);
			if (notificationEventOptional.isPresent()) {
				return notificationEventOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public NotificationEvent save(NotificationEvent notificationEvent) throws CustomException {
		try {
			if (notificationEvent.getId() != null && notificationEvent.getId() > 0) {
				Optional<NotificationEvent> existingNotificationEventRecord = notificationEventRepository.getById(notificationEvent.getId());
				if (existingNotificationEventRecord.isPresent()) {
					return notificationEventRepository.save(notificationEvent);
				}
			} else {
				notificationEvent = notificationEventRepository.save(notificationEvent);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return notificationEvent;
	}

	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<NotificationEvent> existingNotificationEventRecord = notificationEventRepository.getById(id);
			if (existingNotificationEventRecord.isPresent()) {
				notificationEventRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<NotificationEvent> getAll() {
		try {
			return notificationEventRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public List<NotificationEvent> getAllByModule(Integer moduleId, String assetEventType) {
		if(assetEventType != null && !assetEventType.isEmpty()) {
			return notificationEventRepository.getAllByModuleAndEventType(moduleId, assetEventType);
		}
		return notificationEventRepository.getAllByModule(moduleId);	
	}
}