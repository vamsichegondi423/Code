package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.dipl.evin2.controller.MasterAssetModelController.AssetModelJackson;
import com.dipl.evin2.controller.MasterAssetModelController.AssetTypeDetais;
import com.dipl.evin2.controller.MasterAssetModelController.AssetTypeDetais.AssetVendorDetails;
import com.dipl.evin2.controller.MasterAssetModelController.AssetTypeDetais.AssetVendorDetails.AssetModelDetails;
import com.dipl.evin2.controller.MasterAssetModelController.AssetVendorDTO;
import com.dipl.evin2.dto.AssetModelDTO;
import com.dipl.evin2.entity.MasterAssetModel;
import com.dipl.evin2.entity.MasterAssetType;
import com.dipl.evin2.entity.MasterAssetVendor;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.AssetModelSensorMappingRepository;
import com.dipl.evin2.repository.MasterAssetModelRepository;
import com.dipl.evin2.repository.MasterAssetTypeRepository;
import com.dipl.evin2.repository.MasterAssetVendorRepository;
import com.dipl.evin2.util.Constants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MasterAssetModelService {

	@Autowired
	private MasterAssetVendorService masterAssetVendorService;

	@Autowired
	private MasterAssetModelService masterAssetModelService;

	@Autowired
	private MasterAssetVendorRepository masterAssetVendorRepository;

	@Autowired
	private MasterAssetModelRepository masterAssetModelRepository;

	@Autowired
	private MasterAssetTypeRepository masterAssetTypeRepository;

	@Autowired
	private AssetModelSensorMappingRepository assetModelSensorMappingRepository;

	@Autowired
	private JdbcTemplate jdbcTemplate;


	@Cacheable(value = "master-asset-model", key = "#id")
	public MasterAssetModel getById(Long id) {
		Optional<MasterAssetModel> masterAssetModelOptional = masterAssetModelRepository.getById(id);
		if (masterAssetModelOptional.isPresent()) {
			return masterAssetModelOptional.get();
		} else {
			return null;
		}
	}

	@CachePut(value = "master-asset-model", key = "#masterAssetModel.id")
	public MasterAssetModel save(MasterAssetModel masterAssetModel) {
		if (masterAssetModel.getId() != null && masterAssetModel.getId() > 0) {
			Optional<MasterAssetModel> existingMasterAssetModelRecord = masterAssetModelRepository
					.getById(masterAssetModel.getId());
			if (existingMasterAssetModelRecord.isPresent()) {
				return masterAssetModelRepository.save(masterAssetModel);
			}
		} else {
			masterAssetModel = masterAssetModelRepository.save(masterAssetModel);
		}
		return masterAssetModel;
	}

	@CacheEvict(value = "master-asset-model", allEntries = true)
	public Integer deleteById(Long id) {
		Optional<MasterAssetModel> existingMasterAssetModelRecord = masterAssetModelRepository.getById(id);
		if (existingMasterAssetModelRecord.isPresent()) {
			masterAssetModelRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	@Cacheable(value = "master-asset-model")
	public List<MasterAssetModel> getAll() {
		return masterAssetModelRepository.findAll();
	}

	public List<MasterAssetModel> saveAll(List<MasterAssetModel> masterAssetModels) {
		if (!masterAssetModels.isEmpty()) {
			masterAssetModels = masterAssetModelRepository.saveAll(masterAssetModels);
		}
		return masterAssetModels;
	}

	public List<?> fetchAssetModelsByType(Long assestTypeId) {
		try {
			if (assestTypeId.intValue() == Constants.ASSET_TYPE_TEMPERATURE_LOGGER.intValue()) {
				String query = "select msm.asset_type_id as assetTypeId,mat.\"name\" as assetTypeName,msm.model_name as"
						+ " modelName ,msm.id as modelId,msm.is_active as modelIsActive ,msm.asset_vendor_id as assetVendorid,"
						+ "mav.\"name\" as vendorName, mav.is_active as vendorIsActive,msm.default_censor as  defaultCensor "
						+ "from master_asset_model msm join "
						+ "master_asset_type mat on mat.id = msm.asset_type_id join master_asset_vendor mav on "
						+ "mav.id = msm.asset_vendor_id where msm.asset_type_id = "+assestTypeId+"  and msm.is_deleted = false";
				return jdbcTemplate.query(query, new BeanPropertyRowMapper<AssetModelDTO>(AssetModelDTO.class));
			} else {
				String query = "select distinct msm.asset_type_id as assetTypeId,mat.\"name\" as assetTypeName, msm.asset_vendor_id as assetVendorid,mav.\"name\" as vendorName, \r\n"
						+ "mav.is_active as vendorIsActive from master_asset_model msm join master_asset_type mat on mat.id = msm.asset_type_id join\r\n"
						+ "master_asset_vendor mav on mav.id = msm.asset_vendor_id where msm.asset_type_id = " + assestTypeId
						+ "  and msm.is_deleted = false";
				return  jdbcTemplate.query(query, new BeanPropertyRowMapper<AssetVendorDTO>(AssetVendorDTO.class));
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public AssetTypeDetais fetchAssetModel(Long assetTypeId) throws CustomException {
		AssetTypeDetais assetResponseDTO = new AssetTypeDetais();
		List<AssetVendorDetails> vendorDetails = new ArrayList<>();
		List<AssetModelDetails> assetModelDetails = new ArrayList<>();
		String query = "";
		try {
			Optional<MasterAssetType> findById = masterAssetTypeRepository.findById(assetTypeId);
			if(findById.isPresent()) {
				assetResponseDTO.setAssetTypeId(findById.get().getId().intValue());
				assetResponseDTO.setAssetTypeName(findById.get().getName());
				assetResponseDTO.setMonitoringPoint(findById.get().getDefaultMonitoringPoint());
				query = "select distinct mav.id as assetVendorId, mav.name as vendorName,mav.is_active as vendorIsActive from master_asset_vendor mav join master_asset_model mam on"
						+ " mam.asset_vendor_id = mav.id where mam.asset_type_id = "+assetTypeId+" and mam.is_deleted = false";
				vendorDetails = jdbcTemplate.query(query, new BeanPropertyRowMapper<AssetVendorDetails>(AssetVendorDetails.class));
				for(AssetVendorDetails vd : vendorDetails) {
					String query1 = "select id as modelId,model_name as modelName,is_active as modelIsActive,default_censor as defaultCensor from"
							+ " master_asset_model mam where asset_vendor_id = "+vd.getAssetVendorId()+" and is_deleted= false";
					assetModelDetails = jdbcTemplate.query(query1, new BeanPropertyRowMapper<AssetModelDetails>(AssetModelDetails.class));
					assetModelDetails.stream().forEach(amd ->{
						amd.setAssetModelSensorMappings(assetModelSensorMappingRepository.getByAssetModel(amd.getModelId()));			
					});
					vd.setAssetModelDetailsList(assetModelDetails);
				}
				assetResponseDTO.setAssetVendorDetailsList(vendorDetails);
				return assetResponseDTO;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException(e.toString(), HttpStatus.OK);
		}
		return null;
	}


	@Cacheable(value = "master-asset-model", key = "{#vendorId,#isActive}")
	public List<MasterAssetModel> getByVendorId(Long vendorId, Optional<Boolean> isActive) {
		if (isActive.isPresent()) {
			return masterAssetModelRepository.getActiveModelsByVendorId(vendorId, isActive.get());
		} else {
			return masterAssetModelRepository.getByVendorId(vendorId);
		}
	}

	public List<MasterAssetModel> saveList(List<AssetModelJackson> modelJacksons) throws CustomException{
		Map<Long, MasterAssetVendor> allMasterAssetVendorsMap = masterAssetVendorService.getAll().stream().collect(Collectors.toMap(MasterAssetVendor::getId, MasterAssetVendor -> MasterAssetVendor));
		Map<Long, MasterAssetModel> allMasterAssetModelsMap = masterAssetModelService.getAll().stream().collect(Collectors.toMap(MasterAssetModel::getId, MasterAssetModel -> MasterAssetModel));
		List<MasterAssetModel> modelList = new ArrayList<>();
		List<MasterAssetVendor> vendorsList = new ArrayList<>();
		try {
			for(AssetModelJackson modelData : modelJacksons) {
				MasterAssetVendor masterAssetVendor = allMasterAssetVendorsMap.get(modelData.getVendorId());
				if(masterAssetVendor != null) {
					masterAssetVendor.setIsActive(modelData.getVendorIsActive());
					masterAssetVendor.setUpdatedBy(modelData.getUpdatedBy());
					masterAssetVendor.setUpdatedOn(new Date());
					vendorsList.add(masterAssetVendor);
				}

				if(modelData.getAssetModelId()!= null) {
					MasterAssetModel masterAssetModel = allMasterAssetModelsMap.get(modelData.getAssetModelId());
					masterAssetModel.setIsActive(modelData.getAssetModelIsActive());
					masterAssetModel.setDefaultCensor(modelData.getDefaultSensor());
					masterAssetModel.setUpdatedBy(modelData.getUpdatedBy());
					masterAssetModel.setUpdatedOn(new Date());
					modelList.add(masterAssetModel);
				}
			}
			modelList = masterAssetModelRepository.saveAll(modelList);
			vendorsList = masterAssetVendorRepository.saveAll(vendorsList);
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException(e.toString(), HttpStatus.OK);
		}
		return modelList;
	}
}