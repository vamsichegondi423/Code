package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.dipl.evin2.entity.AssetConfiguration;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface AssetConfigurationRepository extends JpaRepository<AssetConfiguration, Long> {

	@Query(value = "select * from asset_configuration where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<AssetConfiguration> getById(Long id);

	@Query(value = "select * from asset_configuration where is_deleted = false", nativeQuery = true)
	public List<AssetConfiguration> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from asset_configuration where id = ?1", nativeQuery = true)
	public void deleteById(Long id);
	
	@Modifying
	@Transactional
	@Query(value = "update asset_configuration set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from asset_configuration where country_id = ?1 and asset_id = ?2 and phone_numbers_to_send_sms_notification like '?3' and is_deleted = false", nativeQuery = true)
	public Optional<AssetConfiguration> findByCountryAndDeviceIdAndPhoneNumber(Integer countryId, Long assetId, String phn);

	@Query(value = "select ac.* from asset a join asset_configuration ac on a.id = ac.asset_id \n"
			+ "join master_asset_model mam on a.asset_model_id  = mam.id join master_asset_vendor mav on mav.id = mam.asset_vendor_id \n"
			+ "where a.id = ?2 and mav.id =?1 and a.firmware_version  = ?3 ", nativeQuery = true)
	public Optional<AssetConfiguration> findByVendorIdAndDeviceIdAndFirmwareVersion(Long vendorId, Long deviceId, String firmwareVersion);

	@Query(value = "select ac.* from asset a join asset_configuration ac on a.id = ac.asset_id \n"
			+ "join master_asset_model mam on a.asset_model_id  = mam.id join master_asset_vendor mav on mav.id = mam.asset_vendor_id \n"
			+ "where a.id = ?2 and mav.id =?1", nativeQuery = true)
	public Optional<AssetConfiguration> findByVendorIdAndDeviceId(Long vendorId, Long deviceId);

	@Query(value = "select * from asset_configuration where asset_id = ?1 and sensor_id is not null and is_deleted = false", nativeQuery = true)
	public List<AssetConfiguration> findSensorsByAssetId(Long assetId);

	@Query(value = "select * from asset_configuration where asset_id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<AssetConfiguration> getByAssetId(Long assetId);

	@Query(value = "select * from asset_configuration where asset_id in (?1) and is_deleted = false", nativeQuery = true)
	public List<AssetConfiguration> getAllByAssetIds(Set<Long> assetIds);
	
}