package com.dipl.evin2.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dipl.evin2.entity.TxnConsumptionLog;

/**
 * @author madhumohan.p 27-Aug-2021
 */

@Repository
public interface TxnConsumptionRepository extends CrudRepository<TxnConsumptionLog, Long> {

	@Query(value = "Select * from txn_consumption_log where store_id=?1 and product_id=?2 and txn_type_id=?3 and txn_date=?4", nativeQuery = true)
	public TxnConsumptionLog findConsumptionRecord(Long storeId, Long productId, Integer txnTypeId, Date date);

}
