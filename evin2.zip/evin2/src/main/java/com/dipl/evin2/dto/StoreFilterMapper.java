package com.dipl.evin2.dto;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StoreFilterMapper implements RowMapper<StoreFiltersDTO> {

	public StoreFiltersDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		StoreFiltersDTO storeResult = StoreFiltersDTO.builder().storeName(rs.getString("store_name"))
				.location(rs.getString("location")).tag(rs.getString("tag")).lastupdated(rs.getTimestamp("lastupdated"))
				.updatedBy(rs.getString("updated_by")).storeId(rs.getLong("store_id")).build();

		return storeResult;
	}
}
