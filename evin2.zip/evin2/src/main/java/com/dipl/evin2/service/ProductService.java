package com.dipl.evin2.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.dipl.evin2.controller.ProductController.MaterialWiseMinMaxDTO;
import com.dipl.evin2.controller.ProductController.ProdModel;
import com.dipl.evin2.controller.ProductController.ProductFilterModel;
import com.dipl.evin2.entity.Product;
import com.dipl.evin2.entity.ProductBadge;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.jackson.ProductModel;
import com.dipl.evin2.repository.ProductBadgeRepository;
import com.dipl.evin2.repository.ProductRepository;
import com.dipl.evin2.util.JdbcTemplateHelper;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductService {

	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private ProductBadgeRepository productBadgeRepository;
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	private PranthHierarchyService pranthHierarchyService;
	
	@Autowired
	private JdbcTemplateHelper jdbcTemplateHelper;

	public Product getById(Integer id) {
		try {
			Optional<Product> productOptional = productRepository.getById(id);
			if (productOptional.isPresent()) {
				return productOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public Product save(Product product) throws CustomException {
		try {
			if (product.getId() != null && product.getId() > 0) {
				Optional<Product> existingProductRecord = productRepository.getById(product.getId());
				if (existingProductRecord.isPresent()) {
					return productRepository.save(product);
				}
			} else {
				product = productRepository.save(product);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return product;
	}

	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<Product> existingProductRecord = productRepository.getById(id);
			if (existingProductRecord.isPresent()) {
				productRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<Product> getAll() {
		try {
			return productRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public Product createProduct(ProductModel productPayload) throws Exception {
		Product product = new Product();
		try {
			if (productPayload.getId() != null && productPayload.getId() > 0) {
				product = saveProduct(productPayload);
				product.setId(productPayload.getId());
				Product prod = productRepository.save(product);
				if (prod != null) {
					List<Integer> badgeIds = productPayload.getProductBadgeIds();
					for (Integer productbadge : badgeIds) {
						saveProductBadge(productPayload, product, productbadge);
					}
				}
			} else {
				product = saveProduct(productPayload);
				Product prod = productRepository.save(product);
				if (prod != null) {
					List<Integer> badgeIds = productPayload.getProductBadgeIds();
					for (Integer productbadge : badgeIds) {
						saveProductBadge(productPayload, product, productbadge);
					}
				}
			}

		} catch (Exception e) {
			log.error("Exception occured while Creating a product", e.getMessage());
			throw new Exception("Exception occured while Creating a product" + e.getCause());
		}

		return product;
	}

	private Product saveProduct(ProductModel productPayload) {
		Product product;
		product = Product.builder().name(productPayload.getName()).isBatchEnabled(productPayload.getIsBatchEnabled())
				.shortName(productPayload.getShortName()).description(productPayload.getDescription())
				.isSeasonal(productPayload.getIsSeasonal())
				.isTemperatureSensitive(productPayload.getIsTemperatureSensitive())
				.handlingUnit(productPayload.getHandlingUnit())
				.minimumTemperature(productPayload.getMinimumTemperature())
				.maximumTemperature(productPayload.getMaximumTemperature()).build();
		product.setCreatedBy(Long.valueOf(productPayload.getUserId()));
		product.setUpdatedBy(Long.valueOf(productPayload.getUserId()));
		return product;
	}

	private void saveProductBadge(ProductModel productPayload, Product product, Integer productbadge) {
		ProductBadge prdbadge = new ProductBadge();
		prdbadge.setProductId(product.getId());
		prdbadge.setBadgeId(productbadge);
		prdbadge.setCreatedBy(Long.valueOf(productPayload.getUserId()));
		prdbadge.setUpdatedBy(Long.valueOf(productPayload.getUserId()));
		prdbadge = productBadgeRepository.save(prdbadge);
	}

	public Product findProductByName(String name) {
		try {
			Product prod = productRepository.findProductByName(name);
			if (prod != null) {
				return prod;
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured while dtting product by name", e.getCause());
		}
		return null;
	}

	public List<ProductFilterModel> getProductsByFilters(Long pranthId, String productName, String badgeName,
			Pageable pageable) throws CustomException {
		List<ProductFilterModel> materilaFilterModel = null;
		String query = "select p.id as productId ,p.name as productName,p.description,u.user_id userId,  case when p.is_batch_enabled ='true' then\n"
				+ "'Enabled' else 'NotEnabled' end as batchEnabled,p.created_by,p.updated_on as lastUpdated, string_agg(b.name,',') as\n"
				+ "badge from product p left join product_badge pb on  pb.product_id = p.id  left join badge b on b.id = pb.badge_id and\n"
				+ "b.badge_type_id = 1 left join users u on u.id = p.created_by where p.is_deleted=false ";
		query = addFilltersForProducts(productName, badgeName, query);
		query = query
				+ " group by p.id,p.name,p.description,u.user_id,p.is_batch_enabled,p.updated_on  order by p.name asc LIMIT "
				+ pageable.getPageSize() + " OFFSET " + pageable.getOffset();
		try {
			materilaFilterModel = jdbcTemplate.query(query,
					new BeanPropertyRowMapper<ProductFilterModel>(ProductFilterModel.class));
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}

		return materilaFilterModel;

	}

	private String addFilltersForProducts(String productName, String badgeName, String query) {
		StringBuilder builder = new StringBuilder();
		if (productName != null && !productName.isEmpty()) {
			builder = builder.length() == 0 ? builder.append(" and ") : builder.append(" and ");
			builder.append(" p.name like '%" + productName + "%'");
		}
		if (badgeName != null && !badgeName.isEmpty()) {
			builder = builder.length() == 0 ? builder.append(" and ") : builder.append(" and ");
			builder = builder.append(" b.name = '" + badgeName + "'");
		}
		return query + builder.toString();
	}

	public Long getProductCount(Long pranthId, String productName, String badgeName) throws CustomException {
		Long count = null;
		String query = "select count (distinct productId) from(select p.id as productId ,p.name as productName,p.description,u.user_id userId,  case when p.is_batch_enabled ='true' then\n"
				+ "'Enabled' else 'NotEnabled' end as batchEnabled,p.created_by,p.updated_on as lastUpdated, string_agg(b.name,',') as\n"
				+ "badge from product p left join product_badge pb on  pb.product_id = p.id  left join badge b on b.id = pb.badge_id and\n"
				+ "b.badge_type_id = 1 left join users u on u.id = p.created_by where p.is_deleted=false ";
		query = addFilltersForProducts(productName, badgeName, query);
		query = query
				+ " group by p.id,p.name,p.description,u.user_id,p.is_batch_enabled,p.updated_on  order by p.name asc)a";
		try {
			count = jdbcTemplate.queryForObject(query, Long.class);
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}

		return count;
	}

	public List<ProdModel> getProductByProductId(Long productId, Pageable pageable) {
		List<ProdModel> productModel = null;
		String productByProductId = "";
		if (productId != null) {
			productByProductId = "select p.id as product_id,p.name as product_name,b.name as badge,u.user_id as updated_by,p.updated_on, "
					+ "case when p.is_batch_enabled=true then 'Enabled' else 'NotEnabled' end as batch_enabled, "
					+ "case when p.is_seasonal=true then 'Yes' else 'No' end as is_seasonal, "
					+ "case when p.is_temperature_sensitive=true then 'Yes' else 'No' end as is_temperature_sensitive,p.handling_unit "
					+ "from product p left join product_badge pb on p.id=pb.product_id "
					+ "left join users u on p.updated_by=u.id "
					+ "left join badge b on b.id=pb.badge_id left join master_badge_type mbt on b.badge_type_id=mbt.id and mbt.name='Product' "
					+ "where p.id=" + productId + " LIMIT " + pageable.getPageSize() + " OFFSET "
					+ pageable.getOffset();
		}

		try {
			productModel = jdbcTemplate.query(productByProductId, new ProdDTO());
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}

		return productModel;
	}

	public class ProdDTO implements RowMapper<ProdModel> {

		@Override
		public ProdModel mapRow(ResultSet rs, int rowNum) throws SQLException {
			ProdModel materialByIdModel = ProdModel.builder().batchEnabled(rs.getString("batch_enabled"))
					.isSeasonal(rs.getString("is_seasonal")).product_id(rs.getLong("product_id"))
					.productName(rs.getString("product_name")).isTempSensitive(rs.getString("is_temperature_sensitive"))
					.badge(rs.getString("badge")).updatedBy(rs.getString("updated_by"))
					.updatedOn(rs.getTimestamp("updated_on")).build();

			return materialByIdModel;
		}
	}

	public List<MaterialWiseMinMaxDTO> getProductWiseMinMaxConsumption(Long storeId, Long productId) {
		try {
			StringBuilder builder = new StringBuilder();
			builder.append("select store_id,product_id,min_stock,max_stock,i.updated_on,u.user_id as updated_by");
			builder.append(" from icatalogue i left join users u on i.updated_by=u.id and u.is_deleted = false ");
			builder.append(" where i.is_deleted = false and store_id = {0} and product_id = {1} ");
			String query = MessageFormat.format(builder.toString(), storeId.toString(), productId.toString());

			List<MaterialWiseMinMaxDTO> productsWiseMinMaxDTOs = jdbcTemplate.query(query,
					new RowMapper<MaterialWiseMinMaxDTO>() {
						@Override
						public MaterialWiseMinMaxDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
							return MaterialWiseMinMaxDTO.builder().StoreId(rs.getLong("store_id"))
									.productId(rs.getLong("product_id")).max(rs.getLong("max_stock"))
									.min(rs.getLong("min_stock")).updatedBy(rs.getString("updated_by"))
									.updatedOn(rs.getTimestamp("updated_on")).build();
						}
					});
			return productsWiseMinMaxDTOs;
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
		}
		return new ArrayList<MaterialWiseMinMaxDTO>();

	}

	public List<Map<String, Object>> getHistoryOfProducts(Long storeId, Long productId) throws SQLException {
		List<Map<String, Object>> productsHistory = null;
		try {
			productsHistory = productRepository.getHistoryOfProducts(storeId, productId);
			if (productsHistory != null && !productsHistory.isEmpty()) {
				return productsHistory;
			}
		} catch (Exception e) {
			log.error("Exception Occured while fetching product history.. ");
			e.printStackTrace();
			return productsHistory;
		}
		return productsHistory;
	}

	public Optional<Product> getProductsById(Integer productId) {
		Optional<Product> product = null;
		try {
			product = productRepository.findById(productId);
			if (product.isEmpty()) {
				return product;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	
	public List<ProductBadgeDetails> getProductBadgeDetails(Set<Long> productIds){
		String productIdsString = StringUtils.join(productIds.toArray(), ",");
		String query = "select p.id as productId, p.\"name\" as productName, b.id as badgeId, b.\"name\" as badgeName from product p join product_badge pb on \r\n"
				+ " p.id = pb.product_id join badge b on pb.badge_id = b.id"
				+ " where p.id in ("+productIdsString+")";
		return jdbcTemplateHelper.getResults(query, ProductBadgeDetails.class);
	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ProductBadgeDetails{
		private Long productId;
		private String productName;
		private Long badgeId;
		private String badgeName;
	}

}
