package com.dipl.evin2.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dipl.evin2.controller.IcatalogueController;
import com.dipl.evin2.dto.ExportStockReportDTO;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.model.ExportStockReportModel;
import com.dipl.evin2.model.FileReportResponse;
import com.dipl.evin2.service.RolePermissionConfigurationService.RolePermissionConfigurationModel;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.JdbcTemplateHelper;
import com.dipl.evin2.util.KafkaProducer;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ExportStockReportService {

	@Autowired
	private SendEmailService sendEmailService;
	@Autowired
	private UploadFileService uploadFileService;
	@Autowired
	private PranthHierarchyService pranthHierarchyService;
	@Autowired
	private IcatalogueController icatalogueController;
	@Autowired
	private UsersService usersService;
	@Autowired
	private RolePermissionConfigurationService rolePermissionConfigurationService;
	@Autowired
	private JdbcTemplateHelper jdbcTemplateHelper;
//	@Autowired
//	private KafkaProducer kafkaProducer;
	@Autowired
	@Lazy
	private ExportExcelAsyncService exportExcelAsyncService;
	
	@Value("${DBURL}")
	private String dbUrl;

	@Value("${DBUSERNAME}")
	private String dbUserName;

	@Value("${DBPASSWORD}")
	private String dbPassword;
	
	public ResponseBean getStockService(ExportStockReportModel exportStockReportModel) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		try {
//			this.getStockWithoutBatch(exportStockReportModel);
			exportExcelAsyncService.getStockWithoutBatch(exportStockReportModel);
//			kafkaProducer.sendStockWithoutBatchReportToProducer(exportStockReportModel);
			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
					+ exportStockReportModel.getEmail()
					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
			responsebean.setReturnCode(1);
			responsebean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured while exporting stock report : {}", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		} 
		return responsebean;
	}

	public void getStockWithoutBatch(ExportStockReportModel exportStockReportModel) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<ExportStockReportDTO> stockReports = null;
		Object fileData;
		String url = null;
		File file = File.createTempFile("StockReport", ".csv");
		BufferedWriter bw = null;
		String updatedOn = null;

		try {
			Connection connection = getConnection(dbUrl, dbUserName, dbPassword);
			Statement statement = connection.createStatement();
			String sql = "select j.jobname, max(r.start_time) as updated_on from cron.job j join cron.job_run_details r on j.jobid=r.jobid "
					+ "where r.status='succeeded'  and j.jobname = 'mvw_export_stock_report' group by 1 "; 
			ResultSet resultSet = statement.executeQuery(sql);		
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			while(resultSet.next()) {
				updatedOn = formatter.format(resultSet.getTimestamp("updated_on"));	
			}	
			log.info("last updated on : "+updatedOn);
			
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
	//	Writer writer = Files.newBufferedWriter(file.toPath());
		bw.write("Title," + Constants.stock_report);
		bw.newLine();
		bw.write("Generated on," + uploadFileService.dateWithHoursMinutes());
        bw.newLine();
		
		bw.write("Data Updated On," + updatedOn);
		bw.newLine();
		bw.newLine();

		CSVPrinter csvPrinter = new CSVPrinter(bw,
				CSVFormat.DEFAULT.withHeader("Material Name", "Material Tags", "Store Name", "Store Tags", "Country",
						"State", "District/County", "Taluk/Block", "Village/City", "Total Stock", "Days Of Stock",
						"Allocated Stock", "In Transit Stock", "Min Stock", "Max Stock", "Abnormality Type",
						"Abnormality Duration-Days", "Updated On"));
		

		Users users = usersService.getById(exportStockReportModel.getUserId());
		RolePermissionConfigurationModel permissionConfigurationModel = rolePermissionConfigurationService
				.getPermissionCodeValue("mnstomtbhfiv29", users.getRoleId(), exportStockReportModel.getPranthId());
		
		Set<Long> consolidatedPranthIds = pranthHierarchyService
				.getConsolidatedPranthIds(exportStockReportModel.getPranthId());
		List<Long> totalKioskIdsWithOutPagination = icatalogueController.getToatalStoreIdsWithoutPagination(
				consolidatedPranthIds, exportStockReportModel.getUserId(), exportStockReportModel.getState(),
				exportStockReportModel.getDistrict(), exportStockReportModel.getBlock());
		stockReports = getAllProductsBasedOnPranth(totalKioskIdsWithOutPagination, consolidatedPranthIds,
				 exportStockReportModel);
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");		

		stockReports.stream().forEach(s -> {
			// Writing records in the generated CSV file
			try {
				csvPrinter.printRecord(
						s.getProductName() == null ? "" : s.getProductName(),
						s.getProductBadge() == null ? "" : s.getProductBadge(),
						s.getStoreName() == null ? "" : s.getStoreName(),
						s.getStoreBadge() == null ? "" : s.getStoreBadge(),
						s.getCountryName() == null ? "" : s.getCountryName(),
						s.getStateName() == null ? "" : s.getStateName(),
						s.getDistrictName() == null ? "" : s.getDistrictName(),
						s.getBlock_name() == null ? "" : s.getBlock_name(),
						s.getCity() == null ? "" : s.getCity(),
						s.getTotalStock() == null ? 0 : s.getTotalStock(),
						s.getDaysOfStock() == null ? 0 : s.getDaysOfStock(),
						s.getAllocatedStock() == null ? 0 : s.getAllocatedStock(),
						s.getInTransitStock() == null ? 0 : s.getInTransitStock(),
						s.getMinStock() == null ? 0 : s.getMinStock(),
						s.getMaxStock() == null ? 0 : s.getMaxStock(),
						s.getAbnormalityType() == null ? "" : s.getAbnormalityType(),
						s.getAbnormalityDurationDays() == null ? 0 : s.getAbnormalityDurationDays(),
						s.getUpdatedOn() == null ? "": dateFormat.format(s.getUpdatedOn()));
				        
			} catch (IOException e) {
				e.printStackTrace();
			}
		});

		csvPrinter.flush();
		csvPrinter.close();
		log.info("File path {}", file.getAbsolutePath());
			// uploading excel file
			HttpResponse<String> response = uploadFileService.uploadFile(url, exportStockReportModel.getUserName(),
					file, "StockReport");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			Map<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			file.delete();

			HashMap<String, Object> emailbody = new HashMap<>();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";

			// sending excel file to particular user's email
			emailbody = sendEmailService.getStockReportEmail(link, exportStockReportModel.getUserName(),
					exportStockReportModel.getEmail());

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody,
					exportStockReportModel.getEmail(), exportStockReportModel.getUserName(), fileDownloadUrl, fileType,
					fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ exportStockReportModel.getEmail()
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting stock report : {}", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		} 
		bw.close();
//		return responsebean;
	}

	// query withtout pagination without batch
	public List<ExportStockReportDTO> getAllProductsBasedOnPranth(List<Long> totalStoreIdsWithOutPagination,Set<Long> consolidatedPranthIds,ExportStockReportModel exportStockReportModel) throws CustomException {
		List<ExportStockReportDTO> productsList = null;
		int i = 0;
		StringBuilder consolidatedDomainsBuilder = new StringBuilder();
		consolidatedDomainsBuilder.append(" (");
		for (Long e : consolidatedPranthIds) {
			consolidatedDomainsBuilder.append(e.toString());
			if (i < consolidatedPranthIds.size() - 1) {
				consolidatedDomainsBuilder.append(" ,");
			}
			i++;
		}
		StringBuilder builder = new StringBuilder();
		builder.append(" select pranth_id,product_id,product_name,product_badge,product_badge_id,store_name,store_badge,store_badge_id,"
				+ " country_name,state_id,state_name, "
				+ "district_id, district_name,block_id,block_name,city,total_stock,days_of_stock,allocated_stock,in_transit_stock, "
				+ " min_stock,max_stock,abnormality_id,abnormality_type, abnormality_duration_days, updated_on from mvw_export_stock_report"
				+ "  where pranth_id in " + (consolidatedDomainsBuilder.toString()) +" "+")"+"  ");
		addFilterConditionsForStockView(builder, totalStoreIdsWithOutPagination,exportStockReportModel);

		builder.append(" group by pranth_id,product_id, product_name,product_badge,product_badge_id,store_name,store_badge,store_badge_id,country_name,state_id,state_name,"
				+ " district_id,district_name, block_id,block_name,city,total_stock,days_of_stock,allocated_stock,in_transit_stock,min_stock,max_stock,abnormality_id,"
				+ " abnormality_type,abnormality_duration_days,updated_on  order by 3 ");
		log.info(builder.toString());
		productsList = jdbcTemplateHelper.getResults(builder.toString(), ExportStockReportDTO.class);
		return productsList;
	}
	public ResponseBean getStockServiceWithBatch(ExportStockReportModel exportStockReportModel) throws IOException {
		ResponseBean responsebean = new ResponseBean();
		try {
//			this.getStockWithBatch(exportStockReportModel);
			exportExcelAsyncService.getStockWithBatch(exportStockReportModel);
//			kafkaProducer.sendStockWithBatchReportToProducer(exportStockReportModel); 
			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
					+ exportStockReportModel.getEmail()
					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
			responsebean.setReturnCode(1);
			responsebean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured while exporting stock report : {}", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		return responsebean;
	}
	
	public void getStockWithBatch(ExportStockReportModel exportStockReportModel) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<ExportStockReportDTO> stockReports = null;
		Object fileData;
		String url = null;
		File file = File.createTempFile("StockReport", ".csv");
		BufferedWriter bw = null;
		String updatedOn = null;

		try {
			Connection connection = getConnection(dbUrl, dbUserName, dbPassword);
			Statement statement = connection.createStatement();
			String sql = "select j.jobname, max(r.start_time) as updated_on from cron.job j join cron.job_run_details r on j.jobid=r.jobid "
					+ "where r.status='succeeded'  and j.jobname = 'mvw_export_stock_report_with_batch' group by 1 "; 
			ResultSet resultSet = statement.executeQuery(sql);	
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			while(resultSet.next()) {
				updatedOn = formatter.format(resultSet.getTimestamp("updated_on"));	
			}	
			log.info("last updated on : "+updatedOn);
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
			//Writer writer = Files.newBufferedWriter(file.toPath());
			bw.write("Title," + Constants.stock_report);
			bw.newLine();
			bw.write("Generated on," + uploadFileService.dateWithHoursMinutes());
			bw.newLine();				
			bw.write("Data Updated On," + updatedOn);
			bw.newLine();
			bw.newLine();
			CSVPrinter csvPrinter = new CSVPrinter(bw,
					CSVFormat.DEFAULT.withHeader("Material Name", "Material Tags", "Store Name", "Store Tags", "Country",
							"State", "District/County", "Taluk/Block", "Village/City", "Batch ID","Stock In Batch","Batch Expiry","Batch Manufacturer","Batch Manufactured Date","Batch Updated On","Total Stock", "Days Of Stock",
							"Allocated Stock", "In Transit Stock", "Min Stock", "Max Stock", "Abnormality Type",
							"Abnormality Duration-Days", "Updated On"));
			
            // getting stock reports from query
			Users users = usersService.getById(exportStockReportModel.getUserId());
			RolePermissionConfigurationModel permissionConfigurationModel = rolePermissionConfigurationService.getPermissionCodeValue("mnstomtbhfiv29", users.getRoleId(), exportStockReportModel.getPranthId());
			Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(exportStockReportModel.getPranthId());
			List<Long> totalKioskIdsWithOutPagination = icatalogueController.getToatalStoreIdsWithoutPagination(consolidatedPranthIds, exportStockReportModel.getUserId(), exportStockReportModel.getState(), exportStockReportModel.getDistrict(), exportStockReportModel.getBlock());
			stockReports = getAllProductsBasedOnPranthWithBatch(totalKioskIdsWithOutPagination,consolidatedPranthIds,exportStockReportModel);
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");		

			stockReports.stream().forEach(s -> {
					// Writing records in the generated CSV file
					try {
						csvPrinter.printRecord(
								s.getProductName() == null ? "" : s.getProductName(),
								s.getProductBadge() == null ? "" : s.getProductBadge(),
								s.getStoreName() == null ? "" : s.getStoreName(),
								s.getStoreBadge() == null ? "" : s.getStoreBadge(),
								s.getCountryName() == null ? "" : s.getCountryName(),
								s.getStateName() == null ? "" : s.getStateName(),
								s.getDistrictName() == null ? "" : s.getDistrictName(),
								s.getBlock_name() == null ? "" : s.getBlock_name(),
								s.getCity() == null ? "" : s.getCity(),
										
								s.getBatchNo() == null ? "" : s.getBatchNo(),
								s.getStockInBatch() == null ? 0 : s.getStockInBatch(),
								s.getBatchExpiry() == null ? "" : s.getBatchExpiry(),
								s.getBatchManufacturer() == null ? "" : s.getBatchManufacturer(),
								s.getBatchManufacturedDate() == null ? "" : s.getBatchManufacturedDate(),
								s.getBatchUpdatedOn() == null ? "" :  dateFormat.format(s.getBatchUpdatedOn()),

								s.getTotalStock() == null ? 0 : s.getTotalStock(),
								s.getDaysOfStock() == null ? 0 : s.getDaysOfStock(),
								s.getAllocatedStock() == null ? 0 : s.getAllocatedStock(),
								s.getInTransitStock() == null ? 0 : s.getInTransitStock(),
								s.getMinStock() == null ? 0 : s.getMinStock(),
								s.getMaxStock() == null ? 0 : s.getMaxStock(),
								s.getAbnormalityType() == null ? "" : s.getAbnormalityType(),
								s.getAbnormalityDurationDays() == null ? 0 : s.getAbnormalityDurationDays(),
								s.getUpdatedOn() == null ? "": dateFormat.format(s.getUpdatedOn()));
					} catch (IOException e) {
						e.printStackTrace();
					}
				});

			
			csvPrinter.flush();
			csvPrinter.close();
			
            //uploading excel file
			HttpResponse<String> response = uploadFileService.uploadFile(url,exportStockReportModel.getUserName(), file, "StockReport");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			file.delete();

			HashMap<String, Object> emailbody = new HashMap<>();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";

			//sending excel file to particular user's email
			emailbody = sendEmailService.getStockReportEmail(link, exportStockReportModel.getUserName(), exportStockReportModel.getEmail());

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, exportStockReportModel.getEmail(), exportStockReportModel.getUserName(),
					fileDownloadUrl, fileType, fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ exportStockReportModel.getEmail()
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting stock report : {}", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		bw.close();
//		return responsebean;
	}

	// query withtout pagination with batch
		public List<ExportStockReportDTO> getAllProductsBasedOnPranthWithBatch(List<Long> totalStoreIdsWithOutPagination,Set<Long> consolidatedPranthIds,ExportStockReportModel exportStockReportModel) throws CustomException {
			List<ExportStockReportDTO> productsList = null;
			int i = 0;
			StringBuilder consolidatedDomainsBuilder = new StringBuilder();
			consolidatedDomainsBuilder.append(" (");
			for (Long e : consolidatedPranthIds) {
				consolidatedDomainsBuilder.append(e.toString());
				if (i < consolidatedPranthIds.size() - 1) {
					consolidatedDomainsBuilder.append(" ,");
				}
				i++;
			}
			StringBuilder builder = new StringBuilder();
			builder.append(" select pranth_id,product_id,product_name,product_badge,product_badge_id,store_id,store_name,store_badge,store_badge_id,country_name,state_id, "
					+ "  state_name, district_id,district_name,block_id, block_name,city,batch_no,stock_in_batch, batch_expiry,batch_manufacturer, "
					+ " batch_manufactured_date,batch_updated_on, total_stock,days_of_stock,allocated_stock,in_transit_stock,min_stock,max_stock, abnormality_id, "
					+ " abnormality_type, abnormality_duration_days, updated_on from mvw_export_stock_report_with_batch "
					+ "  where pranth_id in " + (consolidatedDomainsBuilder.toString()) +" "+")"+" ");
			
			addFilterConditionsForStockView(builder, totalStoreIdsWithOutPagination,exportStockReportModel);

			builder.append(" group by pranth_id,product_id,product_name,product_badge,product_badge_id,store_id,store_name,store_badge,store_badge_id,country_name,state_id, "
					+ " state_name,district_id, district_name,block_id,block_name,city,batch_no,stock_in_batch,batch_expiry,batch_manufacturer,batch_manufactured_date, "
					+ " batch_updated_on,total_stock, days_of_stock,allocated_stock,in_transit_stock,min_stock,max_stock,abnormality_id,abnormality_type, "
					+ " abnormality_duration_days,updated_on order by 3 ");
			
			log.info(builder.toString());
			productsList = jdbcTemplateHelper.getResults(builder.toString(), ExportStockReportDTO.class);
			return productsList;
		}
		
		private void addFilterConditionsForStockView(StringBuilder builder, List<Long> offsetStoreIds,ExportStockReportModel exportStockReportModel) {
			
			if (offsetStoreIds != null && !offsetStoreIds.isEmpty()) {
				builder.append(" and store_id in ( " + StringUtils.join(offsetStoreIds, " ,") + "  ) ");
			}
			
			if (exportStockReportModel.getIncludeAllProductBadge() != null && !exportStockReportModel.getIncludeAllProductBadge().isEmpty()) {
				builder.append(" and product_badge_id  in ("+ StringUtils.join(exportStockReportModel.getIncludeAllProductBadge(), ",") + ")");

				}
			if (exportStockReportModel.getIncludeStoreBadge() != null && !exportStockReportModel.getIncludeStoreBadge().isEmpty()) {
				builder.append(" and store_badge_id  in ("+ StringUtils.join(exportStockReportModel.getIncludeStoreBadge(), ",") + ")");
				}
			if (exportStockReportModel.getAbnormalityType() != null && exportStockReportModel.getAbnormalityType() == 200) {
				builder.append("  and total_stock=0  ");
			} else if (exportStockReportModel.getAbnormalityType() != null && exportStockReportModel.getAbnormalityType() == 201) {
				builder.append("  and total_stock<min_stock and total_stock<>0 ");
			} else if (exportStockReportModel.getAbnormalityType() != null && exportStockReportModel.getAbnormalityType() == 202) {
				builder.append("  and total_stock>max_stock ");
			} else if (exportStockReportModel.getAbnormalityType() == null) {
				builder.append(
						"  and (total_stock = 0 or total_stock<min_stock and total_stock<>0 or total_stock>max_stock ) ");
			}
				
				/*if (exportStockReportModel.getCountry() != null) {
					builder.append("  and country_id = '" + exportStockReportModel.getCountry() + " '");
				}*/	
				if (exportStockReportModel.getState() != null) {
					builder.append("  and state_id = '" + exportStockReportModel.getState() + " '");
				}
				if (exportStockReportModel.getDistrict() != null) {
					builder.append("  and district_id = '" + exportStockReportModel.getDistrict() + " '");
				}
				if (exportStockReportModel.getBlock() != null) {
					builder.append("  and block_id = '" + exportStockReportModel.getBlock() + " '");
				}				
		}
		
        
          
          private static Connection getConnection(String dbUrl, String dbUserName, String dbPaswrd) {
  			try {
  				Class.forName("org.postgresql.Driver");
  				Connection conn = DriverManager.getConnection(dbUrl, dbUserName, dbPaswrd);
  				return conn;
  			} catch (SQLException | ClassNotFoundException e) {
  				// TODO Auto-generated catch block
  				e.printStackTrace();
  			}
  			return null;
  		}
}
