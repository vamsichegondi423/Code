package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.dto.AssetDTO;
import com.dipl.evin2.dto.AssetDetailsDTO;
import com.dipl.evin2.dto.AssetDetailsDTO.SensorMonitoringPoint;
import com.dipl.evin2.dto.AssetDetailsDTO.TemperatureLogData;
import com.dipl.evin2.dto.AssetDetailsDTO.UserDetails;
import com.dipl.evin2.entity.Asset;
import com.dipl.evin2.entity.AssetConfiguration;
import com.dipl.evin2.entity.AssetDefaultConfiguration;
import com.dipl.evin2.entity.AssetMapping;
import com.dipl.evin2.entity.AssetSensorConfiguration;
import com.dipl.evin2.entity.AssetUsers;
import com.dipl.evin2.entity.SensorDefaultConfiguration;
import com.dipl.evin2.entity.Store;
import com.dipl.evin2.entity.StoreUsers;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.model.TemperatureLog;
import com.dipl.evin2.model.TemperatureLog.Tmp;
import com.dipl.evin2.service.AssetConfigurationService;
import com.dipl.evin2.service.AssetDefaultConfigurationService;
import com.dipl.evin2.service.AssetMappingService;
import com.dipl.evin2.service.AssetSensorConfigurationService;
import com.dipl.evin2.service.AssetService;
import com.dipl.evin2.service.AssetService.AssetSensorMonitoringPointDTO;
import com.dipl.evin2.service.AssetUsersService;
import com.dipl.evin2.service.PranthHierarchyService;
import com.dipl.evin2.service.SensorDefaultConfigurationService;
import com.dipl.evin2.service.StoreService;
import com.dipl.evin2.service.StoreUsersService;
import com.dipl.evin2.service.UsersService;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.PowerAvailabilityGraphResponse;
import com.dipl.evin2.util.ResponseBean;
import com.dipl.evin2.util.TempatureGraphResponse;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/asset")
public class AssetController {

	private static final String RECORDS_FETCHED_SUCCESSFULLY = "Records fetched successfully";

	private static final String NO_RECORDS_FOUND = "No records found";

	private static final String EXCEPTION_OCCURED = "Exception occured";

	@Autowired
	private AssetService assetService;

	@Autowired
	private AssetConfigurationService assetConfigurationService;

	@Autowired
	private AssetDefaultConfigurationService assetDefaultConfigurationService;

	@Autowired
	private AssetSensorConfigurationService assetSensorConfigurationService; 

	@Autowired
	private SensorDefaultConfigurationService sensorDefaultConfigurationService;

	@Autowired
	private StoreService storeService;

	@Autowired
	private UsersService usersService;

	@Autowired
	private AssetUsersService assetUsersService;

	@Autowired
	private AssetMappingService assetMappingService;

	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private StoreUsersService storeUsersService;

	@Value("${ASSETS_URL}")
	private String assetsURL; 

	@Transactional(rollbackFor = Exception.class)
	@ApiOperation("Use this api for saving or updating Asset. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody Asset request, BindingResult result) {
		Asset asset = new Asset();
		BeanUtils.copyProperties(request, asset);
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (asset.getId() == null || asset.getId() == 0) {
				Asset existingAsset = assetService.getBySerialNumberAndAssetModel(asset.getSerialNumber(), asset.getAssetModelId());
				if(existingAsset != null) {
					return ResponseBean.builder().data(existingAsset).message("Asset with the given serial number and model already exists.").returnCode(1).status(HttpStatus.OK).build();
				}
			}

			if (asset.getId() != null && asset.getId() > 0) {
				Asset existingAsset = assetService.getById(asset.getId());
				if (existingAsset != null) {
					asset.setCreatedBy(existingAsset.getCreatedBy());
					asset.setCreatedOn(existingAsset.getCreatedOn());
				} else {
					log.info(NO_RECORDS_FOUND);
					return ResponseBean.builder().data(existingAsset).message(NO_RECORDS_FOUND).returnCode(1).status(HttpStatus.OK).build();
				}
			} else {
				if(asset.getCreatedBy() == null) {
					asset.setCreatedBy(asset.getUpdatedBy());
				}
				if(asset.getCreatedOn() == null) {
					asset.setCreatedOn(asset.getUpdatedOn());
				}
			}
			asset.setUpdatedOn(new Date());
			asset = assetService.save(asset);
			AssetConfiguration assetConfiguration = request.getAssetConfiguration();
			AssetConfiguration existingAssetConfiguration = assetConfigurationService.getByAssetId(asset.getId());
			if(existingAssetConfiguration == null) {
				assetConfiguration.setCreatedBy(asset.getUpdatedBy());
				assetConfiguration.setCreatedOn(new Date());
				assetConfiguration.setUpdatedBy(asset.getUpdatedBy());
				assetConfiguration.setUpdatedOn(new Date());
			}else {
				assetConfiguration.setId(existingAssetConfiguration.getId());
				assetConfiguration.setCreatedBy(existingAssetConfiguration.getCreatedBy());
				assetConfiguration.setCreatedOn(existingAssetConfiguration.getCreatedOn());
				assetConfiguration.setUpdatedBy(asset.getUpdatedBy());
				assetConfiguration.setUpdatedOn(new Date());
			}
			asset.setIsDeleted(asset.getIsDeleted() == null ? false : asset.getIsDeleted());
			List<AssetUsers> assetUsersList = new ArrayList<>();
			if(request.getOwners() != null && !request.getOwners().isEmpty()) {
				processOwners(asset, assetUsersList, request.getOwners());
			}

			if(request.getMaintainers() != null && !request.getMaintainers().isEmpty()) {
				processMaintainers(asset, assetUsersList, request.getMaintainers());
			}
			assetUsersService.saveAll(assetUsersList);

			assetConfiguration.setAssetId(asset.getId());


			assetConfigurationService.save(assetConfiguration);
			List<AssetSensorConfiguration> sensorConfigurations = new ArrayList<>();
			if(request.getAssetConfiguration() != null && request.getAssetConfiguration().getAssetSensorConfigurationList() != null && !request.getAssetConfiguration().getAssetSensorConfigurationList().isEmpty()) {
				for(AssetSensorConfiguration assetSensorConfiguration : request.getAssetConfiguration().getAssetSensorConfigurationList()) {
					processSensorConfigurations(asset, sensorConfigurations, assetSensorConfiguration);
				}
			}

			assetSensorConfigurationService.saveAll(sensorConfigurations);

			if(request.getId() != null && request.getId() > 0) {
				log.info("Record updated successfully");
				responseBean.setMessage("Record updated successfully");
			}else {
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
			}

			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage(EXCEPTION_OCCURED);
		}
		return responseBean;
	}

	private void processSensorConfigurations(Asset asset, List<AssetSensorConfiguration> sensorConfigurations,
			AssetSensorConfiguration assetSensorConfiguration) {
		AssetSensorConfiguration existingAssetSensorConfiguration = null;
		AssetModelDetailsDTO assetModelDetailsDTO = assetService.getAssetModelDetails(asset.getId());
		if (assetModelDetailsDTO.getAssetTypeId().equals(Constants.ASSET_TYPE_TEMPERATURE_LOGGER)) {
			existingAssetSensorConfiguration = assetSensorConfigurationService
					.getByAssetIdAndSensorId(asset.getId(), assetSensorConfiguration.getSensorId());
			if (existingAssetSensorConfiguration != null) {
				assetSensorConfiguration.setId(existingAssetSensorConfiguration.getId());
				assetSensorConfiguration.setCreatedBy(existingAssetSensorConfiguration.getCreatedBy());
				assetSensorConfiguration.setCreatedOn(existingAssetSensorConfiguration.getCreatedOn());
			} else {
				assetSensorConfiguration.setCreatedBy(asset.getUpdatedBy());
				assetSensorConfiguration.setCreatedOn(new Date());
			}
			assetSensorConfiguration.setAssetId(asset.getId());
			assetSensorConfiguration.setUpdatedBy(asset.getUpdatedBy());
			assetSensorConfiguration.setUpdatedOn(new Date());
			sensorConfigurations.add(assetSensorConfiguration);
		}
	}

	private void processOwners(Asset asset, List<AssetUsers> assetUsersList, List<Users> list)
			throws CustomException {
		List<AssetUsers> existingAssetUsers = assetUsersService.getByAssetIdAndRole(asset.getId(), Constants.ASSET_OWNER_USER_ROLE);
		existingAssetUsers.stream().forEach(au -> assetUsersService.deleteByIdHard(au.getId()));
		for (Iterator<Users> iterator = list.iterator(); iterator.hasNext();) {
			Users users = iterator.next();
			Users ownerUser = usersService.getById(users.getId());
			if(ownerUser == null) {
				throw new CustomException("Owner does not exist", HttpStatus.BAD_REQUEST);
			}else {
				AssetUsers assetUsers = AssetUsers.builder().assetId(asset.getId()).roleId(Constants.ASSET_OWNER_USER_ROLE).userId(ownerUser.getId()).build();
				assetUsers.setUpdatedBy(asset.getUpdatedBy());
				assetUsers.setUpdatedOn(new Date());
				assetUsers.setCreatedBy(asset.getUpdatedBy());
				assetUsers.setCreatedOn(new Date());
				assetUsersList.add(assetUsers);
			}
		}
	}

	private void processMaintainers(Asset asset, List<AssetUsers> assetUsersList, List<Users> list)
			throws CustomException {
		List<AssetUsers> existingAssetUsers = assetUsersService.getByAssetIdAndRole(asset.getId(), Constants.ASSET_MAINTAINER_USER_ROLE);
		existingAssetUsers.stream().forEach(au -> assetUsersService.deleteByIdHard(au.getId()));
		for (Iterator<Users> iterator = list.iterator(); iterator.hasNext();) {
			Users users = iterator.next();
			Users ownerUser = usersService.getById(users.getId());
			if(ownerUser == null) {
				throw new CustomException("Maintainer does not exist", HttpStatus.BAD_REQUEST);
			}else {
				AssetUsers assetUsers = AssetUsers.builder().assetId(asset.getId()).roleId(Constants.ASSET_MAINTAINER_USER_ROLE).userId(ownerUser.getId()).build();
				assetUsers.setUpdatedBy(asset.getUpdatedBy());
				assetUsers.setUpdatedOn(new Date());
				assetUsers.setCreatedBy(asset.getUpdatedBy());
				assetUsers.setCreatedOn(new Date());
				assetUsersList.add(assetUsers);
			}
		}
	}

	@ApiOperation("Use this api for fetching Asset record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id,@RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Asset asset = assetService.getById(id);
			if (asset != null) {
				AssetConfiguration assetConfiguration = assetConfigurationService.getByAssetId(id);
				if(asset.getEnablePushConfiguration() != null && asset.getEnablePushConfiguration() && assetConfiguration != null) {
					List<AssetSensorConfiguration> assetSensorConfigurations = assetSensorConfigurationService.getByAssetId(id);
					assetConfiguration.setAssetSensorConfigurationList(assetSensorConfigurations);
					asset.setAssetConfiguration(assetConfiguration);
				}else if(asset.getEnablePushConfiguration() != null && asset.getEnablePushConfiguration()) {
					List<AssetDefaultConfiguration> assetDefaultConfigurations = assetDefaultConfigurationService.getAll(pranthId);
					assetConfiguration = new AssetConfiguration(assetDefaultConfigurations.iterator().next());
					List<SensorDefaultConfiguration> sensorDefaultConfigurations = sensorDefaultConfigurationService.getAll(pranthId);
					List<AssetSensorConfiguration> assetSensorConfigurations = new ArrayList<>();
					for(SensorDefaultConfiguration sensorDefaultConfiguration : sensorDefaultConfigurations) {
						assetSensorConfigurations.add(new AssetSensorConfiguration(sensorDefaultConfiguration));
					}
					assetConfiguration.setAssetSensorConfigurationList(assetSensorConfigurations);
					asset.setAssetConfiguration(assetConfiguration);
				}

				List<Users> owners = usersService.getByAssetIdAndRole(id, Constants.ASSET_OWNER_USER_ROLE);
				asset.setOwners(owners);

				List<Users> maintainers = usersService.getByAssetIdAndRole(id, Constants.ASSET_MAINTAINER_USER_ROLE);
				asset.setMaintainers(maintainers);

				Store store = storeService.getById(asset.getStoreId());
				asset.setStore(store);

				log.info(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setMessage(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setData(asset);
			} else {
				log.info(NO_RECORDS_FOUND);
				responseBean.setMessage(NO_RECORDS_FOUND);
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage(EXCEPTION_OCCURED);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting Asset record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = assetService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage(EXCEPTION_OCCURED);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all Asset records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Asset> assetRecords = assetService.getAll();
			if (!assetRecords.isEmpty()) {
				log.error(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setMessage(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setData(assetRecords);
			} else {
				log.error(NO_RECORDS_FOUND);
				responseBean.setMessage(NO_RECORDS_FOUND);
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage(EXCEPTION_OCCURED);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all available temperature logger Assets. No params required.")
	@GetMapping(value = "/v1/available-temperature-loggers", produces = "application/json")
	public ResponseBean getAvailableTemperatureLoggers(@RequestParam(value = "serialnumber", required = false) String serialNumber) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Asset> assets = assetService.getAvailableTemperatureLoggers(Constants.ASSET_TYPE_TEMPERATURE_LOGGER, serialNumber);
			if (!assets.isEmpty()) {
				responseBean.setMessage(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setData(assets);
			} else {
				responseBean.setMessage(NO_RECORDS_FOUND);
				responseBean.setData(null);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured while getting available temperature loggers : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Exception occured while getting available temperature loggers : " +e);
		}
		return responseBean;
	}


	@ApiOperation("Use this api for get all assets by serial number")
	@PostMapping(value = "/v1/get-assets-by-serial-number")
	public ResponseBean fetchAssetsBySerialNoAndType(@RequestBody AssetsByFilterPayload filterPayload, Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<AssetDTO> listOfAssets = assetService.fetchAssetsBySerialNoAndType(filterPayload.getSerialNumber(),filterPayload.getAssetTypes(),pageable);
			if (!listOfAssets.isEmpty()) {
				AssetDTODetails assetDTODetails = AssetDTODetails.builder().assetsList(listOfAssets).totalCount(listOfAssets.size()).build();
				responseBean.setData(assetDTODetails);
				responseBean.setMessage(RECORDS_FETCHED_SUCCESSFULLY);
			} else {
				responseBean.setMessage(NO_RECORDS_FOUND);
				responseBean.setData(null);
			}

			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured while for get assets by serial number : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption occured for get assets by serial number " +e);
		}
		return responseBean;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class AssetDTODetails {
		private List<AssetDTO> assetsList;
		private Integer totalCount;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class AssetDetails {
		private List<AssetDetailsDTO> assetsList;
		private Integer totalCount;
	}


	@ApiOperation("Use this api for get all assets details by id")
	@GetMapping(value = {"/v1/getassetdetailsbyid/{assetid}", "/v1/getassetdetailsbystore/{storeid}"})
	public ResponseBean getAssetsDetailsById(@PathVariable(value = "assetid", required = false) Optional<Long> assetIdOptional, @PathVariable(value = "storeid", required = false) Optional<Long> storeIdOptional, Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Long assetId = assetIdOptional.isPresent() ? assetIdOptional.get() : null;
			Long storeId = storeIdOptional.isPresent() ? storeIdOptional.get() : null;
			List<AssetDetailsDTO> listOfAssets = assetService.getAssetsDetails(assetId, storeId, pageable);
			populateTemperatures(listOfAssets);
			populateSensorMonitoringPoints(listOfAssets);
			if (!listOfAssets.isEmpty()) {
				responseBean.setMessage(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setData(listOfAssets);
			} else {
				responseBean.setMessage(NO_RECORDS_FOUND);
				responseBean.setData(null);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured while getting assets details : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption occured while getting asset details " +e);
		}
		return responseBean;
	}

	private HttpResponse<String> getAssetTemeratureData(Set<String> assetSerialNumbers) throws UnirestException {
		Unirest.setTimeouts(0, 0);
		return Unirest.get(assetsURL+"temperature_log/v1/get-by-device?deviceIds="+StringUtils.collectionToCommaDelimitedString(assetSerialNumbers))
				.header("Accept", "application/json")
				.asString();
	}

	private List<TemperatureLogData> getTemperatureLogData(TemperatureLog temperatureLog, AssetConfiguration assetConfiguration) {
		List<TemperatureLogData> temperatureLogDataList = new ArrayList<>();
		for(Tmp tmp : temperatureLog.getData().get(0).getTmps()) {
			Map<String, Double> sensorLow = assetConfiguration.getAssetSensorConfigurationList().stream().collect(Collectors.toMap(AssetSensorConfiguration::getSensorId, AssetSensorConfiguration::getLowAlarmTemperature));
			Map<String, Double> sensorHigh = assetConfiguration.getAssetSensorConfigurationList().stream().collect(Collectors.toMap(AssetSensorConfiguration::getSensorId, AssetSensorConfiguration::getHighAlarmTemperature));
			Double min = sensorLow.get(tmp.getSId()) != null ? sensorLow.get(tmp.getSId()) : assetConfiguration.getLowAlarmTemperature();
			Double max = sensorHigh.get(tmp.getSId()) != null ? sensorHigh.get(tmp.getSId()) : assetConfiguration.getHighAlarmTemperature();
			TemperatureLogData temperatureLogData = TemperatureLogData.builder().isDefault(false).lastUpdated(temperatureLog.getUpdatedOn())
					.sensor(tmp.getSId()).temperature(tmp.getTmp()).timeInSeconds(tmp.getTime()).type(tmp.getTyp()).tempLow(min).tempHigh(max).build();
			temperatureLogDataList.add(temperatureLogData);
		}
		return temperatureLogDataList;
	}

	@ApiOperation("Use this api for get all assets by filter")
	@PostMapping(value = "/v1/getassetdetailsbyfilter")
	public ResponseBean getAssetsDetailsByStore(@RequestBody AssetsByFilterPayload assetsByFilterPayload, Pageable pageable, @RequestParam("pranthId") Long pranthId, @RequestParam("userId") Long userId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Users users = usersService.getById(userId);
			Set<Long> storeIds = null;
			if(users.getRoleId().equals(Constants.ADMINISTRATOR_ROLE) || users.getRoleId().equals(Constants.OWNER_ROLE)) {
				Set<Long> pranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);
				storeIds = new HashSet<>(storeService.getStoresByPranthIds(pranthIds, 0, Integer.MAX_VALUE));
			}else{
				List<StoreUsers> storeUsers = storeUsersService.getByUserId(userId);
				storeIds = storeUsers.stream().map(StoreUsers::getStoreId).collect(Collectors.toSet());
			}
			List<AssetDetailsDTO> listOfAssets = assetService.getAssetsDetails(assetsByFilterPayload.getStoreId(), assetsByFilterPayload.getAssetId(),
					assetsByFilterPayload.getAssetTypes(), assetsByFilterPayload.getRelationships(), assetsByFilterPayload.getStatusId(), 
					assetsByFilterPayload.getAlarms(), pageable, storeIds, assetsByFilterPayload.getSerialNumber());

			populateTemperatures(listOfAssets);
			populateSensorMonitoringPoints(listOfAssets);
			AssetDetails assetDetails = AssetDetails.builder().assetsList(listOfAssets).totalCount(listOfAssets.size()).build();
			responseBean.setMessage("Records fetched successfully.");
			responseBean.setData(assetDetails);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured while getting assets details : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption occured while getting asset details " +e);
		}
		return responseBean;
	}

	private void populateTemperatures(List<AssetDetailsDTO> listOfAssets)
			throws UnirestException, JsonProcessingException, JsonMappingException {
		if(!listOfAssets.isEmpty()) {
			Set<String> allSerialNos = listOfAssets.stream().map(AssetDetailsDTO::getSerialNumber).collect(Collectors.toSet());
			List<TemperatureLog> temperatureLogDetailsList = null;
			Map<String, List<TemperatureLog>> temperatureLogsMap = null;

			if(!allSerialNos.isEmpty()) {
				Unirest.setTimeouts(0, 0);
				HttpResponse<String> response = getAssetTemeratureData(allSerialNos);
				try {
					if(response.getBody() != null && !response.getBody().isEmpty()) {
						ResponseBean bean = objectMapper.readValue(response.getBody(), ResponseBean.class);
						temperatureLogDetailsList = objectMapper.readValue(objectMapper.writeValueAsString(bean.getData()), new TypeReference<List<TemperatureLog>>() {});
						if(temperatureLogDetailsList != null && !temperatureLogDetailsList.isEmpty()) {
							temperatureLogsMap = temperatureLogDetailsList.stream().filter(t -> t.getData().get(0).getDId()!= null).collect(Collectors.groupingBy(t -> t.getData().get(0).getDId()));
						}
					}
				}catch (Exception e) {
					log.error("Unable to fetch temperature data.", e);
				}
			}

			addTemperatures(listOfAssets, temperatureLogDetailsList, temperatureLogsMap);
		}
	}

	private void addTemperatures(List<AssetDetailsDTO> listOfAssets, List<TemperatureLog> temperatureLogDetailsList,
			Map<String, List<TemperatureLog>> temperatureLogsMap) {
		Set<Long> allAssetIds = listOfAssets.stream().map(AssetDetailsDTO::getAssetId).collect(Collectors.toSet());
		List<AssetConfiguration> assetConfigurations = assetConfigurationService.getAllByAssetIds(allAssetIds);
		assetConfigurations.forEach(assetConfiguration -> {
			List<AssetSensorConfiguration> assetSensorConfigurations = assetSensorConfigurationService.getByAssetId(assetConfiguration.getAssetId());
			assetConfiguration.setAssetSensorConfigurationList(assetSensorConfigurations);
		});
		Map<Long, AssetConfiguration> assetConfigMap = assetConfigurations.stream().collect(Collectors.toMap(AssetConfiguration::getAssetId, a->a));
		for (AssetDetailsDTO assetDetailsDTO : listOfAssets) {
			String serialNo = null;
			if (assetDetailsDTO.getAssetTypeId().equals(Constants.ASSET_TYPE_TEMPERATURE_LOGGER)) {
				serialNo = assetDetailsDTO.getSerialNumber();
			} else {
				serialNo = assetDetailsDTO.getMappedAssetSerialNumber();
			}
			if (temperatureLogDetailsList != null && temperatureLogsMap != null
					&& temperatureLogsMap.get(serialNo) != null) {
				List<TemperatureLog> temperatureLogs1 = temperatureLogsMap.get(serialNo);
				if (temperatureLogs1 != null) {
					AssetConfiguration assetConfiguration = assetConfigMap.get(assetDetailsDTO.getAssetId());
					temperatureLogs1.sort(Comparator.comparing(TemperatureLog::getCreatedOn).reversed());
					List<TemperatureLogData> temperatureLogData = getTemperatureLogData(temperatureLogs1.get(0), assetConfiguration);
					assetDetailsDTO.setTemperatureLogDataList(temperatureLogData);
				}
			}
		}
	}

	private void populateSensorMonitoringPoints(List<AssetDetailsDTO> listOfAssets) throws JsonProcessingException, JsonMappingException {
		if(!listOfAssets.isEmpty()) {
			Set<Long> assetIds = listOfAssets.stream().filter(a -> !a.getAssetTypeId().equals(Constants.ASSET_TYPE_TEMPERATURE_LOGGER)).map(AssetDetailsDTO::getAssetId).collect(Collectors.toSet());
			Map<Long, Long> mappedAssets = new HashMap<>();
			List<AssetMapping> assetMappings = assetMappingService.getAllMappedAssetsByAssetIds(new ArrayList<>(assetIds));
			List<AssetSensorMonitoringPointDTO> assetSensorMonitoringPointDTOs = assetService.getSensorMonitoringPoints(assetIds);
			assetMappings.forEach(a -> mappedAssets.put(a.getAssetId(), a.getMappedAssetId()));
			Map<Long, String> sensorMonitoringPointsMap = assetSensorMonitoringPointDTOs.stream().collect(Collectors.toMap(AssetSensorMonitoringPointDTO::getAssetId, AssetSensorMonitoringPointDTO::getSensorMonitoringPoint));
			for(AssetDetailsDTO assetDetailsDTO : listOfAssets) {
				if(!assetDetailsDTO.getAssetTypeId().equals(Constants.ASSET_TYPE_TEMPERATURE_LOGGER) && sensorMonitoringPointsMap != null && sensorMonitoringPointsMap.get(mappedAssets.get(assetDetailsDTO.getAssetId()))!= null) {
					assetDetailsDTO.setSensorMonitoringPoints(sensorMonitoringPointsMap.get(mappedAssets.get(assetDetailsDTO.getAssetId())) != null ? objectMapper.readValue(sensorMonitoringPointsMap.get(mappedAssets.get(assetDetailsDTO.getAssetId())), new TypeReference<List<SensorMonitoringPoint>>() {
					}) : null);						
				} else if(assetDetailsDTO.getSensorMonitoringPoint() != null && !assetDetailsDTO.getSensorMonitoringPoint().isBlank()) {
					assetDetailsDTO.setSensorMonitoringPoints(assetDetailsDTO.getSensorMonitoringPoint() != null ? objectMapper.readValue(assetDetailsDTO.getSensorMonitoringPoint(), new TypeReference<List<SensorMonitoringPoint>>() {
					}) : null);
				}
				if(assetDetailsDTO.getUserDetail() != null && !assetDetailsDTO.getUserDetail().isBlank()) {
					List<UserDetails> userDetails = assetDetailsDTO.getUserDetail() != null ? objectMapper.readValue(assetDetailsDTO.getUserDetail(), new TypeReference<List<UserDetails>>() {
					}) : null;
					assetDetailsDTO.setUserDetailsList(userDetails);
				}
			}
		}
	}


	@Component
	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class AssetsByFilterPayload{
		private Long storeId;
		private Long assetId;
		private List<Integer> assetTypes;
		private String relationships;
		private Integer statusId;
		private String alarms;
		private String serialNumber;
	}

	@PostMapping("/v1/is-valid-asset")
	public ResponseEntity<Boolean> isValidAsset(@RequestBody String serialNumber){

		Asset asset = assetService.getBySerialNumber(serialNumber);
		if(asset!=null) {
			return ResponseEntity.ok(true);
		}
		return ResponseEntity.ok(false);

	}

	@ApiOperation("Use this api for fetching Users existing or not .")
	@GetMapping(value = "/v1/find-assest-by-serial-number")
	public ResponseBean findAssetBySerialNumber(@RequestParam (value = "assestSerialNum") String assestSerialNum) {
		ResponseBean responseBean = new ResponseBean();
		List<Map<String,Object>> assetDetails = null;
		try {
			assetDetails = assetService.findAssetBySerialNumber(assestSerialNum);
			if (assetDetails != null && !assetDetails.isEmpty()) {
				log.info(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setMessage( "this "+ assestSerialNum + " is already exists. ");
				responseBean.setData(assetDetails.get(0).get("serial_number"));
			} else {
				log.info("No record found with serial number");
				responseBean.setMessage(" No record found with this serial number");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured while finding user details", e.getMessage());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Exception occured while finding user details" + e.getCause());
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching Tempature graph Details")
	@PostMapping(value = "/v1/temp-graph-details")
	public ResponseBean findTempatureGraphDetails(@RequestBody GraphDTO graphDTO) {
		ResponseBean responseBean = new ResponseBean();
		TempatureGraphResponse assetDetails = null;
		try {
			assetDetails = assetService.findTempatureGraphDetails(graphDTO);
			responseBean.setMessage("Success");
			responseBean.setData(assetDetails);
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured while fetching data", e.getMessage());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Exception occured while fetching data" + e.getMessage());
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching Tempature graph Details")
	@PostMapping(value = "/v1/power-availible-details")
	public ResponseBean findPowerAvailabilityGraphDetails(@RequestBody GraphDTO graphDTO) {
		ResponseBean responseBean = new ResponseBean();
		PowerAvailabilityGraphResponse pwaDetails = null;
		try {
			pwaDetails = assetService.findPowerAvailabilityGraphDetails(graphDTO);
			responseBean.setMessage("Success");
			responseBean.setData(pwaDetails);
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured while fetching data", e.getMessage());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Exception occured while fetching data" + e.getMessage());
		}
		return responseBean;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class AssetModelDetailsDTO{

		private Long assetId;
		private Integer assetTypeId;
		private String assetType;
		private Integer modelId;
		private String modelName;
		private Integer vendorId;
		private String vendorName;

	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class GraphDTO{


		private String fromDate;
		private String toDate;
		private Integer assetTypeId;
		private String assetSerialNumber;
		private Long assetId;
		private String sensorName;

	}

}