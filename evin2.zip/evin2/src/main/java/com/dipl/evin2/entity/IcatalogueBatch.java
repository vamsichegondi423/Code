/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "icatalogue_batch")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder 
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class IcatalogueBatch extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Long id;
	@Basic(optional = false)
	@Column(name = "icatalogue_id")
	private Long icatalogueId;
	@Basic(optional = false)
	@Column(name = "manufactured_date")
	@Temporal(TemporalType.DATE)
	private Date manufacturedDate;
	@Column(name = "expiry_date")
	@Temporal(TemporalType.DATE)
	private Date expiryDate;
	@Column(name = "producer_id")
	private Integer producerId;
	// @Max(value=?) @Min(value=?)//if you know range of your decimal fields
	// consider using these annotations to enforce field validation
	@Column(name = "quantity")
	private Long quantity;
	@Column(name = "batch_no")
	private String batchNo;
	@Column(name = "total_stock")
	private Long totalStock;
	@Column(name = "available_stock")
	private Long availableStock;
	@Column(name = "in_transit_stock")
	private Long inTransitStock;
	@Column(name = "product_id")
	private Integer productId;
	@Column(name = "allocated_stock")
	private Long allocatedStk;

}
