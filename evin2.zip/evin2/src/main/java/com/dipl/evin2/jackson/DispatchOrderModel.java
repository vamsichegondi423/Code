
package com.dipl.evin2.jackson;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DispatchOrderModel {

	private List<Products> products;
	private String comments;
	private Long userId;
	private Long pranthId;

	@Data
	@NoArgsConstructor
	public static class ProductBatch {
		private String batchId;
		@JsonFormat(pattern = "yyyy-MM-dd")
		private Date expiryDate;
		private Long quantity;
		@JsonFormat(pattern = "yyyy-MM-dd")
		private Date manufacturedDate;
		private Integer producerId;
	}

	@Data
	@NoArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Products {
		private Integer productId;
		private Long orderedQuantity;
		private Long allocatedQuantity;
		private Long bookingItemId;
		private List<ProductBatch> productBatches;
	}

	/*
	 * -==> Sample Payload for Manual allocation for order <==- { "products": [ {
	 * "productId": 1, "orderedQuantity": 200, "productBatches": [ { "batchId":
	 * "B123df", "expiryDate": "2021-04-30", "quantity": 50 }, { "batchId":
	 * "B123df", "expiryDate": "2021-04-30", "quantity": 150 } ],
	 * "allocatedQuantity": 0 }, { "productId": 2, "orderedQuantity": 200,
	 * "productBatches": [ { "batchId": "C123df", "expiryDate": "2021-04-30",
	 * "quantity": 100 }, { "batchId": "C123df", "expiryDate": "2021-04-30",
	 * "quantity": 100 } ], "allocatedQuantity": 0 } ], "userId": "undp2",
	 * "pranthId":23421323 }
	 * 
	 * 
	 * 
	 */
}
