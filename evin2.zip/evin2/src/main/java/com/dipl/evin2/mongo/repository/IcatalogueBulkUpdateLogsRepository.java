package com.dipl.evin2.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.dipl.evin2.entity.IcatalogueBulkUpdateLogs;


@Repository
public interface IcatalogueBulkUpdateLogsRepository extends MongoRepository<IcatalogueBulkUpdateLogs ,String> {

}
