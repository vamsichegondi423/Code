package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterTxnType;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterTxnTypeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterTxnTypeService {

	@Autowired
	private MasterTxnTypeRepository masterTxnTypeRepository;

	@Cacheable(value = "txn_type", key = "#id")
	public MasterTxnType getById(Integer id) throws CustomException {
		try {
			Optional<MasterTxnType> masterTxnTypeOptional = masterTxnTypeRepository.getById(id);
			if (masterTxnTypeOptional.isPresent()) {
				return masterTxnTypeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "txn_type", key = "#masterTxnType.id")
	public MasterTxnType save(MasterTxnType masterTxnType) throws CustomException {
		try {
			if (masterTxnType.getId() != null && masterTxnType.getId() > 0) {
				Optional<MasterTxnType> existingMasterTxnTypeRecord = masterTxnTypeRepository
						.getById(masterTxnType.getId());
				if (existingMasterTxnTypeRecord.isPresent()) {
					masterTxnType = masterTxnTypeRepository.save(masterTxnType);
				}
			} else {
				masterTxnType = masterTxnTypeRepository.save(masterTxnType);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterTxnType;
	}

	@CacheEvict(value = "txn_type", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterTxnType> existingMasterTxnTypeRecord = masterTxnTypeRepository.getById(id);
			if (existingMasterTxnTypeRecord.isPresent()) {
				masterTxnTypeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "txn_type")
	public List<MasterTxnType> getAll() {
		try {
			return masterTxnTypeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}