/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "users")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder 
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Users extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Long id;
	
	@Basic(optional = false)
	@Column(name = "user_id")
	private String userId;
	@Basic(optional = false)
	@Column(name = "salt_password")
	private String saltPassword;
	@Basic(optional = false)
	@Column(name = "ekey")
	private String ekey;
	@Basic(optional = false)
	@Column(name = "dpassword")
	private String dpassword;
	@Basic(optional = false)
	@Column(name = "f_name")
	private String fName;
	@Column(name = "l_name")
	private String lName;
	@Column(name = "sex")
	private Character sex;
	@Column(name = "dob")
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date dob;
	@Basic(optional = false)
	@Column(name = "mobile")
	private String mobile;
	@Column(name = "alt_number")
	private String altNumber;
	@Basic(optional = false)
	@Column(name = "email")
	private String email;
	@Column(name = "city")
	private String city;
	@Column(name = "address")
	private String address;
	@Column(name = "pin")
	private String pin;
	@Basic(optional = false)
	@Column(name = "language_id")
	private Integer languageId;
	@Basic(optional = false)
	@Column(name = "time_zone_id")
	private Integer timeZoneId;
	@Column(name = "mobile_brand")
	private String mobileBrand;
	@Column(name = "mobile_model")
	private String mobileModel;
	@Column(name = "imei")
	private String imei;
	@Column(name = "msp")
	private String msp;
	@Column(name = "sim")
	private String sim;
	@Column(name = "login_preferences")
	private Integer loginPreferences;
	@Column(name = "permissions")
	private String permissions;
	@Column(name = "token_expiry_indays")
	private Integer tokenExpiryIndays;
	@Basic(optional = false)
	@Column(name = "role_id")
	private Integer roleId;
	@Basic(optional = false)
	@Column(name = "country_id")
	private Integer countryId;
	@Basic(optional = false)
	@Column(name = "state_id")
	private Integer stateId;
	@Column(name = "pranth_id")
	private Long pranthId;
	@Column(name = "district_id")
	private Integer districtId;
	@Column(name = "last_logged_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastLoggedOn;
	@Column(name = "block_id")
	private Integer blockId;

}
