package com.dipl.evin2.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExportStockDeviantPayload {


		private Long storeId;
		private Long ProductId;
		private Integer abnormalityType;
		private Date expireBefore;
		private Integer state;
		private Integer district;
		private Integer country;
		private Integer block;
		private List<Integer> includeALLStoreBadge;	
		private List<Integer> includeAllProductBadge;
		private Long pranthId;
		private Long duration;
		private Long userId;
	
}
