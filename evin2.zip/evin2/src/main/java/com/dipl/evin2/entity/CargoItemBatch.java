/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "cargo_item_batch")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder 
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CargoItemBatch extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Long id;
	@Column(name = "cargo_item_id")
	private Long cargoItemId;
	@Column(name = "batch_no")
	private String batchNo;
	@Column(name = "batch_expiry_date")
	@Temporal(TemporalType.DATE)
	private Date batchExpiryDate;
	// @Max(value=?) @Min(value=?)//if you know range of your decimal fields
	// consider using these annotations to enforce field validation
	@Column(name = "ordered_stock")
	private Long orderedStock;
	@Column(name = "cargo_stock")
	private Long cargoStock;
	@Column(name = "fulfilled_stock")
	private Long fulfilledStock;
	@Column(name = "discarded_stock")
	private Long discardedStock;
	@Column(name = "discarded_reason_id")
	private Integer discardedReasonId;
	@Column(name = "producer_id")
	private Integer producerId;

}
