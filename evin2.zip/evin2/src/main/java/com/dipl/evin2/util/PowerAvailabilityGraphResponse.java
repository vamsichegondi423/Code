package com.dipl.evin2.util;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PowerAvailabilityGraphResponse {

	
	
	private List<PowerData> powerData;
	private List<PowerChartConfig> powerChartConfig;

	@Builder
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class PowerData {
		private Integer stat;
		private Integer time;
		private Date powerAvailabilityTime;
	}
	
	@Builder
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class PowerChartConfig {
		private String caption;
		private String subCaption;
		private String xAxisname;
		private String yAxisName;
		private String numberSuffix;
		private String snumbersuffix;
	}

}
