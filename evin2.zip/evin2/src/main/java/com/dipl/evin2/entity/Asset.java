/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "asset")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Asset extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Long id;
    @Column(name = "serial_number")
    private String serialNumber;
    @Column(name = "year_of_manufacture")
    private Integer yearOfManufacture;
    @Column(name = "store_id")
    private Long storeId;
    @Column(name = "mobile_number")
    private String mobileNumber;
    @Column(name = "sim_number")
    private String simNumber;
    @Column(name = "sim_vendor")
    private String simVendor;
    @Column(name = "alternate_mobile")
    private String alternateMobile;
    @Column(name = "alternate_sim_number")
    private String alternateSimNumber;
    @Column(name = "alternate_sim_vendor")
    private String alternateSimVendor;
    @Column(name = "asset_imei_number")
    private String assetImeiNumber;
    @Column(name = "firmware_version")
    private String firmwareVersion;
    @Column(name = "gsm_module_version")
    private String gsmModuleVersion;
    @Column(name = "enable_push_configuration")
    private Boolean enablePushConfiguration;
    @Column(name = "asset_model_id")
    private Long assetModelId;
    @Column(name = "status_id")
    private Integer statusId;
    @Column(name = "set_default_configuration")
    private Boolean setDefaultConfiguration;
    
    @Transient
    private List<Users> owners;
    
    @Transient
    private List<Users> maintainers;
    
    @Transient
    private AssetConfiguration assetConfiguration;
    
    @Transient
    private Store store;
    
}
