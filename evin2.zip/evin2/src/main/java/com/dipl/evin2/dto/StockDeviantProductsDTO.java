package com.dipl.evin2.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class StockDeviantProductsDTO {
	private Long txnId;
	private Long icatalogueId;
	private Long totalStock;
	private Long productId;
	private Long storeId;
	private String productName;
	private String storeName;
	private Date fromDate;
	private String duration;
	private String location;
	private Date until;
}
