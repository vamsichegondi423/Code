package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.StoreBadge;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.StoreBadgeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StoreBadgeService {

	@Autowired
	private StoreBadgeRepository storeBadgeRepository;

	public StoreBadge getById(Integer id) throws CustomException {
		try {
			Optional<StoreBadge> storeBadgeOptional = storeBadgeRepository.getById(id);
			if (storeBadgeOptional.isPresent()) {
				return storeBadgeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public StoreBadge save(StoreBadge storeBadge) throws CustomException {
		try {
			if (storeBadge.getId() != null && storeBadge.getId() > 0) {
				Optional<StoreBadge> existingStoreBadgeRecord = storeBadgeRepository.getById(storeBadge.getId());
				if (existingStoreBadgeRecord.isPresent()) {
					return storeBadgeRepository.save(storeBadge);
				}
			} else {
				storeBadge = storeBadgeRepository.save(storeBadge);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return storeBadge;
	}

	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<StoreBadge> existingStoreBadgeRecord = storeBadgeRepository.getById(id);
			if (existingStoreBadgeRecord.isPresent()) {
				storeBadgeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<StoreBadge> getAll() {
		try {
			return storeBadgeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}