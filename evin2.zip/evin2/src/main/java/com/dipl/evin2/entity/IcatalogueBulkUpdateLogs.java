package com.dipl.evin2.entity;

import java.util.Date;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Document(collection = "icatalogue_bulk_update_logs")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IcatalogueBulkUpdateLogs {

	@Id
	private String id;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "IST")
	private Date createdOn;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "IST")
	private Date updatedOn;
	private Long userId;
	private Long pranthId;
	private Long storeId;
	private Integer productId;
	private String productName;
	private String storeName;
	private String maxStock;
	private String minStock;

}