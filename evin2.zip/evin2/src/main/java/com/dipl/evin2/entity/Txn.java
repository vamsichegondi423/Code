/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "txn")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Txn extends BaseEntity implements Serializable, Cloneable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Long id;
	@Column(name = "txn_type_id")
	private Integer txnTypeId;
	// @Max(value=?) @Min(value=?)//if you know range of your decimal fields
	// consider using these annotations to enforce field validation
	@Column(name = "opening_stock")
	private Long openingStock;
	@Column(name = "closing_stock")
	private Long closingStock;
	@Column(name = "stock")
	private Long stock;
	// Issuing Store in Booking
	@Column(name = "source_store_id")
	private Long sourceStoreId;
	@Column(name = "product_id")
	private Integer productId;
	@Column(name = "pranth_id")
	private Long pranthId;
	@Column(name = "batch_no")
	private String batchNo;
	// Receiving store in booking
	@Column(name = "dest_store_id")
	private Long destStoreId;
	@Column(name = "initial_txn_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date initialTxnDate;
	@Column(name = "reason_id")
	private Integer reasonId;
	@Column(name = "source_type")
	private String sourceType;
	@Column(name = "icatalogue_id")
	private Long icatalogueId;
	@Column(name = "opening_stock_batch")
	private Long openingStockBatch;
	@Column(name = "closing_stock_batch")
	private Long closingStockBatch;
	@Column(name = "cargo_id")
	private Long cargoId;
	@Column(name = "status_id")
	private Integer statusId;
	@Column(name = "tracking_object_type_id")
	private Integer trackingObjectTypeId;
	@Column(name = "tracking_no")
	private String trackingNo;
	@Column(name = "producer_id")
	private Integer producerId;
	

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}
