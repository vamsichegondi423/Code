package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.CargoItem;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.CargoItemRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CargoItemService {

	@Autowired
	private CargoItemRepository cargoItemRepository;

	public CargoItem getById(Long id) throws CustomException {
		try {
			Optional<CargoItem> cargoItemOptional = cargoItemRepository.getById(id);
			if (cargoItemOptional.isPresent()) {
				return cargoItemOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public CargoItem save(CargoItem cargoItem) throws CustomException {
		try {
			if (cargoItem.getId() != null && cargoItem.getId() > 0) {
				Optional<CargoItem> existingCargoItemRecord = cargoItemRepository.getById(cargoItem.getId());
				if (existingCargoItemRecord.isPresent()) {
					return cargoItemRepository.save(cargoItem);
				}
			} else {
				cargoItem = cargoItemRepository.save(cargoItem);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return cargoItem;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<CargoItem> existingCargoItemRecord = cargoItemRepository.getById(id);
			if (existingCargoItemRecord.isPresent()) {
				cargoItemRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<CargoItem> getAll() {
		try {
			return cargoItemRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}