package com.dipl.evin2.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;

public class EvinException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
	private BindingResult bindingResult;

	public EvinException() {

	}

	public EvinException(String message, Throwable cause) {
		super(message, cause);
	}

	public EvinException(HttpStatus httpStatus, BindingResult bindingResult) {
		if (httpStatus != null) {
			this.httpStatus = httpStatus;
		}
		this.bindingResult = bindingResult;
	}

	public EvinException(String message, HttpStatus code) {
		super(message);
		this.httpStatus = code;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public BindingResult getBindingResult() {
		return bindingResult;
	}

}
