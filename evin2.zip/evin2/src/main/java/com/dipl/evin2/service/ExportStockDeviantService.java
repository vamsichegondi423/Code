package com.dipl.evin2.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dipl.evin2.controller.IcatalogueController.IcatalogueDetails;
//import com.dipl.evin2.entity.ExportExcelReportLogs;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.model.ExportStockDeviantModel;
import com.dipl.evin2.model.ExportStockDeviantPayload;
import com.dipl.evin2.model.FileReportResponse;
//import com.dipl.evin2.mongo.repository.ExportExcelReportLogsRepository;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.JdbcTemplateHelper;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ExportStockDeviantService {

	@Autowired
	private SendEmailService sendEmailService;
	@Autowired
	private UploadFileService uploadFileService;
	@Autowired
	private JdbcTemplateHelper jdbcTemplateHelper;
	@Autowired
	private PranthHierarchyService pranthHierarchyService;
//	@Autowired
//	private KafkaProducer kafkaProducer;
	@Autowired
	@Lazy
	 private ExportExcelAsyncService exportExcelAsyncService;
	@Autowired
	private ObjectMapper objectMapper;
//	@Autowired
	//private ExportExcelReportLogsRepository exportExcelReportLogsRepository;

	public ResponseBean getStockDeviantService(ExportStockDeviantPayload detailsPayload, Long pranthId, Long userId,
			String userName, String email, List<Integer> materialTagsToHide, List<Long> totalStoreIds)
			throws CustomException, IOException {
		ResponseBean responsebean = new ResponseBean();
		try {
			ExportStockDeviantModel exportStockDeviantModel = new ExportStockDeviantModel();
//			this.getStockDeviantDataToExport(detailsPayload, pranthId, userId, userName, email, materialTagsToHide,
//					totalStoreIds);
			exportExcelAsyncService.getStockDeviantDataToExport(detailsPayload, pranthId, userId, userName, email, materialTagsToHide,
					totalStoreIds);
//			this.setStockDeviantExportData(exportStockDeviantModel, detailsPayload, pranthId, userId, userName, email,
//					materialTagsToHide, totalStoreIds);
//			kafkaProducer.sendStockDeviantExportToProducer(exportStockDeviantModel);
			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
					+ email
					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
			responsebean.setReturnCode(1);
			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting stock deviant report : " + e.getStackTrace());
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock deviant report ");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		return responsebean;
	}
//	void setStockDeviantExportData(ExportStockDeviantModel exportStockDeviantModel,
//			ExportStockDeviantPayload detailsPayload, Long pranthId, Long userId, String userName, String email,
//			List<Integer> materialTagsToHide, List<Long> totalStoreIds) {
//		exportStockDeviantModel.setExportStockDeviantPayload(detailsPayload);
//		exportStockDeviantModel.setPranthId(pranthId);
//		exportStockDeviantModel.setUserId(userId);
//		exportStockDeviantModel.setUserName(userName);
//		exportStockDeviantModel.setEmail(email);
//		exportStockDeviantModel.setMaterialTagsToHide(materialTagsToHide);
//		exportStockDeviantModel.setTotalStoreIds(totalStoreIds);
//	}
	public void getStockDeviantDataToExport(ExportStockDeviantPayload detailsPayload,Long pranthId,Long userId,
			String userName,String email,List<Integer> materialTagsToHide,List<Long> totalStoreIds)
			throws CustomException, IOException {

		ResponseBean responsebean = new ResponseBean();
		List<IcatalogueDetails> stockdeviant = null;
		
		Object fileData;
		String url = null;
		Workbook workbook =  null;
		FileOutputStream outputStream = null;
//		ExportExcelReportLogs exportExcelReportLogs = new ExportExcelReportLogs();
		try {
			StringBuilder builder = new StringBuilder();
			Set<Long> consolidatePranthIds = pranthHierarchyService.getConsolidatedPranthIds(detailsPayload.getPranthId());
			stockdeviant = getStockDeviantData(detailsPayload, builder, consolidatePranthIds, materialTagsToHide, totalStoreIds);
			String payloadJSON = objectMapper.writeValueAsString(detailsPayload);
//			exportExcelReportLogs.setInput(payloadJSON);
//			exportExcelReportLogs.setExportInitiateTime(new Date());
//			exportExcelReportLogs.setPranthId(pranthId);
//			exportExcelReportLogs.setUserName(userName);
//			exportExcelReportLogsRepository.save(exportExcelReportLogs);
//			if(stockdeviant != null && !stockdeviant.isEmpty()) {
//				exportExcelReportLogs.setFetchData("Data fetched from Database ");
//			}else {
//				exportExcelReportLogs.setFetchData("Data not fetched from Database ");
//			}
//			exportExcelReportLogsRepository.save(exportExcelReportLogs);
			//creating workbook
			workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0, cellIndex3 = 0;
			// Creating row
			Row row = sheet.createRow(0);

			row.createCell(cellIndex++).setCellValue("Title");
			row.createCell(cellIndex++).setCellValue("" + Constants.stock_deviannt + "");
			Row row1 = sheet.createRow(1);
			row1.createCell(cellIndex1++).setCellValue("Generated on");
			row1.createCell(cellIndex1++).setCellValue("" + uploadFileService.dateWithHoursMinutes());

			Row row3 = sheet.createRow(3);

			row3.createCell(cellIndex3++).setCellValue("ProductName");
			row3.createCell(cellIndex3++).setCellValue("BatchManagement");
			row3.createCell(cellIndex3++).setCellValue("Country");
			row3.createCell(cellIndex3++).setCellValue("State");
			row3.createCell(cellIndex3++).setCellValue("District");
			row3.createCell(cellIndex3++).setCellValue("Block");
			row3.createCell(cellIndex3++).setCellValue("City");
			row3.createCell(cellIndex3++).setCellValue("StorageBadge");
			row3.createCell(cellIndex3++).setCellValue("StoreName");
			row3.createCell(cellIndex3++).setCellValue("TotalStock");
			row3.createCell(cellIndex3++).setCellValue("MinStock");
			row3.createCell(cellIndex3++).setCellValue("MaxStock");
			row3.createCell(cellIndex3++).setCellValue("Duration");
			row3.createCell(cellIndex3++).setCellValue("Since");

			for (int i = 0; i < stockdeviant.size(); i++) {
				Row dataRow = sheet.createRow(i + 4);
				int rowIndex1 = 0;

				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getProductName() == null ? ""
						: stockdeviant.get(i).getProductName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getBatchManagement() == null ? ""
						: stockdeviant.get(i).getBatchManagement() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getCountry() == null ? ""
						: stockdeviant.get(i).getCountry() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getState() == null ? ""
						: stockdeviant.get(i).getState()+ "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getDistrict() == null ? ""
						: stockdeviant.get(i).getDistrict() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getBlock() == null ? ""
						: stockdeviant.get(i).getBlock() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						stockdeviant.get(i).getCity() == null ? "" : stockdeviant.get(i).getCity() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getStorageBadge() == null ? ""
						: stockdeviant.get(i).getStorageBadge() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getStoreName() == null ? ""
						: stockdeviant.get(i).getStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(stockdeviant.get(i).getCurrentStock() == null ? 0
						: stockdeviant.get(i).getCurrentStock());
				log.info(""+stockdeviant.get(i).getCurrentStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						stockdeviant.get(i).getInvMax() == null ? 0 : stockdeviant.get(i).getInvMax());
				dataRow.createCell(rowIndex1++).setCellValue(
						stockdeviant.get(i).getInvMin() == null ? 0 : stockdeviant.get(i).getInvMin());
				dataRow.createCell(rowIndex1++).setCellValue(
						stockdeviant.get(i).getDuration() == null ? "" : stockdeviant.get(i).getDuration() + "");
				
				Cell cell = dataRow.createCell(rowIndex1++);
				cell.setCellValue(
						stockdeviant.get(i).getUntil() == null ? null : stockdeviant.get(i).getUntil());
				cell.setCellStyle(dateCellStyle);			

			}

			File tempFile = null;
			tempFile = File.createTempFile("StockDeviantReport", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
		    workbook.write(outputStream);
//		    exportExcelReportLogs.setExportExcel("Writing data to excel file done successfully");
//		    exportExcelReportLogsRepository.save(exportExcelReportLogs);
			HttpResponse<String> response = uploadFileService.uploadFile(url,userName, tempFile, "StockDeviant");
			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();
			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			tempFile.delete();
			HashMap<String, Object> emailbody = new HashMap<>();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";

			emailbody = sendEmailService.getStockDeviantEmail(link, userName, email);

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, email, userName,
					fileDownloadUrl, fileType, fileName, fileSystemPath);
//			log.info("exporting stock deviant report done successfully");
//			exportExcelReportLogs.setExportSuccess("exporting stock deviant report done successfully");
//			exportExcelReportLogsRepository.save(exportExcelReportLogs);
//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ email
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting stock deviant report : " + e.getStackTrace());
//			exportExcelReportLogs.setExportSuccess("Exception occured while exporting stock deviant report");
//			exportExcelReportLogsRepository.save(exportExcelReportLogs);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting stock deviant report ");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		finally {
			
			 outputStream.close();
			 workbook.close();
		}
//		return responsebean;
	}
	
	public List<IcatalogueDetails> getStockDeviantData(ExportStockDeviantPayload detailsPayload, StringBuilder builder,
			Set<Long> consolidatePranthIds, List<Integer> materialTagsToHide, List<Long> offsetKioskIds){
		List<IcatalogueDetails> stockDeviantList = null;

		int i = 0;
		StringBuilder consolidatedDomainsBuilder = new StringBuilder();
		consolidatedDomainsBuilder.append(" (");
		for (Long e : consolidatePranthIds) {
			consolidatedDomainsBuilder.append(e.toString());
			if (i < consolidatePranthIds.size() - 1) {
				consolidatedDomainsBuilder.append(" ,");
			}
			i++;
		}
		consolidatedDomainsBuilder.append(" )");
		builder.append(
				" select distinct a.pranth_id,a.store_id,s.store_name,a.product_id,p.product_name,s.city,\n" + 
				"s.country_name as country,s.state_name as state,s.district_name as district,s.block_name\n" + 
				",s.address,s.store_badge as storageBadge,s.store_badge_id,p.product_badge_id,  p.product_badge as productBage,a.min_stock as invMin,a.max_stock as invMax,a.total_stock as current_stock,  a.expiry_date, case when p.is_batch_enabled=true then 'Enabled' else 'Not Enabled' end batchManagement, a.updated_on as until,current_timestamp-a.updated_on as duration from  (select i.pranth_id,i.store_id,i.product_id, i.min_stock,i.max_stock,i.total_stock,i.created_on as since,expiry_date,i.updated_on  from icatalogue i left join (select icatalogue_id, product_id, max(expiry_date) as expiry_date  \n" + 
				"   from icatalogue_batch where is_deleted=false group by 1,2)icb   \n" + 
				"   on icb.icatalogue_id = i.id and i.product_id=icb.product_id \n" + 
				"where (total_stock = 0 or (total_stock <min_stock and total_stock!=0) or total_stock > max_stock) ");
		if (detailsPayload.getAbnormalityType()  != null&& detailsPayload.getAbnormalityType() .equals(200)) {
			builder.append(" and i.total_stock=0)a ");
		} else if (detailsPayload.getAbnormalityType()  != null && detailsPayload.getAbnormalityType().equals(201)) {
			builder.append(" and (i.total_stock < min_stock and i.total_stock<>0))a ");
		} else if (detailsPayload.getAbnormalityType() != null && detailsPayload.getAbnormalityType().equals(202)) {
			builder.append(" and i.total_stock > max_stock)a ");
		} else if(detailsPayload.getAbnormalityType() == null ){
			builder.append(
					" and i.total_stock=0 or (i.total_stock < min_stock and i.total_stock<>0)  or  i.total_stock > max_stock)a ");
		}		
		builder.append(
				" join (select s.id,s.name as store_name, s.pranth_id, c.name as country_name,st.name as state_name, " + 
				" d.name as district_name,bl.name as block_name,city,address " + 
				"   ,sb.badge_id as store_badge_id,  string_agg(distinct bd.name,',') as store_badge " + 
				"   from store s " + 
				"   left join store_badge sb on s.id=sb.store_id " + 
				"   left join badge bd on bd.id=sb.badge_id and bd.badge_type_id=2 " + 
				"	left join master_district d on d.id=s.district_id " + 
				"   left join master_state st on st.id=s.state_id  " + 
				"   left join master_country c on c.id=s.country_id " + 
				"   left join master_block bl on s.block_id=bl.id  " + 
				"   group by 1,2,3,4,5,6,7,8,9,10)s on s.id = a.store_id " + 
				"   inner join (select p.id,p.name as product_name, is_batch_enabled,pb.badge_id as product_badge_id,string_agg(distinct bd.name,',') as product_badge " + 
				"   from product p  " + 
				"   left join product_badge pb on pb.product_id=p.id " + 
				"   left join badge bd on bd.id=pb.badge_id and bd.badge_type_id=1 " + 
				"   group by p.id,pb.badge_id)p on p.id=a.product_id where s.pranth_id in " + consolidatedDomainsBuilder.toString());
		addFilterConditionsForAbnormalStock(detailsPayload, builder, materialTagsToHide, offsetKioskIds);
		stockDeviantList = jdbcTemplateHelper.getResults(builder.toString(), IcatalogueDetails.class);

		return stockDeviantList;	
		}
	
	private void addFilterConditionsForAbnormalStock(ExportStockDeviantPayload detailsPayload, StringBuilder builder, List<Integer> materialTagsToHide, List<Long> offsetKioskIds) {
		if (detailsPayload.getStoreId() != null) {
			builder.append("  and a.store_id = " + detailsPayload.getStoreId());
		}
		if (offsetKioskIds != null && !offsetKioskIds.isEmpty()) {
			builder.append(" and a.store_id in ( " + StringUtils.join(offsetKioskIds, " ,") + "  ) ");
		}
		if (detailsPayload.getProductId() != null) {
			builder.append("  and a.product_id = " + detailsPayload.getProductId());
		}
		if (detailsPayload.getExpireBefore() != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat(" yyyy-MM-dd");
			builder.append("  and icb.expiry_date <= '" + dateFormat.format(detailsPayload.getExpireBefore()) + " '");
		}
		if (detailsPayload.getState() != null) {
			builder.append("  and st.name = '" + detailsPayload.getState() + " '");
		}
		if (detailsPayload.getDistrict() != null) {
			builder.append("  and d.name = '" + detailsPayload.getDistrict() + " '");
		}
		if (detailsPayload.getCountry() != null) {
			builder.append("  and c.name = '" + detailsPayload.getCountry() + " '");
		}
		 if (detailsPayload.getIncludeALLStoreBadge() != null  && !detailsPayload.getIncludeALLStoreBadge().isEmpty()) {
//			StringBuilder paramBuilder = new StringBuilder();
//			StringBuilder storeBadges = new StringBuilder();
			builder.append(" and s.store_badge_id in ("+ StringUtils.join(detailsPayload.getIncludeALLStoreBadge(), ",") + ")");

//			storeBadges.append(" (");
//			List<Integer> materialBadgeList = detailsPayload.getIncludeALLStoreBadge();
//			int j = 0;
//
//			for (Integer e : materialBadgeList) {
//				storeBadges.append(e.toString());
//				if (j < materialBadgeList.size() - 1) {
//					storeBadges.append(" ,");
//				}
//				j++;
//			}
//			storeBadges.append(" )");
//			paramBuilder.append("   s.store_badge_id in "+(storeBadges));
//			builder.append(paramBuilder);

		}
		 if (detailsPayload.getIncludeAllProductBadge() != null && !detailsPayload.getIncludeAllProductBadge().isEmpty()) {
			builder.append(" and p.product_badge_id in ("+ StringUtils.join(detailsPayload.getIncludeAllProductBadge(), ",") + ")");
		}
		if (materialTagsToHide != null && !materialTagsToHide.isEmpty()) {
			builder.append("  and p.product_badge_id not in (" + StringUtils.join(materialTagsToHide, ",")+")");
		}
		
			builder.append ("order by store_name ");
		
	}
}