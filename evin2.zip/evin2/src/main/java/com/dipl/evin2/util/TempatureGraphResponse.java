package com.dipl.evin2.util;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TempatureGraphResponse {

	private List<RecentActivity> recentActivity;

	
	private List<TempatureData> data;
	private List<ChartConfig> chartConfig;
	private List<TrendLine> trendLine;

	@Builder
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class TempatureData {
		private Date label;
		private Double value;
	}
	
	@Builder
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ChartConfig {
		private String caption;
		private String subCaption;
		private String xAxisname;
		private String yAxisName;
		private String numberSuffix;
		private String snumbersuffix;
	}

	@Builder
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class TrendLine {
		private Double startValue;
		private Double displayValue;
		private String displayName;
	}

	@Builder
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class RecentActivity {

		@JsonProperty("sensor_name")
		public String sensorName;
		@JsonProperty("monitoring_point")
		public String monitoringPoint;
		@JsonProperty("alarm_message")
		public String alarmMessage;
		@JsonProperty("time")
		public String time;

	}
}
