package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.dto.BookingCargoDTO;
import com.dipl.evin2.dto.CargoBatchDTO;
import com.dipl.evin2.dto.CargoDTO;
import com.dipl.evin2.dto.CargoProductsDTO;
import com.dipl.evin2.entity.Bookings;
import com.dipl.evin2.entity.Cargo;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.exceptions.CustomRollBackException;
import com.dipl.evin2.model.FulfilCargoModel;
import com.dipl.evin2.service.BookingsService;
import com.dipl.evin2.service.CargoService;
import com.dipl.evin2.service.CargoShipmentInvoiceService;
import com.dipl.evin2.service.StoreService;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/cargo")
public class CargoController {

	@Autowired
	private CargoService cargoService;
	@Autowired
	private BookingsService bookingService;
	@Autowired
	private CargoShipmentInvoiceService cargoShipmentInvoiceService;
	@Autowired
	private StoreService storeService;

	@ApiOperation("Use this api for saving or updating Cargo. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/create")
	public ResponseBean save(@RequestBody CargoModel cargoPayload, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (cargoPayload.getBookingId() > 0 && cargoPayload.getBookingId() != null) {
				Bookings booking = bookingService.getById(cargoPayload.getBookingId());
				if (booking.getStatusId().equals(4)) {
					if (cargoPayload.getCargoId() != null && cargoPayload.getCargoId() > 0) {
						Cargo existingCargo = cargoService.getById(cargoPayload.getCargoId());
						if (existingCargo != null) {
							responseBean = cargoService.createCargo(cargoPayload);
							log.info("Record updated successfully");
							responseBean.setMessage("Record updated successfully");

						} else {
							log.info("No record found");
							responseBean.setMessage("No record found");
						}
					} else {
						responseBean = cargoService.createCargo(cargoPayload);
					}
				} else {
					log.info("Please allocate fully");
					responseBean.setMessage("Please allocate fully");
					responseBean.setData(null);
				}
			} else {
				log.info("Invalid PayLoad");
				responseBean.setMessage("Invalid PayLoad");
				responseBean.setData(null);
			}
		} catch (CustomRollBackException e) {
			log.error("Requested Quantity is greater than avilable Quantity " + e.getCause());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.BAD_GATEWAY);
			responseBean.setData(null);
			responseBean.setMessage("Requested Quantity is greater than avilable Quantity");
		} catch (Exception e) {
			log.error("Exception occured while creating Cargo", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching Cargo record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Cargo cargo = cargoService.getById(id);
			if (cargo != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(cargo);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Please contact your admin");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting Cargo record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = cargoService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Please contact your admin");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all Cargo records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Cargo> cargoRecords = cargoService.getAll();
			if (!cargoRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(cargoRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching cargo by booking id. Provide booking id as request param.")
	@GetMapping(value = "/v1/get-cargo-by-booking-id", produces = "application/json")
	public ResponseBean getCargoByBookingId(@RequestParam(value = "bookingId") Long bookingId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<BookingCargoDTO> orderMaterials = cargoService.getCargoByBookingId(bookingId);
			responseBean.setStatus(HttpStatus.OK);
			if (orderMaterials != null && !orderMaterials.isEmpty()) {
				log.info(" Cargo of Booking fetched successfully");
				responseBean.setMessage("Cargo of Booking fetched successfully");
				responseBean.setData(orderMaterials);
			} else {
				log.info("Cargo of Booking not found");
				responseBean.setMessage("Cargo of Booking not found");
			}
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured in fetching Cargo of Booking", e.getMessage());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all Shipment records. No params required.")
	@PostMapping(value = "/v1/get-all-cargos", produces = "application/json")
	public ResponseBean getAllShipmentByDomainId(@RequestBody CargoFilterModel shipmentPayload, Pageable pageable,
			@RequestParam(name = "pranthId") Long pranthId, @RequestParam(name = "userId") Long userId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Long> totalstoreIds = storeService.getToatalStoreIds(pranthId, userId);
			ShipmentByFilterDetails shipmentRecords = cargoService.getAllShipmentsByDomainId(shipmentPayload, pageable,
					totalstoreIds);
			if (shipmentRecords != null && !shipmentRecords.getShipmenByFiltertDTO().isEmpty()) {
				responseBean.setMessage("Shipment Records fetched successfully");
				responseBean.setData(shipmentRecords);
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
			} else {
				responseBean.setMessage("No Shipments found.");
				responseBean.setReturnCode(0);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching Cargo Record: {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong " );
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching cargo details by cargo id. Provide cargo id as request param.")
	@GetMapping(value = "/v1/get-cargo-details-by-cargo-id", produces = "application/json")
	public ResponseBean getCargoDetailsByCargoId(@RequestParam(value = "cargoId") Long cargoId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			CargoDTO shipmentDTO = cargoService.getCargoDetailsByCargoId(cargoId);
			responseBean.setStatus(HttpStatus.OK);
			if (shipmentDTO != null) {
				log.error("Cargo details fetched successfully");
				responseBean.setMessage("Cargo details fetched successfully");
				responseBean.setData(shipmentDTO);
			} else {
				log.error("Cargo details not fetched ");
				responseBean.setMessage("Cargo details not fetched ");
			}
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured in fetching Cargo details", e);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching products by cargo id. Provide cargo id as request param.")
	@GetMapping(value = "/v1/get-products-by-cargo-id", produces = "application/json")
	public ResponseBean getProductsByCargoId(@RequestParam(value = "cargoId") Long cargoId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<CargoProductsDTO> shipmentMaterialList = cargoService.getProductsByCargoId(cargoId);
			responseBean.setStatus(HttpStatus.OK);
			if (shipmentMaterialList != null && !shipmentMaterialList.isEmpty()) {
				log.error("products of Cargo fetched successfully");
				responseBean.setMessage("materials of Cargo fetched successfully");
				responseBean.setData(shipmentMaterialList);
			} else {
				log.error("products of Cargo not fetched ");
				responseBean.setMessage("products of Cargo not fetched ");
				responseBean.setData(shipmentMaterialList);
			}
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured in fetching products of cargo", e);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching batch details by shipment id. Provide shipment id as request param.")
	@GetMapping(value = "/v1/get-batch-details-by-cargo-id", produces = "application/json")
	public ResponseBean getBatchDetailsByShipmentId(@RequestParam(value = "cargoId") Long cargoId,
			@RequestParam(value = "productId") Long productId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<CargoBatchDTO> shipmentBatchList = cargoService.getBatchDetailsByShipmentId(cargoId, productId);
			responseBean.setStatus(HttpStatus.OK);
			if (shipmentBatchList != null && !shipmentBatchList.isEmpty()) {
				log.error("batch details of cargo fetched successfully");
				responseBean.setMessage("batch details of cargo fetched successfully");
				responseBean.setData(shipmentBatchList);
			} else {
				log.error("batch details of cargo not fetched ");
				responseBean.setMessage("batch details of cargo not fetched ");
			}
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured in fetching batch details of cargo", e);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("USe this API to fulfil Shipment or Cargo")
	@PostMapping(value = "/v1/fulfil-booking")
	public ResponseBean fulfilCargo(@RequestBody FulfilCargoModel fulfillModel) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (fulfillModel.getBookingId() != null) {
				Bookings bookings;
				bookings = bookingService.getById(fulfillModel.getBookingId());
				if (bookings.getStatusId().equals(7)) {
					responseBean = cargoService.createFulfilment(fulfillModel);
				} else {
					responseBean.setData(responseBean);
					responseBean.setMessage("shipment was not done for this produts");
					responseBean.setReturnCode(HttpStatus.OK);
				}
			} else {
				responseBean.setData(responseBean);
				responseBean.setMessage("Invalid Payload");
				responseBean.setReturnCode(0);
			}
		} catch (CustomException e) {
			log.error("Invntry not found for receving store while booking fullfillment ", e.getCause());
			responseBean.setStatus(HttpStatus.BAD_GATEWAY);
			responseBean
					.setMessage("Invntry not found for receving store while booking fullfillment " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			log.error("Exception occured in while fulfilling the Indent ", e.getCause());
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong ");
			e.printStackTrace();
		}
		return responseBean;
	}

	@PostMapping("/v1/generate-shipment-invoice")
	public ResponseBean generateBookingInvoice(@RequestParam(name = "shipping-id") String shippingId) {
		return cargoShipmentInvoiceService.generateShipmentInvoice(shippingId);
	}

	@Data
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ShipmentByFilterDetails {
		private List<ShipmenByFiltertDTO> shipmenByFiltertDTO;
		private Long totalRecordsCount;
	}

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ShipmenByFiltertDTO {
		private Long pranthId;
		private Long cargoId;
		private String cargoNo;
		private Long bookingId;
		private Long noOfItems;
		private Long receivingStoreId;
		private String receivingStoreName;
		private String receivingStoreLocation;
		private Long issuingStoreId;
		private String issuingStoreName;
		private String issuingStoreLocation;
		private String status;
		private Date createdOn;
		private String createdName;
		private String userId;
		private Date expectedDateArrvl;
		private String transporter;
		private Integer sourceType;

	}

	@Data
	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class CargoFilterModel {
		private Long pranthId;
		private Long receivingStoreId;
		private Long issuingStoreId;
		private String status;
		private String transporter;
		private String tracking;
		private Date fromDate;
		private Date toDate;
		private Date fromExpectedArrvlDate;
		private Date toExpectedArrvlDate;
	}
	
	@Data
	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ShipmentExportModel {
		private CargoFilterModel cargoFilterModel;
		private Long pranthId;
		private Long userId; 
		private String userName;
		private String email;
		private List<Long> offsetStoreIds;
	}

	@Data
	@Builder
	@AllArgsConstructor
	@NoArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class CargoModel {

		private String cargoNo;
		private Long cargoId;
		private Long createdBy;
		private Date arrivalDate;
		private Long issuingStoreId; // issuingStore
		private Long bookingId;
		private Long pranthId;
		private String orderReferenceNo;
		private String carrierName;
		private String driverPhone;
		private String reason;
		private Long updatedBy;
//		private Long carrierId;
		private String vehicleInfo;
		private Boolean customerDelivery;
		private String carrierAddress;
		private String carrierTypeId;
		private String sourceType;
		private String packageNo;
		private String packageType;
		private Long packageQuantity;
		private Double packageCost;
		private Double wtkg;
		private Double length;
		private Double breadth;
		private Double height;
		private String remarks;
		private Integer statusId;

	}

}