package com.dipl.evin2.service;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.dipl.evin2.controller.IcatalogueController.IcatalogueChartDetails;
import com.dipl.evin2.controller.IcatalogueController.IcatalogueDetails;
import com.dipl.evin2.controller.IcatalogueController.IcatalogueDetailsPayload;
import com.dipl.evin2.controller.IcatalogueController.IcatalogueTotalDetails;
import com.dipl.evin2.controller.IcatalogueController.ProductsDetails;
import com.dipl.evin2.controller.IcatalogueController.StockDeviantPaylod;
import com.dipl.evin2.controller.IcatalogueController.StockViewProductsDTO;
import com.dipl.evin2.dto.AllocatedStockDTO;
import com.dipl.evin2.dto.InTransitStockDTO;
import com.dipl.evin2.dto.StockDeviantProductsDTO;
import com.dipl.evin2.entity.Icatalogue;
import com.dipl.evin2.entity.IcatalogueBulkUpdateLogs;
import com.dipl.evin2.entity.MasterBlock;
import com.dipl.evin2.entity.MasterDistrict;
import com.dipl.evin2.entity.MasterState;
import com.dipl.evin2.entity.Product;
import com.dipl.evin2.entity.Store;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.mongo.repository.IcatalogueBulkUpdateLogsRepository;
import com.dipl.evin2.repository.IcatalogueRepository;
import com.dipl.evin2.repository.MasterBlockRepository;
import com.dipl.evin2.repository.MasterDistrictRepository;
import com.dipl.evin2.repository.MasterStateRepository;
import com.dipl.evin2.repository.ProductRepository;
import com.dipl.evin2.repository.StoreRepository;
import com.dipl.evin2.util.IcatalogueModel;
import com.dipl.evin2.util.ImportFileData;
import com.dipl.evin2.util.ResponseBean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class IcatalogueService {

	@Autowired
	private IcatalogueRepository icatalogueRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private MasterStateRepository masterStateRepository;

	@Autowired
	private MasterDistrictRepository masterDistrictRepository;

	@Autowired
	private MasterBlockRepository masterBlockRepository;

	@Autowired
	private StoreRepository storeRepository;

	@Autowired
	private ImportFileData importFileData;

	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@Autowired
	private IcatalogueBulkUpdateLogsRepository icatalogueBulkUpdateLogsRepository;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public Icatalogue getById(Long id) throws CustomException {
		try {
			Optional<Icatalogue> icatalogueOptional = icatalogueRepository.getById(id);
			if (icatalogueOptional.isPresent()) {
				return icatalogueOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error(" Exception occured : ", e);
		}
		return null;
	}

	public Icatalogue save(Icatalogue icatalogue) throws CustomException {
		try {
			if (icatalogue.getId() != null && icatalogue.getId() > 0) {
				Optional<Icatalogue> existingIcatalogueRecord = icatalogueRepository.getById(icatalogue.getId());
				if (existingIcatalogueRecord.isPresent()) {
					return icatalogueRepository.save(icatalogue);
				}
			} else {
				icatalogue = icatalogueRepository.save(icatalogue);
			}
		} catch (Exception e) {
			log.error(" Exception occured : ", e);
		}
		return icatalogue;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<Icatalogue> existingIcatalogueRecord = icatalogueRepository.getById(id);
			if (existingIcatalogueRecord.isPresent()) {
				icatalogueRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error(" Exception occured : ", e);
		}
		return null;
	}

	public List<Icatalogue> getAll() {
		try {
			return icatalogueRepository.findAll();
		} catch (Exception e) {
			log.error(" Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public List<IcatalogueDetails> getAbnormalStrockDetails(IcatalogueDetailsPayload detailsPayload, Pageable pageable,
			List<Integer> materialTagsToHide, List<Long> totalKioskIds) throws CustomException {
		StringBuilder builder = new StringBuilder();
		Set<Long> consolidatePranthIds = pranthHierarchyService.getConsolidatedPranthIds(detailsPayload.getPranthId());
		buildQueryForAbnormalStocksDetails(detailsPayload, builder, consolidatePranthIds, pageable, materialTagsToHide,
				totalKioskIds);
		log.info(builder.toString());
		return jdbcTemplate.query(builder.toString(), new RowMapper<IcatalogueDetails>() {
			@Override
			public IcatalogueDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				IcatalogueDetails icatalogueDetails = IcatalogueDetails.builder().city(rs.getString("city"))
						.country(rs.getString("country_name")).pranthId(rs.getLong("pranth_id"))
						.storageBadge(rs.getString("store_badge")).productBage(rs.getString("product_badge"))
						.district(rs.getString("district_name")).currentStock(rs.getLong("total_stock"))
						.invMax(rs.getLong("max_stock")).invMin(rs.getLong("min_stock"))
						.block(rs.getString("block_name")).street(rs.getString("address"))
						.storeId(rs.getLong("store_id")).storeName(rs.getString("store_name"))
						.productId(rs.getLong("product_id")).productName(rs.getString("product_name"))
						.state(rs.getString("state_name")).until(rs.getDate("until")).duration(rs.getString("duration"))
						.batchManagement(rs.getString("batch_enabled")).build();
				String[] daysandmin = null;
				String duration = rs.getString("duration");
				if (duration != null) {
					if (duration.contains("days")) {
						daysandmin = duration.split(" ");
						icatalogueDetails.setDuration(daysandmin[0] + "  " + daysandmin[1] + " ago");
					} else {
						daysandmin = duration.split(":");
						if (!daysandmin[0].contentEquals("00")) {
							icatalogueDetails.setDuration(daysandmin[0] + " hours ago");
						} else if (!daysandmin[1].contentEquals("00")) {
							icatalogueDetails.setDuration(daysandmin[1] + " minutes ago");
						} else if (!daysandmin[2].contentEquals("00")) {
							icatalogueDetails.setDuration(" 1 minute ago");
						}
					}

				} else {
					icatalogueDetails.setDuration(duration);
				}

				return icatalogueDetails;
			}
		});

	}

	public List<Map<String, Object>> getStockDeviantDataByQuery(IcatalogueDetailsPayload detailsPayload,
			StringBuilder builder, Set<Long> consolidatePranthIds, Pageable pageable, List<Integer> materialTagsToHide,
			List<Long> offsetKioskIds) {
		List<Map<String, Object>> stockDeviantList = null;

		int i = 0;
		StringBuilder consolidatedDomainsBuilder = new StringBuilder();
		consolidatedDomainsBuilder.append(" (");
		for (Long e : consolidatePranthIds) {
			consolidatedDomainsBuilder.append(e.toString());
			if (i < consolidatePranthIds.size() - 1) {
				consolidatedDomainsBuilder.append(" ,");
			}
			i++;
		}
		consolidatedDomainsBuilder.append(" )");
		builder.append(
				"select a.pranth_id,a.store_id,s.store_name,a.product_id,p.product_name,s.city,s.country_name,s.state_name,s.district_name,s.block_name , "
						+ " s.address,s.store_badge,p.product_badge,a.min_stock,a.max_stock,a.total_stock,a.expiry_date,case when p.is_batch_enabled = true then 'Enabled' "
						+ " else 'Not Enabled' end batch_enabled,a.updated_on as until,current_timestamp-a.updated_on as duration "
						+ " from ( select i.pranth_id,i.store_id,i.product_id,i.min_stock,i.max_stock,i.total_stock,i.created_on as since,expiry_date,i.updated_on "
						+ " from icatalogue i "
						+ " left join (select icatalogue_id,product_id,max(expiry_date) as expiry_date "
						+ " from icatalogue_batch where is_deleted = false "
						+ " group by 1,2)icb on icb.icatalogue_id = i.id and i.product_id = icb.product_id and i.is_deleted = false ");
		if (detailsPayload.getAbnormalityType() != null && detailsPayload.getAbnormalityType().equals(200)) {
			builder.append(" where i.total_stock = 0 ");
		} else if (detailsPayload.getAbnormalityType() != null && detailsPayload.getAbnormalityType().equals(201)) {
			builder.append(" where (i.total_stock < min_stock and i.total_stock<>0) ");
		} else if (detailsPayload.getAbnormalityType() != null && detailsPayload.getAbnormalityType().equals(202)) {
			builder.append(" where i.total_stock > max_stock ");
		} else if (detailsPayload.getAbnormalityType() == null) {
			builder.append(
					" where i.total_stock=0 or (i.total_stock < min_stock and i.total_stock<>0)  or  i.total_stock > max_stock ");
		}
		if (offsetKioskIds != null && !offsetKioskIds.isEmpty()) {
			builder.append(" and i.store_id in ( " + StringUtils.join(offsetKioskIds, " ,") + "  ))a ");
		}
		builder.append(
				" join (select s.id,s.name as store_name, s.pranth_id, c.name as country_name,st.name as state_name,"
						+ " d.name as district_name,bl.name as block_name,city,address ,sb.badge_id as store_badge_id , string_agg(distinct bd.name,',') as store_badge "
						+ "   from store s  " + "   left join store_badge sb on s.id=sb.store_id "
						+ "   left join badge bd on bd.id=sb.badge_id and bd.badge_type_id=2 "
						+ "	left join master_district d on d.id=s.district_id "
						+ "   left join master_state st on st.id=s.state_id  "
						+ "   left join master_country c on c.id=s.country_id "
						+ "   left join master_block bl on s.block_id=bl.id  where s.pranth_id in "
						+ consolidatedDomainsBuilder.toString()
						+ "   group by 1,2,3,4,5,6,7,sb.badge_id)s on s.id = a.store_id"
						+ "   inner join (select p.id,p.name as product_name, is_batch_enabled,pb.badge_id as product_badge_id , string_agg(distinct bd.name,',') as product_badge "
						+ "   from product p  " + "   left join product_badge pb on pb.product_id=p.id "
						+ "   left join badge bd on bd.id=pb.badge_id and bd.badge_type_id=1 	"
						+ "   group by p.id,pb.badge_id)p on p.id=a.product_id ");
		addFilterConditionsForAbnormalStock(detailsPayload, builder, true, materialTagsToHide, offsetKioskIds,
				pageable);
		stockDeviantList = jdbcTemplate.queryForList(builder.toString());
		return stockDeviantList;
	}

	// with pagination
	private void buildQueryForAbnormalStocksDetails(IcatalogueDetailsPayload detailsPayload, StringBuilder builder,
			Set<Long> consolidatePranthIds, Pageable pageable, List<Integer> materialTagsToHide,
			List<Long> offsetKioskIds) {
		getStockDeviantDataByQuery(detailsPayload, builder, consolidatePranthIds, pageable, materialTagsToHide,
				offsetKioskIds);
	}

	private void addFilterConditionsForAbnormalStock(IcatalogueDetailsPayload detailsPayload, StringBuilder builder,
			boolean isAbnormalStocks, List<Integer> materialTagsToHide, List<Long> offsetKioskIds, Pageable pageable) {
		if (!detailsPayload.getIncludeALLStoreBadge().isEmpty()
				&& detailsPayload.getIncludeAllProductBadge().size() > 0) {
			builder.append("  where s.store_badge_id in ("
					+ StringUtils.join(detailsPayload.getIncludeALLStoreBadge(), ",") + ")");
		}
		if (detailsPayload.getStoreId() != null) {
			builder.append("  and a.store_id = " + detailsPayload.getStoreId());
		}
		if (detailsPayload.getProductId() != null) {
			builder.append("  and a.product_id = " + detailsPayload.getProductId());
		}
		if (detailsPayload.getExpireBefore() != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			builder.append("  and icb.expiry_date <= '" + dateFormat.format(detailsPayload.getExpireBefore()) + " '");
		}
		if (detailsPayload.getState() != null) {
			builder.append("  and st.name = '" + detailsPayload.getState() + " '");
		}
		if (detailsPayload.getDistrict() != null) {
			builder.append("  and d.name = '" + detailsPayload.getDistrict() + " '");
		}
		if (detailsPayload.getCountry() != null) {
			builder.append("  and c.name = '" + detailsPayload.getCountry() + " '");
		}
		if (!detailsPayload.getIncludeAllProductBadge().isEmpty()
				&& detailsPayload.getIncludeAllProductBadge().size() > 0) {
			builder.append("  and p.product_badge_id in  ("
					+ StringUtils.join(detailsPayload.getIncludeAllProductBadge(), ",") + ")");
		}
		if (materialTagsToHide != null && !materialTagsToHide.isEmpty()) {
			builder.append("  p.product_badge_id not in ( " + StringUtils.join(materialTagsToHide, " ,") + " )");
		}
		if (pageable != null) {
			builder.append("order by store_name LIMIT " + pageable.getPageSize() + " OFFSET "
					+ (pageable.getPageNumber() * pageable.getPageSize()));
		}
	}

	private void addFilterConditionsForStockView(IcatalogueDetailsPayload detailsPayload, StringBuilder builder,
			Boolean isAbnormalStocks, List<Integer> materialTagsToHide, List<Long> offsetKioskIds) {
		if (detailsPayload.getStoreId() != null) {
			builder.append("  and store_id = " + detailsPayload.getStoreId());
		}
		if (offsetKioskIds != null && !offsetKioskIds.isEmpty()) {
			builder.append(" and store_id in ( " + StringUtils.join(offsetKioskIds, " ,") + "  ) ");
		}
		if (detailsPayload.getProductId() != null) {
			builder.append("  and product_id = " + detailsPayload.getProductId());
		}
		if (detailsPayload.getAbnormalityType() != null && detailsPayload.getAbnormalityType() == 200) {
			builder.append("  and total_stock=0  ");
		} else if (detailsPayload.getAbnormalityType() != null && detailsPayload.getAbnormalityType() == 201) {
			builder.append("  and total_stock<min_stock and total_stock<>0 ");
		} else if (detailsPayload.getAbnormalityType() != null && detailsPayload.getAbnormalityType() == 202) {
			builder.append("  and total_stock>max_stock ");
		} else if (detailsPayload.getAbnormalityType() == null && isAbnormalStocks) {
			builder.append(
					"  and (total_stock = 0 or total_stock<min_stock and total_stock<>0 or total_stock>max_stock ) ");
		}
		if (detailsPayload.getExpireBefore() != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat(" yyyy-MM-dd");
			builder.append("  and expiry_date <= '" + dateFormat.format(detailsPayload.getExpireBefore()) + " '");
		}
		/*if (detailsPayload.getCountry() != null) {
			builder.append("  and country_id = " + detailsPayload.getCountry());
		}*/
		if (detailsPayload.getState() != null) {
			builder.append("  and state_id = " + detailsPayload.getState());
		}
		if (detailsPayload.getDistrict() != null) {
			builder.append("  and district_id = " + detailsPayload.getDistrict());
		}
		if (detailsPayload.getBlock() != null) {
			builder.append("  and block_id = " + detailsPayload.getBlock());
		}
		if (detailsPayload.getDuration() != null) {
			builder.append("  and date_part('day', age(now(),created_on)) >= '" + detailsPayload.getDuration() + " '");
		}
		if (detailsPayload.getIncludeStoreBadge() != null && !detailsPayload.getIncludeStoreBadge().isEmpty()) {
			builder.append("  and store_badge_id in (" + StringUtils.join(detailsPayload.getIncludeStoreBadge(), " ,")
			+ " )");
		}
		if (detailsPayload.getIncludeProductBadge() != null && !detailsPayload.getIncludeProductBadge().isEmpty()) {
			builder.append("  and product_badge_id  in ("
					+ StringUtils.join(detailsPayload.getIncludeProductBadge(), " ,") + " )");
		}
		if (!materialTagsToHide.isEmpty() && materialTagsToHide != null) {
			builder.append("  and product_badge_id not in (" + StringUtils.join(materialTagsToHide, " ,") + " )");
		}
	}

	public Long getAbnormalStockCount(IcatalogueDetailsPayload detailsPayload, List<Integer> materialTagsToHide,
			List<Long> offsetKioskIds) {
		try {
			StringBuilder builder = new StringBuilder();
			Set<Long> consolidatePranthIds = pranthHierarchyService
					.getConsolidatedPranthIds(detailsPayload.getPranthId());
			consolidatePranthIds.add(detailsPayload.getPranthId());
			buildQueryForAbnormalStocksCount(detailsPayload, builder, consolidatePranthIds, materialTagsToHide,
					offsetKioskIds);
			log.info(builder.toString());
			return jdbcTemplate.queryForObject(builder.toString(), Long.class);
		} catch (Exception e) {
			log.error(" Exception occured : {}", e);
		}
		return 0L;
	}

	private void buildQueryForAbnormalStocksCount(IcatalogueDetailsPayload detailsPayload, StringBuilder builder,
			Set<Long> consolidatePranthIds, List<Integer> materialTagsToHide, List<Long> offsetKioskIds) {
		int i = 0;
		StringBuilder consolidatedDomainsBuilder = new StringBuilder();
		consolidatedDomainsBuilder.append(" (");
		for (Long e : consolidatePranthIds) {
			consolidatedDomainsBuilder.append(e.toString());
			if (i < consolidatePranthIds.size() - 1) {
				consolidatedDomainsBuilder.append(" ,");
			}
			i++;
		}
		consolidatedDomainsBuilder.append(" )");
		builder.append(
				" select count (*) from (select a.pranth_id,a.store_id,s.store_name,a.product_id,p.product_name,s.city,s.country_name,s.state_name,s.district_name,s.block_name , "
						+ " s.address,s.store_badge,p.product_badge,a.min_stock,a.max_stock,a.total_stock,a.expiry_date,case when p.is_batch_enabled = true then 'Enabled' "
						+ " else 'Not Enabled' end batch_enabled,a.updated_on as until,current_timestamp-a.updated_on as duration "
						+ " from ( select i.pranth_id,i.store_id,i.product_id,i.min_stock,i.max_stock,i.total_stock,i.created_on as since,expiry_date,i.updated_on "
						+ " from icatalogue i "
						+ " left join (select icatalogue_id,product_id,max(expiry_date) as expiry_date "
						+ " from icatalogue_batch where is_deleted = false "
						+ " group by 1,2)icb on icb.icatalogue_id = i.id and i.product_id = icb.product_id and i.is_deleted = false  ");
		if (detailsPayload.getAbnormalityType() != null && detailsPayload.getAbnormalityType().equals(200)) {
			builder.append(" where i.total_stock = 0 ");
		} else if (detailsPayload.getAbnormalityType() != null && detailsPayload.getAbnormalityType().equals(201)) {
			builder.append(" where (i.total_stock < min_stock and i.total_stock<>0) ");
		} else if (detailsPayload.getAbnormalityType() != null && detailsPayload.getAbnormalityType().equals(202)) {
			builder.append(" where i.total_stock > max_stock ");
		} else if (detailsPayload.getAbnormalityType() == null) {
			builder.append(
					" where i.total_stock=0 or (i.total_stock < min_stock and i.total_stock<>0)  or  i.total_stock > max_stock ");
		}
		if (offsetKioskIds != null && !offsetKioskIds.isEmpty()) {
			builder.append(" and i.store_id in ( " + StringUtils.join(offsetKioskIds, " ,") + "  ) )a");
		}
		builder.append(
				" join (select s.id,s.name as store_name, s.pranth_id, c.name as country_name,st.name as state_name,"
						+ " d.name as district_name,bl.name as block_name,city,address ,sb.badge_id as store_badge_id, string_agg(distinct bd.name,',') as store_badge "
						+ "   from store s  " + "   left join store_badge sb on s.id=sb.store_id "
						+ "   left join badge bd on bd.id=sb.badge_id and bd.badge_type_id=2 "
						+ "	left join master_district d on d.id=s.district_id "
						+ "   left join master_state st on st.id=s.state_id  "
						+ "   left join master_country c on c.id=s.country_id "
						+ "   left join master_block bl on s.block_id=bl.id  where s.pranth_id in "
						+ consolidatedDomainsBuilder.toString()
						+ "   group by 1,2,3,4,5,6,7,sb.badge_id)s on s.id = a.store_id"
						+ "   inner join (select p.id,p.name as product_name, is_batch_enabled,pb.badge_id as product_badge_id ,string_agg(distinct bd.name,',') as product_badge "
						+ "   from product p  " + "   left join product_badge pb on pb.product_id=p.id "
						+ "   left join badge bd on bd.id=pb.badge_id and bd.badge_type_id=1 	"
						+ "   group by p.id,pb.badge_id)p on p.id=a.product_id  ");
		addFilterConditionsForAbnormalStock(detailsPayload, builder, true, materialTagsToHide, offsetKioskIds, null);
		builder.append(" order by a.store_id desc)c");
	}

	public List<IcatalogueDetails> getInventoryDetails(IcatalogueDetailsPayload detailsPayload,
			List<Long> offsetKioskIds, List<Integer> materialTagsToHide, Set<Long> consolidatedDomainIds) throws CustomException {
		StringBuilder builder = new StringBuilder();
		buildQueryForInventoryDetails(detailsPayload, builder,consolidatedDomainIds, offsetKioskIds, materialTagsToHide);
		log.info(builder.toString());
		return jdbcTemplate.query(builder.toString(), new RowMapper<IcatalogueDetails>() {
			@Override
			public IcatalogueDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				return IcatalogueDetails.builder().city(rs.getString("city")).country(rs.getString("country_name"))
						.pranthId(rs.getLong("pranth_id")).storageBadge(rs.getString("store_badge"))
						.productBage(rs.getString("product_badge")).district(rs.getString("district_name"))
						.currentStock(rs.getLong("total_stock")).invMax(rs.getLong("max_stock"))
						.invMin(rs.getLong("min_stock")).block(rs.getString("block_name"))
						.storeId(rs.getLong("store_id"))
						.storeName(rs.getString("store_name")).productId(rs.getLong("product_id"))
						.productName(rs.getString("product_name")).state(rs.getString("state_name"))
						.batchManagement(rs.getString("batch_enabled")).build();
			}
		});
	}


	public List<IcatalogueTotalDetails> getInventoryTotalDetails(IcatalogueDetailsPayload detailsPayload,
			List<Long> offsetKioskIds, List<Integer> materialTagsToHide, Set<Long> consolidatedDomainIds)
					throws CustomException {
		StringBuilder builder = new StringBuilder();
		buildQueryForInventoryTotalDetails(detailsPayload, builder, consolidatedDomainIds, offsetKioskIds,
				materialTagsToHide);
		log.info(builder.toString());
		return jdbcTemplate.query(builder.toString(),
				new BeanPropertyRowMapper<IcatalogueTotalDetails>(IcatalogueTotalDetails.class));
	}

	private void buildQueryForInventoryTotalDetails(IcatalogueDetailsPayload detailsPayload, StringBuilder builder,
			Set<Long> consolidatedDomainIds, List<Long> offsetKioskIds, List<Integer> materialTagsToHide) {
		int i = 0;
		StringBuilder consolidatedDomainsBuilder = new StringBuilder();
		consolidatedDomainsBuilder.append(" (");
		for (Long e : consolidatedDomainIds) {
			consolidatedDomainsBuilder.append(e.toString());
			if (i < consolidatedDomainIds.size() - 1) {
				consolidatedDomainsBuilder.append(" ,");
			}
			i++;
		}
		consolidatedDomainsBuilder.append(" )");
		builder.append(
				" select sum(allocated_stock)  as allocated,sum(in_transit_stock) as in_transit,"
				+ " sum(total_stock) as total,product_id as productId,product_name as productName "
				+ "  from mvw_stock_report  where pranth_id in " + 
								(consolidatedDomainsBuilder.toString()) +" ");
		
		addFilterConditionsForStockView(detailsPayload, builder, false, materialTagsToHide, offsetKioskIds);
		builder.append(" group by 4,5");
	}

	private void buildQueryForInventoryDetails(IcatalogueDetailsPayload detailsPayload, StringBuilder builder,
			Set<Long> consolidatedDomainIds, List<Long> offsetKioskIds, List<Integer> materialTagsToHide) {

		int i = 0;
		StringBuilder consolidatedDomainsBuilder = new StringBuilder();
		consolidatedDomainsBuilder.append(" (");
		for (Long e : consolidatedDomainIds) {
			consolidatedDomainsBuilder.append(e.toString());
			if (i < consolidatedDomainIds.size() - 1) {
				consolidatedDomainsBuilder.append(" ,");
			}
			i++;
		}
		consolidatedDomainsBuilder.append(" )");
		builder.append(
				" select distinct pranth_id,store_id,store_name,city,country_name,state_name,district_name,block_name, " + 
				" store_badge,product_badge,product_id,product_name, " + 
				" min_stock, max_stock, total_stock, " + 
				" allocated_stock, in_transit_stock,updated_on,expiry_date," + 
				" batch_enabled , " + 
				" abnormal_type_id, duration_days " + 
				" from mvw_stock_report where pranth_id in " + 
								(consolidatedDomainsBuilder.toString()) +" ");

		addFilterConditionsForStockView(detailsPayload, builder, false, materialTagsToHide, offsetKioskIds);
		builder.append("  order by store_name ");
	}

	public List<IcatalogueChartDetails> getIcatalogueLogChartDetails(Long pranthId) {
		StringBuilder builder = new StringBuilder();
		builder.append(
				"  select pranth_id,sum(normal_stock) as normal_stock, sum(zero_stock) as zero_stock,sum(min_stock) as min_stock,sum(max_stock) as max_stock from "
						+ " (select pranth_id,case when total_stock between min_stock and max_stock then 1 else 0 end as normal_stock, "
						+ " case when total_stock=0 then 1 else 0 end as zero_stock,case when total_stock<min_stock then 1 else 0 end as min_stock, "
						+ " case when total_stock > max_stock then 1 else 0 end as max_stock from icatalogue)i where pranth_id = "
						+ pranthId + "  group by 1 " + "  order by 1 ");
		return jdbcTemplate.query(builder.toString(), new RowMapper<IcatalogueChartDetails>() {
			@Override
			public IcatalogueChartDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				return IcatalogueChartDetails.builder().pranthId(rs.getLong(" pranth_id"))
						.maxStock(rs.getLong(" max_stock")).minStock(rs.getLong(" min_stock"))
						.zeroStock(rs.getLong(" zero_stock")).normalStock(rs.getLong(" normal_stock")).build();
			}
		});
	}

	public List<AllocatedStockDTO> getAllocatedStock(Long storeId, Long productId) {
		List<AllocatedStockDTO> allocatedStockDTOs = null;
		try {
			allocatedStockDTOs = icatalogueRepository.getAllocatedStockBysidandpid(storeId, productId);
		} catch (Exception e) {
			log.error(" Exception occured while getting allocated stock details " + e.getCause());
		}
		if (allocatedStockDTOs != null) {
			return allocatedStockDTOs;
		}
		return new ArrayList<>();
	}

	public List<InTransitStockDTO> getInTransitStock(Long storeId, Long productId) {
		List<InTransitStockDTO> inTransitStockDTOs = null;
		try {
			inTransitStockDTOs = icatalogueRepository.getinTransitStockBysidandpid(storeId, productId);
		} catch (Exception e) {
			log.error(" Exception occured while getting in-Transit stock details " + e.getCause());
		}
		if (inTransitStockDTOs != null) {
			return inTransitStockDTOs;
		}
		return new ArrayList<>();
	}

	public List<StockDeviantProductsDTO> getStockDeviantProducts(StockDeviantPaylod stockDeviantPaylod) {
		List<StockDeviantProductsDTO> stockDeviantProductsDTOList = null;
		StringBuilder builder = new StringBuilder();
		builder.append("  select distinct i.product_id,p.name as product_name,i.store_id,s.name as store_name,\n"
				+ " date_start as fromDate,coalesce(date_end,current_timestamp) as until,"
				+ " age(coalesce(date_end,current_timestamp),date_start) as duration,abnormal_type_id "
				+ " from icatalogue_log i " + " join store s on s.id = i.store_id and s.is_deleted = false "
				+ " join product p on p.id = i.product_id and p.is_deleted = false "
				+ " where i.is_delted = false and abnormal_type_id = " + stockDeviantPaylod.getAbnormalityType()
				+ " and s.id = " + stockDeviantPaylod.getStoreId() + " and p.id = " + stockDeviantPaylod.getProductId()
				+ " " + " order by store_id,product_id,date_start desc  ");

		stockDeviantProductsDTOList = jdbcTemplate.query(builder.toString(),
				new BeanPropertyRowMapper<StockDeviantProductsDTO>(StockDeviantProductsDTO.class));
		for (StockDeviantProductsDTO stockDeviantProductsDTO : stockDeviantProductsDTOList) {
			String[] daysandmin = null;
			String duration = stockDeviantProductsDTO.getDuration();
			if (duration != null) {
				if (duration.contains("days")) {
					daysandmin = duration.split(" ");
					stockDeviantProductsDTO.setDuration(daysandmin[0] + " " + daysandmin[1]);
				} else {
					daysandmin = duration.split(":");
					if (!daysandmin[0].contentEquals("00")) {
						stockDeviantProductsDTO.setDuration(daysandmin[0] + "  hours ");
					} else if (!daysandmin[1].contentEquals("00")) {
						stockDeviantProductsDTO.setDuration(daysandmin[1] + "  minutes ");
					} else if (!daysandmin[2].contentEquals("00")) {
						stockDeviantProductsDTO.setDuration("  1 minute ");
					}
				}

			} else {
				stockDeviantProductsDTO.setDuration(duration);
			}
		}
		return stockDeviantProductsDTOList;
	}

	public ProductsDetails getAllProductsBasedOnPranth(Long productId, Integer abnormalityType, Long pranthId,
			Long duration, Pageable pageable) throws Exception {
		ProductsDetails productsDetails = null;
		// Set<Long> consolidatedPranthIds =
		// pranthHierarchyService.getConsolodatedPranthIds(pranthId);
		List<StockViewProductsDTO> productsList = null;
		StringBuilder builder = new StringBuilder();
		Long count = buildQueryParamsForProductFilterInInvntry(productId, abnormalityType, pranthId, builder, pageable);
		if (count > 0) {
			log.info(builder.toString());
			productsList = jdbcTemplate.query(builder.toString(),
					new BeanPropertyRowMapper<StockViewProductsDTO>(StockViewProductsDTO.class));
			return ProductsDetails.builder().stockViewProductsDTO(productsList).totalRecordCount(count).build();
		} else {
			return productsDetails;
		}

	}

	private Long buildQueryParamsForProductFilterInInvntry(Long productId, Integer abnormalityType, Long pranthId,
			StringBuilder builder, Pageable pageable) throws Exception {
		builder.append("select *  " + "from (select distinct i.pranth_id,s.id as store_id,s.name as store_name,  "
				+ " concat(s.city,', ',d.name,', ',st.name,', ',c.name) as location,  "
				+ " p.id as product_id,p.name as product_name,i.total_stock,i.allocated_stock,i.current_stock as available_stock,  "
				+ " i.in_transit_stock as intransitStock ,days_of_stock,i.min_stock,i.max_stock,i.updated_on,p.is_batch_enabled,  "
				+ " case when i.total_stock = 0 then 200 when i.total_stock<i.min_stock then 201  "
				+ " when i.total_stock >i.max_stock then 202 end as abnormality_type  " + "from icatalogue i   "
				+ " left join store s on s.id = i.store_id  and s.is_deleted = false"
				+ " left join master_district d on d.id=s.district_id  "
				+ " left join master_state st on st.id=s.state_id  "
				+ " left join master_country c on c.id=s.country_id  "
				+ " left join product p on p.id = i.product_id )a where pranth_id = " + pranthId + "");
		if (productId != null && productId > 0 && abnormalityType != null) {
			builder.append(" and a.product_id = " + productId + " and abnormality_type = " + abnormalityType + "");
		} else if (productId != null && productId > 0) {
			builder.append(" and a.product_id = " + productId + "");
		} else if (abnormalityType != null) {
			builder.append(" and abnormality_type = " + abnormalityType + "");
		}
		String query = builder.toString();
		String mainQuery = "SELECT COUNT(*) FROM (" + query + " ) as cnt";
		Long count = jdbcTemplate.queryForObject(mainQuery, Long.class);
		if (count > 0) {
			builder.append("order by store_name LIMIT " + pageable.getPageSize() + " OFFSET " + pageable.getOffset());
		} else {
			count = 0l;
		}
		return count;
	}

	public List<Map<String, Object>> getAllProductsByExpierDateBasedOnPranth(Long pranthId, Date expireBefore,
			Pageable pageable) throws CustomException {
		List<Map<String, Object>> result = null;
		StringBuilder builder = new StringBuilder();
		builder.append("select distinct i.pranth_id,s.id as store_id,s.name as store_name, "
				+ " concat(s.city,', ',d.name,', ',st.name,', ',c.name) as location, "
				+ " p.id as product_id,p.name as product_name,ib.batch_no,ib.manufactured_date,pr.name as manufacturer_name, "
				+ " ib.expiry_date, i.total_stock,ib.updated_on " + "from public.icatalogue i "
				+ "left join public.icatalogue_batch ib on ib.icatalogue_id = i.id  "
				+ "left join public.producer pr on pr.id = ib.producer_id " + "left join store s on s.id = i.store_id "
				+ "left join master_district d on d.id=s.district_id "
				+ "left join master_state st on st.id=s.state_id " + "left join master_country c on c.id=s.country_id "
				+ "left join product p on p.id = i.product_id " + "where i.pranth_id = " + pranthId
				+ " and expiry_date<='" + expireBefore + "' " + " order by expiry_date asc;");
		result = jdbcTemplate.queryForList(builder.toString());
		return result;
	}

	public Long getAllProductsByExpierDateCount(Long pranthId, Date expireBefore) {
		StringBuilder builder = new StringBuilder();
		builder.append("select count (*) from (select distinct i.pranth_id,s.id as store_id,s.name as store_name, "
				+ " concat(s.city,', ',d.name,', ',st.name,', ',c.name) as location, "
				+ " p.id as product_id,p.name as product_name,ib.batch_no,ib.manufactured_date,pr.name as manufacturer_name, "
				+ " ib.expiry_date, i.total_stock,ib.updated_on " + "from public.icatalogue i "
				+ "left join public.icatalogue_batch ib on ib.icatalogue_id = i.id  "
				+ "left join public.producer pr on pr.id = ib.producer_id " + "left join store s on s.id = i.store_id "
				+ "left join master_district d on d.id=s.district_id "
				+ "left join master_state st on st.id=s.state_id " + "left join master_country c on c.id=s.country_id "
				+ "left join product p on p.id = i.product_id " + "where i.pranth_id = " + pranthId
				+ " and expiry_date<='" + expireBefore + "' " + " order by expiry_date asc)a");
		return jdbcTemplate.queryForObject(builder.toString(), Long.class);
	}

	/**
	 * To upload bulk data of Stores MIN and MAX values
	 * 
	 * @param file
	 * @param userId
	 * @param pranthId
	 * @param userName
	 * @return
	 * @throws CustomException
	 * @throws IOException
	 */
	public ResponseBean uploadRecords(MultipartFile file, Long userId, Long pranthId, String userName)
			throws CustomException, IOException {
		ExcelResponse excelResponse = new ExcelResponse();
		ResponseBean bean = new ResponseBean();
		List<MasterState> masterStates = masterStateRepository.findAll();
		Map<String, MasterState> statesMap = new HashMap<>();
		statesMap.putAll(masterStates.stream().collect(Collectors.toMap(ms -> ms.getName(), ms -> ms)));

		List<MasterDistrict> masterDistricts = masterDistrictRepository.findAll();
		Map<String, MasterDistrict> districtMap = new HashMap<>();
		districtMap.putAll(masterDistricts.stream().collect(Collectors.toMap(md -> {
			return md.getName() + "_" + md.getStateId();
		}, md -> md)));

		List<MasterBlock> masterBlocks = masterBlockRepository.findAll();
		Map<String, MasterBlock> blockMap = new HashMap<>();
		blockMap.putAll(masterBlocks.stream().collect(Collectors.toMap(mb -> {
			return mb.getName() + "_" + mb.getDistrictId();
		}, mb -> mb)));

		List<IcatalogueBulkUpdateLogs> icatalogueLogList = new ArrayList<>();
		List<IcatalogueModel> icatalogueModelList = new ArrayList<>();
		try {
			icatalogueModelList = importFileData.csvToIcatalogueModel(file.getInputStream());
		} catch (Exception e) {
			log.info("Error while reading excel data", e.getMessage());
			bean.setMessage("Error while reading excel data");
			bean.setReturnCode(1);
			bean.setStatus(HttpStatus.FORBIDDEN);
			throw new CustomException("Error while reading excel data", HttpStatus.OK);
		}
		IcatalogueModel modelHeaders = null;
		if (!icatalogueModelList.isEmpty()) {
			modelHeaders = icatalogueModelList.get(0);
			icatalogueModelList.remove(0);
		}
		for (IcatalogueModel icatalogueMode : icatalogueModelList) {
			try {
				String storeName = icatalogueMode.getStoreName();
				Long pranth =icatalogueMode.getPranthId() != null ? Long.valueOf(icatalogueMode.getPranthId()) : 0L;
				Long storeId = icatalogueMode.getStoreId() != null ? Long.valueOf(icatalogueMode.getStoreId()) : 0L;
				Integer stateId = 0;
				Integer districtId = 0;
				Integer blockId = 0;
				if (icatalogueMode.getStateName() != null && !icatalogueMode.getStateName().equalsIgnoreCase("")
						&& icatalogueMode.getDistrictName() != null
						&& !icatalogueMode.getDistrictName().equalsIgnoreCase("")) {
					stateId = statesMap.get(icatalogueMode.getStateName()) != null
							? statesMap.get(icatalogueMode.getStateName()).getId()
									: 0;
							districtId = districtMap.get(icatalogueMode.getDistrictName() + "_" + stateId) != null
									? districtMap.get(icatalogueMode.getDistrictName() + "_" + stateId).getId()
											: 0;
									blockId = blockMap.get(icatalogueMode.getBlockName() + "_" + districtId) != null
											? blockMap.get(icatalogueMode.getBlockName() + "_" + districtId).getId()
													: 0;
				}
				List<Store> storeList = new ArrayList<>();
				if(storeId != 0L) {
					storeList = storeRepository.getByStoreId(storeId);
					if (!storeList.isEmpty() && storeList.size() == 1) {
						storeId = storeList.get(0).getId();
					} 
				} 
				if(storeId == 0 && storeList.isEmpty() && stateId != 0 && districtId != 0 && blockId != 0 && pranth != 0){
					storeList = storeRepository.getStoreByNameAndStateAndDistrictAndBlockAndPranth(storeName, stateId, districtId, blockId, pranth);
					if (!storeList.isEmpty() && storeList.size() == 1) {
						storeId = storeList.get(0).getId();
					} else {
						icatalogueMode.setRemarks("No record found with the given inputs");
					}
				} else if(storeId == 0 && storeList.isEmpty() && stateId != 0 && districtId != 0  && pranth != 0){
					storeList = storeRepository.getStoreByNameAndStateAndDistrictAndPranth(storeName, stateId, districtId , pranth);
					if (!storeList.isEmpty() && storeList.size() == 1) {
						storeId = storeList.get(0).getId();
					} else {
						icatalogueMode.setRemarks("No record found with the given inputs");
					}
				} else if(storeId == 0 && storeList.isEmpty() && stateId != 0  && pranth != 0){
					storeList = storeRepository.getStoreByNameAndStateAndPranth(storeName, stateId, pranth);
					if (!storeList.isEmpty() && storeList.size() == 1) {
						storeId = storeList.get(0).getId();
					} else {
						icatalogueMode.setRemarks("No record found with the given inputs");
					}
				} else if(storeId == 0 && storeName != null) {
					storeList = storeRepository.getStoreByName(storeName);
					if (!storeList.isEmpty() && storeList.size() == 1) {
						storeId = storeList.get(0).getId();
					}else {
						icatalogueMode.setRemarks("No record found with the store name");
					}
				} else {
					icatalogueMode.setRemarks("No record found with the store name");
				}

				Product product = productRepository.findProductByName(icatalogueMode.getMaterialName());
				if (icatalogueMode.getRemarks() == null && product != null) {
					Icatalogue icatalogue = icatalogueRepository.findByStoreIdAndProductIdAndIsDeletedFalse(storeId,
							product.getId());
					if (icatalogue != null) {
						icatalogue.setMinStock(Long.valueOf(icatalogueMode.getMinStock()));
						icatalogue.setMaxStock(Long.valueOf(icatalogueMode.getMaxStock()));
						icatalogueRepository.save(icatalogue);
						;
						icatalogueMode.setRemarks("Record updated successfully");
						// save data in mongo db
						IcatalogueBulkUpdateLogs ibul = IcatalogueBulkUpdateLogs.builder().createdOn(new Date())
								.updatedOn(new Date()).maxStock(icatalogueMode.getMaxStock())
								.minStock(icatalogueMode.getMinStock()).pranthId(pranthId).userId(userId)
								.storeId(storeId).productId(product.getId()).storeName(storeName)
								.productName(icatalogueMode.getMaterialName()).build();
						icatalogueLogList.add(ibul);
					} else {
						icatalogueMode.setRemarks("No record found with the store name and product name");
					}
				} else if (icatalogueMode.getRemarks() == null) {
					icatalogueMode.setRemarks("No record found with the product name");
				}
			} catch (Exception e) {
				log.info("Error while saving excel data", e);
				icatalogueMode.setRemarks("error while updating");
			}
		}
		if (!icatalogueLogList.isEmpty()) {
			icatalogueBulkUpdateLogsRepository.saveAll(icatalogueLogList);
		}
		if (!icatalogueModelList.isEmpty()) {
			excelResponse = importFileData.exportErrorFile(icatalogueModelList, modelHeaders, excelResponse, userName);
		}
		bean.setMessage(excelResponse.getMessage());
		bean.setData(excelResponse);
		bean.setReturnCode(1);
		bean.setStatus(HttpStatus.OK);
		return bean;
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public class ExcelResponse {

		private String message;
		private String downloadUrl;
		private Long errorCount;
		private Long successCount;

	}

}