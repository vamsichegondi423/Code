package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.MasterLanguage;

@Repository
public interface MasterLanguageRepository extends JpaRepository<MasterLanguage, Integer> {

	@Query(value = "select * from master_language where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterLanguage> getById(Integer id);

	@Query(value = "select * from master_language where is_deleted = false", nativeQuery = true)
	public List<MasterLanguage> findAll();
	
	@Query(value = "select * from master_language where \"name\" = ? and is_deleted = false", nativeQuery = true)
	public MasterLanguage getMasterLanguage(String name);

	@Modifying
	@Transactional
	@Query(value = "delete from master_language where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);

	@Modifying
	@Transactional
	@Query(value = "update master_language set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

}