package com.dipl.evin2.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class GeneralCongifurationDTO {
	
	@JsonProperty("localeDefaults")
	public LocaleDefaults localeDefaults;
	@JsonProperty("support_contacts")
	public List<SupportContact> supportContacts;
	@JsonProperty("admin_contacts")
	public List<AdminContact> adminContacts;
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class AdminContact {

		@JsonProperty("admin_type")
		public String adminType;
		@JsonProperty("user_id")
		public Integer userId;
		@JsonProperty("name")
		public String name;
		@JsonProperty("phone_number")
		public String phoneNumber;
		@JsonProperty("email_id")
		public String emailId;

	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class LocaleDefaults {

		@JsonProperty("country_id")
		public Integer countryId;
		@JsonProperty("state")
		public Integer state;
		@JsonProperty("disrict_id")
		public Integer disrictId;
		@JsonProperty("language_id")
		public Integer languageId;
		@JsonProperty("time_zone_id")
		public Integer timeZoneId;
		@JsonProperty("currency_id")
		public Integer currencyId;
		@JsonProperty("custom_page_header")
		public String customPageHeader;

	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@EqualsAndHashCode(callSuper=false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class SupportContact {

		@JsonProperty("role_id")
		public Integer roleId;
		@JsonProperty("user_id")
		public Integer userId;
		@JsonProperty("name")
		public String name;
		@JsonProperty("phone_number")
		public String phoneNumber;
		@JsonProperty("email_id")
		public String emailId;

	}

}
