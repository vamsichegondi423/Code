package com.dipl.evin2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.dto.StockReportPayload;
import com.dipl.evin2.service.ExportStockReportViewService;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/report")
public class ExportStockReportViewController {

	@Autowired
	private ExportStockReportViewService exportStockReportViewService;

	@PostMapping(value = "/v1/export-stock-report")
	public ResponseBean getBookings(@RequestBody StockReportPayload exportStockReportViewPayload,
			@RequestParam("pranthId") Long pranthId, @RequestParam("userId") Long userId,
			@RequestParam("userName") String userName, @RequestParam("email") String email,Pageable pageable) {
		try {
			return exportStockReportViewService.getStockReportService(exportStockReportViewPayload, pranthId,pageable,userId, userName, email);
		} catch (Exception e) {
			log.error("Exception occured while fetching  : {}", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
	}

}