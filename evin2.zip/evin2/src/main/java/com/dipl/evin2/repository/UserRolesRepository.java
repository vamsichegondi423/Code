package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import com.dipl.evin2.entity.UserRoles;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface UserRolesRepository extends JpaRepository<UserRoles, Long> {

	@Query(value = "select * from user_roles where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<UserRoles> getById(Long id);

	@Query(value = "select * from user_roles where is_deleted = false", nativeQuery = true)
	public List<UserRoles> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from user_roles where id = ?1", nativeQuery = true)
	public void deleteById(Long id);
	
	@Modifying
	@Transactional
	@Query(value = "update user_roles set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);
	
}