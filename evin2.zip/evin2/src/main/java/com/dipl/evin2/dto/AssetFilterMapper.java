package com.dipl.evin2.dto;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class AssetFilterMapper implements RowMapper<AssetDTO> {

	@Override
	public AssetDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		AssetDTO assetResult = AssetDTO.builder().assetId(rs.getLong("asset_id"))
				.serialNumber(rs.getString("serial_number")).assetModelId(rs.getInt("asset_model_id"))
				.modelName(rs.getString("model_name")).assetVendorId(rs.getInt("asset_vendor_id"))
				.assetVendorName(rs.getString("asset_vendor_name")).assetTypeId(rs.getInt("asset_type_id"))
				.assetTypeName(rs.getString("asset_type_name")).storeId(rs.getInt("store_id"))
				.storeName(rs.getString("store_name")).address(rs.getString("address")).city(rs.getString("city"))
				.blockName(rs.getString("block_name")).districtName(rs.getString("district_name"))
				.stateName(rs.getString("state_name")).country(rs.getString("country"))
				.lastUpdatedOn(rs.getTimestamp("last_updated_on"))
				.lastUpdatedByName(rs.getString("last_updated_by_name"))
				.lastUpdatedById(rs.getInt("last_updated_by_id")).build();
		return assetResult;
	}

}
