package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.entity.AssetConfiguration;
import com.dipl.evin2.repository.AssetConfigurationRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AssetConfigurationService {

	@Autowired
	private AssetConfigurationRepository assetConfigurationRepository;

	public AssetConfiguration getById(Long id) {
		Optional<AssetConfiguration> assetConfigurationOptional = assetConfigurationRepository.getById(id);
		if (assetConfigurationOptional.isPresent()) {
			return assetConfigurationOptional.get();
		} else {
			return null;
		}
	}

	public AssetConfiguration save(AssetConfiguration assetConfiguration) {
		if (assetConfiguration.getId() != null && assetConfiguration.getId() > 0) {
			Optional<AssetConfiguration> existingAssetConfigurationRecord = assetConfigurationRepository.getById(assetConfiguration.getId());
			if (existingAssetConfigurationRecord.isPresent()) {
				return assetConfigurationRepository.save(assetConfiguration);
			}
		} else {
			assetConfiguration = assetConfigurationRepository.save(assetConfiguration);
		}
		return assetConfiguration;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<AssetConfiguration> existingAssetConfigurationRecord = assetConfigurationRepository.getById(id);
			if (existingAssetConfigurationRecord.isPresent()) {
				assetConfigurationRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<AssetConfiguration> getAll() {
		try {
			return assetConfigurationRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public AssetConfiguration getByCountryAndDeviceIdAndPhoneNumber(Integer countryId, Long assetId, String phoneNumber) {
		Optional<AssetConfiguration> assetConfigurationOptional = assetConfigurationRepository.findByCountryAndDeviceIdAndPhoneNumber(countryId, assetId, phoneNumber);
		if (assetConfigurationOptional.isPresent()) {
			return assetConfigurationOptional.get();
		} else {
			return null;
		}
	}

	public AssetConfiguration getByVendorIdAndDeviceIdAndFirmwareVersion(Long vendorId, Long deviceId,
			String firmwareVersion) {
		Optional<AssetConfiguration> assetConfigurationOptional = assetConfigurationRepository.findByVendorIdAndDeviceIdAndFirmwareVersion(vendorId, deviceId, firmwareVersion);
		if (assetConfigurationOptional.isPresent()) {
			return assetConfigurationOptional.get();
		} else {
			return null;
		}
	}

	public AssetConfiguration getByVendorIdAndDeviceId(Long vendorId, Long deviceId) {
		Optional<AssetConfiguration> assetConfigurationOptional = assetConfigurationRepository.findByVendorIdAndDeviceId(vendorId, deviceId);
		if (assetConfigurationOptional.isPresent()) {
			return assetConfigurationOptional.get();
		} else {
			return null;
		}
	}

	public List<AssetConfiguration> getSensorsByAssetId(Long assetId) {
		List<AssetConfiguration> assetConfigurations = assetConfigurationRepository.findSensorsByAssetId(assetId);
		return assetConfigurations;
	}

	public AssetConfiguration getByAssetId(Long assetId) {
		Optional<AssetConfiguration> assetConfigurationOptional = assetConfigurationRepository.getByAssetId(assetId);
		if (assetConfigurationOptional.isPresent()) {
			return assetConfigurationOptional.get();
		} else {
			return null;
		}
	}

	public List<AssetConfiguration> getAllByAssetIds(Set<Long> assetIds) {
		return assetConfigurationRepository.getAllByAssetIds(assetIds);
	}
}