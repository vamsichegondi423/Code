package com.dipl.evin2.mongo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.dipl.evin2.model.CargoHistory;

public interface CargoHistoryRepository extends MongoRepository<CargoHistory, String> {

	List<CargoHistory> findByCargoIdOrderByIdAsc(String cargoId);

}
