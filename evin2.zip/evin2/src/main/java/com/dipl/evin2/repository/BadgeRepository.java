package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.Badge;

@Repository
public interface BadgeRepository extends JpaRepository<Badge, Integer> {

	@Query(value = "select * from badge where badge_type_id = ?1 and pranth_id = ?2 and is_deleted = false", nativeQuery = true)
	public Optional<Badge> getByBadgeTypeId(Integer id, Long pranthId);
	
	@Query(value = "select * from badge where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<Badge> getById(Integer id);

	@Query(value = "select * from badge where pranth_id = ?1 and is_deleted = false", nativeQuery = true)
	public List<Badge> findAll(Long pranthId);

	@Modifying
	@Transactional
	@Query(value = "delete from badge where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);

	@Modifying
	@Transactional
	@Query(value = "update badge set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);

	@Query(value = "select * from badge where badge_type_id=?1 and pranth_id = ?2 and is_deleted = false", nativeQuery = true)
	public List<Badge> getAllBadgesByTypeId(Integer badgeId, Long pranthId);

	@Query(value = "select * from badge where name like %:name% and badge_type_id=:badgeTypeId and pranth_id = :pranthId and is_deleted = false", nativeQuery = true)
	public List<Badge> getAllByNameAndBadgeType(@Param("name") String name, @Param("badgeTypeId") Integer badgeTypeId, @Param("pranthId") Long pranthId);

	@Query(value = "select b.id from badge b join badge_pranth bp on bp.badge_id= b.id where b.id in (?1) and bp.pranth_id = ?2 and is_deleted = false", nativeQuery = true)
	public List<Integer> getAllByNameAndBadgeType(List<Integer> productBadgeIds, Long pranthId);

	@Query(value = "select b.id,b.name, b.badge_type_id, b.description, b.created_on, b.is_deleted, b.created_by, b.updated_by, b.updated_on, bp.pranth_id from badge b join badge_pranth bp on bp.badge_id = b.id where bp.pranth_id = ?1 and is_deleted = false", nativeQuery = true)
	public List<Badge> findAllByPranth(Long pranthId);

}