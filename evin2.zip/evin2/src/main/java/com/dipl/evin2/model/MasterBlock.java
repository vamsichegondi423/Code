package com.dipl.evin2.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MasterBlock implements Serializable {

	private static final long serialVersionUID = 1L;

    private Integer id;
    
    @JsonProperty("block_code")
    private String blockCode;
    
    @JsonProperty("block_name")
    private String blockNameEng;
    
    @JsonProperty("block_name_local")
    private String blockNameLocal;
    
    @JsonProperty("is_active")
    private Boolean isActive;
    
    @JsonProperty("local_body_type_id")
    private Integer localBodyTypeId;
    
  
    
}
