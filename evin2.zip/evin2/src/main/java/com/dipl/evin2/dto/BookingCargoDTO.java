package com.dipl.evin2.dto;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

public interface BookingCargoDTO {

	@Value(("#{target.booking_id}"))
	Long getBookingId();

	@Value(("#{target.cargo_id}"))
	Long getCargoId();

	@Value(("#{target.cargo_no}"))
	String getCargoNo();

	@Value(("#{target.cargo_status}"))
	String getCargoStatus();

	@Value(("#{target.items_count}"))
	Long getNoOfItems();

	@Value(("#{target.carrier_name}"))
	String getTransporter();

	@Value(("#{target.order_reference_no}"))
	String getTrackingid();

	@Value(("#{target.arrival_date}"))
	Date getEstimatedDeliveryDate();

	@Value(("#{target.created_by}"))
	String getCreatedBy();

	@Value(("#{target.gender}"))
	String getGender();

	@Value(("#{target.created_on}"))
	Date getCreatedOn();

	@Value(("#{target.user_id}"))
	String getUserId();
}
