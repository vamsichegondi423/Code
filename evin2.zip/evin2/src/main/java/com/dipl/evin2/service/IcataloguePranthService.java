package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.IcataloguePranth;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.IcataloguePranthRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class IcataloguePranthService {

	@Autowired
	private IcataloguePranthRepository icataloguePranthRepository;

	public IcataloguePranth getById(Long id) throws CustomException {
		try {
			Optional<IcataloguePranth> icataloguePranthOptional = icataloguePranthRepository.getById(id);
			if (icataloguePranthOptional.isPresent()) {
				return icataloguePranthOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public IcataloguePranth save(IcataloguePranth icataloguePranth) throws CustomException {
		try {
			if (icataloguePranth.getId() != null && icataloguePranth.getId() > 0) {
				Optional<IcataloguePranth> existingIcataloguePranthRecord = icataloguePranthRepository
						.getById(icataloguePranth.getId());
				if (existingIcataloguePranthRecord.isPresent()) {
					return icataloguePranthRepository.save(icataloguePranth);
				}
			} else {
				icataloguePranth = icataloguePranthRepository.save(icataloguePranth);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return icataloguePranth;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<IcataloguePranth> existingIcataloguePranthRecord = icataloguePranthRepository.getById(id);
			if (existingIcataloguePranthRecord.isPresent()) {
				icataloguePranthRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<IcataloguePranth> getAll() {
		try {
			return icataloguePranthRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}