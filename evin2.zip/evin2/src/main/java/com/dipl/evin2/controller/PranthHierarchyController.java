package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.PranthHierarchy;
import com.dipl.evin2.repository.PranthHierarchyRepository;
import com.dipl.evin2.service.PranthHierarchyService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/pranth-hierarchy")
public class PranthHierarchyController {

	@Autowired
	private PranthHierarchyService pranthHierarchyService;
	
	@Autowired
	private PranthHierarchyRepository pranthHierarchyRepository;

	@ApiOperation("Use this api for saving or updating PranthHierarchy. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody PranthHierarchy pranthHierarchy, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			Optional<PranthHierarchy> exstngPranthHierarchy = pranthHierarchyRepository.findByPranthIdMappingTypeAndMappingId(pranthHierarchy.getPranthId(), pranthHierarchy.getMappedPranthId(), pranthHierarchy.getMappingType());
			if(exstngPranthHierarchy.isPresent()) {
				log.info("Pranth Hierarchy pranth id " + pranthHierarchy.getPranthId() + " with mapped pranth id " + pranthHierarchy.getMappedPranthId() + " and mapping type " + pranthHierarchy.getMappingType() + " already exist");
				responseBean.setMessage("Pranth Hierarchy pranth id " + pranthHierarchy.getPranthId() + " with mapped pranth id " + pranthHierarchy.getMappedPranthId() + " and mapping type " + pranthHierarchy.getMappingType() + " already exist");
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setReturnCode(1);
				return responseBean;
			}
			if (pranthHierarchy.getId() != null && pranthHierarchy.getId() > 0) {
				PranthHierarchy existingPranthHierarchy = pranthHierarchyService.getById(pranthHierarchy.getId());
				if (existingPranthHierarchy != null) {
					pranthHierarchy.setCreatedOn(existingPranthHierarchy.getCreatedOn());			
					pranthHierarchy = pranthHierarchyService.save(pranthHierarchy);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(pranthHierarchy);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				Optional<PranthHierarchy> existingPranthHierarchy = pranthHierarchyRepository.findByPranthIdMappingTypeAndMappingId(pranthHierarchy.getPranthId(), pranthHierarchy.getMappedPranthId(), pranthHierarchy.getMappingType());
				if(!existingPranthHierarchy.isPresent()) {
					pranthHierarchy = pranthHierarchyService.save(pranthHierarchy);
					log.info("Record saved successfully");
					responseBean.setMessage("Record saved successfully");
					responseBean.setData(pranthHierarchy);
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setReturnCode(1);
				} else {
					log.info("Record already exists");
					responseBean.setMessage("Record already exists");
					responseBean.setData(null);
					responseBean.setStatus(HttpStatus.FORBIDDEN);
					responseBean.setReturnCode(0);
				}
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching PranthHierarchy record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			PranthHierarchy pranthHierarchy = pranthHierarchyService.getById(id);
			if (pranthHierarchy != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(pranthHierarchy);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting PranthHierarchy record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = pranthHierarchyService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all PranthHierarchy records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<PranthHierarchy> pranthHierarchyRecords = pranthHierarchyService.getAll();
			if (!pranthHierarchyRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(pranthHierarchyRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
	
	@ApiOperation("\"Use this api for fetching PranthHierarchy records Based on Pranth ID. Provide pranth id as path param.")
	@GetMapping(value = "/v1/getpranthsbypranthid", produces = "application/json")
	public ResponseBean getPranthsByPranthId(@RequestParam(value = "pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<PranthHierarchy> pranthHierarchyRecords = pranthHierarchyService.getPranthsByPranthId(pranthId);
			if (!pranthHierarchyRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(pranthHierarchyRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
}