package com.dipl.evin2.controller;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.controller.IcatalogueController.IcatalogueDetailsPayload;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.model.ExportStockDeviantPayload;
import com.dipl.evin2.service.BookingsService;
import com.dipl.evin2.service.ExportStockDeviantService;
import com.dipl.evin2.service.PranthHierarchyService;
import com.dipl.evin2.service.RolePermissionConfigurationService;
import com.dipl.evin2.service.RolePermissionConfigurationService.RolePermissionConfigurationModel;
import com.dipl.evin2.service.UsersService;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/icatalogue")
public class ExportExcelStockDeviantController {

	@Autowired
	private ExportStockDeviantService exportStockDeviantService;

	@Autowired
	private RolePermissionConfigurationService rolePermissionConfigurationService;

	@Autowired
	private UsersService usersService;
	
	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@Autowired
	private BookingsService bookingsService;

	@Autowired
	private IcatalogueController icatalogueController;

	@PostMapping(value = "/v1/export-stock-deviant-report", produces = "application/json")
	public ResponseBean getStockDeviantReport(@RequestBody ExportStockDeviantPayload detailsPayload, Pageable pageable,
			@RequestParam(name = "pranthId") Long pranthId, @RequestParam(name = "userId") Long userId,
			@RequestParam(name = "userName") String userName, @RequestParam(name = "email") String email)
			throws CustomException, IOException {
		pageable = PageRequest.of(0, Integer.MAX_VALUE);
		detailsPayload.setUserId(userId);
		ValidatorFactory validatorFactory = Validation.byDefaultProvider().configure().buildValidatorFactory();
		Validator validator = validatorFactory.getValidator();
		Set<ConstraintViolation<ExportStockDeviantPayload>> constraintViolations = validator.validate(detailsPayload);
		if (!constraintViolations.isEmpty()) {
			validatorFactory.close();
			return ResponseBean.builder().data(null).status(HttpStatus.BAD_REQUEST).returnCode(0)
					.message(constraintViolations.iterator().next().getMessage()).build();
		}
		Users users = usersService.getById(userId);
		RolePermissionConfigurationModel permissionConfigurationModel = rolePermissionConfigurationService.getPermissionCodeValue("mnstomtbhfiv29", users.getRoleId(), pranthId);

		Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(pranthId);
		List<Long> totalStoreIds = icatalogueController.getToatalStoreIdsWithoutPagination(consolidatedPranthIds, userId, detailsPayload.getState(), detailsPayload.getDistrict(), detailsPayload.getBlock());
		List<Integer> materialTagsToHide = bookingsService.getMaterialTagsToHide(permissionConfigurationModel, pranthId);
		validatorFactory.close();
		return exportStockDeviantService.getStockDeviantService(detailsPayload, pranthId, userId, userName, email,
				 materialTagsToHide, totalStoreIds);

	}
}