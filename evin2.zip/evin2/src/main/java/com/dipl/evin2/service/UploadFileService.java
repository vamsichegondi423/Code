package com.dipl.evin2.service;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UploadFileService {
	
	@Value("${BASE_URL}")
	private String fileUrl;
	
	public HttpResponse<String> uploadFile(String url,String userName, File tempFile, String fileType)
			throws UnirestException {

		url = fileUrl + "evin-files" + "/" + "uploadFile";
		log.info(url);
		return Unirest.post("" + url + "?fileType="+fileType+"&timeOfUpload="
				+ dateWithHoursMinutes().replace(" ", "_") + "&userId=" + userName + "").header("accept", "*/*")
				.field("file", tempFile).asString();
	}
	
	public String dateWithHoursMinutes() {
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		
		return formatter.format(date);
	}
	
	
}
