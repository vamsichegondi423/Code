package com.dipl.evin2.mongo.services;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.dipl.evin2.model.CargoHistory;
import com.dipl.evin2.mongo.repository.CargoHistoryRepository;

@Service
public class CargoHistoryService {
	@Autowired
	private CargoHistoryRepository cargoHistoryRepository;
	@Autowired
	MongoTemplate mongoTemplate;


	public CargoHistory save(CargoHistory cargohistory) {
		cargohistory.setTime(new Date());
		return cargoHistoryRepository.save(cargohistory);
	}
	
	public List<CargoHistory> getCargoHist(String cargoId) {
		return cargoHistoryRepository.findByCargoIdOrderByIdAsc(cargoId);
	}
	
	public List<CargoHistory> getAll() {
		List<CargoHistory> result =  cargoHistoryRepository.findAll();
		return result;
	}
		
	}
	
	
