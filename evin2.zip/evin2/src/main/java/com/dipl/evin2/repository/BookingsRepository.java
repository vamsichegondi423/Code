package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.controller.BookingsController.RecmndQtyDTO;
import com.dipl.evin2.dto.BookingDetailDTO;
import com.dipl.evin2.dto.RcmndQutyDTO;
import com.dipl.evin2.entity.Bookings;

@Repository
public interface BookingsRepository extends JpaRepository<Bookings, Long> {

	@Query(value = "select * from bookings where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<Bookings> getById(Long id);
	
//	@Query(value = "select * from bookings where status_id = ?1 and is_deleted = false", nativeQuery = true)
//	public Optional<Bookings> getBystatusId(int status_id);

	@Query(value = "select * from bookings where is_deleted = false", nativeQuery = true)
	public List<Bookings> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from bookings where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update bookings set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select sum(i.current_stock) as tot_stk "
			+ " from bookings b "
			+ "inner join booking_items bi on bi.booking_id = b.id and bi.is_deleted = false "
			+ " inner join icatalogue i on  i.product_id = bi.product_id and i.store_id = bi.store_id and i.is_deleted = false "
			+ " inner join product p on p.id = i.product_id and p.is_batch_enabled = 'false' and p.is_deleted = false "
			+ "where bi.booking_id = ?1", nativeQuery = true)
	public Long getStockCountForwithOutBatchEnabled(Long bookingId);

	@Query(value = "select sum(ib.available_stock) as tot_stk "
			+ "from bookings b "
			+ "inner join booking_items bi on bi.booking_id = b.id and bi.is_deleted = false"
			+ "inner join icatalogue i on i.product_id = bi.product_id and i.store_id = bi.store_id and i.is_deleted = false "
			+ "inner join icatalogue_batch ib on ib.icatalogue_id = i.id and ib.expiry_date > current_date and ib.is_deleted = false "
			+ " inner join product p on p.id = i.product_id and  p.is_batch_enabled = 'true' and p.is_deleted = false "
			+ "where bi.booking_id = ?1", nativeQuery = true)
	public Long getStockCountForwithBatchEnabled(Long bookingId);

	@Query(value = "select bi.booking_id,bi.id as bookingItemId,bi.is_modified as isEdited,p.id as product_id,p.name as product_name, p.is_batch_enabled,bi.ordered_stock, bdg.name as product_badge, "
			+ " bi.shipped_stock, ci.fulfilled_stock,bi.allocated_stock, coalesce(bi.allocated_stock,0)-coalesce(bi.shipped_stock,0) as yet_to_ship,  "
			+ " ic.current_stock as available_stock,ic.in_transit_stock as ic_in_transit_stock,ic.min_stock as ic_min,ic.max_stock as ic_max, ic.total_stock as ic_total_stock, "
			+ " rc.current_stock,rc.total_stock,rc.in_transit_stock, rc.min_stock as rc_min,rc.max_stock as rc_max ,ci.id as cargo_item_id,bi.recommanded_stock,bi.reason,p.handling_unit  "
			+ "  from booking_items bi "
			+ "  join product p on bi.product_id=p.id and p.is_deleted =false "
			+ "  join bookings b on b.id=bi.booking_id and b.is_deleted =false "
			+ " left join cargo c on c.booking_id = b.id and c.is_deleted =false "
			+ "  left join cargo_item ci on ci.cargo_id = c.id and ci.product_id=bi.product_id and ci.is_deleted =false "
			+ "  left join product_badge pbg on pbg.product_id = p.id and pbg.is_deleted =false "
			+ "  left join badge bdg on bdg.id = pbg.badge_id and bdg.is_deleted =false "
			+ " left join icatalogue ic on b.issuing_store_id=ic.store_id and bi.product_id=ic.product_id and ic.is_deleted =false  "
			+ " left join icatalogue rc on b.receiving_store_id=rc.store_id and bi.product_id=rc.product_id  and rc.is_deleted =false where bi.booking_id=?1 and bi.is_deleted =false", nativeQuery = true)
	public List<Map<String, Object>> getProductsByBookingId(Long bookingId);

	@Query(value = "select distinct b.id as booking_id,ms.name as status,b.order_reference_no,b.created_on,concat(uc.f_name,' ',uc.l_name) as created_name,uc.user_id,b.updated_on, "
			+ " concat(uu.f_name,' ',uu.l_name) as updated_name,string_agg(bd.name,',') as booking_badge,b.receiving_store_id, "
			+ " rs.name as receiving_store_name,concat(rs.city,', ',rd.name,', ',rst.name,', ',rc.name) as receiving_store_location,b.issuing_store_id, "
			+ " s.name as issuing_store_name,concat(s.city,', ',id.name,', ',ist.name,', ',ic.name) as issuing_store_location,b.arrival_date,b.receipt_date,b.order_type_id ,b.badge_id as booking_badge_id,b.status_id,b.source_type"
			+ " from bookings b "
			+ " left join users uc on b.created_by=uc.id "
			+ " left join users uu on b.updated_by=uu.id  "
			+ " left join booking_badge bb on b.id=bb.booking_id"
			+ " left join badge bd on bb.badge_id=bd.id "
			+ " left join store rs on b.receiving_store_id=rs.id"
			+ " left join master_district rd on rs.district_id=rd.id "
			+ " left join master_state rst on rs.state_id=rst.id "
			+ "left join master_country rc on rc.id=rs.country_id   "
			+ " left join store s on b.issuing_store_id=s.id "
			+ "left join master_district id on s.district_id=id.id "
			+ " left join master_state ist on s.state_id=ist.id"
			+ " left join master_country ic on ic.id=s.country_id "
			+ " left join master_status ms on b.status_id=ms.id  where b.id =?1  "
			+ " group by b.id,ms.name,b.order_reference_no,b.created_on,uc.f_name,uc.l_name,uc.user_id,uu.f_name,uu.l_name, "
			+ " b.receiving_store_id, "
			+ " rs.name,rs.city,rd.name,rst.name,rc.name,b.issuing_store_id,s.name,s.city,id.name,ist.name,ic.name,b.arrival_date,b.receipt_date,b.order_type_id,b.badge_id,b.status_id,b.source_type", nativeQuery = true)
	public List<BookingDetailDTO> getBookingsByBookingId(Long bookingId);

	@Query(value = "select * from vw_recommanded_quantity where store_id=?1 and material_id=?2", nativeQuery = true)
	public Map<String, Long> getRcmndQutyByMid(Long storeId, Long productId);

	@Query(value = "select * from vw_recommanded_quantity where store_id=?1 and material_id=?2", nativeQuery = true)
	public RcmndQutyDTO getRcmndQutyByPid(Long storeId, Long productId);

	@Query(value = "select status_id from bookings where id = ?1", nativeQuery = true)
	public Integer getStatusByOrderId(Long orderId);

	@Query(value = "select * from bookings where id = ?1 and is_deleted = false", nativeQuery = true)
	public Bookings getByBookingId(Long bookingId);

	@Query(value = "select * from bookings where id = ?1 and is_deleted = false", nativeQuery = true)
	public List<Bookings> getListByBookingId(Long bookingId);

	@Query(value = "select * from bookings where id = ?1 and is_deleted = false order by created_on desc ", nativeQuery = true)
	public Bookings getStatusByBkid(Long bookingId);

	@Query(value = "select id from icatalogue where store_id = ?1 and product_id =?2 and is_deleted = false ", nativeQuery = true)
	public Long findAllocateBatchDetailsByBId(Long IssuingStoreId, Long productId);

	@Query(value = "select DISTINCT b.id as booking_id,p.name as product_name, p.is_batch_enabled,bi.quantity,bi.recommanded_stock, " + 
			" bib.batch_no,bib.batch_expiry_date, s.name as issuing_store_name,st.name as issuing_state_name, d.name as issing_store_district," + 
			" r.name as receiving_store_name,rt.name as receiving_state_name,rd.name as receiving_district_name, " + 
			" b.order_reference_no,b.transfer_reference_no as issue_reference_no,current_date as invoice_date, " + 
			" cast(bt.created_on as date) as date_of_supply,cast(bt.created_on as date) as date_of_receipt,b.status_id,bi.reason as reason,bi.id as booking_item_id " + 
			" from booking_items bi left join booking_item_batch bib on bi.id=bib.booking_item_id " + 
			" join product p on bi.product_id=p.id join bookings b on b.id=bi.booking_id join booking_tracking bt on bt.booking_id=b.id   and  b.status_id=bt.status_id " + 
			" join store s on b.issuing_store_id=s.id join master_state st on st.id=s.state_id left join  master_district d on d.id=s.district_id " + 
			" join store r on b.receiving_store_id=r.id join master_state rt on rt.id=r.state_id left join master_district rd on rd.id=r.district_id " + 
			" left join cargo c on b.id=c.booking_id and c.is_deleted=false where b.is_deleted=false and bi.is_deleted=false " + 
			" and bi.booking_id=?1", nativeQuery = true)
	public List<Map<String, Object>> getInvoiceData(Long bookingId);
	
	@Query(value = "select * from vw_recommanded_quantity where store_id=?1 ", nativeQuery = true)
	public List<RcmndQutyDTO> getRcmndQutyByStoreId(Long storeId);
	
	@Query(value = "select * from vw_recommanded_quantity where store_id in ?1 ", nativeQuery = true)
	public List<RcmndQutyDTO> getRcmndQutyByStores(List<Long> storeIds);
	
	@Query(value = "select * from vw_recommanded_quantity where store_id=?1 and material_id = ?2 ", nativeQuery = true)
	public List<RcmndQutyDTO> getRcmndQutyByStoreIdPid(Long storeId, Long productId);	
	
	@Query(value = "select *  from bookings b  JOIN cargo c on b.id=c.booking_id  and  b.id = ?1 and b.is_deleted = false and c.is_deleted = false", nativeQuery = true)
	public Bookings  getStatusByBookingId(Object object);	
	
}