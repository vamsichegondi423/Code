package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.controller.MasterReasonController.MasterReasonDTO;
import com.dipl.evin2.entity.BadgePranth;
import com.dipl.evin2.entity.MasterReason;
import com.dipl.evin2.entity.PranthHierarchy;
import com.dipl.evin2.entity.ReasonPranth;
import com.dipl.evin2.entity.StatusPranth;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterReasonRepository;
import com.dipl.evin2.repository.ReasonPranthRepository;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterReasonService {

	@Autowired
	private MasterReasonRepository masterReasonTypeRepository;

	@Autowired
	private ReasonPranthRepository reasonPranthRepository;

	@Autowired
	private PranthHierarchyService pranthHierarchyService;

	@Cacheable(value = "reason_type", key = "#id")
	public MasterReason getById(Integer id) throws CustomException {
		try {
			Optional<MasterReason> masterReasonTypeOptional = masterReasonTypeRepository.getById(id);
			if (masterReasonTypeOptional.isPresent()) {
//				ReasonPranth byReasonId = reasonPranthRepository.getByReasonId(id);
//				if(byReasonId != null)
//					masterReasonTypeOptional.get().setPranthId(byReasonId.getPranthId());
				return masterReasonTypeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "reason_type", key = "#masterReasonType.id")
	public MasterReason save(MasterReason masterReasonType,Long pranthId) {
		Boolean isReasonMand = masterReasonType.getIsReasonMandatory();
		Boolean isDefault = masterReasonType.getIsDefault();
		if (masterReasonType.getId() != null && masterReasonType.getId() > 0) {
			Optional<MasterReason> existingMasterReasonRecord = masterReasonTypeRepository
					.getById(masterReasonType.getId());
			if (existingMasterReasonRecord.isPresent()) {
				masterReasonType = masterReasonTypeRepository.save(masterReasonType);
				ReasonPranth findByPranthIdAndId = reasonPranthRepository.findByPranthIdAndReasonId(pranthId,masterReasonType.getId());
				if(findByPranthIdAndId != null && findByPranthIdAndId.getId() != null && findByPranthIdAndId.getId() > 0) {
					findByPranthIdAndId.setIsDefault(isDefault);
					findByPranthIdAndId.setIsReasonMandatory(isReasonMand);
					if(!findByPranthIdAndId.getIsActive()) {
						findByPranthIdAndId.setIsActive(true);
					}
					reasonPranthRepository.save(findByPranthIdAndId);
				} else {
					ReasonPranth reasonPranth = ReasonPranth.builder().pranthId(pranthId).isDefault(isDefault)
							.isReasonMandatory(isReasonMand).reasonId(masterReasonType.getId()).build();
					reasonPranthRepository.save(reasonPranth);
				}
				updateReasonMandatoryField(masterReasonType,pranthId,isReasonMand);
				return masterReasonType;
			}
		} else {
			masterReasonType = masterReasonTypeRepository.save(masterReasonType);
			if(masterReasonType.getId() > 0) {
				ReasonPranth findByPranthIdAndId = reasonPranthRepository.findByPranthIdAndReasonIdAndIsActiveTrue(pranthId,masterReasonType.getId());
				if(findByPranthIdAndId != null && findByPranthIdAndId.getId() != null && findByPranthIdAndId.getId() > 0) {
					findByPranthIdAndId.setIsDefault(isDefault);
					findByPranthIdAndId.setIsReasonMandatory(isReasonMand);
					if(!findByPranthIdAndId.getIsActive()) {
						findByPranthIdAndId.setIsActive(true);
					}
					reasonPranthRepository.save(findByPranthIdAndId);
				} else {
					ReasonPranth reasonPranth = ReasonPranth.builder().pranthId(pranthId).reasonId(masterReasonType.getId()).build();
					reasonPranth.setIsDefault(isDefault);
					reasonPranth.setIsReasonMandatory(isReasonMand);
					reasonPranthRepository.save(reasonPranth);
				}
				updateReasonMandatoryField(masterReasonType,pranthId,isReasonMand);
			}
		}
		return masterReasonType;
	}

	private void updateReasonMandatoryField(MasterReason masterReasonType, Long pranthId,Boolean isReasonMand) {
		List<ReasonPranth> findAllByPranthId = reasonPranthRepository.findAllByPranthId(pranthId,masterReasonType.getReasonType());
		findAllByPranthId.stream().forEach(rp ->{
			rp.setIsReasonMandatory(isReasonMand);
		});
		reasonPranthRepository.saveAll(findAllByPranthId);
	}

	@CacheEvict(value = "reason_type", allEntries = true)
	public Integer deleteById(Integer id,Long pranthId) throws CustomException {
		try {
			Optional<MasterReason> existingMasterReasonRecord = masterReasonTypeRepository.getById(id);
			if (existingMasterReasonRecord.isPresent()) {
				masterReasonTypeRepository.deleteByIdSoft(id);
				ReasonPranth existsReasonPranth = reasonPranthRepository.findByPranthIdAndReasonIdAndIsActiveTrue(pranthId, id);
				if(existsReasonPranth != null) {
					reasonPranthRepository.deleteByIdSoft(existsReasonPranth.getId());
				}
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<MasterReasonDTO> fetchAllByReasonType(String reasonType, Long pranthId) {
		List<MasterReasonDTO> result = null;
		try {
			if (reasonType != null) {
				result = masterReasonTypeRepository.fetchReasonByTpe(reasonType, pranthId);
			} else {
				result = masterReasonTypeRepository.fetchReasonType(pranthId);
			}
		} catch (Exception e) {
			log.error("Exception occured in master reason : ", e);
		}
		return result;
	}


	@Transactional(rollbackOn = { Exception.class , CustomException.class })
	public ResponseBean updateParentReasonToChild(Long pranthId, Long mappedPranthId, Long userId)  throws CustomException{
		ResponseBean responseBean  = new ResponseBean();
		Long pranthid = 0L;
		List<ReasonPranth> rpList= new ArrayList<>();
		Optional<PranthHierarchy> pranthHierarchy = pranthHierarchyService.getByMappingId(mappedPranthId);
		try {
			if(pranthHierarchy.isPresent()) {
				if(pranthId != null && pranthId != 0) {
					pranthid = pranthId;
				} else {
					pranthid = pranthHierarchy.get().getPranthId();
				}
				List<ReasonPranth> reasonPranthList = reasonPranthRepository.getAllReasonByPranthId(pranthid);
				for(ReasonPranth mr: reasonPranthList) {
					ReasonPranth reasonPranth = new ReasonPranth();
					ReasonPranth reasonPranthObject = reasonPranthRepository.findByPranthIdAndReasonIdAndIsActiveTrue(mappedPranthId, mr.getReasonId());
					if(reasonPranthObject == null) {
						 reasonPranth = ReasonPranth.builder()
								.pranthId(mappedPranthId).isActive(true).reasonId(mr.getReasonId()).isDefault(mr.getIsDefault())
								.isReasonMandatory(mr.getIsReasonMandatory()).build();
						 rpList.add(reasonPranth);
					}
				}
				reasonPranthRepository.saveAll(rpList);
				responseBean.setMessage("MasterReason has been updated for child");
				responseBean.setReturnCode(1);
				responseBean.setStatus(HttpStatus.OK);
			} else {
				responseBean.setMessage("No Record found with mappedPranthId");
				responseBean.setReturnCode(0);
				responseBean.setStatus(HttpStatus.NO_CONTENT);
			}
		}catch(Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseBean;
	}
	
	
	public MasterReason findDuplicateReason(String name,String reasonType,Long pranthId) throws CustomException {
		try {
			List<MasterReason> existingMasterReasonRecord = masterReasonTypeRepository.findByReasonTypeAndNameAndPranthId(reasonType, name ,pranthId);
			if (!existingMasterReasonRecord.isEmpty()) {
				return existingMasterReasonRecord.get(0);
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}
	
}