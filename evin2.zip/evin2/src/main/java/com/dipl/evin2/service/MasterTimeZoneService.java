package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterTimeZone;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterTimeZoneRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterTimeZoneService {

	@Autowired
	private MasterTimeZoneRepository masterTimeZoneRepository;

	@Cacheable(value = "timezone", key = "#id")
	public MasterTimeZone getById(Integer id) {
		Optional<MasterTimeZone> masterTimeZoneOptional = masterTimeZoneRepository.getById(id);
		if (masterTimeZoneOptional.isPresent()) {
			return masterTimeZoneOptional.get();
		} else {
			return null;
		}
	}

	@CachePut(value = "timezone", key = "#masterTimeZone.id")
	public MasterTimeZone save(MasterTimeZone masterTimeZone) throws CustomException {
		try {
			if (masterTimeZone.getId() != null && masterTimeZone.getId() > 0) {
				Optional<MasterTimeZone> existingMasterTimeZoneRecord = masterTimeZoneRepository
						.getById(masterTimeZone.getId());
				if (existingMasterTimeZoneRecord.isPresent()) {
					masterTimeZone = masterTimeZoneRepository.save(masterTimeZone);
				}
			} else {
				masterTimeZone = masterTimeZoneRepository.save(masterTimeZone);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterTimeZone;
	}

	@CacheEvict(value = "timezone", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterTimeZone> existingMasterTimeZoneRecord = masterTimeZoneRepository.getById(id);
			if (existingMasterTimeZoneRecord.isPresent()) {
				masterTimeZoneRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "timezone")
	public List<MasterTimeZone> getAll() {
		try {
			return masterTimeZoneRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}