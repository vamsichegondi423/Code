package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.controller.BookingsController.BookingsByFilterPayload;
import com.dipl.evin2.dto.BatchProductDTO;
import com.dipl.evin2.dto.BookingDetailDTO;
import com.dipl.evin2.dto.BookingItemTooltipDTO;
import com.dipl.evin2.dto.UserCommentsDTO;
import com.dipl.evin2.entity.Bookings;
import com.dipl.evin2.entity.Bookings.BookingProducts;
import com.dipl.evin2.entity.UserComments;
import com.dipl.evin2.jackson.DispatchOrderModel;
import com.dipl.evin2.model.UpdateOrderModel;
import com.dipl.evin2.service.BookingsService;
import com.dipl.evin2.service.BookingsService.CancelOrderModel;
import com.dipl.evin2.service.BookingsService.GenericBookingModel;
import com.dipl.evin2.service.StoreService;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/bookings")
public class BookingsController {

	@Autowired
	private BookingsService bookingsService;

	@Autowired
	private StoreService storeService;

	@ApiOperation("Use this api for saving or updating Bookings. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody Bookings bookings, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (bookings.getId() != null && bookings.getId() > 0) {
				Bookings existingBookings = bookingsService.getById(bookings.getId());
				if (existingBookings != null) {
					bookings = bookingsService.save(bookings);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(bookings);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				bookings = bookingsService.save(bookings);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(bookings);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for creating an Order")
	@PostMapping(value = "/v1/add")
	public ResponseBean createOrder(@RequestBody Bookings bookings, BindingResult result,
			@RequestParam("userId") Long userId, @RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured while creating Indent : {}", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}

		try {
			responseBean = bookingsService.createBooking(bookings, userId, pranthId);

		} catch (Exception e) {
			log.error("Exception occured while creating Indent: {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for creating a release Indent")
	@PostMapping(value = "/v1/add-release-order")
	public ResponseBean createReleaseOrder(@RequestBody Bookings bookingsPayload, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload for release Indent ");
				return ResponseBean.builder().data(null).message("Invalid Payload for release Indent")
						.status(HttpStatus.BAD_REQUEST).returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured while creating release Indent : {}", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}

		try {
			responseBean = bookingsService.createReleaseBooking(bookingsPayload);

		} catch (Exception e) {
			log.error("Exception occured while creating release Indent : {}", e.getCause());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("something went wrong ");
		}
		return responseBean;
	}
	

	@ApiOperation("Use this api for creating a transfer Indent")
	@PostMapping(value = "/v1/add-transfer-order")
	public ResponseBean createTransferOrder(@RequestBody Bookings bookingsPayload, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload for transfer Indent ");
				return ResponseBean.builder().data(null).message("Invalid Payload for transfer Indent")
						.status(HttpStatus.BAD_REQUEST).returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured while creating transfer Indent : {}", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}

		try {
			responseBean = bookingsService.createTransferBooking(bookingsPayload);

		} catch (Exception e) {
			log.error("Exception occured while creating transfer Indent : {}", e.getCause());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}
	
	@ApiOperation("Use this api for updating an Order")
	@PostMapping(value = "/v1/update-booking/{order_id}")
	public ResponseBean updateBooking(@RequestBody UpdateOrderModel bookings, @PathVariable("order_id") Long orderId,
			@RequestParam("pranthId") Long pranthId, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured while doing auto allocation  : {}", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}

		try {
			responseBean = bookingsService.updateBookingStatus(bookings, orderId, pranthId);

		} catch (Exception e) {
			log.error("Exception occured while doing auto allocation  : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for Updating/Dispatch an Order")
	@PostMapping(value = "/v1/dispatch-booking/{order_id}")
	public ResponseBean dispatchBooking(@RequestBody DispatchOrderModel updateOrderModel,
			@PathVariable("order_id") Long orderId, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured while doing manual allocation  : {}", e);
			return ResponseBean.builder().data(null).message("something went wrong").status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}

		try {
			responseBean = bookingsService.ManualBookingDispatch(updateOrderModel, orderId);

		} catch (Exception e) {
			log.error("Exception occured while doing manual allocation : {}", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching Bookings record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Bookings bookings = bookingsService.getById(id);
			if (bookings != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(bookings);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting Bookings record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = bookingsService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all Bookings records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Bookings> bookingsRecords = bookingsService.getAll();
			if (!bookingsRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(bookingsRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all Order by filtetr.")
	@PostMapping(value = "/v1/get-bookings-by-filter", produces = "application/json")
	public ResponseBean getOrdersByFilter(@RequestBody BookingsByFilterPayload bookingsByFilterPayload,
			Pageable pageable, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestParam("userId") Long userId, @RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Long> totalKioskIds = storeService.getToatalStoreIds(pranthId, userId);
			BookingByFilterDetails bookingByFilterDetails = bookingsService.getBookingsByFilter(bookingsByFilterPayload,
					pageable, userId, totalKioskIds, pranthId);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
			if (bookingByFilterDetails == null || bookingByFilterDetails.getBookingFilterDTOs().isEmpty()) {
				return ResponseBean.builder().data(null).returnCode(1).status(HttpStatus.OK).message("No records found")
						.build();
			}
			return ResponseBean.builder().data(bookingByFilterDetails).status(HttpStatus.OK).returnCode(1)
					.message("Records fetched successfully").build();
		} catch (Exception e) {
			log.error("Exception occured while fetching all Order : {}", e);
			return ResponseBean.builder().data(null).message("something went wrong").status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
	}

	@ApiOperation("Use this api for fetching products by booking id. Provide booking id as request param.")
	@GetMapping(value = "/v1/get-products-by-booking-id", produces = "application/json")
	public ResponseBean getProductsByBookingId(@RequestParam(value = "booking_id") Long bookingId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<Map<String, Object>> bookingProducts = bookingsService.getProductsByBookingId(bookingId);
			responseBean.setStatus(HttpStatus.OK);
			if (bookingProducts != null) {
				log.info(" Products of booking fetched successfully");
				responseBean.setMessage("Products of booking fetched successfully");
				responseBean.setData(bookingProducts);
			} else {
				log.info("Products are not found for this booking id");
				responseBean.setMessage("Products are not found for this booking id");
			}
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured in fetching products by bookings", e.getMessage());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong" );
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching products by booking id. Provide booking id as request param.")
	@GetMapping(value = "/v1/get-bookings-by-id", produces = "application/json")
	public ResponseBean getBookingById(@RequestParam(value = "booking_id") Long bookingId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<BookingDetailDTO> bookingProducts = bookingsService.getBookingsByBookingId(bookingId);
			responseBean.setStatus(HttpStatus.OK);
			if (bookingProducts != null) {
				log.info(" Products of booking fetched successfully");
				responseBean.setMessage("Products of booking fetched successfully");
				responseBean.setData(bookingProducts);
			} else {
				log.info("Products are not found for this booking id");
				responseBean.setMessage("Products are not found for this booking id");
			}
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured in fetching products by bookings", e.getMessage());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@SuppressWarnings("unchecked")
	@GetMapping(value = "/v1/get-recmnd-quty")
	public ResponseBean getRcmndQutyByMid(@RequestParam(value = "storeId") Long storeId,
			@RequestParam(value = "productId") Long productId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Long rcmndQutydata = bookingsService.getRcmndQutyByProductId(storeId, productId);
			JSONObject mainObject = new JSONObject();
			mainObject.put("recmndQuty", rcmndQutydata);
			if (rcmndQutydata != null) {
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setMessage("Recommended Quty fetched successfully");
				responseBean.setData(mainObject);
				responseBean.setReturnCode(1);
			} else {
				log.info(" No Records Found in Recommended Quty ");
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setMessage(" No Records Found in Recommended Quty");
				responseBean.setReturnCode(1);
			}
		} catch (Exception e) {
			log.error("Exception Occured in Recommended Quty" + e.getMessage());
			responseBean.setMessage("something went wrong");
			responseBean.setReturnCode(0);
		}

		return responseBean;
	}

	@ApiOperation("Use this api for fetching batch products by products id. Provide order id and material id as request params.")
	@GetMapping(value = "/v1/get-batch-products-by-booking-id", produces = "application/json")
	public ResponseBean getBatchProductsByBooking(@RequestParam(value = "bookingId") Long bookingId,
			@RequestParam(value = "bookingItemIds") List<Long> bookingItemIds, Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		try {
			responseBean = bookingsService.getBatchProductsByBooking(bookingId, bookingItemIds);
		} catch (Exception e) {
			log.error("Exception occured in fetching products batch", e.getMessage());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching batch products by booking item id. Provide order id and material id as request params.")
	@GetMapping(value = "/v1/get-batch-products-by-booking-item-id", produces = "application/json")
	public ResponseBean getBatchProductsByBookingItemId(@RequestParam(value = "bookingItemId") Long bookingItemId,
			Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		try {
			responseBean = bookingsService.getBatchProductsByBookingItemId(bookingItemId);
		} catch (Exception e) {
			log.error("Exception occured in fetching products batch", e.getMessage());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("something went wrong");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for edit/update booking orderd quantity ")
	@PostMapping(value = "/edit-booking")
	public ResponseBean updateOrderdQuantity(@RequestBody UpdateOrderProductModel updateOrderdQuantity) {
		ResponseBean responseBean = new ResponseBean();
		try {
			responseBean = bookingsService.updateOrderdQuantity(updateOrderdQuantity);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured while update order quantity" + e.getCause());
			responseBean.setMessage("something went wrong");
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for update booking details ")
	@PostMapping(value = "/update-order-details")
	public ResponseBean updateOrderDetails(@RequestBody UpdateBookingModel updateBookingPayload, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
			if (updateBookingPayload.getBookingId() != null) {
				responseBean = bookingsService.updateBookingDetails(updateBookingPayload);
			} else {
				responseBean.setMessage("Invalid Payload");
				responseBean.setStatus(HttpStatus.BAD_REQUEST);
				responseBean.setReturnCode(0);
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured while update order details" + e.getCause());
			responseBean.setMessage("something went wrong");
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for get allocate batch Details ")
	@GetMapping(value = "/get-allocate-by-batch")
	public ResponseBean getAllocateBatchDetails(@RequestParam Long IssuingStoreId, @RequestParam Long productId) {
		ResponseBean responseBean = new ResponseBean();
		List<BatchProductDTO> batchProductDTOs = null;
		try {
			batchProductDTOs = bookingsService.getAllocateBatchDetailsByBId(IssuingStoreId, productId);
		} catch (Exception e) {
			log.error("Exception occured at get allocate by batch details " + e.getCause());
			responseBean.setMessage("something went wrong");
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if (batchProductDTOs != null) {
			responseBean.setData(batchProductDTOs);
			responseBean.setMessage("record fetched successfully");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} else {
			responseBean.setData(null);
			responseBean.setMessage(" no record found ");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for get tool tip Details of booking Item")
	@GetMapping(value = "/get-booking-item-tooltip")
	public ResponseBean getBookingItemTooltip(@RequestParam Long bookingItemId) {
		ResponseBean responseBean = new ResponseBean();
		List<BookingItemTooltipDTO> bookingItemTooltipDTO = null;
		try {
			bookingItemTooltipDTO = bookingsService.getBookingItemTooltip(bookingItemId);
		} catch (Exception e) {
			log.error("Exception Occured at Booking Item Tooltip Details  " + e.getCause());
			responseBean.setMessage("something went wrong");
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if (bookingItemTooltipDTO != null) {
			responseBean.setData(bookingItemTooltipDTO);
			responseBean.setMessage("record fetched successfully");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} else {
			responseBean.setData(null);
			responseBean.setMessage(" no record found ");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for get tool tip Details of booking Item")
	@GetMapping(value = "/get-fulfilled-order-batches")
	public ResponseBean getFulfilledOrderBatches(@RequestParam Long cargoItemId) {
		ResponseBean responseBean = new ResponseBean();
		List<Map<String, Object>> fulfilledOrderBatches = null;
		try {
			fulfilledOrderBatches = bookingsService.getFulfilledOrderBatchesDetails(cargoItemId);
		} catch (Exception e) {
			log.error("Exception Occured at Booking Item Tooltip Details  " + e.getCause());
			responseBean.setMessage("something went wrong ");
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if (fulfilledOrderBatches != null) {
			responseBean.setData(fulfilledOrderBatches);
			responseBean.setMessage("record fetched successfully");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} else {
			responseBean.setData(null);
			responseBean.setMessage(" no record found ");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for save comments")
	@PostMapping(value = "/save-user-comments")
	public ResponseBean saveUserComments(@RequestBody UserComments userCommentsPayload) {
		ResponseBean responseBean = new ResponseBean();
		UserComments userComments = null;
		try {
			userComments = bookingsService.saveUserComments(userCommentsPayload);
		} catch (Exception e) {
			log.error("Exception Occured while saving Comments  " + e.getCause());
			responseBean.setMessage("something went wrong");
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if (userComments != null) {
			responseBean.setData(userComments);
			responseBean.setMessage("message added successfully");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} else {
			responseBean.setData(null);
			responseBean.setMessage(" message not saved ");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for get conversation on bookings/cargo")
	@GetMapping(value = "/get-user-comments")
	public ResponseBean getUserComments(@RequestParam String objType, @RequestParam Long objId, Pageable pageable) {
		ResponseBean responseBean = new ResponseBean();
		List<UserCommentsDTO> userComments = null;
		try {
			userComments = bookingsService.getUserComments(objType, objId, pageable);
		} catch (Exception e) {
			log.error("Exception Occured while get user Comments  " + e.getCause());
			responseBean.setMessage("something went wrong");
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if (userComments != null && !userComments.isEmpty()) {
			responseBean.setData(userComments);
			responseBean.setMessage("records fetched successfully");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} else {
			responseBean.setData(userComments);
			responseBean.setMessage("No record found");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}
		return responseBean;
	}

	@PostMapping("/v1/generate-booking-invoice")
	public ResponseBean generateBookingInvoice(@RequestParam(name = "booking-id") Long bookingId) {
		return bookingsService.generateBookingInvoice(bookingId);
	}

	@PostMapping("/v1/cancel-order")
	public ResponseBean cancelBooking(@RequestBody(required = true) CancelOrderModel cancelOrderModel) {
		if (cancelOrderModel.getBookingId() == null || cancelOrderModel.getBookingId() == 0) {
			return ResponseBean.builder().data(null).message("Please pass booking Id it is mandatory")
					.status(HttpStatus.BAD_REQUEST).returnCode(1).build();
		}
		if (cancelOrderModel.getUserId() == null) {
			return ResponseBean.builder().data(null).message("Please pass User Id it is mandatory")
					.status(HttpStatus.BAD_REQUEST).returnCode(1).build();

		}
		if (cancelOrderModel.getReason() == null) {

			return ResponseBean.builder().data(null).message("Please pass Reason, Reason is mandatory")
					.status(HttpStatus.BAD_REQUEST).returnCode(1).build();
		}
		return bookingsService.cancelOrderService(cancelOrderModel);
	}

	@PostMapping("/v1/reopen-order")
	public ResponseBean reOpenBooking(@RequestBody GenericBookingModel reOpenModel) {
		if (reOpenModel.getBookingId() == null || reOpenModel.getBookingId() == 0) {
			return ResponseBean.builder().data(null).message("Please pass booking Id it is mandatory")
					.status(HttpStatus.BAD_REQUEST).returnCode(1).build();
		} else if (reOpenModel.getUserId() == null) {
			return ResponseBean.builder().data(null).message("Please pass User Id it is mandatory")
					.status(HttpStatus.BAD_REQUEST).returnCode(1).build();

		}
		return bookingsService.reOpenOrder(reOpenModel);

	}

	@PostMapping(value = "/v1/confirm-order", produces = "application/json", consumes = "application/json")
	public ResponseBean confirmBooking(@RequestBody GenericBookingModel confirmBkngModel) {
		if (confirmBkngModel.getBookingId() == null || confirmBkngModel.getBookingId() == 0) {
			return ResponseBean.builder().data(null).message("Please pass booking Id as it is mandatory")
					.status(HttpStatus.BAD_REQUEST).returnCode(1).build();
		} else if (confirmBkngModel.getUserId() == null) {
			return ResponseBean.builder().data(null).message("Please pass User Id as it is mandatory")
					.status(HttpStatus.BAD_REQUEST).returnCode(1).build();

		}
		return bookingsService.confirmBooking(confirmBkngModel);

	}

	@GetMapping(value = "/v1/get-recmnd-quty-by-store")
	public ResponseBean getRcmndQutyBySid(@RequestParam(value = "storeId") Long storeId,
			@RequestParam(value = "productId", required = false) Long productId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<RecmndQtyDTO> rcmndQutyDTO = bookingsService.getRcmndQutyByStoreId(storeId, productId);
			if (rcmndQutyDTO != null) {
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setMessage("Recommended Quty fetched successfully");
				responseBean.setData(rcmndQutyDTO);
				responseBean.setReturnCode(1);
			} else {
				log.info(" No Records Found in Recommended Quty ");
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setMessage(" No Records Found in Recommended Quty");
				responseBean.setReturnCode(1);
			}
		} catch (Exception e) {
			log.error("Exception Occured in Recommended Quty" + e.getMessage());
			responseBean.setMessage("something went wrong");
			responseBean.setReturnCode(0);
		}

		return responseBean;
	}

	@PostMapping(value = "/v1/get-recmnd-quty-by-stores")
	public ResponseBean getRcmndQutyByStores(@RequestBody List<Long> storeIds) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<RecmndQtyDTO> rcmndQutyDTO = bookingsService.getRcmndQutyByStores(storeIds);
			if (rcmndQutyDTO != null) {
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setMessage("Recommended Quty fetched successfully");
				responseBean.setData(rcmndQutyDTO);
				responseBean.setReturnCode(1);
			} else {
				log.info(" No Records Found in Recommended Quty ");
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setMessage(" No Records Found in Recommended Quty");
				responseBean.setReturnCode(1);
			}
		} catch (Exception e) {
			log.error("Exception Occured in Recommended Quty" + e.getMessage());
			responseBean.setMessage("something went wrong");
			responseBean.setReturnCode(0);
		}
		return responseBean;
	}

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class UpdateBookingModel {
		private Long userId;
		private Long bookingId;
		private Date requiredByDate;
		private Date estimatedDateOfArvl;
		private String issuseRefNo;
		private Integer bookingBadge;
		private String comments;

	}

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class BookingsByFilterPayload {
		private Long pranthId;
		private String recevingStoreName;
		private String issuingStoreName;
		private String status;
		private Date fromDate;
		private Date toDate;
		private Long bookingId;
		private String issueReferenceId;
		private String receiptReferenceId;
		private String approvalStatus;
		private Long bookingBadgeId;
		private Long storeBadgeId;
		private Integer indentTypeId;
		private Long storeId;
	}
	
	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class BookingsExportModel {
		private BookingsByFilterPayload bookingsByFilterPayload;
		private Long pranthId;
		private Long userId;
		private String userName;
		private String email;
		private List<Long> offsetStoreIds;
	}

	@Data
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class BookingByFilterDetails {
		private List<BookingsFilterDTO> bookingFilterDTOs;
		private Long totalRecordsCount;
	}

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class BookingsFilterDTO {
		private Long pranthId;
		private Long bookingId;
		private Long bookingItemsCount;
		private String status;
		private Long statusId;
		private Long recevingStoreId;
		private String recevingStoreName;
		private String recevingStoreLocation;
		private String createdBy;
		private Date createdOn;
		private Long issuingStoreId;
		private String issuingStoreName;
		private String issuingStoreLocation;
		private String bookingBadge;
		private Integer bookingBadgeId;
		private Integer sourceType;
		private Integer indentTypeId;
	}

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class RecmndQtyDTO {
		private Long productId;
		private Long recmndQty;
		private Long stroreId;
	}

	@Data
	@NoArgsConstructor
	@Builder
	@AllArgsConstructor
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class UpdateOrderProductModel {
		private Long userId;
		private Long bookingId;
		private Date UpdatedDate;
		private Long PranthId;
		private Long issuingStoreId;
		private List<BookingProducts> bookingItems;
	}

}