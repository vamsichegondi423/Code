package com.dipl.evin2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.AssetModelSensorMapping;
import com.dipl.evin2.repository.AssetModelSensorMappingRepository;

@Service
public class AssetModelSensorMappingService {

	@Autowired
	private AssetModelSensorMappingRepository assetModelSensorMappingRepository;

	public AssetModelSensorMapping getById(Long id) {
		Optional<AssetModelSensorMapping> assetModelSensorMappingOptional = assetModelSensorMappingRepository.getById(id);
		if (assetModelSensorMappingOptional.isPresent()) {
			return assetModelSensorMappingOptional.get();
		} else {
			return null;
		}
	}

	public AssetModelSensorMapping save(AssetModelSensorMapping assetModelSensorMapping) {
		if (assetModelSensorMapping.getId() != null && assetModelSensorMapping.getId() > 0) {
			Optional<AssetModelSensorMapping> existingAssetModelSensorMappingRecord = assetModelSensorMappingRepository.getById(assetModelSensorMapping.getId());
			if (existingAssetModelSensorMappingRecord.isPresent()) {
				return assetModelSensorMappingRepository.save(assetModelSensorMapping);
			}
		} else {
			assetModelSensorMapping = assetModelSensorMappingRepository.save(assetModelSensorMapping);
		}
		return assetModelSensorMapping;
	}

	public Integer deleteById(Long id) {
		Optional<AssetModelSensorMapping> existingAssetModelSensorMappingRecord = assetModelSensorMappingRepository.getById(id);
		if (existingAssetModelSensorMappingRecord.isPresent()) {
			assetModelSensorMappingRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}

	public List<AssetModelSensorMapping> getAll() {
			return assetModelSensorMappingRepository.findAll();
	}

	public List<AssetModelSensorMapping> getByAssetModel(Long assetModelId) {
		return assetModelSensorMappingRepository.getByAssetModel(assetModelId);
	}
}