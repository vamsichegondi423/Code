package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dipl.evin2.entity.Store;

@Repository
public interface MasterStoreRepository extends JpaRepository<Store, Long>{	
	
	@Query(value = "select distinct s.id as storeId,s.name as storeName,sb.store_tag from store s "
			+ " left join (select store_id,b.id,string_agg(b.name,',') as store_tag from store_badge sb join badge b on sb.badge_id=b.id "
			+ " where sb.is_deleted=false group by 1,2)sb on s.id=sb.store_id "
			+ " left join store_users su on s.id= su.store_id and su.is_deleted=false "
			+ " left join users u on u.id = su.user_id and u.is_deleted = false "
			+ " where s.is_deleted=false and s.state_id=?1 and sb.id=53 and store_tag is not null ", nativeQuery = true)
	public List<Map<String, Object>> findStoreByStateId(Integer stateId);

	@Query(value = "select distinct s.id as storeId,s.name as storeName,sb.store_tag from store s "
			+ " left join (select store_id,b.id,string_agg(b.name,',') as store_tag from store_badge sb join badge b on sb.badge_id=b.id "
			+ " where sb.is_deleted=false group by 1,2)sb on s.id=sb.store_id "
			+ " left join store_users su on s.id=su.store_id and su.is_deleted=false "
			+ " left join users u on u.id = su.user_id and u.is_deleted = false "
			+ " where s.is_deleted=false and s.state_id=?1 and s.district_id=?2 and  sb.id=53 and store_tag is not null ", nativeQuery = true)
	public List<Map<String, Object>> findStoreByStateAndDistricAndStoreId(Integer stateId,Integer districtId);
}