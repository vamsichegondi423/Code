package com.dipl.evin2.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dipl.evin2.dto.TxnWithBatchDTO;
import com.dipl.evin2.model.ExportTransactionModel;
import com.dipl.evin2.model.ExportTxnModel;
import com.dipl.evin2.model.FileReportResponse;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.JdbcTemplateHelper;
import com.dipl.evin2.util.KafkaProducer;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ExportTransactionService {

	@Autowired
	private SendEmailService sendEmailService;
	@Autowired
	private UploadFileService uploadFileService;
	@Autowired
	private PranthHierarchyService pranthHierarchyService;
	@Autowired
	private JdbcTemplateHelper jdbcTemplateHelper;
//	@Autowired
//	private KafkaProducer kafkaProducer;
	@Autowired
	@Lazy
	private ExportExcelAsyncService exportExcelAsyncService;

	@Value("${DBURL}")
	private String dbUrl;

	@Value("${DBUSERNAME}")
	private String dbUserName;

	@Value("${DBPASSWORD}")
	private String dbPassword;

	public ResponseBean getTransactionService(ExportTxnModel transactionsPayload, Long pranthId, Long userId,
			String userName, String email, List<Long> offsetStoreIds) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		try {
			ExportTransactionModel exportTransactionModel = new ExportTransactionModel();
			this.setTransactionData(exportTransactionModel, transactionsPayload, pranthId, userId, userName, email,
					offsetStoreIds);
			// getTransactionDataWithoutBatch(transactionsPayload, pranthId, userId,
			// userName, email, offsetStoreIds);
			exportExcelAsyncService.getTransactionDataWithoutBatch(transactionsPayload, pranthId, userId, userName,
					email, offsetStoreIds);
			// kafkaProducer.sendTxnDataWithoutBatchToProducer(exportTransactionModel);
			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
					+ email
					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
			responsebean.setReturnCode(1);
			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting transacton report : ", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting transacton report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		return responsebean;
	}

	void setTransactionData(ExportTransactionModel exportTransactionModel, ExportTxnModel transactionsPayload,
			Long pranthId, Long userId, String userName, String email, List<Long> offsetStoreIds) {
		exportTransactionModel.setExportTxnModel(transactionsPayload);
		exportTransactionModel.setPranthId(pranthId);
		exportTransactionModel.setUserId(userId);
		exportTransactionModel.setUserName(userName);
		exportTransactionModel.setEmail(email);
		exportTransactionModel.setOffsetStoreIds(offsetStoreIds);
	}

	public void getTransactionDataWithoutBatch(ExportTxnModel transactionsPayload, Long pranthId, Long userId,
			String userName, String email, List<Long> offsetStoreIds) throws IOException {

		ResponseBean responsebean = new ResponseBean();
		List<TxnWithBatchDTO> transactions = null;
		Object fileData;
		String url = null;
		Workbook workbook = null;
		Sheet sheet = null;
		FileOutputStream outputStream = null;
		String updatedOn = null;
		try {
			transactions = getAllStoresByTransactionLevelWithOutBatch(transactionsPayload, userName, email, pranthId,
					userId, offsetStoreIds);
			// creating workbook
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0, cellIndex2 = 0, cellIndex3 = 0, cellIndex4 = 0;
			// Creating row
			Row row = sheet.createRow(0);

			row.createCell(cellIndex++).setCellValue("Title");
			row.createCell(cellIndex++).setCellValue("" + Constants.transaction + "");
			Row row1 = sheet.createRow(1);
			row1.createCell(cellIndex1++).setCellValue("Generated on");
			row1.createCell(cellIndex1++).setCellValue("" + uploadFileService.dateWithHoursMinutes());

			Connection connection = getConnection(dbUrl, dbUserName, dbPassword);
			Statement statement = connection.createStatement();
			String sql = "select j.jobname, max(r.start_time) as updated_on from cron.job j join cron.job_run_details r on j.jobid=r.jobid "
					+ "where r.status='succeeded'  and j.jobname = 'mvw_export_txn' group by 1 ";
			ResultSet resultSet = statement.executeQuery(sql);

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			while (resultSet.next()) {
				updatedOn = formatter.format(resultSet.getTimestamp("updated_on"));
			}
			log.info("" + updatedOn);

			Row row2 = sheet.createRow(2);
			row2.createCell(cellIndex4++).setCellValue("Data Updated On");
			row2.createCell(cellIndex4++).setCellValue("" + updatedOn);

			StringBuilder filterString = new StringBuilder();
			if (transactionsPayload.getTxnType() != null && !transactionsPayload.getTxnType().isEmpty()) {
				filterString.append("Type : " + transactionsPayload.getTxnType());
			}
			String storeTagNames = null;
			Set<String> storeBadges = new HashSet<>();

			for (TxnWithBatchDTO txns : transactions) {
				storeTagNames = txns.getStoreBadges();
				storeBadges.add(storeTagNames);

			}
			if (transactionsPayload.getStoreBadge() != null) {
				filterString.append(" Facility Tag : " + StringUtils.join(storeBadges, ",") + "  ");
			}

			log.info("" + storeBadges);

			String materialTagNames = null;
			Set<String> uniqueMaterialBadges = new HashSet<>();

			for (TxnWithBatchDTO txns : transactions) {
				materialTagNames = txns.getMaterialBadges();
				uniqueMaterialBadges.add(materialTagNames);

			}
			log.info("" + uniqueMaterialBadges);
			if (transactionsPayload.getProductBadge() != null) {

				filterString.append("Material Tag :  " + StringUtils.join(uniqueMaterialBadges, ",") + "  ");

			}
			if (transactionsPayload.getTxnReason() != null) {
				filterString.append(" Txn Reason :" + transactionsPayload.getTxnReason());
			}
			if (transactionsPayload.getIsActualTxn() != null && transactionsPayload.getIsActualTxn() == true) {
				filterString.append(" Filter by date of actual transaction : " + transactionsPayload.getIsActualTxn());
			} else {
				filterString.append(" Filter by date of actual transaction : " + false);
			}
			if (transactionsPayload.getTxnsFromDate() != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				filterString.append(" From Date : " + dateFormat.format(transactionsPayload.getTxnsFromDate()));
			}
			if (transactionsPayload.getTxnsToDate() != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				filterString.append(" To Date : " + dateFormat.format(transactionsPayload.getTxnsToDate()));
			}
			String stateNames = null;
			Set<String> states = new HashSet<>();

			for (TxnWithBatchDTO txns : transactions) {
				stateNames = txns.getStateName();
				states.add(stateNames);

			}
			log.info("" + states);
			if (transactionsPayload.getState() != null) {
				filterString.append(" State : " + StringUtils.join(states, ",") + "  ");
			}
			String districtNames = null;
			Set<String> districts = new HashSet<>();

			for (TxnWithBatchDTO txns : transactions) {
				districtNames = txns.getDistrictName();
				districts.add(districtNames);

			}
			log.info("" + districts);
			if (transactionsPayload.getDistrict() != null) {
				filterString.append(" District : " + StringUtils.join(districts, ",") + "  ");

			}
			if (transactionsPayload.getBlock() != null) {
				filterString.append(" Block : " + "");

			}

			Row filterRow = sheet.createRow(3);
			filterRow.createCell(cellIndex2++).setCellValue("filter");
			filterRow.createCell(cellIndex2++).setCellValue("" + filterString);

			// Creating Headers/Columns
			Row row3 = sheet.createRow(5);

			row3.createCell(cellIndex3++).setCellValue("Transaction ID");
			row3.createCell(cellIndex3++).setCellValue("Transaction Type");
			row3.createCell(cellIndex3++).setCellValue("Tracking Object Type");
			row3.createCell(cellIndex3++).setCellValue("Tracking No");
			row3.createCell(cellIndex3++).setCellValue("Store id");
			row3.createCell(cellIndex3++).setCellValue("Store Name");
			row3.createCell(cellIndex3++).setCellValue("Store tag");
			row3.createCell(cellIndex3++).setCellValue("Material ID");
			row3.createCell(cellIndex3++).setCellValue("Material Name");
			row3.createCell(cellIndex3++).setCellValue("Material Tag");
			row3.createCell(cellIndex3++).setCellValue("Opening Stock");
			row3.createCell(cellIndex3++).setCellValue("Qunaity");
			row3.createCell(cellIndex3++).setCellValue("Closing Stock");
			row3.createCell(cellIndex3++).setCellValue("Reason");
			row3.createCell(cellIndex3++).setCellValue("Material Status");
			row3.createCell(cellIndex3++).setCellValue("updated on");
			row3.createCell(cellIndex3++).setCellValue("Date of actual transaction");
			row3.createCell(cellIndex3++).setCellValue("Receiving Store ID");
			row3.createCell(cellIndex3++).setCellValue("Receiving store name");
			row3.createCell(cellIndex3++).setCellValue("Country");
			row3.createCell(cellIndex3++).setCellValue("State");
			row3.createCell(cellIndex3++).setCellValue("District");
			row3.createCell(cellIndex3++).setCellValue("Taluk/Block");
			row3.createCell(cellIndex3++).setCellValue("Village/City");
			row3.createCell(cellIndex3++).setCellValue("Zip/PIN code");
			row3.createCell(cellIndex3++).setCellValue("Latitude");
			row3.createCell(cellIndex3++).setCellValue("Longitude");
			row3.createCell(cellIndex3++).setCellValue("Transaction source");
			row3.createCell(cellIndex3++).setCellValue("Created by ID");
			row3.createCell(cellIndex3++).setCellValue("Created by full name");

			// Displaying data under headers
			for (int i = 0; i < transactions.size(); i++) {
				Row dataRow = sheet.createRow(i + 6);
				int rowIndex1 = 0;

				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTransactionId() == null ? ""
						: transactions.get(i).getTransactionId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTransactionType() == null ? ""
						: transactions.get(i).getTransactionType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTrackingObjectType() == null ? ""
						: transactions.get(i).getTrackingObjectType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getTrackingNo() == null ? "" : transactions.get(i).getTrackingNo() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getStoreId() == null ? "" : transactions.get(i).getStoreId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getStoreName() == null ? "" : transactions.get(i).getStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getStoreBadges() == null ? "" : transactions.get(i).getStoreBadges() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getProductId() == null ? "" : transactions.get(i).getProductId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getProductName() == null ? "" : transactions.get(i).getProductName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getMaterialBadges() == null ? ""
						: transactions.get(i).getMaterialBadges() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getOpeningStock() == null ? 0 : transactions.get(i).getOpeningStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getQuantity() == null ? 0 : transactions.get(i).getQuantity());
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getClosingStock() == null ? 0 : transactions.get(i).getClosingStock());
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTransactionReason() == null ? ""
						: transactions.get(i).getTransactionReason() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getMaterialReason() == null ? ""
						: transactions.get(i).getMaterialReason() + "");

				Cell cell = dataRow.createCell(rowIndex1++);
				cell.setCellValue(
						transactions.get(i).getUpdatedOn() == null ? null : transactions.get(i).getUpdatedOn());
				cell.setCellStyle(dateCellStyle);

				Cell cell1 = dataRow.createCell(rowIndex1++);
				cell1.setCellValue(transactions.get(i).getActualTransactionDate() == null ? null
						: transactions.get(i).getActualTransactionDate());
				cell1.setCellStyle(dateCellStyle);

				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getReceivingStoreId() == null ? ""
						: transactions.get(i).getReceivingStoreId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getReceivingStoreName() == null ? ""
						: transactions.get(i).getReceivingStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getCountryName() == null ? "" : transactions.get(i).getCountryName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getStateName() == null ? "" : transactions.get(i).getStateName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getDistrictName() == null ? ""
						: transactions.get(i).getDistrictName() + "");
				dataRow.createCell(rowIndex1++).setCellValue("");
				dataRow.createCell(rowIndex1++)
						.setCellValue(transactions.get(i).getCity() == null ? "" : transactions.get(i).getCity() + "");
				dataRow.createCell(rowIndex1++)
						.setCellValue(transactions.get(i).getPin() == null ? "" : transactions.get(i).getPin() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getLatitude() == null ? "" : transactions.get(i).getLatitude() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getLongitude() == null ? "" : transactions.get(i).getLongitude() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getSourceType() == null ? "" : transactions.get(i).getSourceType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getCreatedBy() == null ? "" : transactions.get(i).getCreatedBy() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getFullName() == null ? "" : transactions.get(i).getFullName() + "");
			}
			// creating temporary excel file
			File tempFile = null;
			tempFile = File.createTempFile("TransactionReport", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
			workbook.write(outputStream);

			// upload excel file
			HttpResponse<String> response = uploadFileService.uploadFile(url, userName, tempFile, "Transactions");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			// deleting temporary excel file
			tempFile.delete();

			HashMap<String, Object> emailbody = new HashMap<>();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";
			// sending excel file to user's email
			emailbody = sendEmailService.getTransactionEmail(link, userName, email);

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, email, userName,
					fileDownloadUrl, fileType, fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ email
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting transacton report : ", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting transacton report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		} finally {

			outputStream.close();
			workbook.close();
		}
//		return responsebean;
	}

	public List<TxnWithBatchDTO> getAllStoresByTransactionLevelWithOutBatch(ExportTxnModel txnPayload, String userName,
			String email, Long pranthId, Long userId, List<Long> offsetStoreIds) throws Exception {
		Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(txnPayload.getPranthId());
		List<TxnWithBatchDTO> fetchStoresList = null;
		StringBuilder builder = new StringBuilder();

		builder.append(" select transactionId,transactionType, TrackingObjectType,trackingNo, state_id, district_id,"
				+ " block_id,storeId,storeName,store_badge_id,storeBadges, "
				+ " productId, productName,product_badge_id, materialBadges,isBatchEnable, openingStock,quantity,"
				+ " closingStock, transactionReason,materialReason, "
				+ " updatedOn,actualTransactionDate, receivingStoreId,receivingStoreName,expriedDate, "
				+ " countryName, stateName,districtName,city,pin,latitude,longitude,"
				+ "sourceType,createdBy,userId,fullName, createdOn from mvw_export_txn ");
		addFiltersForGetAllTxnsWithOutBatch(txnPayload, consolidatedPranthIds, builder, offsetStoreIds, userId,
				pranthId);
		builder.append(" ORDER by createdon DESC");
		log.info(builder.toString());
		try {
			fetchStoresList = jdbcTemplateHelper.getResults(builder.toString(), TxnWithBatchDTO.class);
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
			throw new Exception("Exception occured while get the tnx ", e.getCause());
		}
		return fetchStoresList;
	}

	private void addFiltersForGetAllTxnsWithOutBatch(ExportTxnModel transactionsPayload,
			Set<Long> consolidatedPranthIds, StringBuilder builder, List<Long> totalStoreIds, Long userId,
			Long pranthId) throws JsonMappingException, JsonProcessingException {

		if (consolidatedPranthIds != null && !consolidatedPranthIds.isEmpty()) {

			builder.append("where pranth_id in  ( " + StringUtils.join(consolidatedPranthIds, ",") + " ) ");
		}
		if (totalStoreIds != null && !totalStoreIds.isEmpty()) {
			builder.append(" and storeId in ( " + StringUtils.join(totalStoreIds, " ,") + ")");
		}
		if (transactionsPayload.getStoreId() != null) {
			builder.append(" and storeId = " + transactionsPayload.getStoreId() + " ");
		}
		if (transactionsPayload.getProductId() != null) {
			builder.append(" and productId = " + transactionsPayload.getProductId() + " ");
		}
		if (transactionsPayload.getTxnType() != null && !transactionsPayload.getTxnType().isEmpty()) {
			builder.append(" and transactiontype = '" + transactionsPayload.getTxnType() + "' ");
		}
		if (transactionsPayload.getStoreBadge() != null && (!transactionsPayload.getStoreBadge().isEmpty())) {
			builder.append(
					" and store_badge_id  in (" + StringUtils.join(transactionsPayload.getStoreBadge(), ",") + ")");
		}
		if (transactionsPayload.getProductBadge() != null && (!transactionsPayload.getProductBadge().isEmpty())) {
			builder.append(
					" and product_badge_id  in (" + StringUtils.join(transactionsPayload.getProductBadge(), ",") + ")");
		}

		if (transactionsPayload.getTxnReason() != null) {
			builder.append(" and transactionreason = '" + transactionsPayload.getTxnReason() + "' ");
		}
		if (transactionsPayload.getIsActualTxn() != null && transactionsPayload.getIsActualTxn() == true) {
			// builder.append(" and tx.initial_txn_date is not null ");
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			builder.append(" and actualtransactiondate between " + "'"
					+ dateFormat.format(transactionsPayload.getTxnsFromDate()) + "' and " + "'"
					+ dateFormat.format(transactionsPayload.getTxnsToDate()) + "'");

			// builder.append(" and tx.is_deleted=false ");
		} else if (transactionsPayload.getIsActualTxn() != null && transactionsPayload.getIsActualTxn() == false) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			builder.append(" and createdon between " + "'" + dateFormat.format(transactionsPayload.getTxnsFromDate())
					+ "' and " + "'" + dateFormat.format(transactionsPayload.getTxnsToDate()) + "'");

			// builder.append(" and tx.is_deleted=false ");
		}
		/*
		 * if (transactionsPayload.getCountry() != null) {
		 * builder.append("  and s.country_id = " + transactionsPayload.getCountry()); }
		 */
		if (transactionsPayload.getState() != null) {
			builder.append("  and state_id = " + transactionsPayload.getState());
		}
		if (transactionsPayload.getDistrict() != null) {
			builder.append("  and district_id = " + transactionsPayload.getDistrict());
		}
		if (transactionsPayload.getBlock() != null) {
			builder.append("  and block_id = " + transactionsPayload.getBlock());
		}
	}

	public ResponseBean getTransactionWithBatchService(ExportTxnModel txnPayload, String userName, String email,
			Long pranthId, Long userId, List<Long> offsetStoreIds) throws IOException {
		ResponseBean responsebean = new ResponseBean();
		try {
			ExportTransactionModel exportTransactionModel = new ExportTransactionModel();
			this.setTransactionData(exportTransactionModel, txnPayload, pranthId, userId, userName, email,
					offsetStoreIds);
//			this.getTransactionDataWithBatch(txnPayload, userName, email,
//					 pranthId, userId, offsetStoreIds);
			exportExcelAsyncService.getTransactionDataWithBatch(txnPayload, userName, email, pranthId, userId,
					offsetStoreIds);
//			kafkaProducer.sendTxnDataWithBatchToProducer(exportTransactionModel);
			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
					+ email
					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
			responsebean.setReturnCode(1);
			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting transacton report : ", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting transacton report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		}
		return responsebean;
	}

	public void getTransactionDataWithBatch(ExportTxnModel txnPayload, String userName, String email, Long pranthId,
			Long userId, List<Long> offsetStoreIds) throws IOException {
		ResponseBean responsebean = new ResponseBean();
		List<TxnWithBatchDTO> transactions = null;
		Object fileData;
		String url = null;
		Workbook workbook = null;
		Sheet sheet = null;
		FileOutputStream outputStream = null;
		String updatedOn = null;
		try {
			transactions = getAllStoresByTransactionLevelWithBatch(txnPayload, userName, email, pranthId, userId,
					offsetStoreIds);
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("ExportExCel");
			CellStyle rowCellStyle = workbook.createCellStyle();
			rowCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			CellStyle dateCellStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd hh:mm:ss"));
			int cellIndex = 0, cellIndex1 = 0, cellIndex2 = 0, cellIndex3 = 0, cellIndex4 = 0;
			// Creating row
			Row titleRow = sheet.createRow(0);

			titleRow.createCell(cellIndex++).setCellValue("Title");
			titleRow.createCell(cellIndex++).setCellValue("" + Constants.transaction + "");

			Row dateRow = sheet.createRow(1);
			dateRow.createCell(cellIndex1++).setCellValue("Generated on");
			dateRow.createCell(cellIndex1++).setCellValue("" + uploadFileService.dateWithHoursMinutes());

			Connection connection = getConnection(dbUrl, dbUserName, dbPassword);
			Statement statement = connection.createStatement();
			String sql = "select j.jobname, max(r.start_time) as updated_on from cron.job j join cron.job_run_details r on j.jobid=r.jobid "
					+ "where r.status='succeeded'  and j.jobname = 'mvw_export_txn' group by 1 ";
			ResultSet resultSet = statement.executeQuery(sql);

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			while (resultSet.next()) {
				updatedOn = formatter.format(resultSet.getTimestamp("updated_on"));
			}
			log.info("" + updatedOn);

			Row row2 = sheet.createRow(2);
			row2.createCell(cellIndex4++).setCellValue("Data Updated On");
			row2.createCell(cellIndex4++).setCellValue("" + updatedOn);

			StringBuilder filterString = new StringBuilder();
			if (txnPayload.getTxnType() != null && !txnPayload.getTxnType().isEmpty()) {
				filterString.append("Type : " + txnPayload.getTxnType());
			}
			String storeTagNames = null;
			Set<String> storeBadges = new HashSet<>();

			for (TxnWithBatchDTO txns : transactions) {
				storeTagNames = txns.getStoreBadges();
				storeBadges.add(storeTagNames);

			}
			if (txnPayload.getStoreBadge() != null) {
				filterString.append(" Facility Tag : " + StringUtils.join(storeBadges, ",") + "  ");
			}

			log.info("" + storeBadges);

			String materialTagNames = null;
			Set<String> uniqueMaterialBadges = new HashSet<>();

			for (TxnWithBatchDTO txns : transactions) {
				materialTagNames = txns.getMaterialBadges();
				uniqueMaterialBadges.add(materialTagNames);

			}
			log.info("" + uniqueMaterialBadges);
			if (txnPayload.getProductBadge() != null) {

				filterString.append("Material Tag :  " + StringUtils.join(uniqueMaterialBadges, ",") + "  ");

			}
			if (txnPayload.getTxnReason() != null) {
				filterString.append(" Txn Reason :" + txnPayload.getTxnReason());
			}
			if (txnPayload.getIsActualTxn() != null && txnPayload.getIsActualTxn() == true) {
				filterString.append(" Filter by date of actual transaction : " + txnPayload.getIsActualTxn());
			} else {
				filterString.append(" Filter by date of actual transaction : " + false);
			}
			if (txnPayload.getTxnsFromDate() != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				filterString.append(" From Date : " + dateFormat.format(txnPayload.getTxnsFromDate()));
			}
			if (txnPayload.getTxnsToDate() != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				filterString.append(" To Date : " + dateFormat.format(txnPayload.getTxnsToDate()));
			}
			String stateNames = null;
			Set<String> states = new HashSet<>();

			for (TxnWithBatchDTO txns : transactions) {
				stateNames = txns.getStateName();
				states.add(stateNames);

			}
			log.info("" + states);
			if (txnPayload.getState() != null) {
				filterString.append(" State : " + StringUtils.join(states, ",") + "  ");
			}
			String districtNames = null;
			Set<String> districts = new HashSet<>();

			for (TxnWithBatchDTO txns : transactions) {
				districtNames = txns.getDistrictName();
				districts.add(districtNames);

			}
			log.info("" + districts);
			if (txnPayload.getDistrict() != null) {
				filterString.append(" District : " + StringUtils.join(districts, ",") + "  ");

			}
			if (txnPayload.getBlock() != null) {
				filterString.append(" Block : " + "");

			}

			Row filterRow = sheet.createRow(3);
			filterRow.createCell(cellIndex2++).setCellValue("filter");
			filterRow.createCell(cellIndex2++).setCellValue("" + filterString);

			// Creating Headers/Columns
			Row headerRow = sheet.createRow(5);

			headerRow.createCell(cellIndex3++).setCellValue("Transaction ID");
			headerRow.createCell(cellIndex3++).setCellValue("Transaction Type");
			headerRow.createCell(cellIndex3++).setCellValue("Tracking Object Type");
			headerRow.createCell(cellIndex3++).setCellValue("Tracking No");
			headerRow.createCell(cellIndex3++).setCellValue("Store id");
			headerRow.createCell(cellIndex3++).setCellValue("Store Name");
			headerRow.createCell(cellIndex3++).setCellValue("Store tag");
			headerRow.createCell(cellIndex3++).setCellValue("Material ID");
			headerRow.createCell(cellIndex3++).setCellValue("Material Name");
			headerRow.createCell(cellIndex3++).setCellValue("Material Tag");
			headerRow.createCell(cellIndex3++).setCellValue("Opening Stock");
			headerRow.createCell(cellIndex3++).setCellValue("Qunaity");
			headerRow.createCell(cellIndex3++).setCellValue("Closing Stock");
			headerRow.createCell(cellIndex3++).setCellValue("Reason");
			headerRow.createCell(cellIndex3++).setCellValue("Material Status");
			headerRow.createCell(cellIndex3++).setCellValue("updated on");
			headerRow.createCell(cellIndex3++).setCellValue("Date of actual transaction");
			headerRow.createCell(cellIndex3++).setCellValue("Receiving Store ID");
			headerRow.createCell(cellIndex3++).setCellValue("Receiving store name");
			headerRow.createCell(cellIndex3++).setCellValue("Batch ID");
			headerRow.createCell(cellIndex3++).setCellValue("Batch Expiry");
			headerRow.createCell(cellIndex3++).setCellValue("Batch Manufacturer");
			headerRow.createCell(cellIndex3++).setCellValue("Batch Manufacture date");
			headerRow.createCell(cellIndex3++).setCellValue("Opening stock of batch");
			headerRow.createCell(cellIndex3++).setCellValue("Closing stock of batch");
			headerRow.createCell(cellIndex3++).setCellValue("Country");
			headerRow.createCell(cellIndex3++).setCellValue("State");
			headerRow.createCell(cellIndex3++).setCellValue("District");
			headerRow.createCell(cellIndex3++).setCellValue("Taluk/Block");
			headerRow.createCell(cellIndex3++).setCellValue("Village/City");
			headerRow.createCell(cellIndex3++).setCellValue("Zip/PIN code");
			headerRow.createCell(cellIndex3++).setCellValue("Latitude");
			headerRow.createCell(cellIndex3++).setCellValue("Longitude");
			headerRow.createCell(cellIndex3++).setCellValue("Transaction source");
			headerRow.createCell(cellIndex3++).setCellValue("Created by ID");
			headerRow.createCell(cellIndex3++).setCellValue("Created by full name");
			// Displaying data under headers
			for (int i = 0; i < transactions.size(); i++) {
				Row dataRow = sheet.createRow(i + 6);
				int rowIndex1 = 0;

				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTransactionId() == null ? ""
						: transactions.get(i).getTransactionId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTransactionType() == null ? ""
						: transactions.get(i).getTransactionType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTrackingObjectType() == null ? ""
						: transactions.get(i).getTrackingObjectType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getTrackingNo() == null ? "" : transactions.get(i).getTrackingNo() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getStoreId() == null ? "" : transactions.get(i).getStoreId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getStoreName() == null ? "" : transactions.get(i).getStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getStoreBadges() == null ? "" : transactions.get(i).getStoreBadges() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getProductId() == null ? "" : transactions.get(i).getProductId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getProductName() == null ? "" : transactions.get(i).getProductName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getMaterialBadges() == null ? ""
						: transactions.get(i).getMaterialBadges() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getOpeningStock() == null ? 0 : transactions.get(i).getOpeningStock());
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getQuantity() == null ? 0 : transactions.get(i).getQuantity());
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getClosingStock() == null ? 0 : transactions.get(i).getClosingStock());
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getTransactionReason() == null ? ""
						: transactions.get(i).getTransactionReason() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getMaterialReason() == null ? ""
						: transactions.get(i).getMaterialReason() + "");
				Cell cell = dataRow.createCell(rowIndex1++);
				cell.setCellValue(
						transactions.get(i).getUpdatedOn() == null ? null : transactions.get(i).getUpdatedOn());
				cell.setCellStyle(dateCellStyle);

				Cell cell1 = dataRow.createCell(rowIndex1++);
				cell1.setCellValue(transactions.get(i).getActualTransactionDate() == null ? null
						: transactions.get(i).getActualTransactionDate());
				cell1.setCellStyle(dateCellStyle);

				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getReceivingStoreId() == null ? ""
						: transactions.get(i).getReceivingStoreId() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getReceivingStoreName() == null ? ""
						: transactions.get(i).getReceivingStoreName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getBatchId() == null ? "" : transactions.get(i).getBatchId() + "");
				Cell cell2 = dataRow.createCell(rowIndex1++);
				cell2.setCellValue(
						transactions.get(i).getExpriedDate() == null ? null : transactions.get(i).getExpriedDate());
				cell2.setCellStyle(dateCellStyle);

				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getBatchManufacturerName() == null ? ""
						: transactions.get(i).getBatchManufacturerName() + "");

				Cell cell3 = dataRow.createCell(rowIndex1++);
				cell3.setCellValue(transactions.get(i).getManufacturedDate() == null ? null
						: transactions.get(i).getManufacturedDate());
				cell3.setCellStyle(dateCellStyle);

				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getOpeningStockBatch() == null ? 0
						: transactions.get(i).getOpeningStockBatch());
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getClosingStockBatch() == null ? 0
						: transactions.get(i).getClosingStockBatch());
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getCountryName() == null ? "" : transactions.get(i).getCountryName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getStateName() == null ? "" : transactions.get(i).getStateName() + "");
				dataRow.createCell(rowIndex1++).setCellValue(transactions.get(i).getDistrictName() == null ? ""
						: transactions.get(i).getDistrictName() + "");
				dataRow.createCell(rowIndex1++).setCellValue("");
				dataRow.createCell(rowIndex1++)
						.setCellValue(transactions.get(i).getCity() == null ? "" : transactions.get(i).getCity() + "");
				dataRow.createCell(rowIndex1++)
						.setCellValue(transactions.get(i).getPin() == null ? "" : transactions.get(i).getPin() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getLatitude() == null ? "" : transactions.get(i).getLatitude() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getLongitude() == null ? "" : transactions.get(i).getLongitude() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getSourceType() == null ? "" : transactions.get(i).getSourceType() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getCreatedBy() == null ? "" : transactions.get(i).getCreatedBy() + "");
				dataRow.createCell(rowIndex1++).setCellValue(
						transactions.get(i).getFullName() == null ? "" : transactions.get(i).getFullName() + "");

			}
			// creating temporary excel file
			File tempFile = null;
			tempFile = File.createTempFile("TransactionWithBatchReport", ".xlsx");
			outputStream = new FileOutputStream(tempFile);
			workbook.write(outputStream);
			// upload excel file
			HttpResponse<String> response = uploadFileService.uploadFile(url, userName, tempFile, "Transactions");

			ObjectMapper mapper = new ObjectMapper();
			String fileResponse = response.getBody();

			HashMap<String, Object> fileResponseObj = mapper.readValue(fileResponse, HashMap.class);
			fileData = fileResponseObj.get("data");
			String fileJson = new Gson().toJson(fileData);
			FileReportResponse reportResponse = mapper.readValue(fileJson, FileReportResponse.class);
			String fileDownloadUrl = reportResponse.getFileDownloadUrl();
			String fileType = reportResponse.getFileType();
			String fileName = reportResponse.getFileName();
			String fileSystemPath = reportResponse.getFileSystemPath();

			// deleting temporary excel file
			tempFile.delete();

			HashMap<String, Object> emailbody = new HashMap<>();

			String link = "<a href=\"" + fileDownloadUrl + "\">here</a>";
			// sending excel file to user's email
			emailbody = sendEmailService.getTransactionEmail(link, userName, email);

			ResponseEntity<String> emailresponse = sendEmailService.sendemail(emailbody, email, userName,
					fileDownloadUrl, fileType, fileName, fileSystemPath);

//			responsebean.setMessage("Your request for export is successfully placed. Please check your email later at "
//					+ email
//					+ " to download the exported spreadsheet. You can track the status of the export by clicking on the My Exports link.");
//			responsebean.setReturnCode(1);
//			responsebean.setStatus(HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured while exporting transacton report : ", e);
			responsebean.setReturnCode(0);
			responsebean.setMessage("Exception occured while exporting transacton report");
			responsebean.setStatus(HttpStatus.BAD_REQUEST);
		} finally {
			workbook.close();
			outputStream.close();
		}
//		return responsebean;
	}

	public List<TxnWithBatchDTO> getAllStoresByTransactionLevelWithBatch(ExportTxnModel txnPayload, String userName,
			String email, Long pranthId, Long userId, List<Long> offsetStoreIds) throws Exception {
		Set<Long> consolidatedPranthIds = pranthHierarchyService.getConsolidatedPranthIds(txnPayload.getPranthId());
		List<TxnWithBatchDTO> fetchStoresList = null;
		StringBuilder builder = new StringBuilder();

		builder.append("select transactionId,transactionType,TrackingObjectType,trackingNo,storeName,store_badge_id,"
				+ " storeBadges,productId,productName,  "
				+ " product_badge_id,materialBadges,isBatchEnable,openingStock,quantity,closingStock,"
				+ " transactionReason,materialReason,updatedOn,"
				+ " actualTransactionDate, receivingStoreId,receivingStoreName, batchId,expriedDate,"
				+ " batchManufacturerName,manufacturedDate,openingStockBatch,closingStockBatch, countryName, stateName, "
				+ " districtName, city , pin,latitude,longitude, sourceType,createdBy,userId, "
				+ " fullName,createdOn from mvw_export_txn_with_batch ");
		addFiltersForGetAllTxnsWithBatch(txnPayload, consolidatedPranthIds, builder, offsetStoreIds, userId, pranthId);
		builder.append(" ORDER by createdOn DESC");
		log.info(builder.toString());
		try {
			fetchStoresList = jdbcTemplateHelper.getResults(builder.toString(), TxnWithBatchDTO.class);
		} catch (Exception e) {
			log.error("Exception occured : {}", e);
			throw new Exception("Exception occured while get the tnx ", e.getCause());
		}
		return fetchStoresList;
	}

	private void addFiltersForGetAllTxnsWithBatch(ExportTxnModel transactionsPayload, Set<Long> consolidatedPranthIds,
			StringBuilder builder, List<Long> totalStoreIds, Long userId, Long pranthId)
			throws JsonMappingException, JsonProcessingException {

		if (consolidatedPranthIds != null && !consolidatedPranthIds.isEmpty()) {

			builder.append("where pranth_id in  ( " + StringUtils.join(consolidatedPranthIds, ",") + " ) ");
		}
		if (totalStoreIds != null && !totalStoreIds.isEmpty()) {
			builder.append(" and storeId in ( " + StringUtils.join(totalStoreIds, " ,") + ")");
		}
		if (transactionsPayload.getStoreId() != null) {
			builder.append(" and storeId = " + transactionsPayload.getStoreId() + " ");
		}
		if (transactionsPayload.getProductId() != null) {
			builder.append(" and productId = " + transactionsPayload.getProductId() + " ");
		}
		if (transactionsPayload.getTxnType() != null && !transactionsPayload.getTxnType().isEmpty()) {
			builder.append(" and transactiontype = '" + transactionsPayload.getTxnType() + "' ");
		}
		if (transactionsPayload.getStoreBadge() != null && (!transactionsPayload.getStoreBadge().isEmpty())) {
			builder.append(
					" and store_badge_id  in (" + StringUtils.join(transactionsPayload.getStoreBadge(), ",") + ")");

		}
		if (transactionsPayload.getProductBadge() != null && (!transactionsPayload.getProductBadge().isEmpty())) {
			builder.append(
					" and product_badge_id  in (" + StringUtils.join(transactionsPayload.getProductBadge(), ",") + ")");

		}

		if (transactionsPayload.getTxnReason() != null) {
			builder.append(" and transactionreason = '" + transactionsPayload.getTxnReason() + "' ");
		}
		if (transactionsPayload.getIsActualTxn() != null && transactionsPayload.getIsActualTxn() == true) {
			// builder.append(" and tx.initial_txn_date is not null ");
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			builder.append(" and actualtransactiondate between " + "'"
					+ dateFormat.format(transactionsPayload.getTxnsFromDate()) + "' and " + "'"
					+ dateFormat.format(transactionsPayload.getTxnsToDate()) + "'");

			// builder.append(" and tx.is_deleted=false ");
		} else if (transactionsPayload.getIsActualTxn() != null && transactionsPayload.getIsActualTxn() == false) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			builder.append(" and createdOn between " + "'" + dateFormat.format(transactionsPayload.getTxnsFromDate())
					+ "' and " + "'" + dateFormat.format(transactionsPayload.getTxnsToDate()) + "'");

			// builder.append(" and tx.is_deleted=false ");
		}

		/*
		 * if (transactionsPayload.getCountry() != null) {
		 * builder.append("  and s.country_id = " + transactionsPayload.getCountry()); }
		 */
		if (transactionsPayload.getState() != null) {
			builder.append("  and state_id = " + transactionsPayload.getState());
		}
		if (transactionsPayload.getDistrict() != null) {
			builder.append("  and district_id = " + transactionsPayload.getDistrict());
		}
		if (transactionsPayload.getBlock() != null) {
			builder.append("  and block_id = " + transactionsPayload.getBlock());
		}

	}

	private static Connection getConnection(String dbUrl, String dbUserName, String dbPaswrd) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection(dbUrl, dbUserName, dbPaswrd);
			return conn;
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}