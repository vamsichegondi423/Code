package com.dipl.evin2.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BatchDetailsDTO {
	
	private Integer productId;
	private String productName;
	private String batchNo;
	private String expiryDate;
	private Integer producerId;
	private String producerName;
	private String manufacturedDate;

}
