package com.dipl.evin2.jackson;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionModel {
	
	@JsonProperty("id")
	private Long id;
	@JsonProperty("store_id")
	private Long storeId;
	@JsonProperty("linked_store_id")
	private Long linkedStoreId;
	@JsonProperty("txn_type_id")
	private Integer txnTypeId;
	@JsonProperty("products")
	private List<TransactionProductModel> products;
	@JsonProperty("batch_products")
	private List<TransactionBatchProductModel> batchProducts;
	@JsonProperty("user_id")
	private Long userId;
	@JsonProperty("source")
	private int source;
	@JsonProperty("pranth_id")
	private Long pranthId;
	@JsonProperty("txn_actual_date")
	private Date txnActualDate;
	
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class TransactionProductModel {
		@JsonProperty("product_id")
		private Integer productId;
		@JsonProperty("quantity")
		private Long quantity;
		@JsonProperty("reason_id")
		private Integer reasonId;
		@JsonProperty("material_status")
		private Integer materialStatus;
	}
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class TransactionBatchProductModel {
		
		@JsonProperty("product_id")
		private Integer productId;
		@JsonProperty("quantity")
		private Long quantity;
		@JsonProperty("expiry_date")
		private Date expiryDate;
		@JsonProperty("catalog_id")
		private Long catalogId;
		@JsonProperty("manufactured_date")
		private Date manufacturedDate;
		@JsonProperty("producer_id")
		private Integer producerId;
		@JsonProperty("reason_id")
		private Integer reasonId;
		@JsonProperty("material_status")
		private Integer materialStatus;
		@JsonProperty("batch_id")
		private String batchId;
	}
}