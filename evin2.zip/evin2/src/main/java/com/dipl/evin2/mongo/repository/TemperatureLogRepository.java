package com.dipl.evin2.mongo.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.dipl.evin2.model.TemperatureLog;
import com.dipl.evin2.model.TemperatureLogDetails;

public interface TemperatureLogRepository extends MongoRepository<TemperatureLog, String>{
	


	@Query(value = "{'data.dId' : ?0, 'data.assetDId' :?1, 'data.pwa': { $exists: true }  ,isDeleted : false }")
	List<TemperatureLog> findByDIdAndAssetDIdAndCreatedOn(String mappedSerialNumber, String assetSerialNumber);

	@Query("{'data.dId' :  ?0, 'createdOn' : {$gte :?1 ,$lt : ?2},'data.pwa' : { $exists: true }  ,'isDeleted' : false}")
	List<TemperatureLog> findByDIdAndCreatedOnAndIsDeletedFalse(String assetSerialNumber,Date fromDate, Date toDate);
	
	@Query(value = "{'data.dId' : ?0, 'data.assetDId' :?1, 'createdOn' : {$gte :?2 ,$lt : ?3}, 'data.pwa'  : { $exists: true }  ,isDeleted : false }")
	List<TemperatureLog> findByDIdAndAssetDIdAndCreatedOnAndIsDeletedFalse(String mappedSerialNumber, String assetSerialNumber, Date fromDate ,Date toDate);

	@Query("{'data.dId' :  ?0 ,'data.pwa'  : { $exists: true }  ,'isDeleted' : false}")
	List<TemperatureLog> findByDIdAndIsDeletedFalse(String assetSerialNumber);
}
