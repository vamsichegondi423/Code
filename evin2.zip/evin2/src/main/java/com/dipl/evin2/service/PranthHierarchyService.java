package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.PranthHierarchy;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.PranthHierarchyRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PranthHierarchyService {

	@Autowired
	private PranthHierarchyRepository pranthHierarchyRepository;

	@Cacheable(value = "pranth-hierarchy", key = "id")
	public PranthHierarchy getById(Long id) throws CustomException {
		try {
			Optional<PranthHierarchy> pranthHierarchyOptional = pranthHierarchyRepository.getById(id);
			if (pranthHierarchyOptional.isPresent()) {
				return pranthHierarchyOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Cacheable(value = "pranth-hierarchy", key = "#pId")
	public List<PranthHierarchy> getPranthsByPranthId(Long pId) throws CustomException {
		try {
			List<PranthHierarchy> pranthHierarchies = pranthHierarchyRepository.getPranthsByPranthId(pId);
			if (!pranthHierarchies.isEmpty()) {
				return pranthHierarchies;
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Cacheable(value = "pranth-hierarchy", key = "#parentPranthId")
	public Optional<PranthHierarchy> getByMappingId(Long parentPranthId) {
		Optional<PranthHierarchy> optional = pranthHierarchyRepository.findByMappingId(parentPranthId);
		return optional;
	}

	@CacheEvict(value = "pranth-hierarchy", allEntries = true)
	public PranthHierarchy save(PranthHierarchy pranthHierarchy) throws CustomException {
		try {
			if (pranthHierarchy.getId() != null && pranthHierarchy.getId() > 0) {
				Optional<PranthHierarchy> existingPranthHierarchyRecord = pranthHierarchyRepository
						.getById(pranthHierarchy.getId());
				if (existingPranthHierarchyRecord.isPresent()) {
					return  pranthHierarchyRepository.save(pranthHierarchy);
				}
			} else {
				pranthHierarchy = pranthHierarchyRepository.save(pranthHierarchy);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return pranthHierarchy;
	}

	@CacheEvict(value = "pranth-hierarchy", allEntries = true)
	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<PranthHierarchy> existingPranthHierarchyRecord = pranthHierarchyRepository.getById(id);
			if (existingPranthHierarchyRecord.isPresent()) {
				pranthHierarchyRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Cacheable(value = "pranth-hierarchy")
	public List<PranthHierarchy> getAll() throws CustomException {
		List<PranthHierarchy> hierarchies = new ArrayList<PranthHierarchy>();
		try {
			hierarchies = pranthHierarchyRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return hierarchies;
	}

	@Cacheable(value = "pranth-hierarchy", key = "#prId")
	public Set<Long> getConsolidatedPranthIds(Long prId) throws CustomException {
		try {
			Set<Long> consolidatePranthIds = pranthHierarchyRepository.getConsolodatedDomainIds(prId);
			consolidatePranthIds.add(prId);
			return consolidatePranthIds;
		} catch (Exception e) {
			log.error("Exception occured : ", e);
			throw new CustomException("Exception occured : {} "+e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public String buildQuery(Set<Long> consolidatedPranthIds) {
		int i = 0;
		StringBuilder consolidatedPranthsBuilder = new StringBuilder();
		consolidatedPranthsBuilder.append("(");
		for (Long e : consolidatedPranthIds) {
			consolidatedPranthsBuilder.append(e.toString());
			if (i < consolidatedPranthIds.size() - 1) {
				consolidatedPranthsBuilder.append(",");
			}
			i++;
		}
		return consolidatedPranthsBuilder.append(")").toString();
	}


}