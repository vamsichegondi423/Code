package com.dipl.evin2.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.dipl.evin2.dto.TxnDTO;
import com.dipl.evin2.entity.ClosingStockLog;
import com.dipl.evin2.entity.Icatalogue;
import com.dipl.evin2.entity.IcatalogueBatch;
import com.dipl.evin2.entity.IcatalogueLog;
import com.dipl.evin2.entity.Product;
import com.dipl.evin2.entity.ReportSyncStatus;
import com.dipl.evin2.entity.ReportTxns;
import com.dipl.evin2.entity.Txn;
import com.dipl.evin2.entity.TxnConsumptionLog;
import com.dipl.evin2.entity.TxnCountLog;
import com.dipl.evin2.entity.TxnLog;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.jackson.TransactionModel;
import com.dipl.evin2.jackson.TransactionModel.TransactionBatchProductModel;
import com.dipl.evin2.jackson.TransactionModel.TransactionProductModel;
import com.dipl.evin2.repository.ClosingStockLogRepository;
import com.dipl.evin2.repository.IcatalogueBatchRepository;
import com.dipl.evin2.repository.IcatalogueRepository;
import com.dipl.evin2.repository.ProductRepository;
import com.dipl.evin2.repository.ReportSyncStatusRepository;
import com.dipl.evin2.repository.TxnConsumptionRepository;
import com.dipl.evin2.repository.TxnCountLogRepository;
import com.dipl.evin2.repository.TxnLogRepository;
import com.dipl.evin2.repository.TxnRepository;
import com.dipl.evin2.util.KafkaProducer;
import com.dipl.evin2.util.ReportConsumption;
import com.dipl.evin2.util.ReportStockTrend;
import com.dipl.evin2.util.ReportStockTrendType;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.core.JsonProcessingException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TxnService {
	@Autowired
	private KafkaProducer kafkaProducer;

	@Autowired
	private TxnRepository txnRepository;

	@Autowired
	private IcatalogueBatchRepository icatalogueBatchRepository;

	@Autowired
	private IcatalogueRepository icatalogueRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ReportSyncStatusRepository reportSyncRepository;

	@Autowired
	private IcatalogueLogService icatalogueLogService;
	@Autowired
	private TxnLogRepository txnLogRepository;
	@Autowired
	private TxnConsumptionRepository txnConsumptionRepository;
	@Autowired
	private ClosingStockLogRepository closingStockLogRepository;

	@Autowired
	private TxnCountLogRepository txnCountsLogRepository;

	public Txn getById(Long id) throws CustomException {
		try {
			Optional<Txn> txnOptional = txnRepository.getById(id);
			if (txnOptional.isPresent()) {
				return txnOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Transactional(rollbackOn = Exception.class)
	public ResponseBean saveTransaction(TransactionModel transactionModel) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<TransactionProductModel> txnProductModel = transactionModel.getProducts();
			List<TransactionBatchProductModel> txnBatchProdModel = transactionModel.getBatchProducts();
			Long storeId = transactionModel.getStoreId(); // store ID
			Integer txnTypeId = transactionModel.getTxnTypeId();
			if (!txnProductModel.isEmpty()) {
				Boolean responseFlag = true;
				for (TransactionProductModel materials : txnProductModel) {
					Integer productId = materials.getProductId();
					Icatalogue icatalogue = icatalogueRepository.getInventoryByStoreIdAndProductId(storeId,
							productId.longValue());
					Long quanty = materials.getQuantity();
					Optional<Product> prd = productRepository.getById(productId);
					if (prd.isPresent() && prd.get().getIsBatchEnabled()) {
						responseBean.setData(null);
						responseBean.setStatus(HttpStatus.BAD_REQUEST);
						responseBean.setMessage("Please don't pass Batch enabled item in products JSON");
						responseFlag = false;
						break;
					}
					Long pcs = Long.valueOf(0L);
					Long pos = Long.valueOf(0L);
					Long closingStk = 0l;
					if (quanty.equals(0L) && !txnTypeId.equals(3)) {
						responseBean.setData(null);
						responseBean.setStatus(HttpStatus.BAD_REQUEST);
						responseBean.setMessage("Issueing Quantity should be more than ZERO.");
						responseFlag = false;
						break;
					}
					if (icatalogue != null) {
						closingStk = icatalogue.getCurrentStock();
						if (txnTypeId.equals(1)) {
							pos = closingStk;
							pcs = pos - quanty;
							if (pos <= 0) {
								responseBean.setData(null);
								responseBean.setStatus(HttpStatus.BAD_REQUEST);
								responseBean.setMessage(
										"No sufficient stock is avaiable to issue the transaction for this Store ");
								responseFlag = false;
								break;
							}

						} else if (txnTypeId.equals(2)) {
							pos = closingStk;
							pcs = pos + quanty;
						} else if (txnTypeId.equals(3) && quanty >= icatalogue.getAllocatedStock()) {
							pos = closingStk;
							pcs = quanty - icatalogue.getAllocatedStock();
						} else if (txnTypeId.equals(4) && icatalogue.getCurrentStock() >= quanty) {
							pos = closingStk;
							pcs = pos - quanty;
							addProductsDiscardQuantityToReports(materials, icatalogue, quanty);
						} else if (txnTypeId.equals(5) && closingStk >= quanty) {
							pos = closingStk;
							pcs = pos - quanty;
						} else {
							responseBean.setData(null);
							responseBean.setStatus(HttpStatus.BAD_REQUEST);
							responseBean.setMessage("No Transaction type has found in the payload for the Store ID.");
							responseFlag = false;
							break;
						}
						icatalogue.setTotalStock(pcs + icatalogue.getAllocatedStock());
						icatalogue.setCurrentStock(pcs);
						icatalogue.setUpdatedBy(transactionModel.getUserId());
						icatalogueRepository.save(icatalogue);

					} else if (txnTypeId.equals(3) || txnTypeId.equals(2)) {
						pos = closingStk;
						pcs = pos + quanty;
					} else {
						responseBean.setData(null);
						responseBean.setStatus(HttpStatus.BAD_REQUEST);
						responseBean
								.setMessage("No Inventory/Transactions are found please add physical Stock First .");
						responseFlag = false;
						break;

					}
					Long txnId = saveTxnAndIcatLog(transactionModel, materials, null, 0L, 0L, icatalogue, pos, pcs,
							quanty);

					Icatalogue icatalogueDetails = icatalogueRepository.getIcatalogueDetailsBySidPidIcatId(storeId,
							materials.getProductId(), icatalogue.getId());
					Integer abnormalTypeId = null;
					if (icatalogueDetails.getTotalStock().equals(0L)) {
						abnormalTypeId = 200;
					} else if (icatalogueDetails.getTotalStock() <= icatalogueDetails.getMinStock()) {
						abnormalTypeId = 201;
					} else if (icatalogueDetails.getTotalStock() >= icatalogueDetails.getMaxStock()) {
						abnormalTypeId = 202;
					} else if (icatalogueDetails.getTotalStock() != 0
							|| !(icatalogueDetails.getTotalStock() <= icatalogueDetails.getMinStock())
							|| !(icatalogueDetails.getTotalStock() >= icatalogueDetails.getMaxStock())) {
						abnormalTypeId = 0;
					}
					icatalogueLogService.saveIcatalogueLog(materials.getProductId(), storeId,
							transactionModel.getPranthId(), transactionModel.getTxnTypeId(), txnId, icatalogue.getId(),
							transactionModel.getUserId(), false, abnormalTypeId);
				}
				if (responseFlag) {
					responseBean.setData(null);
					responseBean.setStatus(HttpStatus.OK);
					responseBean.setMessage("Transactions created successfully for the below Store ID");
				} else {
					return responseBean;
				}
			}
			if (!txnBatchProdModel.isEmpty()) {
				for (TransactionBatchProductModel bProducts : txnBatchProdModel) {
					Integer productId = bProducts.getProductId();
					Long productCurrentStock = 0L;
					Long batchavilableQuantity = 0L;
					Icatalogue icatalogue = icatalogueRepository.getInventoryByStoreIdAndProductId(storeId,
							productId.longValue());
					productCurrentStock = icatalogue.getCurrentStock();
					if (productId != null && icatalogue != null) {
						String bid = bProducts.getBatchId();
						if (bid != null) {
							Long quantity = bProducts.getQuantity();
							if (quantity.equals(0L) && !txnTypeId.equals(3)) {
								responseBean.setData(null);
								responseBean.setStatus(HttpStatus.BAD_REQUEST);
								responseBean.setMessage("Issueing Quantity should be more than ZERO.");
								break;
							}
							IcatalogueBatch icatalogueBatch = icatalogueBatchRepository
									.findIcatalogueBatchByBIdAndPidIcatId(bProducts.getProductId(), bid,
											icatalogue.getId(), bProducts.getProducerId());
							Boolean flag = false;
							if (icatalogueBatch != null) {
								batchavilableQuantity = icatalogueBatch.getAvailableStock();
								Long quan = 0L;
								if ((txnTypeId.equals(1) || txnTypeId.equals(5))
										&& (batchavilableQuantity >= quantity)) {
									quan = icatalogueBatch.getAvailableStock() - quantity;
									icatalogueBatch.setTotalStock(quan + icatalogueBatch.getAllocatedStk());
								} else if (txnTypeId.equals(4) && (icatalogueBatch.getAvailableStock() >= quantity)) {
									quan = icatalogueBatch.getAvailableStock() - quantity;
									icatalogueBatch.setTotalStock(quan + icatalogueBatch.getAllocatedStk());
									addReportDiscardQuantityToKafka(bProducts, icatalogue, quantity);

								} else if (txnTypeId.equals(2)) {
									quan = icatalogueBatch.getAvailableStock() + quantity;
									icatalogueBatch.setTotalStock(quan + icatalogueBatch.getAllocatedStk());
								} else if (txnTypeId.equals(3) && icatalogueBatch.getAllocatedStk() <= quantity) {
									quan = quantity;

								} else {
									responseBean.setData(null);
									responseBean.setStatus(HttpStatus.BAD_REQUEST);
									responseBean.setMessage("Issueing Quantity should be more than Avaialable Stock.");
									break;
								}
								icatalogueBatch.setQuantity(quantity);
								icatalogueBatch.setAllocatedStk(icatalogueBatch.getAllocatedStk());
								if (txnTypeId.equals(3) && icatalogueBatch.getAllocatedStk() <= quantity) {
									icatalogueBatch.setAvailableStock(quan - icatalogueBatch.getAllocatedStk());
									icatalogueBatch.setTotalStock(quan);
								} else {
									icatalogueBatch.setAvailableStock(quan);
								}
								icatalogueBatch.setCreatedBy(transactionModel.getUserId());
								icatalogueBatch.setUpdatedBy(transactionModel.getUserId());
								icatalogueBatchRepository.save(icatalogueBatch);
								flag = true;

							} else if (icatalogueBatch == null && (txnTypeId.equals(3) || txnTypeId.equals(2))) {
								IcatalogueBatch icb = icatalogueBatchRepository.findBatchDetails(bProducts.getBatchId(),
										bProducts.getProductId(), bProducts.getProducerId());
								IcatalogueBatch ibv = new IcatalogueBatch();
								if (icb == null) {
									ibv.setExpiryDate(bProducts.getExpiryDate());
									ibv.setManufacturedDate(bProducts.getManufacturedDate());
								} else {
									ibv.setExpiryDate(icb.getExpiryDate());
									ibv.setManufacturedDate(icb.getManufacturedDate());
								}
								ibv.setBatchNo(bProducts.getBatchId());
								ibv.setProducerId(bProducts.getProducerId());
								ibv.setIcatalogueId(bProducts.getCatalogId());
								ibv.setProductId(bProducts.getProductId());
								ibv.setQuantity(bProducts.getQuantity());
								ibv.setAllocatedStk(0l);
								ibv.setAvailableStock(quantity);
								ibv.setTotalStock(quantity);
								ibv.setIcatalogueId(icatalogue.getId());
								ibv.setCreatedBy(transactionModel.getUserId());
								ibv.setUpdatedBy(transactionModel.getUserId());
								icatalogueBatchRepository.save(ibv);
								flag = true;
							}
							Long pcs = Long.valueOf(0L);
							Long pos = Long.valueOf(0L);
							Long bcs = Long.valueOf(0L);
							Long bos = Long.valueOf(0L);
							if (icatalogueBatch != null) {
								pos = icatalogue.getCurrentStock();
								bcs = icatalogueBatch.getAvailableStock();
								if (txnTypeId.equals(1) || txnTypeId.equals(4)
										|| txnTypeId.equals(5) && (batchavilableQuantity >= quantity)) {
									bos = bcs + quantity;
									pcs = pos - quantity;
								} else if (txnTypeId.equals(2)) {
									bos = bcs - quantity;
									pcs = pos + quantity;
								} else if (txnTypeId.equals(3)) {
									bcs = quantity;
									bos = batchavilableQuantity;
									pcs = (productCurrentStock - batchavilableQuantity) + quantity;
								} else {
									responseBean.setData(null);
									responseBean.setStatus(HttpStatus.BAD_REQUEST);
									responseBean.setMessage(
											"No Transaction type has found in the payload for the Store ID.");
									break;
								}
							} else if (icatalogueBatch == null && (txnTypeId.equals(3) || txnTypeId.equals(2))) {
								bos = 0L;
								bcs = bProducts.getQuantity();
								if (icatalogue != null && icatalogue.getCurrentStock() != null) {
									pos = icatalogue.getCurrentStock();
								} else {
									pos = 0L;
								}
								pcs = pos + bProducts.getQuantity();
							} else {
								responseBean.setData(null);
								responseBean.setReturnCode(0);
								responseBean.setStatus(HttpStatus.BAD_REQUEST);
								responseBean.setMessage(
										"Issues/Transfers and Discards new Batches are not allowed... try to do with existing bathes only");

								return responseBean;
							}
							Long txnId = saveTxnAndIcatLog(transactionModel, null, bProducts, bos, bcs, icatalogue, pos,
									pcs, quantity);
							if (flag) {
								Long productBatchAvlCount = icatalogueBatchRepository.getTotalStockQuantity(productId,
										icatalogue.getId());
								if (icatalogue != null) {
									icatalogue.setTotalStock(productBatchAvlCount + icatalogue.getAllocatedStock());
									icatalogue.setUpdatedBy(transactionModel.getUserId());
									icatalogue.setCurrentStock(productBatchAvlCount);
									icatalogue.setUpdatedBy(transactionModel.getUserId());
									icatalogueRepository.save(icatalogue);
								}
								Icatalogue icatalogueDetails = icatalogueRepository.getIcatalogueDetailsBySidPidIcatId(
										storeId, bProducts.getProductId(), icatalogue.getId());
								Integer abnormalTypeId = null;
								if (icatalogueDetails.getTotalStock().equals(0L)) {
									abnormalTypeId = 200;
								} else if (icatalogueDetails.getTotalStock() <= icatalogueDetails.getMinStock()) {
									abnormalTypeId = 201;
								} else if (icatalogueDetails.getTotalStock() >= icatalogueDetails.getMaxStock()) {
									abnormalTypeId = 202;
								} else if (icatalogueDetails.getTotalStock() != 0
										|| !(icatalogueDetails.getTotalStock() <= icatalogueDetails.getMinStock())
										|| !(icatalogueDetails.getTotalStock() >= icatalogueDetails.getMaxStock())) {
									abnormalTypeId = 0;
								}
								try {
									kafkaProducer.saveIcataLogueLogToKafka(bProducts.getProductId(), storeId,
											transactionModel.getPranthId(), transactionModel.getTxnTypeId(), txnId,
											icatalogue.getId(), transactionModel.getUserId(), false, abnormalTypeId);
								} catch (JsonProcessingException e) {
									e.printStackTrace();
								}
								responseBean.setData(null);
								responseBean.setStatus(HttpStatus.OK);
								responseBean.setMessage("Batch Transaction created successfully.. ");
							} else {
								responseBean.setReturnCode(0);
								responseBean.setData(null);
								responseBean.setStatus(HttpStatus.BAD_REQUEST);
								responseBean
										.setMessage("No Transaction type has found in the payload for the Store ID.");
							}

						} else {
							responseBean.setReturnCode(0);
							responseBean.setData(null);
							responseBean.setStatus(HttpStatus.BAD_REQUEST);
							responseBean.setMessage("Please pass BATCH NO in the request for the store ID");
						}

					} else {
						responseBean.setReturnCode(0);
						responseBean.setData(null);
						responseBean.setStatus(HttpStatus.BAD_REQUEST);
						responseBean.setMessage(
								"No Material Id/Inventory found in JSON payload, please add a materail in Inventory to initiate a transaction.");
					}

				}

			}
		} catch (Exception e) {
			log.error("Exception occured while creating txn  : {}", e.getMessage());
			e.printStackTrace();
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Exception occured while creating txn ");
			return responseBean;
		}
		return responseBean;
	}

	private void addProductsDiscardQuantityToReports(TransactionProductModel materials, Icatalogue icatalogue,
			Long quanty) throws JsonProcessingException {
		kafkaProducer.saveDiscardQuantityToKafka(quanty, icatalogue.getStoreId(), icatalogue.getProductId(),
				icatalogue.getIsDeleted(), materials.getReasonId());
	}

	private void addReportDiscardQuantityToKafka(TransactionBatchProductModel bProducts, Icatalogue icat, Long quantity)
			throws JsonProcessingException {
		kafkaProducer.saveDiscardQuantityToKafka(quantity, icat.getStoreId(), icat.getProductId(), icat.getIsDeleted(),
				bProducts.getReasonId());
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<Txn> existingTxnRecord = txnRepository.getById(id);
			if (existingTxnRecord.isPresent()) {
				txnRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	private Long saveTxnAndIcatLog(TransactionModel transactionModel, TransactionProductModel txnProductModel,
			TransactionBatchProductModel txnBatchModel, Long bos, Long bcs, Icatalogue icatalogue, Long pos, Long pcs,
			Long quanty) throws Exception {
		Txn txn = new Txn();
		Integer productId = 0;
		Long stock = 0l;
		IcatalogueLog icatalogueLog = new IcatalogueLog();
		if (txnProductModel != null) {
			txn.setStock(txnProductModel.getQuantity());
			stock = txnProductModel.getQuantity();
			productId = txnProductModel.getProductId();
			txn.setProductId(productId);
			txn.setReasonId(txnProductModel.getReasonId());
			txn.setOpeningStockBatch(0L);
			txn.setClosingStockBatch(0L);
			txn.setStatusId(txnProductModel.getMaterialStatus());
			icatalogueLog.setProductId(txnProductModel.getProductId());
		} else if (txnBatchModel != null) {
			txn.setStock(txnBatchModel.getQuantity());
			stock = txnBatchModel.getQuantity();
			txn.setReasonId(txnBatchModel.getReasonId());
			txn.setBatchNo(txnBatchModel.getBatchId());
			productId = txnBatchModel.getProductId();
			txn.setProductId(productId);
			txn.setOpeningStockBatch(bos);
			txn.setClosingStockBatch(bcs);
			txn.setStatusId(txnBatchModel.getMaterialStatus() == null ? null : txnBatchModel.getMaterialStatus());
			// set data for Icatalogue Log
			icatalogueLog.setProductId(txnBatchModel.getProductId());
			txn.setProducerId(txnBatchModel.getProducerId());
		}
		txn.setIcatalogueId(icatalogue.getId());
		txn.setSourceStoreId(transactionModel.getStoreId());
		txn.setDestStoreId(transactionModel.getLinkedStoreId() == null ? null : transactionModel.getLinkedStoreId());
		txn.setClosingStock(pcs);
		txn.setOpeningStock(pos);
		txn.setPranthId(transactionModel.getPranthId());
		txn.setInitialTxnDate(transactionModel.getTxnActualDate() == null ? null : transactionModel.getTxnActualDate());
		txn.setTxnTypeId(transactionModel.getTxnTypeId());
		txn.setCreatedBy(transactionModel.getUserId());
		txn.setSourceType(transactionModel.getSource() + "");
		Txn iTxn = txnRepository.saveAndFlush(txn);
		if (iTxn != null) {
			TxnLog txnLog = new TxnLog().builder().productId(Long.valueOf(productId))
					.storeId(transactionModel.getStoreId()).isActivityRead(false).isConsumptionRead(false)
					.txnDate(new Date()).txnTypeId(transactionModel.getTxnTypeId()).txnId(iTxn.getId()).build();
			TxnLog tl = txnLogRepository.save(txnLog);
			if (tl != null) {
				insertConsumptionRecord(transactionModel, transactionModel.getTxnTypeId(), productId, stock);
			}
			try {
				insertingInToTxnCountsLog(Long.valueOf(productId), transactionModel.getStoreId(), stock, iTxn);
				insertingClosingStockData(Long.valueOf(productId), transactionModel.getStoreId(), icatalogue.getId(),
						pcs, stock);
			} catch (Exception e) {
				log.error("Exception occured while inserting data in to txn closingStock log",
						e.getCause() + "message " + e.getMessage());
				throw new Exception();
			}
		}
		if (transactionModel.getTxnTypeId().equals(5)) {
			try {
				Txn cloneTxn = (Txn) txn.clone();
				cloneTxn.setId(null);
				cloneTxn.setTxnTypeId(1);
				cloneTxn.setTrackingNo(iTxn.getId() + "");
				cloneTxn.setTrackingObjectTypeId(3);
				Txn cTxn = txnRepository.saveAndFlush(cloneTxn);
				if (cTxn != null) {
					TxnLog txnLog = new TxnLog().builder().productId(Long.valueOf(productId))
							.storeId(transactionModel.getStoreId()).isActivityRead(false).isConsumptionRead(false)
							.txnDate(new Date()).txnTypeId(1).txnId(cTxn.getId()).build();
					TxnLog tl = txnLogRepository.save(txnLog);
					if (tl != null) {
						insertConsumptionRecord(transactionModel, 1, productId, stock);
					}
					try {
						insertingInToTxnCountsLog(Long.valueOf(productId), transactionModel.getStoreId(), stock, cTxn);
						insertingClosingStockData(Long.valueOf(productId), transactionModel.getStoreId(),
								icatalogue.getId(), pcs, stock);
					} catch (Exception e) {
						log.info("Exception occured while inserting data in to txn closingStock log");
					}
				}

			} catch (CloneNotSupportedException e1) {
				log.error("Exception occured while performing cloning the txn Item");
			}
		}

		if (iTxn != null) {
			Txn recvTxn = new Txn();
			int statusId = transactionModel.getTxnTypeId();
			String txnType = null;
			if (statusId == 1) {
				txnType = "Issues";
			} else if (statusId == 2) {
				txnType = "Receipts";
			} else if (statusId == 3) {
				txnType = "Stock Count";
			} else if (statusId == 4) {
				txnType = "Discards";
			} else if (statusId == 5) {
				txnType = "Transfers";
				// updateIcatAtRecivingStroe
				if (txnProductModel != null) {
					Icatalogue recvngStrIcat = icatalogueRepository.getDetailsOfIcatalouge(
							txnProductModel.getProductId().longValue(), transactionModel.getLinkedStoreId());
					Long rcvngStoreOpngStock = recvngStrIcat.getCurrentStock();
					Long rcvngStoreCurrentStock = rcvngStoreOpngStock + quanty;
					recvngStrIcat.setCurrentStock(rcvngStoreCurrentStock);
					recvngStrIcat.setTotalStock(rcvngStoreCurrentStock + recvngStrIcat.getAllocatedStock());
					recvngStrIcat.setCreatedBy(txn.getUpdatedBy());
					recvngStrIcat.setUpdatedOn(new Date());
					icatalogueRepository.save(recvngStrIcat);

					recvTxn.setStock(txnProductModel.getQuantity());
					recvTxn.setProductId(txnProductModel.getProductId());
					recvTxn.setReasonId(txnProductModel.getReasonId());
					recvTxn.setOpeningStockBatch(0L);
					recvTxn.setClosingStockBatch(0L);
					recvTxn.setIcatalogueId(recvngStrIcat.getId());
					recvTxn.setSourceStoreId(transactionModel.getLinkedStoreId());
					recvTxn.setDestStoreId(
							transactionModel.getStoreId() == null ? null : transactionModel.getStoreId());
					Long rcvngStoreClsngStock = recvngStrIcat.getCurrentStock();
					recvTxn.setClosingStock(rcvngStoreClsngStock);
					recvTxn.setOpeningStock(rcvngStoreOpngStock);
					recvTxn.setPranthId(transactionModel.getPranthId());
					recvTxn.setTrackingNo(iTxn.getId() + "");
					recvTxn.setTrackingObjectTypeId(3);
					recvTxn.setCreatedBy(transactionModel.getUserId());
					recvTxn.setSourceType(transactionModel.getSource() + "");
					recvTxn.setStatusId(
							txnProductModel.getMaterialStatus() == null ? null : txnProductModel.getMaterialStatus());
					icatalogueLog.setProductId(txnProductModel.getProductId());
				} else if (txnBatchModel != null) {
					Icatalogue recvngStrIcat = null;
					recvngStrIcat = icatalogueRepository.getDetailsOfIcatalouge(
							txnBatchModel.getProductId().longValue(), transactionModel.getLinkedStoreId());
					if (recvngStrIcat != null) {
						IcatalogueBatch icb = icatalogueBatchRepository.getBatchDetails(txnBatchModel.getProductId(),
								txnBatchModel.getBatchId(), recvngStrIcat.getId(), txnBatchModel.getProducerId());
						if (icb != null) {
							// if already exists it update the record
							icb.setQuantity(txnBatchModel.getQuantity());
							Long batchAllctdblStk = icb.getAllocatedStk();
							icb.setAllocatedStk(batchAllctdblStk);
							Long batchOpngStk = icb.getAvailableStock();
							Long batchAvlblStk = txnBatchModel.getQuantity() + icb.getAvailableStock();
							icb.setAvailableStock(batchAvlblStk);
							icb.setTotalStock(batchAvlblStk + batchAllctdblStk);
							icb.setCreatedBy(transactionModel.getUserId());
							icb.setUpdatedBy(transactionModel.getUserId());
							icatalogueBatchRepository.save(icb);
							recvTxn.setOpeningStockBatch(batchOpngStk);
							recvTxn.setClosingStockBatch(batchAvlblStk);
							recvTxn.setStock(txnBatchModel.getQuantity());
						} else {
							// if batch not exits it create new batch with same batch no in receiving store
							IcatalogueBatch ibv = new IcatalogueBatch();
							ibv.setBatchNo(txnBatchModel.getBatchId());
							ibv.setExpiryDate(txnBatchModel.getExpiryDate());
							ibv.setManufacturedDate(txnBatchModel.getManufacturedDate());
							ibv.setProducerId(txnBatchModel.getProducerId());
							ibv.setProductId(txnBatchModel.getProductId());
							ibv.setQuantity(txnBatchModel.getQuantity());
							ibv.setAllocatedStk(0l);
							ibv.setAvailableStock(txnBatchModel.getQuantity());
							ibv.setTotalStock(txnBatchModel.getQuantity());
							ibv.setIcatalogueId(recvngStrIcat.getId());
							ibv.setCreatedBy(transactionModel.getUserId());
							icatalogueBatchRepository.save(ibv);
							recvTxn.setOpeningStockBatch(0l);
							recvTxn.setClosingStockBatch(txnBatchModel.getQuantity());
							recvTxn.setStock(txnBatchModel.getQuantity());

						}
					}

					recvTxn.setReasonId(txnBatchModel.getReasonId());
					recvTxn.setBatchNo(txnBatchModel.getBatchId());
					recvTxn.setProductId(txnBatchModel.getProductId());
					recvTxn.setIcatalogueId(recvngStrIcat.getId());
					recvTxn.setSourceStoreId(transactionModel.getLinkedStoreId());
					recvTxn.setDestStoreId(
							transactionModel.getStoreId() == null ? null : transactionModel.getStoreId());
					Long rcvngStoreOpngStock = recvngStrIcat.getCurrentStock();
					recvTxn.setOpeningStock(rcvngStoreOpngStock);
					recvTxn.setPranthId(transactionModel.getPranthId());
					recvTxn.setTrackingNo(iTxn.getId() + "");
					recvTxn.setTrackingObjectTypeId(3);
					recvTxn.setCreatedBy(transactionModel.getUserId());
					recvTxn.setSourceType(transactionModel.getSource() + "");
					recvTxn.setProducerId(txnBatchModel.getProducerId());

					// updating receving store icatalogue
					Long productBatchAvlCount = icatalogueBatchRepository
							.getTotalStockQuantity(txnBatchModel.getProductId(), recvngStrIcat.getId());
					if (recvngStrIcat != null) {
						recvngStrIcat.setTotalStock(productBatchAvlCount + recvngStrIcat.getAllocatedStock());
						recvngStrIcat.setUpdatedBy(transactionModel.getUserId());
						recvngStrIcat.setCurrentStock(productBatchAvlCount);
						recvngStrIcat.setUpdatedBy(transactionModel.getUserId());
						icatalogueRepository.save(recvngStrIcat);
					}
					recvTxn.setClosingStock(productBatchAvlCount);
				}

				recvTxn.setInitialTxnDate(
						transactionModel.getTxnActualDate() == null ? null : transactionModel.getTxnActualDate());
				recvTxn.setTxnTypeId(2);
				Txn tTxn = txnRepository.saveAndFlush(recvTxn);
				if (tTxn != null) {
					TxnLog txnLog = new TxnLog().builder().productId(Long.valueOf(productId))
							.storeId(transactionModel.getStoreId()).isActivityRead(false).isConsumptionRead(false)
							.txnDate(new Date()).txnTypeId(2).txnId(tTxn.getId()).build();
					TxnLog tl = txnLogRepository.save(txnLog);
					if (tl != null) {
						insertConsumptionRecord(transactionModel, 2, productId, tTxn.getClosingStock());
					}
					try {
						insertingInToTxnCountsLog(Long.valueOf(productId), transactionModel.getStoreId(),
								tTxn.getClosingStock(), tTxn);
						insertingClosingStockData(Long.valueOf(productId), transactionModel.getStoreId(),
								icatalogue.getId(), pcs, tTxn.getClosingStock());
					} catch (Exception e) {
						log.info("Exception occured while inserting data in to txn closingStock log");
					}
				}

			}
			try {

				Date dte = iTxn.getCreatedOn();
				SimpleDateFormat sfd = new SimpleDateFormat("yyyy-MM-dd");
				String date = sfd.format(dte);

				ReportTxns rTxn = new ReportTxns().builder().pranthId(transactionModel.getPranthId())
						.productId(iTxn.getProductId()).txnDate(date).isActive(true)
						.txnsTypeId(transactionModel.getTxnTypeId()).storeId(txn.getSourceStoreId()).build();
				kafkaProducer.saveTxnToKafka(rTxn);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}

		}
		return iTxn.getId();
	}

	@Async("threadPoolTaskExecutor")
	public void insertingInToTxnCountsLog(Long productId, Long storeId, Long stock, Txn txn) {
		TxnCountLog txnCountLog = new TxnCountLog().builder().created_date(new Date()).productId(productId).stock(stock)
				.txnTypeId(txn.getTxnTypeId()).id(txn.getId()).storeId(storeId).isRead(false).build();
		txnCountsLogRepository.save(txnCountLog);
	}

	@Async("threadPoolTaskExecutor")
	public void insertingClosingStockData(Long productId, Long storeId, Long icatId, Long pcs, Long stock)
			throws Exception {
		Date baseDate = new Date();
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dbDate = sdf.format(baseDate);
		Date date;
		try {
			date = sdf.parse(dbDate);
			ClosingStockLog closingStockLog = closingStockLogRepository.getClosingStockDetails(date, productId,
					storeId);
			if (closingStockLog != null) {
				closingStockLog.setClosingStock(pcs);
				closingStockLog.setIsRead(false);
				closingStockLog.setUpdatedOn(new Date());
				closingStockLogRepository.save(closingStockLog);
			} else {
				ClosingStockLog clsingStock = new ClosingStockLog().builder().icatalogueId(icatId).closingStock(pcs)
						.createdOn(new Date()).isRead(false).updatedOn(new Date()).productId(Long.valueOf(productId))
						.storeId(storeId).build();
				closingStockLogRepository.save(clsingStock);
			}
		} catch (Exception e) {
			log.info("Exception occured while inserting data in to txn closingStock log");
			throw new Exception();
		}
	}

	private void insertConsumptionRecord(TransactionModel transactionModel, Integer txnTypeId, Integer productId,
			Long stock) {
		try {
			Date baseDate = new Date();
			DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String dbDate = sdf.format(baseDate);
			Date date = sdf.parse(dbDate);
			TxnConsumptionLog tcl = txnConsumptionRepository.findConsumptionRecord(transactionModel.getStoreId(),
					Long.valueOf(productId), txnTypeId, date);
			if (tcl != null) {
				tcl.setTxnCount(tcl.getTxnCount() == null ? 0 : tcl.getTxnCount() + stock.intValue());
				tcl.setIsConsumptionRead(false);
				tcl.setIsTxnCountRead(false);
				txnConsumptionRepository.save(tcl);
			} else {
				TxnConsumptionLog tc = new TxnConsumptionLog().builder().storeId(transactionModel.getStoreId())
						.productId(Long.valueOf(productId)).txnDate(date).isConsumptionRead(false).txnTypeId(txnTypeId)
						.txnCount(stock.intValue()).isTxnCountRead(false).build();
				txnConsumptionRepository.save(tc);
			}
		} catch (ParseException e) {
			log.error("Exception occured while inserting the data into txn consumption log");
		}

	}

	public List<Txn> getAll() {
		try {
			return txnRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public List<TxnDTO> getBatchDetailsByTxnId(Long txnId) {
		List<TxnDTO> txnDTOs = null;
		try {
			Txn txn = txnRepository.getBatchDetailsBasedOnTxnId(txnId);
			if (txn != null) {
				txnDTOs = icatalogueBatchRepository.getBatchDetailsBasedOnTxnIdAndBatchNo(txn.getBatchNo(),
						txn.getProductId().longValue(), txn.getIcatalogueId(), txn.getId());
				return txnDTOs;
			}
		} catch (Exception e) {
			log.error("Exception Occured while fetching in txn service" + e.getMessage());
			e.printStackTrace();
		}
		return txnDTOs;
	}

	public void getConsumptionReportDetails() {
		// String query = "select name_table='txn',
		// id,is_synyced='true',created_on,updated_on from txn where id> (select
		// coalesce(max(table_id),0) from report_sync_status where name_table='txn')";
		// jdbcTemplate.execute(query);

		List<Map<Object, Object>> consumptionDetails = txnRepository.findConsumptionReportDetails();
		Object date = null;
		Object c = null;
		for (Map<Object, Object> consumption : consumptionDetails) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			try {
				Date consumptionDate = simpleDateFormat.parse(consumption.get("created_on").toString());
				SimpleDateFormat month = new SimpleDateFormat("MM");
				SimpleDateFormat date11 = new SimpleDateFormat("dd");
				SimpleDateFormat year = new SimpleDateFormat("yyyy");
				System.out.println("Date: " + date11.format(consumptionDate));
				String m = month.format(consumptionDate);
				System.out.println("Month: " + month.format(consumptionDate));
				String yr = year.format(consumptionDate);
				System.out.println("Year: " + year.format(consumptionDate));
				Long receievingStore = consumption.get("dest_store_id") == null ? null
						: Long.parseLong(consumption.get("dest_store_id").toString());
				Integer mon = Integer.parseInt(m);
				Integer yer = Integer.parseInt(yr);
				Integer cc = Integer.parseInt(consumption.get("count").toString());
				ReportConsumption reportConsumption = new ReportConsumption().builder()
						.consumptionDate(consumption.get("created_on").toString()).consumptionMonth(mon)
						.consumptionYear(yer).consumedCount(cc)
						.storeId(Long.parseLong(consumption.get("source_store_id").toString()))
						.receivingStoreId(receievingStore)
						.productId(Long.parseLong(consumption.get("product_id").toString())).consumptionTypeId(2)
						.isActive(true).build();
				kafkaProducer.saveConsumptionToKafka(reportConsumption);
			} catch (ParseException e) {
				e.printStackTrace();
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		}

		List<Map<String, String>> latestList = reportSyncRepository.insertRecordsIntoDB();
		if (!latestList.isEmpty()) {
			for (Map<String, String> latest : latestList) {
				try {
					ReportSyncStatus rss = new ReportSyncStatus();
					rss.setIsSynyced(true);
					rss.setCreatedOn(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse((latest.get("created_on"))));
					rss.setLastModifiedOn(
							new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse((latest.get("updated_on"))));
					rss.setNameTable("txn");
					rss.setTableId(Integer.parseInt(latest.get("id").toString()));
					reportSyncRepository.save(rss);

				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

	public void getStockTrendTypeDetails() {
		List<Map<Object, Object>> stockTrendDetails = txnRepository.findStockTrendTypeReportsDetails();
		for (Map<Object, Object> stockTrendType : stockTrendDetails) {
			try {
				double year = Double.parseDouble(stockTrendType.get("stock_trend_year").toString());
				int covertYear = (int) year;
				double date = Double.parseDouble(stockTrendType.get("stock_trend_month").toString());
				int covertMonth = (int) date;
				Integer stockTrendTypeId = Integer.parseInt(stockTrendType.get("stock_trend_type_id").toString());

				ReportStockTrendType rstt = new ReportStockTrendType().builder()
						.storeId(Long.parseLong(stockTrendType.get("store_id").toString()))
						.productId(Long.parseLong(stockTrendType.get("product_id").toString()))
						.quantity(Integer.parseInt(stockTrendType.get("quantity").toString()))
						.stockTrendDate(stockTrendType.get("stock_trend_date").toString()).stockTrendYear(covertYear)
						.stockTrendTypeId(stockTrendTypeId).stockTrendMonth(covertMonth).build();
				kafkaProducer.saveStockTrendTypeToKafka(rstt);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void getStockTrendDetails() {

		List<Map<Object, Object>> stockTrendDetails = txnRepository.findStockTrendsReportsDetails();
		for (Map<Object, Object> stockTrend : stockTrendDetails) {
			double year = Double.parseDouble(stockTrend.get("stock_trend_year").toString());
			int covertYear = (int) year;
			double date = Double.parseDouble(stockTrend.get("stock_trend_month").toString());
			int covertMonth = (int) date;
			try {

				ReportStockTrend rst = new ReportStockTrend().builder()
						.storeId(Long.parseLong(stockTrend.get("store_id").toString()))
						.productId(Long.parseLong(stockTrend.get("product_id").toString()))
						.closingCount(Integer.parseInt(stockTrend.get("closing_stock").toString()))
						.stockTrendDate(stockTrend.get("stock_trend_date").toString()).stockTrendYear(covertYear)
						.stockTrendMonth(covertMonth).build();
				kafkaProducer.saveClosingStockTrendToKafka(rst);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

}