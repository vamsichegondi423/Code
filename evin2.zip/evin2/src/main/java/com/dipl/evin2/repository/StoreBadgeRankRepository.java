package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.StoreBadgeRank;

@Repository
public interface StoreBadgeRankRepository extends JpaRepository<StoreBadgeRank, Integer> {

	@Query(value = "select * from store_badge_rank where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<StoreBadgeRank> getById(Integer id);

//	@Query(value = "select * from store_badge_rank where is_deleted = false", nativeQuery = true)
//	public List<StoreBadgeRank> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from store_badge_rank where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);
	
	@Modifying
	@Transactional
	@Query(value = "update store_badge_rank set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);
	
	@Query(value = "select s.store_badge_id, s.\"rank\", s.is_deleted, s.created_by, s.created_on, s.updated_by, s.updated_on, \n"
			+ "b.badge_type_id, b.\"name\" from store_badge_rank s join badge b on b.id = s.store_badge_id where s.is_deleted = false and s.pranth_id=?1", nativeQuery = true)
	public List<StoreBadgeRank> findAll(Long pranthId);

	@Query(value = "select * from store_badge_rank where store_badge_id = ?1 and pranth_id = ?2", nativeQuery = true)
	public Optional<StoreBadgeRank> getByStorageBadgeId(Integer storeBadgeId, Long pranthId);
	
}