package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.BookingStoreBadge;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.BookingStoreBadgeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BookingStoreBadgeService {

	@Autowired
	private BookingStoreBadgeRepository bookingStoreBadgeRepository;

	public BookingStoreBadge getById(Long id) throws CustomException {
		try {
			Optional<BookingStoreBadge> bookingStoreBadgeOptional = bookingStoreBadgeRepository.getById(id);
			if (bookingStoreBadgeOptional.isPresent()) {
				return bookingStoreBadgeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public BookingStoreBadge save(BookingStoreBadge bookingStoreBadge) throws CustomException {
		try {
			if (bookingStoreBadge.getId() != null && bookingStoreBadge.getId() > 0) {
				Optional<BookingStoreBadge> existingBookingStoreBadgeRecord = bookingStoreBadgeRepository
						.getById(bookingStoreBadge.getId());
				if (existingBookingStoreBadgeRecord.isPresent()) {
					return bookingStoreBadgeRepository.save(bookingStoreBadge);
				}
			} else {
				bookingStoreBadge = bookingStoreBadgeRepository.save(bookingStoreBadge);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return bookingStoreBadge;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<BookingStoreBadge> existingBookingStoreBadgeRecord = bookingStoreBadgeRepository.getById(id);
			if (existingBookingStoreBadgeRecord.isPresent()) {
				bookingStoreBadgeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<BookingStoreBadge> getAll() {
		try {
			return bookingStoreBadgeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}