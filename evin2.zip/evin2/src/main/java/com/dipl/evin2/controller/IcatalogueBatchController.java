package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.IcatalogueBatch;
import com.dipl.evin2.repository.IcatalogueBatchRepository;
import com.dipl.evin2.service.IcatalogueBatchService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/icatalogue-batch")
public class IcatalogueBatchController {

	@Autowired
	private IcatalogueBatchService icatalogueBatchService;
	@Autowired
	private IcatalogueBatchRepository icatalogueBatchRepository;

	@ApiOperation("Use this api for saving or updating IcatalogueBatch. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody IcatalogueBatch icatalogueBatch, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			IcatalogueBatch exstngIcatalogueBatch = icatalogueBatchRepository
					.getIcatalogueBatch(icatalogueBatch.getIcatalogueId(), icatalogueBatch.getBatchNo());
			if (exstngIcatalogueBatch != null) {
				log.info("Icatalogue  id " + icatalogueBatch.getIcatalogueId() + " with batch number "
						+ icatalogueBatch.getBatchNo() + " already exist");
				responseBean.setMessage("Icatalogue  id " + icatalogueBatch.getIcatalogueId() + " with batch number "
						+ icatalogueBatch.getBatchNo() + " already exist");
				responseBean.setStatus(HttpStatus.OK);
				responseBean.setReturnCode(1);
				return responseBean;
			}
			if (icatalogueBatch.getId() != null && icatalogueBatch.getId() > 0) {
				IcatalogueBatch existingIcatalogueBatch = icatalogueBatchService.getById(icatalogueBatch.getId());
				if (existingIcatalogueBatch != null) {
					icatalogueBatch = icatalogueBatchService.save(icatalogueBatch);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(icatalogueBatch);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				icatalogueBatch = icatalogueBatchService.save(icatalogueBatch);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(icatalogueBatch);
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching IcatalogueBatch record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			IcatalogueBatch icatalogueBatch = icatalogueBatchService.getById(id);
			if (icatalogueBatch != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(icatalogueBatch);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting IcatalogueBatch record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = icatalogueBatchService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all IcatalogueBatch records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<IcatalogueBatch> icatalogueBatchRecords = icatalogueBatchService.getAll();
			if (!icatalogueBatchRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(icatalogueBatchRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching batch details ")
	@GetMapping(value = "/v1/get-batch-wise-details")
	public ResponseBean getBatchDetails(@RequestParam(required = true, value = "batchNo") String batchNo,
			@RequestParam(required = true, value = "producerId") Integer producerId,
			@RequestParam(required = true, value = "productId") Long productId) throws Exception {
		ResponseBean responseBean = new ResponseBean();
		responseBean = icatalogueBatchService.getBatchData(batchNo, producerId, productId);
		return responseBean;

	}

	@ApiOperation("Use this api to fetc all batch details ")
	@PostMapping(value = "/v1/get-batch-details-by-product-ids")
	public ResponseBean getAllBatchDetails(@RequestBody BatchModel batchModel,
			@RequestParam(required = true) Long storeId, @RequestParam(required = false) Long pranthId)
			throws Exception {
		return icatalogueBatchService.getBatchDataByProductIds(storeId, pranthId, batchModel.getProductId());
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class BatchModel {
		private List<Long> productId;
	}

}