/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dipl.evin2.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author VineethKumar
 */
@Entity
@Table(name = "booking_items")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class BookingItems extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Long id;
	@Column(name = "booking_id")
	private Long bookingId;
	@Column(name = "product_id")
	private Integer productId;
	// @Max(value=?) @Min(value=?)//if you know range of your decimal fields
	// consider using these annotations to enforce field validation
	@Column(name = "ordered_stock")
	private Long orderedStock;
	@Column(name = "allocated_stock")
	private Long allocatedStock;
	@Column(name = "fulfilled_stock")
	private Long fulfilledStock;
	@Column(name = "reason")
	private String reason;
	@Column(name = "shipped_stock")
	private Long shippedStock;
	@Column(name = "store_id")
	private Long storeId;
	@Column(name = "pranth_id")
	private Long pranthId;

	@Column(name = "status_id")
	private Integer statusId;

	@Column(name = "quantity")
	private Long quantity;

	@Column(name = "orginial_ordered_stock")
	private Long originalOrderStock;

	@Column(name = "recommanded_stock")
	private Long recommendedStock;

	@Column(name = "modified_reason")
	private String modifiedReason;
	@Column(name = "is_modified")
	private Boolean isModified;

}
