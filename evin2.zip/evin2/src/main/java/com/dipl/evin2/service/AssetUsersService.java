package com.dipl.evin2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.AssetUsers;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.AssetUsersRepository;

@Service
public class AssetUsersService {

	@Autowired
	private AssetUsersRepository assetUsersRepository;

	public AssetUsers getById(Long id) throws CustomException {
		Optional<AssetUsers> assetUsersOptional = assetUsersRepository.getById(id);
		if (assetUsersOptional.isPresent()) {
			return assetUsersOptional.get();
		} else {
			return null;
		}
	}

	public AssetUsers save(AssetUsers assetUsers) throws CustomException {
		if (assetUsers.getId() != null && assetUsers.getId() > 0) {
			Optional<AssetUsers> existingAssetUsersRecord = assetUsersRepository.getById(assetUsers.getId());
			if (existingAssetUsersRecord.isPresent()) {
				return assetUsersRepository.save(assetUsers);
			}
		} else {
			assetUsers = assetUsersRepository.save(assetUsers);
		}
		return assetUsers;
	}

	public Integer deleteById(Long id) throws CustomException {
		Optional<AssetUsers> existingAssetUsersRecord = assetUsersRepository.getById(id);
		if (existingAssetUsersRecord.isPresent()) {
			assetUsersRepository.deleteByIdSoft(id);
			return 1;
		} else {
			return 0;
		}
	}
	
	
	public void deleteByIdHard(Long id) {
		assetUsersRepository.deleteById(id);
	}

	public List<AssetUsers> getAll() {
		return assetUsersRepository.findAll();
	}

	public AssetUsers getByAssetIdAndUserAndRole(Long assetId, Long userId, Integer roleId) {
		Optional<AssetUsers> assetUsersOptional = assetUsersRepository.getByAssetIdAndUserAndRole(assetId, userId, roleId);
		if (assetUsersOptional.isPresent()) {
			return assetUsersOptional.get();
		} else {
			return null;
		}
	}
	
	public List<AssetUsers> getByAssetIdAndRole(Long assetId, Integer roleId) {
		return assetUsersRepository.getByAssetIdAndRole(assetId, roleId);
		
	}

	public List<AssetUsers> saveAll(List<AssetUsers> assetUsersList) {
		return assetUsersRepository.saveAll(assetUsersList);
	}
}