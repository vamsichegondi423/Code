package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.Asset;
import com.dipl.evin2.entity.AssetConfiguration;
import com.dipl.evin2.entity.AssetSensorConfiguration;
import com.dipl.evin2.entity.AssetUsers;
import com.dipl.evin2.entity.MasterAssetVendor;
import com.dipl.evin2.entity.MasterCountry;
import com.dipl.evin2.entity.MasterLanguage;
import com.dipl.evin2.entity.MasterTimeZone;
import com.dipl.evin2.entity.Users;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.model.AssetConfigurationPullModel;
import com.dipl.evin2.model.AssetConfigurationPullModel.Comm;
import com.dipl.evin2.model.AssetConfigurationPullModel.ConfData;
import com.dipl.evin2.model.AssetConfigurationPullModel.HighAlarm;
import com.dipl.evin2.model.AssetConfigurationPullModel.HighWarn;
import com.dipl.evin2.model.AssetConfigurationPullModel.Lba;
import com.dipl.evin2.model.AssetConfigurationPullModel.Locale;
import com.dipl.evin2.model.AssetConfigurationPullModel.LowAlarm;
import com.dipl.evin2.model.AssetConfigurationPullModel.LowWarn;
import com.dipl.evin2.model.AssetConfigurationPullModel.Notf;
import com.dipl.evin2.model.AssetConfigurationPullModel.Poa;
import com.dipl.evin2.model.AssetConfigurationPullModel.Sensor;
import com.dipl.evin2.model.AssetConfigurationPullModel.SensorComm;
import com.dipl.evin2.model.AssetConfigurationPullModel.SensorHighAlarm;
import com.dipl.evin2.model.AssetConfigurationPullModel.SensorHighWarn;
import com.dipl.evin2.model.AssetConfigurationPullModel.SensorLowAlarm;
import com.dipl.evin2.model.AssetConfigurationPullModel.SensorLowWarn;
import com.dipl.evin2.model.AssetConfigurationPullModel.SensorNotf;
import com.dipl.evin2.model.AssetConfigurationPullModel.Wifi;
import com.dipl.evin2.model.AssetConfigurationPushModel;
import com.dipl.evin2.model.AssetConfigurationPushModel.Dv;
import com.dipl.evin2.service.AssetConfigurationService;
import com.dipl.evin2.service.AssetSensorConfigurationService;
import com.dipl.evin2.service.AssetService;
import com.dipl.evin2.service.AssetUsersService;
import com.dipl.evin2.service.MasterAssetVendorService;
import com.dipl.evin2.service.MasterCountryService;
import com.dipl.evin2.service.MasterLanguageService;
import com.dipl.evin2.service.MasterTimeZoneService;
import com.dipl.evin2.service.UsersService;
import com.dipl.evin2.util.Constants;
import com.dipl.evin2.util.EvinUtility;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/asset-configuration")
public class AssetConfigurationController {

	private static final String NO_RECORDS_FOUND = "No records found";

	private static final String EXECPTION_OCCURED = "Execption Occured";

	private static final String NO_RECORD_FOUND = "No record found";

	private static final String RECORDS_FETCHED_SUCCESSFULLY = "Records fetched successfully";

	private static final String EXCEPTION_OCCURED = "Exception occured";

	private static final String INVALID_PAYLOAD = "Invalid Payload";

	@Autowired
	private AssetConfigurationService assetConfigurationService;

	@Autowired
	private AssetSensorConfigurationService assetSensorConfigurationService;

	@Autowired
	private AssetService assetService;

	@Autowired
	private MasterCountryService masterCountryService;

	@Autowired
	private MasterLanguageService masterLanguageService;

	@Autowired
	private MasterAssetVendorService masterAssetVendorService; 

	@Autowired
	private MasterTimeZoneService masterTimeZoneService; 

	@Autowired
	private UsersService usersService;

	@Autowired
	private AssetUsersService assetUsersService; 

	@ApiOperation("Use this api for saving or updating AssetConfiguration. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	@Transactional(rollbackFor = Exception.class)
	public ResponseBean save(@RequestBody AssetConfiguration assetConfiguration, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error(INVALID_PAYLOAD);
				return ResponseBean.builder().data(null).message(INVALID_PAYLOAD).status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		} 
		try {

			if(assetConfiguration != null) {

				Asset asset = assetConfiguration.getAsset();
				if(asset != null) {
					Asset asset1 = assetService.getBySerialNumberAndAssetModel(asset.getSerialNumber(), asset.getAssetModelId());
					if(asset.getId() == null && asset1 != null) {
						log.info("Asset with the given serial number and model already exist.");
						return ResponseBean.builder().data(null).message("Asset with the given serial number and model already exist.").status(HttpStatus.OK).returnCode(1).build();
					}
					if(asset.getId() != null && asset.getId() > 0) {
						Asset existingAsset = assetService.getById(asset.getId());
						if(existingAsset == null) {
							throw new CustomException("Asset does not exist", HttpStatus.BAD_REQUEST);
						}else {
							asset.setCreatedBy(existingAsset.getCreatedBy());
							asset.setCreatedOn(existingAsset.getCreatedOn());
							asset.setUpdatedBy(assetConfiguration.getUpdatedBy());
							asset.setUpdatedOn(new Date());
						}
					}else {
						asset.setUpdatedBy(assetConfiguration.getUpdatedBy());
						asset.setUpdatedOn(new Date());
						asset.setCreatedBy(assetConfiguration.getUpdatedBy());
						asset.setCreatedOn(new Date());
					}
					asset.setIsDeleted(asset.getIsDeleted() == null ? false : asset.getIsDeleted());
					asset = assetService.save(asset);

					AssetConfiguration existingAssetConfiguration = assetConfigurationService.getByAssetId(asset.getId());
					if(existingAssetConfiguration == null) {
						assetConfiguration.setCreatedBy(assetConfiguration.getUpdatedBy());
						assetConfiguration.setCreatedOn(new Date());
						assetConfiguration.setUpdatedBy(assetConfiguration.getUpdatedBy());
						assetConfiguration.setUpdatedOn(new Date());
					}else {
						assetConfiguration.setCreatedBy(existingAssetConfiguration.getCreatedBy());
						assetConfiguration.setCreatedOn(existingAssetConfiguration.getCreatedOn());
						assetConfiguration.setUpdatedBy(assetConfiguration.getUpdatedBy());
						assetConfiguration.setUpdatedOn(new Date());
					}
					
					List<AssetUsers> assetUsersList = new ArrayList<>();
					if(asset.getOwners() != null && !asset.getOwners().isEmpty()) {
						for(Users users : asset.getOwners()) {
							Users ownerUser = usersService.getById(users.getId());
							if(ownerUser == null) {
								throw new CustomException("Owner does not exist", HttpStatus.BAD_REQUEST);
							}else {
								AssetUsers existingOwner = assetUsersService.getByAssetIdAndUserAndRole(asset.getId(), ownerUser.getId(), Constants.ASSET_OWNER_USER_ROLE);
								if(existingOwner != null) {
									existingOwner.setUpdatedBy(assetConfiguration.getUpdatedBy());
									existingOwner.setUpdatedOn(new Date());
									assetUsersList.add(existingOwner);
								}else {
									AssetUsers assetUsers = AssetUsers.builder().assetId(asset.getId()).roleId(Constants.ASSET_OWNER_USER_ROLE).userId(ownerUser.getId()).build();
									assetUsers.setUpdatedBy(assetConfiguration.getUpdatedBy());
									assetUsers.setUpdatedOn(new Date());
									assetUsers.setCreatedBy(assetConfiguration.getUpdatedBy());
									assetUsers.setCreatedOn(new Date());
									assetUsersList.add(assetUsers);
								}
							}
						}
					}

					if(asset.getMaintainers() != null && !asset.getMaintainers().isEmpty()) {
						for(Users users : asset.getMaintainers()) {
							Users maintainerUser = usersService.getById(users.getId());
							if(maintainerUser == null) {
								throw new CustomException("Maintainer does not exist", HttpStatus.BAD_REQUEST);
							}else {
								AssetUsers existingMaintainer = assetUsersService.getByAssetIdAndUserAndRole(asset.getId(), maintainerUser.getId(), Constants.ASSET_MAINTAINER_USER_ROLE);
								if(existingMaintainer != null) {
									existingMaintainer.setUpdatedBy(assetConfiguration.getUpdatedBy());
									existingMaintainer.setUpdatedOn(new Date());
									assetUsersList.add(existingMaintainer);
								}else {
									AssetUsers assetUsers = AssetUsers.builder().assetId(asset.getId()).roleId(Constants.ASSET_MAINTAINER_USER_ROLE).userId(maintainerUser.getId()).build();
									assetUsers.setUpdatedBy(assetConfiguration.getUpdatedBy());
									assetUsers.setUpdatedOn(new Date());
									assetUsers.setCreatedBy(assetConfiguration.getUpdatedBy());
									assetUsers.setCreatedOn(new Date());
									assetUsersList.add(assetUsers);
								}
							}
						}
					}
					assetUsersService.saveAll(assetUsersList);
				}				
				assetConfiguration.setAssetId(asset.getId());

				List<AssetConfiguration> existingAssetConfigurations = assetConfigurationService.getAll();
				if(!existingAssetConfigurations.isEmpty()) {
					assetConfiguration.setId(existingAssetConfigurations.iterator().next().getId());
				}

				assetConfiguration = assetConfigurationService.save(assetConfiguration);
				List<AssetSensorConfiguration> sensorConfigurations = new ArrayList<>();
				if(assetConfiguration.getAssetSensorConfigurationList() != null && !assetConfiguration.getAssetSensorConfigurationList().isEmpty()) {
					for(AssetSensorConfiguration assetSensorConfiguration : assetConfiguration.getAssetSensorConfigurationList()) {
						AssetSensorConfiguration existingAssetSensorConfiguration = null;
						if(assetSensorConfiguration.getId() != null) {
							existingAssetSensorConfiguration = assetSensorConfigurationService.getByAssetIdAndSensorId(asset.getId(), assetSensorConfiguration.getSensorId());
						}
						if(existingAssetSensorConfiguration !=null) {
							assetSensorConfiguration.setCreatedBy(existingAssetSensorConfiguration.getCreatedBy());
							assetSensorConfiguration.setCreatedOn(existingAssetSensorConfiguration.getCreatedOn());
						}else {
							assetSensorConfiguration.setCreatedBy(assetConfiguration.getUpdatedBy());
							assetSensorConfiguration.setCreatedOn(new Date());
						}
						assetSensorConfiguration.setAssetId(asset.getId());
						assetSensorConfiguration.setUpdatedBy(assetConfiguration.getUpdatedBy());
						assetSensorConfiguration.setUpdatedOn(new Date());
						sensorConfigurations.add(assetSensorConfiguration);
					}
				}

				assetSensorConfigurationService.saveAll(sensorConfigurations);
			}

			log.info("Record saved successfully");
			responseBean.setMessage("Record saved successfully");
			responseBean.setData(null);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);

		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage(EXECPTION_OCCURED);
		}
		return responseBean;
	}


	@ApiOperation("Use this api for saving or updating AssetConfiguration. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/push-config")
	public ResponseBean savePushConfiguration(@RequestBody AssetConfigurationPushModel assetConfigurationPushModel, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error(INVALID_PAYLOAD);
				return ResponseBean.builder().data(null).message(INVALID_PAYLOAD).status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}

		for(Dv dv : assetConfigurationPushModel.getDvs()) {
			MasterCountry masterCountry = masterCountryService.getByCode(dv.getCn());
			Asset asset = assetService.getBySerialNumber(dv.getDId());
			AssetConfiguration assetConfiguration = assetConfigurationService.getByCountryAndDeviceIdAndPhoneNumber(masterCountry.getId(), asset.getId(), dv.getPhn());

			if (assetConfiguration != null) {
				assetConfiguration = createAssetConfigurationFromPushModel(assetConfigurationPushModel, assetConfiguration, null, null);
				assetConfiguration = assetConfigurationService.save(assetConfiguration);
				log.info("Record updated successfully");
				responseBean.setMessage("Record updated successfully");
				responseBean.setData(assetConfiguration);
			} else {
				log.info(NO_RECORD_FOUND);
				responseBean.setMessage(NO_RECORD_FOUND);
			}
		}
		responseBean.setStatus(HttpStatus.OK);
		responseBean.setReturnCode(1);
		return responseBean;
	}

	@ApiOperation("Use this api for saving or updating AssetConfiguration. Provide id value in for update. Provide id value as null for save.")
	@GetMapping(value = {"/v2/config/{vendorId}/{deviceId}/{firmware-version}", "/v2/config/{vendorId}/{deviceId}"})
	public ResponseEntity<?> pullConfiguration(@PathVariable(name = "vendorId", required = true) String vId, @PathVariable(name = "deviceId", required = true) String deviceId, @PathVariable(name="firmware-version", required = false) Optional<String> firmwareVersionOptional) {
		String firmwareVersion = "";
		if(firmwareVersionOptional.isPresent()) {
			firmwareVersion = firmwareVersionOptional.get();
		}
		log.info("vendorId: {}, deviceId: {}, firmware-version: {}", vId, deviceId, firmwareVersion);

		AssetConfiguration assetConfiguration = null;
		MasterAssetVendor masterAssetVendor = null;
		if(vId != null && !vId.isEmpty()) {
			masterAssetVendor = masterAssetVendorService.getByName(vId);
		}

		if(masterAssetVendor == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Vendor not found");
		}

		Asset asset = assetService.getBySerialNumber(deviceId);
		if(asset == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Asset with given Device ID does not exist.");
		}
		if(firmwareVersion != null && !firmwareVersion.isEmpty()) {
			assetConfiguration = assetConfigurationService.getByVendorIdAndDeviceIdAndFirmwareVersion(masterAssetVendor.getId(), asset.getId(),firmwareVersion);
		}else {
			assetConfiguration = assetConfigurationService.getByVendorIdAndDeviceId(masterAssetVendor.getId(), asset.getId());
		}
		if(assetConfiguration != null) {
			List<AssetSensorConfiguration> sensorAssetConfigurations = assetSensorConfigurationService.getByAssetId(assetConfiguration.getAssetId());
			MasterLanguage masterLanguage = new MasterLanguage();
			if(assetConfiguration.getLanguageId() != null) {
				masterLanguage = masterLanguageService.getById(assetConfiguration.getLanguageId());
			}

			MasterCountry masterCountry = new MasterCountry();
			if(assetConfiguration.getCountryId() != null) {
				masterCountry = masterCountryService.getById(assetConfiguration.getCountryId());
			}

			MasterTimeZone masterTimeZone = new MasterTimeZone();
			if(assetConfiguration.getTimeZoneId() != null) {
				masterTimeZone = masterTimeZoneService.getById(assetConfiguration.getTimeZoneId());
			}

			List<Sensor> sensors = new ArrayList<>();

			if(!sensorAssetConfigurations.isEmpty()) {
				for(AssetSensorConfiguration configuration : sensorAssetConfigurations) {
					sensors.add(createSensorModel(configuration));
				}
			}

			AssetConfigurationPullModel assetConfigurationPullModel = createAssetConfigurationPullModel(assetConfiguration, masterCountry, masterLanguage, masterTimeZone, sensors);
			return ResponseEntity.ok(assetConfigurationPullModel);
		}else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Device configuration not found");
		}
		
	}
	
	private Sensor createSensorModel(AssetSensorConfiguration configuration) {
		SensorComm comm = SensorComm.builder().tmpNotify(configuration.getTemperaturePushNotification()).incExcNotify(configuration.getTemperatureIncursionExcursionPushNotification())
				.statsNotify(configuration.getStatsPushNotification()).devAlrmsNotify(configuration.getDeviceAlarmPushNotification()).tmpAlrmsNotify(configuration.getTemperatureAlarmPushNotifications())
				.samplingInt(configuration.getSamplingInterval()).pushInt(configuration.getPushInterval())
				.build();
		SensorHighAlarm highAlarm = SensorHighAlarm.builder().temp(configuration.getHighAlarmTemperature()).dur(configuration.getHighAlarmTemperatureDuration()).build();
		SensorHighWarn highWarn = SensorHighWarn.builder().temp(configuration.getHighWarningTemperature()).dur(configuration.getHighWarningTemperatureDuration()).build();
		SensorLowAlarm lowAlarm = SensorLowAlarm.builder().temp(configuration.getLowAlarmTemperature()).dur(configuration.getLowAlarmTemperatureDuration()).build();
		SensorLowWarn lowWarn = SensorLowWarn.builder().temp(configuration.getLowWarningTemperature()).dur(configuration.getLowWarningTemperatureDuration()).build();
		SensorNotf notf = SensorNotf.builder().dur(configuration.getAlarmFrequencyNotificationDuration()).num(configuration.getAlarmFrequencyNotificationNumber()).build();
		if(configuration.getUseDefaultConfiguration() != null && configuration.getUseDefaultConfiguration().booleanValue()) {
			return Sensor.builder().comm(null).highAlarm(null).highWarn(null).lowAlarm(null).lowWarn(null).notf(null).sId(configuration.getSensorId()).build();
		}else {
			return Sensor.builder().comm(comm).highAlarm(highAlarm).highWarn(highWarn).lowAlarm(lowAlarm).lowWarn(lowWarn).notf(notf).sId(configuration.getSensorId()).build();
		}
		
	}

	private AssetConfigurationPullModel createAssetConfigurationPullModel(AssetConfiguration assetConfiguration, MasterCountry masterCountry, MasterLanguage masterLanguage, MasterTimeZone masterTimeZone, List<Sensor> sensors) {
		Wifi wifi = Wifi.builder().pwd(assetConfiguration.getWifiPassword()).security(assetConfiguration.getWifiSecurity()).ssid(assetConfiguration.getWifiSsid()).build();
		Comm comm = Comm.builder().chnl(assetConfiguration.getCommunicationChannelId()).tmpUrl(assetConfiguration.getTemperaturePushUrl()).cfgUrl(assetConfiguration.getConfigurationPullUrl()).alrmUrl(assetConfiguration.getAlarmPushUrl())
				.statsUrl(assetConfiguration.getStatsPushUrl()).devRyUrl(assetConfiguration.getDeviceReadyStatusPushUrl()).smsGyPh(assetConfiguration.getSmsGatewayPhoneNumber()).senderId(assetConfiguration.getSmsGatewaySenderId())
				.smsGyKey(assetConfiguration.getSmsGatewayKeyword()).tmpNotify(assetConfiguration.getTemperaturePushNotification()).incExcNotify(assetConfiguration.getTemperatureIncursionExcursionPushNotification())
				.statsNotify(assetConfiguration.getStatsPushNotification()).devAlrmsNotify(assetConfiguration.getDeviceAlarmPushNotification()).tmpAlrmsNotify(assetConfiguration.getTemperatureAlarmPushNotifications())
				.samplingInt(assetConfiguration.getSamplingInterval()).pushInt(assetConfiguration.getPushInterval())
				.usrPhones(assetConfiguration.getPhoneNumbersToSendSmsNotification() != null && !assetConfiguration.getPhoneNumbersToSendSmsNotification().isEmpty() ? new ArrayList<>(StringUtils.commaDelimitedListToSet(assetConfiguration.getPhoneNumbersToSendSmsNotification())) : null)
				.wifi(wifi).build();
		HighAlarm highAlarm = HighAlarm.builder().temp(assetConfiguration.getHighAlarmTemperature()).dur(assetConfiguration.getHighAlarmTemperatureDuration()).build();
		HighWarn highWarn = HighWarn.builder().temp(assetConfiguration.getHighWarningTemperature()).dur(assetConfiguration.getHighWarningTemperatureDuration()).build();
		Lba lba = Lba.builder().lmt(assetConfiguration.getLowBatteryAlarmThresholdLimit()).build();

		Locale locale = Locale.builder().cn(masterCountry.getCode()).ln(masterLanguage != null ? masterLanguage.getCode() : null).tz(EvinUtility.getTimeZoneIntegerValue(masterTimeZone.getOffset())).build();

		LowAlarm lowAlarm = LowAlarm.builder().temp(assetConfiguration.getLowAlarmTemperature()).dur(assetConfiguration.getLowAlarmTemperatureDuration()).build();
		LowWarn lowWarn = LowWarn.builder().temp(assetConfiguration.getLowWarningTemperature()).dur(assetConfiguration.getLowWarningTemperatureDuration()).build();
		Notf notf = Notf.builder().dur(assetConfiguration.getAlarmFrequencyNotificationDuration()).num(assetConfiguration.getAlarmFrequencyNotificationNumber()).build();
		Poa poa = Poa.builder().dur(assetConfiguration.getPowerOutageAlarmDuration()).build();

		ConfData confData = ConfData.builder().comm(comm).highAlarm(highAlarm).highWarn(highWarn).lba(lba).locale(locale).lowAlarm(lowAlarm).lowWarn(lowWarn).notf(notf)
				.poa(poa).sensors(sensors).build();
		return AssetConfigurationPullModel.builder().data(confData).build();
	}

	private AssetConfiguration createAssetConfigurationFromPushModel(
			AssetConfigurationPushModel assetConfigurationPushModel, AssetConfiguration existingAssetConfiguration, Integer countryId, Integer languageId) {
		return  AssetConfiguration.builder().id(existingAssetConfiguration.getId())
				.temperaturePushUrl(assetConfigurationPushModel.getData().getComm().getTmpUrl())
				.configurationPullUrl(assetConfigurationPushModel.getData().getComm().getCfgUrl())
				.alarmPushUrl(assetConfigurationPushModel.getData().getComm().getAlrmUrl())
				.statsPushUrl(assetConfigurationPushModel.getData().getComm().getStatsUrl())
				.deviceReadyStatusPushUrl(assetConfigurationPushModel.getData().getComm().getDevRyUrl())
				.smsGatewayPhoneNumber(assetConfigurationPushModel.getData().getComm().getSmsGyPh())
				.smsGatewayKeyword(assetConfigurationPushModel.getData().getComm().getSmsGyKey())
				.smsGatewaySenderId(assetConfigurationPushModel.getData().getComm().getSenderId())
				.samplingInterval(assetConfigurationPushModel.getData().getComm().getSamplingInt())
				.pushInterval(assetConfigurationPushModel.getData().getComm().getPushInt())
				.phoneNumbersToSendSmsNotification(StringUtils.collectionToCommaDelimitedString(assetConfigurationPushModel.getData().getComm().getUsrPhones()))
				.temperaturePushNotification(assetConfigurationPushModel.getData().getComm().getTmpNotify())
				.temperatureIncursionExcursionPushNotification(assetConfigurationPushModel.getData().getComm().getIncExcNotify())
				.deviceAlarmPushNotification(assetConfigurationPushModel.getData().getComm().getDevAlrmsNotify())
				.statsPushNotification(assetConfigurationPushModel.getData().getComm().getStatsNotify())
				.temperatureAlarmPushNotifications(assetConfigurationPushModel.getData().getComm().getTmpAlrmsNotify())
				.powerOutageAlarmDuration(assetConfigurationPushModel.getData().getPoa().getDur())
				.lowBatteryAlarmThresholdLimit(assetConfigurationPushModel.getData().getLba().getLmt())
				.highAlarmTemperature(assetConfigurationPushModel.getData().getHighAlarm().getTemp())
				.highAlarmTemperatureDuration(assetConfigurationPushModel.getData().getHighAlarm().getDur())
				.lowAlarmTemperature(assetConfigurationPushModel.getData().getLowAlarm().getTemp())
				.lowAlarmTemperatureDuration (assetConfigurationPushModel.getData().getLowAlarm().getDur())
				.highWarningTemperature(assetConfigurationPushModel.getData().getHighWarn().getTemp())
				.highWarningTemperatureDuration(assetConfigurationPushModel.getData().getHighWarn().getDur())
				.lowWarningTemperature(assetConfigurationPushModel.getData().getLowWarn().getTemp())
				.lowWarningTemperatureDuration(assetConfigurationPushModel.getData().getLowWarn().getDur())
				.alarmFrequencyNotificationDuration(assetConfigurationPushModel.getData().getNotf().getDur())
				.alarmFrequencyNotificationNumber(assetConfigurationPushModel.getData().getNotf().getNum())
				.wifiSsid(assetConfigurationPushModel.getData().getComm().getWifi() != null ? assetConfigurationPushModel.getData().getComm().getWifi().getSsid() : null)
				.wifiPassword(assetConfigurationPushModel.getData().getComm().getWifi() != null ? assetConfigurationPushModel.getData().getComm().getWifi().getPwd() : null)
				.wifiSecurity(assetConfigurationPushModel.getData().getComm().getWifi() != null ? assetConfigurationPushModel.getData().getComm().getWifi().getSecurity() : null)
				.sensorId(existingAssetConfiguration.getSensorId())
				.assetId (existingAssetConfiguration.getAssetId())
				.communicationChannelId(assetConfigurationPushModel.getData().getComm().getChnl())
				.countryId(countryId)
				.languageId(languageId).build();
	}
	@ApiOperation("Use this api for fetching AssetConfiguration record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			AssetConfiguration assetConfiguration = assetConfigurationService.getById(id);
			if (assetConfiguration != null) {
				log.info(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setMessage(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setData(assetConfiguration);
			} else {
				log.info(NO_RECORD_FOUND);
				responseBean.setMessage(NO_RECORD_FOUND);
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage(EXECPTION_OCCURED);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for deleting AssetConfiguration record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = assetConfigurationService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error(EXECPTION_OCCURED);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage(EXECPTION_OCCURED);
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all AssetConfiguration records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<AssetConfiguration> assetConfigurationRecords = assetConfigurationService.getAll();
			if (!assetConfigurationRecords.isEmpty()) {
				log.error(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setMessage(RECORDS_FETCHED_SUCCESSFULLY);
				responseBean.setData(assetConfigurationRecords);
			} else {
				log.error(NO_RECORDS_FOUND);
				responseBean.setMessage(NO_RECORDS_FOUND);
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error(EXCEPTION_OCCURED, e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
	
}