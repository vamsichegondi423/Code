package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.MasterAssetVendor;
import com.dipl.evin2.service.CacheEvictor;
import com.dipl.evin2.service.MasterAssetVendorService;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/master-asset-vendor")
public class MasterAssetVendorController {

	@Autowired
	private MasterAssetVendorService masterAssetVendorService;

	@Autowired
	private CacheEvictor cacheEvictor;

	@ApiOperation("Use this api for saving or updating MasterAssetVendor. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	public ResponseBean save(@RequestBody MasterAssetVendor masterAssetVendor, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			if (masterAssetVendor.getId() != null && masterAssetVendor.getId() > 0) {
				MasterAssetVendor existingMasterAssetVendor = masterAssetVendorService.getById(masterAssetVendor.getId());
				if (existingMasterAssetVendor != null) {
					masterAssetVendor = masterAssetVendorService.save(masterAssetVendor);
					log.info("Record updated successfully");
					responseBean.setMessage("Record updated successfully");
					responseBean.setData(masterAssetVendor);
				} else {
					log.info("No record found");
					responseBean.setMessage("No record found");
				}
			} else {
				masterAssetVendor = masterAssetVendorService.save(masterAssetVendor);
				log.info("Record saved successfully");
				responseBean.setMessage("Record saved successfully");
				responseBean.setData(masterAssetVendor);
			}
			cacheEvictor.evictAllCacheValues("master-asset-vendor");
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for saving or updating MasterAssetVendor. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/save-or-update-list")
	@Transactional(rollbackFor = Exception.class)
	public ResponseBean saveList(@RequestBody VendorJackson vendorJacksons, BindingResult result) {
		List<MasterAssetVendor> assetVendorList = new ArrayList<>();
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message(result.getAllErrors().get(0).getDefaultMessage()).status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		}
		try {
			assetVendorList = masterAssetVendorService.saveList(vendorJacksons);
			cacheEvictor.evictAllCacheValues("master-asset-vendor");
			cacheEvictor.evictAllCacheValues("master-asset-type");
			log.info("Record saved successfully");
			responseBean.setMessage("Record saved successfully");
			responseBean.setData(assetVendorList);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching MasterAssetVendor record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			MasterAssetVendor masterAssetVendor = masterAssetVendorService.getById(id);
			if (masterAssetVendor != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterAssetVendor);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}




	@ApiOperation("Use this api for deleting MasterAssetVendor record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = masterAssetVendorService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all MasterAssetVendor records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll() {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<MasterAssetVendor> masterAssetVendorRecords = masterAssetVendorService.getAll();
			if (!masterAssetVendorRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterAssetVendorRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all MasterAssetVendor records. No params required.")
	@GetMapping(value = "/v1/getbyassettype", produces = "application/json")
	public ResponseBean getByAssetType(@RequestParam("assettypeid") Long assetTypeid, @RequestParam(value = "isactive", required = false) Optional<Boolean> isActive) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<MasterAssetVendor> masterAssetVendorRecords = new ArrayList<>();
			if(isActive.isPresent()) {
				masterAssetVendorRecords = masterAssetVendorService.getActiveVendorsByAssetType(assetTypeid, isActive.get());
			}else {
				masterAssetVendorRecords= masterAssetVendorService.getByAssetType(assetTypeid);
			}

			if (!masterAssetVendorRecords.isEmpty()) {
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(masterAssetVendorRecords);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}


	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class VendorJackson {
		
		private String defaultMonitoringPoint;
		private Long assetTypeId;
		private List<AssetVendor> vendorList;
		private Long updatedBy;
		
		@Data
		@AllArgsConstructor
		@NoArgsConstructor
		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class AssetVendor{
			private Long id;
			private Boolean isActive;
		}
	}
}