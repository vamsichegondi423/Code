package com.dipl.evin2.mongo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.model.OrderHistory;
import com.dipl.evin2.mongo.services.OrderHistoryService;
import com.dipl.evin2.util.ResponseBean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/api")
public class OrderHistoryController {
//
//	@Autowired
//	private final Logger logger = LoggerFactory.getLogger(OrderHistoryController.class);

	@Autowired
	private OrderHistoryService OrderHistoryService;

	@KafkaListener(topics = "ORDER-TOPIC", groupId = "group_id")
	public OrderHistory save(String orderhistory) throws Exception {
		ObjectMapper obj = new ObjectMapper();
		OrderHistory oh = null;
		try {
			oh = obj.readValue(orderhistory, OrderHistory.class);
			OrderHistoryService.save(oh);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new Exception("Exception Occured While saving order topic data into order history document..");
		}
		return oh;
	}

	@RequestMapping(value = "/getAll", method = RequestMethod.GET)
	public Object get() {
		return OrderHistoryService.getAll();
	}

	@GetMapping(value = "/get/{order_id}")
	public Object get(@PathVariable(value = "order_id") String orderId) {
		ResponseBean responseBean = new ResponseBean();
		List<OrderHistory> orderHistList = null;
		try {
			orderHistList = OrderHistoryService.get(orderId);
		} catch (Exception e) {
			responseBean.setData(null);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		if(!orderHistList.isEmpty() && orderHistList != null ) {
			responseBean.setData(orderHistList);
			responseBean.setMessage("record fetched successfully");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}else {
			responseBean.setData(null);
			responseBean.setMessage("no record found");
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		}
		return responseBean;
	}

	@RequestMapping(value = "/getduration/{order_id}", method = RequestMethod.GET)
	public String getDuration(@PathVariable(value = "order_id") String orderId) {
		return OrderHistoryService.getDuration(orderId);
	}

	@GetMapping(value = "/getsatus/{status}")
	public List<OrderHistory> gettime(@PathVariable String status) {
		// logger.debug("Getting all data.");
		return OrderHistoryService.findByStatus(status);
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public OrderHistory update(@RequestBody OrderHistory orderhistory) {
		OrderHistoryService.update(orderhistory);
		return orderhistory;
	}

}
