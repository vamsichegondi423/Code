package com.dipl.evin2.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dipl.evin2.entity.TxnLog;

@Repository
public interface TxnLogRepository extends JpaRepository<TxnLog, Long> {

	@Query(value = "select * from txn_log where is_activity_read = false or is_activity_read is null order by txn_date asc limit 1000", nativeQuery = true)
	public List<TxnLog> getTxnLogsForscheduler();

}
