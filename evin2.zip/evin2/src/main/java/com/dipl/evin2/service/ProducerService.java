package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.dipl.evin2.controller.ProducerController.ProducerDTO;
import com.dipl.evin2.controller.ProducerController.ProducerFilterDTO;
import com.dipl.evin2.entity.Producer;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.ProducerRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProducerService {

	@Autowired
	private ProducerRepository producerRepository;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public Producer getById(Integer id) throws CustomException {
		try {
			Optional<Producer> producerOptional = producerRepository.getById(id);
			if (producerOptional.isPresent()) {
				return producerOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public Producer save(Producer producer) throws CustomException {
		try {
			if (producer.getId() != null && producer.getId() > 0) {
				Optional<Producer> existingProducerRecord = producerRepository.getById(producer.getId());
				if (existingProducerRecord.isPresent()) {
					return producerRepository.save(producer);
				}
			} else {
//				producer.setCode(producer.getReferenceId());
				producer = producerRepository.save(producer);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return producer;
	}

	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<Producer> existingProducerRecord = producerRepository.getById(id);
			if (existingProducerRecord.isPresent()) {
				producerRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<Producer> getAll(Pageable pageable) {
		try {
			return producerRepository.findAllProducers(pageable);
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public List<ProducerFilterDTO> findAllProducersByFillter(String producerName,String producerBadge, Pageable pageable) throws CustomException {
		List<ProducerFilterDTO> result = null;
		StringBuilder builder = new StringBuilder();
		builder.append("select p.id as producerId,p.name as producerName ,p.city,concat(p.city,', ',d.name,', ',st.name,', ',c.name) as location,"
				+ " p.updated_on as lastupdated,p.code as referenceId,b.name as badgeName " + 
				" from producer p " +
				 " left join producer_badge pb on pb.producer_id = p.id " + 
				" left join badge b on b.id = pb.badge_id" + 
				" left join master_district d on d.id=p.district_id " + 
				" left join master_state st on st.id=p.state_id " + 
				" left join master_country c on c.id=p.country_id ");
		if(producerName != null && !producerName.isEmpty()) {
			builder.append("where p.name like '%" + producerName + "%'");
		}
		if(producerBadge != null && !producerBadge.isEmpty()) {
			builder.append(" and b.name like '%" + producerBadge + "%'");
		}
		builder.append(" LIMIT " + pageable.getPageSize()
		+ " OFFSET " + pageable.getOffset()) ;
		try {
			result  = jdbcTemplate.query(builder.toString(), new BeanPropertyRowMapper<ProducerFilterDTO>(ProducerFilterDTO.class));
		} catch (Exception e) {
			log.error("Exception occured while find producers: ", e.getCause());
		}
		
		return result;
	}

	public Long findCountOfProducer(String producerName , String producerBadge) {
		Long count = null;
		StringBuilder builder = new StringBuilder();
		builder.append(
				"select count (*) from ( select p.id as producerId,p.name as producerName ,p.city,concat(p.city,', ',d.name,', ',st.name,', ',c.name) as location,"
	+ " p.updated_on as lastupdated,p.code as referenceId,b.name as badgeName " + " from producer p "
	+ " left join producer_badge pb on pb.producer_id = p.id "
	+ " left join badge b on b.id = pb.badge_id"
	+ " left join master_district d on d.id=p.district_id "
	+ " left join master_state st on st.id=p.state_id "
	+ " left join master_country c on c.id=p.country_id ");
		if(producerName != null && !producerName.isEmpty()) {
			builder.append("where p.name like '%" + producerName + "%'");
		}
		if(producerBadge != null && !producerBadge.isEmpty()) {
			builder.append(" and  b.name like '%" + producerBadge + "%'");
		}
		builder.append(" )a");
		try {
			count  = jdbcTemplate.queryForObject(builder.toString(),Long.class);
		} catch (Exception e) {
			log.error("Exception occured while find producers : ", e.getCause());
		}
		
		return count;
	}

	public List<ProducerDTO> findProducersByPid(Integer producerId) throws CustomException {
		List<ProducerDTO> result = null;
		StringBuilder builder = new StringBuilder();
		builder.append(
				" select p.name as producerName ,p.city,concat(p.city,', ',d.name,', ',st.name,', ',c.name) as location,  " + 
				"				 p.updated_on as lastupdated,p.code as referenceId,concat(u.f_name ,' ' ,u.l_name) as updatedBy, " + 
				"				 p.mobile as PhoneNumber,p.alternate_contact_no as alternatePhoneNumber,p.email as Email , c.name as countryName, " + 
				"				 st.name as stateName,d.name as districtName, bc.name as blockName,p.pin as pinCode, p.address as streetAddress, " + 
				"				 p.latitude as latitude , p.logitude as longitude,p.created_on as createdOn,concat(u1.f_name ,' ' ,u1.l_name) as createdBy, " + 
				"				 p.contact_name as contactName,p.description as description, " + 
				"				 string_agg(b.name, ', ') as badgeName " + 
				"				 from producer p   " + 
				"				 join producer_badge pb on pb.producer_id = p.id  " + 
				"				 left join badge b on b.id = pb.badge_id  " + 
				"				 left join users u on u.id = p.updated_by  " + 
				"				 left join users u1 on u1.id = p.created_by " + 
				"				 left join master_district d on d.id=p.district_id   " + 
				"				 left join master_state st on st.id=p.state_id   " + 
				"				 left join master_country c on c.id=p.country_id " + 
				"				 left join master_block bc on bc.id = p.block_id " + 
				"				 where p.id = "+ producerId +" "
						+ "group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21 ");
		try {
			result  = jdbcTemplate.query(builder.toString(), new BeanPropertyRowMapper<ProducerDTO>(ProducerDTO.class));
		} catch (Exception e) {
			log.error("Exception occured while find producers: ", e.getCause());
		}
		
		return result;
	}
}