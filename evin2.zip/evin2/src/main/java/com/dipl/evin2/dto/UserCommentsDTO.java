package com.dipl.evin2.dto;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

public interface UserCommentsDTO {
	@Value(("#{target.created_on}"))
	Date getCreatedOnDate();
	@Value(("#{target.comments}"))
	String getUserComments();
	@Value(("#{target.user_id}"))
	String getUserId();
}

