package com.dipl.evin2.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.BookingItemBatch;

@Repository
public interface BookingItemBatchRepository extends JpaRepository<BookingItemBatch, Long> {

	@Query(value = "select * from booking_item_batch where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<BookingItemBatch> getById(Long id);

	@Query(value = "select * from booking_item_batch where is_deleted = false", nativeQuery = true)
	public List<BookingItemBatch> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from booking_item_batch where id = ?1", nativeQuery = true)
	public void deleteById(Long id);

	@Modifying
	@Transactional
	@Query(value = "update booking_item_batch set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from booking_item_batch where booking_item_id = ?1 and quantity > 0 and is_deleted = false", nativeQuery = true)
	public List<BookingItemBatch> getProductsByBookingItemId(Long bookingItemId);

	@Query(value = " select bk.booking_id,bk.product_id,p.name as product_name, bk.batch_no,bk.batch_mf_date,bk.batch_expiry_date,bk.quantity, \n"
			+ "	bk.items_count, cr.shipped_stock,cr.fulfilled_stock,pr.id as producer_id,pr.\"name\" as producer_name\n"
			+ "	from 			  \n"
			+ "	(select bi.booking_id,bi.id as booking_item_id,bi.product_id,bi.store_id,bib.batch_no,bib.batch_expiry_date, bib.batch_mf_date, \n"
			+ "	bib.quantity as quantity,b.items_count ,bib.producer_id\n"
			+ "	from bookings b\n"
			+ "	join booking_items bi on b.id=bi.booking_id and b.is_deleted=false and bi.is_deleted=false  \n"
			+ "	join booking_item_batch bib  on bi.id=bib.booking_item_id and bib.is_deleted=false)bk \n"
			+ "	left join (select c.booking_id,ci.product_id,c.store_id,cib.batch_no,cib.batch_expiry_date,  \n"
			+ "	cib.cargo_stock as shipped_stock,cib.fulfilled_stock \n"
			+ "	from cargo c join cargo_item ci on c.id=ci.cargo_id and c.is_deleted=false   \n"
			+ "	join cargo_item_batch cib on ci.id=cib.cargo_item_id and ci.is_deleted=false and cib.is_deleted=false) cr \n"
			+ "	on  bk.booking_id=cr.booking_id and bk.product_id=cr.product_id  \n"
			+ "	and bk.store_id=cr.store_id and bk.batch_no=cr.batch_no and bk.batch_expiry_date=cr.batch_expiry_date \n"
			+ "	left join product p on p.id=bk.product_id \n"
			+ "	 join producer pr on pr.id=bk.producer_id "
			+ "	where bk.booking_id=?1  and bk.booking_item_id in (?2) ", nativeQuery = true)
	public List<Map<String, Object>> getBatchMaterial(Long orderId, List<Long> bookingItemIds);

	@Query(value = "   select bk.batch_no,bk.batch_expiry_date,cr.shipped_stock,bk.quantity,pr.id as manufacture_id, pr.name as manufacturer,bk.batch_mf_date from  \n"
			+ "			   (select bi.booking_id,bi.id as booking_item_id,bi.product_id,bi.store_id,bib.batch_no,bib.batch_expiry_date,bib.batch_mf_date, \n"
			+ "			   bib.quantity as quantity ,bib.producer_id as producer_id\n"
			+ "			   from bookings b join booking_items bi on b.id=bi.booking_id and b.is_deleted=false and bi.is_deleted=false  \n"
			+ "			   join booking_item_batch bib  on bi.id=bib.booking_item_id and bib.is_deleted=false)bk  \n"
			+ "			   left join (select c.booking_id,ci.product_id,c.store_id,cib.batch_no,cib.batch_expiry_date,  \n"
			+ "			   cib.cargo_stock as shipped_stock,cib.producer_id  as producer_id \n"
			+ "			   from cargo c \n"
			+ "			   join cargo_item ci on c.id=ci.cargo_id and c.is_deleted=false   \n"
			+ "			   join cargo_item_batch cib on ci.id=cib.cargo_item_id and ci.is_deleted=false and cib.is_deleted=false) cr  \n"
			+ "			   on  bk.booking_id=cr.booking_id and bk.product_id=cr.product_id  \n"
			+ "			   and bk.store_id=cr.store_id and bk.batch_no=cr.batch_no and bk.batch_expiry_date=cr.batch_expiry_date  \n"
			+ "			   left join icatalogue i on bk.store_id=i.store_id and bk.product_id=i.product_id   \n"
			+ "			   left join icatalogue_batch ib on i.id=ib.icatalogue_id and ib.batch_no=bk.batch_no and ib.is_deleted=false \n"
			+ "			   join producer pr on ib.producer_id=pr.id and  bk.producer_id=pr.id  and  cr.producer_id=pr.id where bk.booking_item_id =?1", nativeQuery = true)
	public List<Map<String, Object>> getBatchMaterialByBookingItemId(Long bookingItemId);

	@Query(value = "select * from booking_item_batch where booking_item_id=?1 and is_deleted = false ", nativeQuery = true)
	public List<BookingItemBatch> findBookingItemBatchByBkId(Long id);

	@Query(value = "select sum(quantity) from booking_item_batch where booking_item_id=?1 and is_deleted = false ", nativeQuery = true)
	public Long sumOffulfilQuantity(Long id);

	@Query(value = "select * from booking_item_batch where booking_item_id=?1 and batch_no =?2 and producer_id =?3 and  is_deleted = false ", nativeQuery = true)
	public BookingItemBatch findBookingItemBatchByBkIdAndBatchNo(Long bookingItemId, String batchId,Integer producerId);

}