package com.dipl.evin2.util;

import java.math.BigInteger;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReportConsumption {

	private Long id;
	private Long storeId;
	private Long receivingStoreId;
	private Long productId;
	private Integer consumptionTypeId;
	private Integer consumedCount;
	private String consumptionDate;
	private Integer consumptionMonth;
	private Integer consumptionYear;
	private Boolean isActive;

}
