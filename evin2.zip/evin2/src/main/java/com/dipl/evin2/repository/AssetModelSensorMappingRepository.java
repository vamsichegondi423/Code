package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import com.dipl.evin2.entity.AssetModelSensorMapping;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface AssetModelSensorMappingRepository extends JpaRepository<AssetModelSensorMapping, Long> {

	@Query(value = "select * from asset_model_sensor_mapping where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<AssetModelSensorMapping> getById(Long id);

	@Query(value = "select * from asset_model_sensor_mapping where is_deleted = false", nativeQuery = true)
	public List<AssetModelSensorMapping> findAll();

	@Modifying
	@Transactional
	@Query(value = "delete from asset_model_sensor_mapping where id = ?1", nativeQuery = true)
	public void deleteById(Long id);
	
	@Modifying
	@Transactional
	@Query(value = "update asset_model_sensor_mapping set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Long id);

	@Query(value = "select * from asset_model_sensor_mapping where asset_model_id = ?1 and is_deleted = false", nativeQuery = true)
	public List<AssetModelSensorMapping> getByAssetModel(Long assetModelId);

	
}