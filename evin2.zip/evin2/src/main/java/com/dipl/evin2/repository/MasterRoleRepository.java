package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.MasterRole;

@Repository
public interface MasterRoleRepository extends JpaRepository<MasterRole, Integer> {

	@Query(value = "select * from master_role where id = ?1 and is_deleted = false", nativeQuery = true)
	public Optional<MasterRole> getById(Integer id);

	@Query(value = "select * from master_role where is_deleted = false", nativeQuery = true)
	public List<MasterRole> findAll();
	
	@Query(value = "select * from master_role where \"name\" = ? and is_deleted = false", nativeQuery = true)
	public MasterRole getMasterRole(String name);

	@Modifying
	@Transactional
	@Query(value = "delete from master_role where id = ?1", nativeQuery = true)
	public void deleteById(Integer id);

	@Modifying
	@Transactional
	@Query(value = "update master_role set is_deleted = true where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);
	
	@Query(value = "select * from master_role where module_name = ?1 and is_deleted = false", nativeQuery = true)
	public List<MasterRole> findByModuleName(String moduleName);

}