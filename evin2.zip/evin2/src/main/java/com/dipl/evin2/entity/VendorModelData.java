package com.dipl.evin2.entity;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class VendorModelData implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long assetTypeId;
	private List<ModelData> modelDataList;
	private VendorData vendorData;

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ModelData {
		private Long vendorId;
		private Boolean vendorIsActive;
		private Long assetModelId;
		private Boolean assetModelIsActive;
		private Character defaultSensor;
	}
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class VendorData {
		
		private String defaultMonitoringPoint;
		private List<Vendor> vendorList;
		
		@Data
		@AllArgsConstructor
		@NoArgsConstructor
		@Builder
		@JsonIgnoreProperties(ignoreUnknown = true)
		public static class Vendor{
			private Long vendorId;
			private Boolean vendorIsActive;
		}
	}
}
