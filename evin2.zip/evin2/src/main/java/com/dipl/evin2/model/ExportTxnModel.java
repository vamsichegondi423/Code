package com.dipl.evin2.model;

import java.util.Date;
import java.util.List;

import com.dipl.evin2.controller.StoreController;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExportTxnModel {

	
	private Long storeId;
	private Long productId;
	private Long pranthId;
	private String txnType;
	private String txnReason;
	private Date txnsFromDate;
	private Date txnsToDate;
	private Boolean isActualTxn;
	private List<Integer> storeBadge;
	private List<Integer> productBadge;
	private Integer state;
	private Integer district;
	private Integer country;
	private Integer block;
}