package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.MasterCountry;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.MasterCountryRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterCountryService {

	@Autowired
	private MasterCountryRepository masterCountryRepository;

	@Cacheable(value = "country", key = "#id")
	public MasterCountry getById(Integer id) {
		Optional<MasterCountry> masterCountryOptional = masterCountryRepository.getById(id);
		if (masterCountryOptional.isPresent()) {
			return masterCountryOptional.get();
		} else {
			return null;
		}
	}

	@CachePut(value = "country", key = "#masterCountry.id")
	public MasterCountry save(MasterCountry masterCountry) throws CustomException {
		try {
			if (masterCountry.getId() != null && masterCountry.getId() > 0) {
				Optional<MasterCountry> existingMasterCountryRecord = masterCountryRepository
						.getById(masterCountry.getId());
				if (existingMasterCountryRecord.isPresent()) {
					masterCountry = masterCountryRepository.save(masterCountry);
				}
			} else {
				masterCountry = masterCountryRepository.save(masterCountry);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterCountry;
	}

	@CacheEvict(value = "country", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterCountry> existingMasterCountryRecord = masterCountryRepository.getById(id);
			if (existingMasterCountryRecord.isPresent()) {
				masterCountryRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "country")
	public List<MasterCountry> getAll() {
		try {
			return masterCountryRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}

	public MasterCountry getByCode(String code) {
		try {
			Optional<MasterCountry> masterCountryOptional = masterCountryRepository.getByCode(code);
			if (masterCountryOptional.isPresent()) {
				return masterCountryOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}
}