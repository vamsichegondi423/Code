package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.entity.MasterParentModule;
import com.dipl.evin2.repository.MasterParentModuleRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterParentModuleService {

	@Autowired
	private MasterParentModuleRepository masterParentModuleRepository;

	@Cacheable(value = "parent-module", key = "#id")
	public MasterParentModule getById(Integer id) throws CustomException {
		try {
			Optional<MasterParentModule> masterParentModuleOptional = masterParentModuleRepository.getById(id);
			if (masterParentModuleOptional.isPresent()) {
				return masterParentModuleOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "parent-module", key = "#masterParentModule.id")
	public MasterParentModule save(MasterParentModule masterParentModule) throws CustomException {
		try {
			if (masterParentModule.getId() != null && masterParentModule.getId() > 0) {
				Optional<MasterParentModule> existingMasterParentModuleRecord = masterParentModuleRepository
						.getById(masterParentModule.getId());
				if (existingMasterParentModuleRecord.isPresent()) {
					return masterParentModuleRepository.save(masterParentModule);
				}
			} else {
				masterParentModule = masterParentModuleRepository.save(masterParentModule);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterParentModule;
	}

	@CacheEvict(value = "parent-module", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterParentModule> existingMasterParentModuleRecord = masterParentModuleRepository.getById(id);
			if (existingMasterParentModuleRecord.isPresent()) {
				masterParentModuleRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "parent-module")
	public List<MasterParentModule> getAll() {
		try {
			return masterParentModuleRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}