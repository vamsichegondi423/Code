package com.dipl.evin2.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dipl.evin2.entity.ClosingStockLog;
@Repository
public interface ClosingStockLogRepository extends JpaRepository<ClosingStockLog, Long>{
	@Query(value = "Select * from closing_stock_log where created_on =?1 and product_id=?2 and store_id = ?3 ", nativeQuery = true)
	public ClosingStockLog getClosingStockDetails(Date date, Long productId, Long storeId);

}
