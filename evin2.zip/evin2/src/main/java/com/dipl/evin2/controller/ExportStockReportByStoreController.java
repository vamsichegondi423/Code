package com.dipl.evin2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.model.ExportStockReportByOneStoreModel;
import com.dipl.evin2.service.ExportStockReportByStoreService;
import com.dipl.evin2.util.ResponseBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/icatalogue")
public class ExportStockReportByStoreController {

	@Autowired
	private ExportStockReportByStoreService exportStockReportByStoreService;	

	@PostMapping(value = "/v1/export-stock-report-by-store",consumes = "application/json",produces = "application/json" )
	public ResponseBean getStockReport(@RequestBody ExportStockReportByOneStoreModel exportStockReportByOneStoreModel) {

		ResponseBean responseBean = new ResponseBean();

		try {
			return exportStockReportByStoreService.getStockReportByStoreService(exportStockReportByOneStoreModel);
		} catch (Exception e) {
			log.error("Exception occured while exporting stock report by store", e.getCause());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occured while exporting stock report by store " + e.getMessage());
			e.printStackTrace();
		}
		return responseBean;
	}
	
	@PostMapping(value = "/v1/export-stock-report-by-store-with-batch",consumes = "application/json",produces = "application/json")
	public ResponseBean getStockReportWithBatch(@RequestBody ExportStockReportByOneStoreModel exportStockReportByOneStoreModel) {

		ResponseBean responseBean = new ResponseBean();

		try {
			return exportStockReportByStoreService.getStockReportByStoreServiceWithBatch(exportStockReportByOneStoreModel);
		} catch (Exception e) {
			log.error("Exception occured while exporting stock report by store", e.getCause());
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occured while exporting stock report by store " + e.getMessage());
			e.printStackTrace();

		}
		return responseBean;
	}

}