package com.dipl.evin2.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dipl.evin2.entity.AssetDefaultConfiguration;
import com.dipl.evin2.entity.SensorDefaultConfiguration;
import com.dipl.evin2.service.AssetDefaultConfigurationService;
import com.dipl.evin2.service.SensorDefaultConfigurationService;
import com.dipl.evin2.util.ResponseBean;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/api/asset-default-configuration")
public class AssetDefaultConfigurationController {

	@Autowired
	private AssetDefaultConfigurationService assetDefaultConfigurationService;

	@Autowired
	private SensorDefaultConfigurationService sensorDefaultConfigurationService;

	@ApiOperation("Use this api for saving or updating AssetDefaultConfiguration. Provide id value in for update. Provide id value as null for save.")
	@PostMapping(value = "/v1/saveorupdate")
	@Transactional(rollbackFor = Exception.class)
	public ResponseBean save(@RequestBody AssetDefaultConfiguration assetDefaultConfiguration,@RequestParam("pranthId") Long pranthId, BindingResult result) {
		ResponseBean responseBean = new ResponseBean();
		try {
			if (result.hasErrors()) {
				log.error("Invalid Payload");
				return ResponseBean.builder().data(null).message("Invalid Payload").status(HttpStatus.BAD_REQUEST)
						.returnCode(0).build();
			}
		} catch (Exception e) {
			log.error("Exception occured", e);
			return ResponseBean.builder().data(null).message(e.getMessage()).status(HttpStatus.INTERNAL_SERVER_ERROR)
					.returnCode(0).build();
		} 
		try {

			if(assetDefaultConfiguration != null) {
				List<AssetDefaultConfiguration> existingAssetDefaultConfigurations = assetDefaultConfigurationService.getAll(pranthId);
				if(!existingAssetDefaultConfigurations.isEmpty()) {
					assetDefaultConfiguration.setId(existingAssetDefaultConfigurations.iterator().next().getId());
				}
				List<SensorDefaultConfiguration> sensorDefaultConfigurations = new ArrayList<>();
				if(assetDefaultConfiguration.getSensorDefaultConfigurationList() != null && !assetDefaultConfiguration.getSensorDefaultConfigurationList().isEmpty()) {
					for(SensorDefaultConfiguration defaultConfiguration : assetDefaultConfiguration.getSensorDefaultConfigurationList()) {
						SensorDefaultConfiguration existingAssetDefaultConfiguration = sensorDefaultConfigurationService.getBySensorId(defaultConfiguration.getSensorId());
						if(existingAssetDefaultConfiguration !=null) {
							defaultConfiguration.setId(existingAssetDefaultConfiguration.getId());
							defaultConfiguration.setCreatedBy(existingAssetDefaultConfiguration.getCreatedBy());
							defaultConfiguration.setCreatedOn(existingAssetDefaultConfiguration.getCreatedOn());
						}else {
							defaultConfiguration.setCreatedBy(assetDefaultConfiguration.getUpdatedBy());
							defaultConfiguration.setCreatedOn(new Date());
						}
						defaultConfiguration.setPranthId(pranthId);
						defaultConfiguration.setUpdatedBy(assetDefaultConfiguration.getUpdatedBy());
						defaultConfiguration.setUpdatedOn(new Date());
						sensorDefaultConfigurations.add(defaultConfiguration);
					}
				}
				assetDefaultConfiguration.setPranthId(pranthId);
				sensorDefaultConfigurationService.saveAll(sensorDefaultConfigurations);
				assetDefaultConfigurationService.save(assetDefaultConfiguration);
			}

			log.info("Record saved successfully");
			responseBean.setMessage("Record saved successfully");
			responseBean.setData(null);
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);

		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching AssetDefaultConfiguration record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getbyid/{id}", produces = "application/json")
	public ResponseBean getById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			AssetDefaultConfiguration assetDefaultConfiguration = assetDefaultConfigurationService.getById(id);
			if (assetDefaultConfiguration != null) {
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(assetDefaultConfiguration);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}


	@ApiOperation("Use this api for fetching AssetDefaultConfiguration record by id. Provide id as path param.")
	@GetMapping(value = "/v1/getOne", produces = "application/json")
	public ResponseBean getOne(@RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<AssetDefaultConfiguration> assetDefaultConfigurations = assetDefaultConfigurationService.getAll(pranthId);
			AssetDefaultConfiguration assetDefaultConfiguration = null;
			if(!assetDefaultConfigurations.isEmpty()) {
				assetDefaultConfiguration = assetDefaultConfigurations.iterator().next();
			}
			if (assetDefaultConfiguration != null) {
				List<SensorDefaultConfiguration> sensorDefaultConfigurations = sensorDefaultConfigurationService.getAll(pranthId);
				assetDefaultConfiguration.setSensorDefaultConfigurationList(sensorDefaultConfigurations);
				log.info("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(assetDefaultConfiguration);
			} else {
				log.info("No record found");
				responseBean.setMessage("No record found");
			}
			responseBean.setReturnCode(1);
			responseBean.setStatus(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setData(null);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}


	@ApiOperation("Use this api for deleting AssetDefaultConfiguration record by id. Provide id as path param.")
	@DeleteMapping(value = "/v1/deletebyid/{id}", produces = "application/json")
	public ResponseBean deleteById(@PathVariable(value = "id") Long id) {
		ResponseBean responseBean = new ResponseBean();
		try {
			Integer result = assetDefaultConfigurationService.deleteById(id);
			if (result == 1) {
				log.info("Records deleted");
				responseBean.setMessage("Records deleted");
			} else {
				log.info("Records with given id does not exist");
				responseBean.setMessage("Records with given id does not exist");
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Execption Occured");
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption Occured");
		}
		return responseBean;
	}

	@ApiOperation("Use this api for fetching all AssetDefaultConfiguration records. No params required.")
	@GetMapping(value = "/v1/getall", produces = "application/json")
	public ResponseBean getAll(@RequestParam("pranthId") Long pranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			List<AssetDefaultConfiguration> assetDefaultConfigurations = assetDefaultConfigurationService.getAll(pranthId);
			if (!assetDefaultConfigurations.isEmpty()) {
				assetDefaultConfigurations.forEach(assetDefaultConfiguration -> {
					List<SensorDefaultConfiguration> sensorDefaultConfigurations = sensorDefaultConfigurationService.getAll(pranthId);
					assetDefaultConfiguration.setSensorDefaultConfigurationList(sensorDefaultConfigurations);
				});
				log.error("Records fetched successfully");
				responseBean.setMessage("Records fetched successfully");
				responseBean.setData(assetDefaultConfigurations);
			} else {
				log.error("No records found");
				responseBean.setMessage("No records found");
				responseBean.setData(new ArrayList<>());
			}
			responseBean.setStatus(HttpStatus.OK);
			responseBean.setReturnCode(1);
		} catch (Exception e) {
			log.error("Exception occured", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Execption occured");
		}
		return responseBean;
	}
	
	@ApiOperation("Use this api for updating AssestDefault Config to child pranth.")
	@GetMapping(value = "/v1/update-assest-default-config-to-child/{userId}", produces = "application/json")
	public ResponseBean updateParentAssetDefaultConfigToChild(@PathVariable(value = "userId") Long userId,@RequestParam(value = "pranthId",required = false) Long pranthId , @RequestParam(value = "mappedPranthId") Long mappedPranthId) {
		ResponseBean responseBean = new ResponseBean();
		try {
			responseBean = assetDefaultConfigurationService.updateParentAssestDefaultConfigToChild(pranthId, mappedPranthId, userId);
		} catch (Exception e) {
			log.error("Exception occurred", e);
			responseBean.setReturnCode(0);
			responseBean.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			responseBean.setMessage("Exception occurred");
		}
		return responseBean;
	}
}