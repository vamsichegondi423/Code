package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.entity.MasterConfigType;
import com.dipl.evin2.repository.MasterConfigTypeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterConfigTypeService {

	@Autowired
	private MasterConfigTypeRepository masterConfigTypeRepository;

	@Cacheable(value = "config-type", key = "#id")
	public MasterConfigType getById(Integer id) throws CustomException {
		try {
			Optional<MasterConfigType> masterConfigTypeOptional = masterConfigTypeRepository.getById(id);
			if (masterConfigTypeOptional.isPresent()) {
				return masterConfigTypeOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@CachePut(value = "config-type", key = "#masterConfigType.id")
	public MasterConfigType save(MasterConfigType masterConfigType) throws CustomException {
		try {
			if (masterConfigType.getId() != null && masterConfigType.getId() > 0) {
				Optional<MasterConfigType> existingMasterConfigTypeRecord = masterConfigTypeRepository
						.getById(masterConfigType.getId());
				if (existingMasterConfigTypeRecord.isPresent()) {
					return masterConfigTypeRepository.save(masterConfigType);
				}
			} else {
				masterConfigType = masterConfigTypeRepository.save(masterConfigType);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return masterConfigType;
	}

	@CacheEvict(value = "config-type", allEntries = true)
	public Integer deleteById(Integer id) throws CustomException {
		try {
			Optional<MasterConfigType> existingMasterConfigTypeRecord = masterConfigTypeRepository.getById(id);
			if (existingMasterConfigTypeRecord.isPresent()) {
				masterConfigTypeRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	@Cacheable(value = "config-type")
	public List<MasterConfigType> getAll() {
		try {
			return masterConfigTypeRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}