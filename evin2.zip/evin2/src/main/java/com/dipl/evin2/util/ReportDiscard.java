package com.dipl.evin2.util;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ReportDiscard {
	    private long storeId;
	    private long productId;
	    private Boolean isActive;
	    private int discardCount;
	    private Integer discardReasonId;
	    private String discardDate;
	    private int discardMonth;
	    private int discardYear;

}
