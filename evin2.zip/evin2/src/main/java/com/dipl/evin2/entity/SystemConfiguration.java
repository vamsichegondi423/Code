package com.dipl.evin2.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "system_configuration")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder 
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SystemConfiguration extends BaseEntity{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	@NotNull(message = "config_type_id cannot be null or empty")
	@Column(name = "config_type_id")
	private Integer configTypeId;
	@NotNull(message = "config_json cannot be null or empty")
    @Column(name = "config_json", columnDefinition = "json")
	@Type(type = "com.dipl.evin2.util.JsonNodeUserType")
    private JsonNode configJson;
    @Column(name = "version_no")
    private Integer versionNo;
	@Column(name = "pranth_id")
	private Long pranthId;
}
