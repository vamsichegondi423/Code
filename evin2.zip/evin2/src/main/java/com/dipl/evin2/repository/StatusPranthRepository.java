package com.dipl.evin2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dipl.evin2.entity.ReasonPranth;
import com.dipl.evin2.entity.StatusPranth;

@Repository
public interface StatusPranthRepository extends JpaRepository<StatusPranth, Integer> {

	@Query(value = "select * from status_pranth where id = ?1 and is_active = true", nativeQuery = true)
	public Optional<StatusPranth> getById(Integer id);

	@Query(value = "select * from status_pranth where pranth_id = ?1 and is_active = true", nativeQuery = true)
	public List<StatusPranth> findAll(Long pranthId);

	@Query(value = "select * from status_pranth where status_id = ?1 and pranth_id = ?2 and is_active = false", nativeQuery = true)
	public List<StatusPranth> getStatusById(Integer statusId, Long pranthId);
	
	@Modifying
	@Transactional
	@Query(value = "update status_pranth set is_active = false where id = ?1", nativeQuery = true)
	public void deleteByIdSoft(Integer id);


	public StatusPranth findByPranthIdAndStatusIdAndIsActiveTrue(Long pranthId, Integer id);

	public StatusPranth getByStatusId(Integer id);

	public List<StatusPranth> findByPranthId(Long pranthid);

	public StatusPranth findByPranthIdAndStatusId(Long mappedPranthId, Integer statusId);

	@Query(value = "select rp.* from status_pranth rp join master_status mr on mr.id = rp.status_id where  rp.pranth_id = ?1 and mr.status_type =?2  and mr.is_deleted = false", nativeQuery = true)
	public List<StatusPranth> findAllByPranthId(Long pranthId, String statusType);


}