package com.dipl.evin2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dipl.evin2.entity.BookingItems;
import com.dipl.evin2.exceptions.CustomException;
import com.dipl.evin2.repository.BookingItemsRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BookingItemsService {

	@Autowired
	private BookingItemsRepository bookingItemsRepository;

	public BookingItems getById(Long id) throws CustomException {
		try {
			Optional<BookingItems> bookingItemsOptional = bookingItemsRepository.getById(id);
			if (bookingItemsOptional.isPresent()) {
				return bookingItemsOptional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public BookingItems save(BookingItems bookingItems) throws CustomException {
		try {
			if (bookingItems.getId() != null && bookingItems.getId() > 0) {
				Optional<BookingItems> existingBookingItemsRecord = bookingItemsRepository.getById(bookingItems.getId());
				if (existingBookingItemsRecord.isPresent()) {
					return bookingItemsRepository.save(bookingItems);
				}
			} else {
				bookingItems = bookingItemsRepository.save(bookingItems);
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return bookingItems;
	}

	public Integer deleteById(Long id) throws CustomException {
		try {
			Optional<BookingItems> existingBookingItemsRecord = bookingItemsRepository.getById(id);
			if (existingBookingItemsRecord.isPresent()) {
				bookingItemsRepository.deleteByIdSoft(id);
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return null;
	}

	public List<BookingItems> getAll() {
		try {
			return bookingItemsRepository.findAll();
		} catch (Exception e) {
			log.error("Exception occured : ", e);
		}
		return new ArrayList<>();
	}
}